const cron = require("node-cron");
const models = require("../db");
const logger = require("../logger");
const Moment = require("moment");
const { generateHtml }  = require("../utils/helper");
const { genericSender }  = require("../services/email/emailProvider");
const { ACTIONS, CONSTANTS }  = require("../utils/constants");

//CRON_TIMER="0 0 * * *"
const { CRON_TIMER } = process.env;

const attachmentsExpiryCron = () =>
  cron.schedule(CRON_TIMER, async () => {
    try {
      logger.log(`info`, `Cron is now completed`);

      // Next 30 Day Logic:
      const currentDate = new Date();
      const numberOfDaysToAdd = 30;

      // Check if any of the contractors are getting expired for the next 30 days from current date
      const next30Day = new Date(currentDate.getTime());
      next30Day.setDate(currentDate.getDate() + numberOfDaysToAdd); // Add 30 days to the current date

      const next30DayStart = Moment(next30Day).startOf('day'); // Start of the day
      const next30DayEnd = Moment(next30Day).endOf('day'); // End of the day

      const next30DayStartFormatted = next30DayStart?.format("YYYY-MM-DD HH:mm:ss");
      const next30DayEndFormatted = next30DayEnd?.format("YYYY-MM-DD HH:mm:ss");
      let nextDayEmailsListToBeDispatched = [];

      const fetchAttachmentsWithExpiriesForNextDay = `
      SELECT cae.*, u.email as user_email, u.full_name, c.email as contractor_email, cat.label as contractor_attachment_type
      FROM contractor_attachments_expiries AS cae
      LEFT JOIN users AS u ON u.id = cae.user_id
      LEFT JOIN contractors AS c ON c.id = cae.contractor_id
      LEFT JOIN contractor_attachment_types AS cat ON cat.id = cae.attachment_id
      WHERE cae.deleted_at IS NULL 
      AND cae.expiry_date >= '${next30DayStartFormatted}'
      AND cae.expiry_date <= '${next30DayEndFormatted}'
      `;

      const fetchNextDayAttachmentsWithExpiries = await models.sequelize.query(
        fetchAttachmentsWithExpiriesForNextDay
      );

      const fetchedNextDayAttachmentsWithExpiries =
        fetchNextDayAttachmentsWithExpiries[0];

      for (const service of fetchedNextDayAttachmentsWithExpiries) {
        const fetchListToDispatchEmails = `
        SELECT u.*, c.address as contractor_address, c.name as contractor_name, c.email as contractor_email
        FROM users as u
        LEFT JOIN contractors c on c.id = u.contractor_id
        WHERE contractor_id = ${service?.contractor_id}
        AND contractor_address_id IS NULL;
        `;

        const fetchedListToDispatchEmails = await models.sequelize.query(
          fetchListToDispatchEmails
        );

        let usersToEmail = [];
        let contractor_id = null;
        let contractor_name = null;
        let contractor_email = null;
        let contractor_address = null;

        for (const emailsObject of fetchedListToDispatchEmails[0]) {
          contractor_id = emailsObject?.contractor_id;
          contractor_name = emailsObject?.contractor_name;
          contractor_email = emailsObject?.contractor_email;
          contractor_address = emailsObject?.contractor_address;
          usersToEmail.push(emailsObject?.email);
        }

        const contractorDataObject = {
          contractor_name: contractor_name,
          contractor_address: contractor_address,
          contractor_email: contractor_email,
          contractor_id: contractor_id,
          user_to_email: usersToEmail,
          contractor_attachment_type: service?.contractor_attachment_type //Which doc is expiring
        };

        nextDayEmailsListToBeDispatched?.push(contractorDataObject);
      }

      // Dispatch Generic Email
      for (const emailData of nextDayEmailsListToBeDispatched) {
        /* Send Email to specific Contractor for letting them
        know that their workers compensation certificate of insurance 
        has been expired and needs to be updated */
        let contractorInfo = {
          name: emailData?.contractor_name,
          email: emailData?.contractor_email,
          contractor_attachment_type: emailData?.contractor_attachment_type
        };

        const dataForEmail = {
          sendEmailTo: "jayp@websoptimization.com",
          sendEmailFrom: "abhishekp@websoptimization.com",
          ...generateHtml(
            {
              contractor: contractorInfo,
            },
            ACTIONS.ABOUT_TO_EXPIRE_EMAIL
          ),
          ccRecipients: process.env?.PES_CC_RECIPIENTS //Add group of PES folks as a CC
        };

        genericSender(dataForEmail);
      }

      // Current Day Logic:
      const start = Moment(new Date()).format("YYYY-MM-DD 00:00:00");
      const end = Moment(new Date()).format("YYYY-MM-DD 23:59:59");
      const fetchAttachmentsWithExpiries = `
      SELECT cae.*, u.email as user_email, u.full_name, c.email as contractor_email 
      FROM contractor_attachments_expiries AS cae
      LEFT JOIN users AS u ON u.id = cae.user_id
      LEFT JOIN contractors AS c ON c.id = cae.contractor_id
      WHERE cae.deleted_at IS NULL 
      AND cae.expiry_date >= '${start}'
      AND cae.expiry_date <= '${end}'
      `;

      const fetchedAttachmentsWithExpiries = await models.sequelize.query(
        fetchAttachmentsWithExpiries
      );

      const attachmentWithExpiriesList = fetchedAttachmentsWithExpiries[0];

      /* Case 1: With respect to contractor worker compensation certificate of insurance */
      let specificEmailsToDispatchList = [];
      let updateSubContractorTierFlag = "";
      let updateHeadContractorTierFlag = "";

      let specificService = attachmentWithExpiriesList?.filter(
        (attachment) => attachment?.attachment_id === 2
      );

      let specificIdsToDisable = specificService?.map(
        (attachment) => attachment?.id
      );
      specificIdsToDisable = [...new Set(specificIdsToDisable)];

      if (specificIdsToDisable?.length > 0) {
        // Specific Attachment Disbaled
        const disableSpecificAttachment = `
        UPDATE contractor_attachments_expiries
        SET disabled = '1'
        WHERE id IN (${specificIdsToDisable});`;

        await models.sequelize.query(disableSpecificAttachment);
      }

      // Disable Specific Contractors
      for (const service of specificService) {
        // Sub Contractor Disbaled
        // if (service?.contractor_address_id) {
        //   updateSubContractorTierFlag = `
        //   UPDATE addresses
        //   SET tier_level = 'Do Not Use'
        //   WHERE
        //   id=${service?.contractor_address_id}
        //   `;
        //   await models.sequelize.query(updateSubContractorTierFlag);
        // } else {
        //   // Head and Sub Contractor Disbaled
        //   updateHeadContractorTierFlag = `
        //   UPDATE contractors
        //   SET tier_level = 'Do Not Use'
        //   WHERE
        //   id=${service?.contractor_id};`;

        //   updateSubContractorTierFlag = `
        //   UPDATE addresses
        //   SET tier_level = 'Do Not Use'
        //   WHERE
        //   entity_id=${service?.contractor_id};`;

        //   await models.sequelize.query(updateHeadContractorTierFlag);

        //   await models.sequelize.query(updateSubContractorTierFlag);
        // }

        const fetchListToDispatchEmails = `
        SELECT u.*, c.address as contractor_address, c.name as contractor_name, c.email as contractor_email
        FROM users as u
        LEFT JOIN contractors c on c.id = u.contractor_id
        WHERE contractor_id = ${service?.contractor_id}
        AND contractor_address_id IS NULL;
        `;

        const fetchedListToDispatchEmails = await models.sequelize.query(
          fetchListToDispatchEmails
        );

        let usersToEmail = [fetchedListToDispatchEmails[0][0].contractor_email];
        let contractor_id = null;
        let contractor_name = null;
        let contractor_email = null;
        let contractor_address = null;

        for (const emailsObject of fetchedListToDispatchEmails[0]) {
          contractor_id = emailsObject?.contractor_id;
          contractor_name = emailsObject?.contractor_name;
          contractor_email = emailsObject?.contractor_email;
          contractor_address = emailsObject?.contractor_address;
          usersToEmail.push(emailsObject?.email);
        }

        const contractorDataObject = {
          contractor_name: contractor_name,
          contractor_address: contractor_address,
          contractor_id: contractor_id,
          user_to_email: usersToEmail,
        };

        specificEmailsToDispatchList?.push(contractorDataObject);
      }

      // Dispatch Specific Email
      for (const emailData of specificEmailsToDispatchList) {
        /* Send Email to specific Contractor for letting them
        know that their workers compensation certificate of insurance 
        has been expired and needs to be updated */
        let contractorInfo = {
          name: emailData?.contractor_name,
          email: emailData?.contractor_email,
        };

        const dataForEmail = {
          sendEmailTo: emailData?.user_to_email,
          sendEmailFrom: CONSTANTS.DEFAULT_EMAIL,
          ...generateHtml(
            {
              contractor: contractorInfo,
            },
            ACTIONS.WORKERS_COMP_CERTIFICATION_EXPIRY
          ),
        };

        // genericSender(dataForEmail);
      }

      /* Case 2: With respect to all other services except contractor 
      worker compensation certificate of insurance */
      const otherServices = attachmentWithExpiriesList?.filter(
        (attachment) => attachment?.attachment_id !== 2
      );
      let idsToDisable = otherServices.map((attachment) => attachment?.id);
      idsToDisable = [...new Set(idsToDisable)];

      if (idsToDisable?.length > 0) {
        // All Attachments Disbaled
        const disableAttachments = `
        UPDATE contractor_attachments_expiries
        SET disabled = '1'
        WHERE id IN (${idsToDisable});`;

        await models.sequelize.query(disableAttachments);
      }
      const attachmentName = [
        'Contractor Liability Certificate of Insurance',
        'Contractor Workers Comp Certificate of Insurance',
        'Contractor W-9',
        'Haz Waste Haulers License',
        'Rate Sheet'
      ]
      let genericEmailsToDispatchList = [];

      for (const service of otherServices) {
        const fetchListToDispatchEmails = `
        SELECT u.*, c.address as contractor_address, c.name as contractor_name, c.email as contractor_email
        FROM users as u
        LEFT JOIN contractors c on c.id = u.contractor_id
        WHERE contractor_id = ${service?.contractor_id}
        AND contractor_address_id IS NULL;
        `;

        const fetchedListToDispatchEmails = await models.sequelize.query(
          fetchListToDispatchEmails
        );

        let usersToEmail = [fetchedListToDispatchEmails[0][0].contractor_email];
        let contractor_id = null;
        let contractor_name = null;
        let contractor_email = null;
        let contractor_address = null;

        for (const emailsObject of fetchedListToDispatchEmails[0]) {
          contractor_id = emailsObject?.contractor_id;
          contractor_name = emailsObject?.contractor_name;
          contractor_email = emailsObject?.contractor_email;
          contractor_address = emailsObject?.contractor_address;
          usersToEmail.push(emailsObject?.email);
        }

        const attachmentIndex = service?.attachment_id - 1; // since array index starts from 0 and attachment_id starts from 1

        const contractorDataObject = {
          contractor_name: contractor_name,
          contractor_address: contractor_address,
          contractor_id: contractor_id,
          user_to_email: usersToEmail,
          attachment_name: attachmentName[attachmentIndex]
        };

        genericEmailsToDispatchList?.push(contractorDataObject);
      }

      // Dispatch Generic Email
      for (const emailData of genericEmailsToDispatchList) {
        /* Send Email to specific Contractor for letting them
        know that their workers compensation certificate of insurance 
        has been expired and needs to be updated */
        let contractorInfo = {
          name: emailData?.contractor_name,
          email: emailData?.contractor_email,
          attachmentName : emailData?.attachment_name
        };

        const dataForEmail = {
          sendEmailTo: emailData?.user_to_email,
          sendEmailFrom: CONSTANTS.DEFAULT_EMAIL,
          ...generateHtml(
            {
              contractor: contractorInfo,
            },
            ACTIONS.HAS_BEEN_EXPIRED_EMAIL
          ),
        };

        // genericSender(dataForEmail);
      }
    } catch (error) {
      logger.log("error", error);
    }
  });


  module.exports = {
    attachmentsExpiryCron
  }
