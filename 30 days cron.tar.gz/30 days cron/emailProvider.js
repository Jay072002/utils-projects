const Email = require("email-templates");
import nodemailer from "nodemailer";
const { calculateRecievingInfo } = require("../../utils/preProcessors");

const { URL_FOR_EMAIL } = process.env;

const options = {
  pool: true,
  host: process.env.AWS_SMTP_SERVER,
  port: 465,
  secure: true,
  auth: {
    user: process.env.AWS_SMTP_USERNAME,
    pass: process.env.AWS_SMTP_PASSWORD,
  },
};

const transporter = nodemailer.createTransport(options);

transporter.verify((error, success) => {
  if (error) {
    console.log("error with email connection");
    console.log("Error ::", error);
  } else if (success) {
    console.log("SMTP server connected successfully");
  }
});

const getEmailAddressConfig = async (senderAddress) => {
  return {
    from: senderAddress,
  };
};

const genericSender = async ({
  sendEmailTo,
  sendEmailFrom,
  header,
  subject,
  body,
  link,
  changes,
  emailType,
  attachments,
  ccRecipients, // Pass nothing if you dont want to incude recipients in CC
}) => {
  const email = new Email({
    views: { root: __dirname },
    preview: false,
    message: await getEmailAddressConfig(sendEmailFrom),
    send: true,
    transport: transporter,
  });

  const messageOptions = {
    template: emailType || "genericView",
    message: {
      ...calculateRecievingInfo(sendEmailTo, subject),
      attachments,
    },
    locals: {
      productName: "PES-Spills",
      header,
      body,
      changes: changes,
      origin: URL_FOR_EMAIL,
      currentYear: new Date().getFullYear()
    },
  };

  // Handle case for ccRecipients
  if (ccRecipients && ccRecipients?.length > 0) {
    messageOptions.message.cc = ccRecipients;
  }

  sendEmailTo &&
    email
      .send(messageOptions)
      .then(() => {
        console.log(
          "Email sent to : ",
          sendEmailTo,
          "    ( ",
          new Date().toLocaleString(),
          " )"
        );
      })
      .catch((error) => {
        if (error.responseCode === 552) {
          genericSender({
            sendEmailTo,
            sendEmailFrom,
            header,
            subject,
            body:
              body +
              "<br/> ** Attachment size limit exceeded. Should be seen from portal.",
            changes,
            emailType,
            attachments: [],
            ccRecipients
          });
        } else {
          console.error(error);
        }
      });
};

module.exports = {
  genericSender,
  getEmailAddressConfig,
};

