const _ = require("lodash");
const { ACTIONS } = require("./constants");

const generateHtml = (info, type) => {
  let bodyToReturn = "";
  let wholeEmailData = null;

  switch (type) {
    case ACTIONS.WORKERS_COMP_CERTIFICATION_EXPIRY:
      bodyToReturn = `
      The <b>Workers Comp Certificate<b/> has expired for contractor: <b>${info?.contractor?.name}<b/>.
      We need an updated certificate showing coverage before PES can dispatch them on incidents.`;

      wholeEmailData = {
        header: `Workers Comp Certificate Expiry Notification`,
        subject: `Expiry for ${info?.contractor?.name} ${
          info?.contractor?.email ? `: ${info?.contractor?.email}` : ""
        }`,
      };

      break;

    case ACTIONS.ABOUT_TO_EXPIRE_EMAIL:
      bodyToReturn = `
      The attachment types for the contractor <b>${info?.contractor?.name}</b> will expire after 30 days.
      This may result in the attachment type being disabled for the specific contractor, and they will
      need to update their expiry date in order to upload these attachments.<br>
      The following document is scheduled to expire after 30 days:
      <b>${info?.contractor?.contractor_attachment_type}</b>
      `;

      wholeEmailData = {
        header: `Attachments to be expired after 30 days`,
        subject: `Attachments about to expire for ${info?.contractor?.name} ${
          info?.contractor?.email ? `: ${info?.contractor?.email}` : ""
        }`,
      };

      break;

    case ACTIONS.HAS_BEEN_EXPIRED_EMAIL:
      bodyToReturn = `
      The <b>${info?.contractor?.attachmentName}<b/> has expired for contractor: <b>${info?.contractor?.name}<b/>.
      We need an updated expiry in order to allow them to upload their attachments.
      `;

      wholeEmailData = {
        header: `${info?.contractor?.attachmentName} Attachments Expired`,
        subject: `Attachments have been expired for ${info?.contractor?.name} ${
          info?.contractor?.email ? `: ${info?.contractor?.email}` : ""
        }`,
      };

    default:
      null;
  }
  return { ...wholeEmailData, body: bodyToReturn };
};

module.exports = {
  generateHtml
}

