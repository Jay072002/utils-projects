import React, { useEffect, useRef, useState } from "react";

import { useOnClickOutside } from "../../utils/hooks";
import Uploader from "../../utils/upload";
import { FileCard, Popup } from "./components";

import "./styles.css";

const FileUploader = ({ files = [], onFileUploaded }) => {
  const uploadContainerRef = useRef();
  const [isWarningPromptVisible, setIsWarningPromptVisible] = useState(false);
  const [uploader, setUploader] = useState(undefined);
  const [uploadsProgress, setUploadsProgress] = useState([]);
  const [currentFileInProgressIndex, setCurrentFileInProgressIndex] =
    useState(0);
  useOnClickOutside(uploadContainerRef, () => setIsWarningPromptVisible(true));

  // will fire when file is selected

  useEffect(() => {
    if (files.length > 0) {
      const file = files[currentFileInProgressIndex];
      let percentage = undefined;

      const videoUploaderOptions = {
        fileName: file?.name,
        file: file,
      };

      const uploader = new Uploader(videoUploaderOptions);
      setUploader(uploader);

      // listening for progress
      uploader
        .onProgress(({ percentage: newPercentage }) => {
          // to avoid the same percentage to be logged twice
          if (newPercentage !== percentage) {
            percentage = newPercentage;
            setUploadsProgress((currentUploadsProgress) => {
              const currentUploadsProgressCopy = [...currentUploadsProgress];
              currentUploadsProgressCopy[currentFileInProgressIndex] =
                percentage;
              return currentUploadsProgressCopy;
            });
            // checking if file in progress has done uploading
            if (percentage === 100) {
              setCurrentFileInProgressIndex((currentFileInProgressIndex) =>
                // checking if active index doesnt exceed the available files length
                currentFileInProgressIndex < files.length - 1
                  ? currentFileInProgressIndex + 1
                  : currentFileInProgressIndex
              );
            }
          }
        })
        .onError((error) => {
          console.error(error);
        });
      uploader.start();
    }
  }, [files, currentFileInProgressIndex]);

  const getFileSizeInMbs = (file) => (file?.size / 1024 / 1024).toFixed(3);

  const getFileType = (file) => {
    const fileName = file.name || "";
    return (
      fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length) ||
      fileName
    );
  };

  const handleResponse = (value) => {
    // value will be false if user doesnt want to proceed
    value === false && handleUploadCancellation();
    setIsWarningPromptVisible(false);
  };

  const popupProps = {
    onResponse: handleResponse,
    title: "Warning",
    desc: "Performing any action will interupt your uploads. Are you sure you want to proceed ?",
    open: isWarningPromptVisible,
  };

  const handleUploadCancellation = () => {
    uploader.abort();
  };

  return (
    <>
      <Popup {...popupProps} />
      <div className="file-upload-overlay">
        <div className="file-upload-progress-wrapper" ref={uploadContainerRef}>
          <div className="file-upload-progress-header">
            <h3>File Uploads</h3>
          </div>
          <div className="file-cards-wrapper">
            {files.map((file, index) => (
              <FileCard
                key={file.name}
                fileName={file.name || "N/A"}
                fileType={getFileType(file)}
                fileSize={getFileSizeInMbs(file)}
                uploadProgress={uploadsProgress[index] || null} // null will be the value of file that is in queue.
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default FileUploader;
