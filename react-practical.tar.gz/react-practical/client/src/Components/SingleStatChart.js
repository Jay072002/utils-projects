import React from 'react';
import PropTypes from 'prop-types';

import {
  makeStyles,
  Typography,
  Card,
  CardContent,
  Grid,
} from '@material-ui/core';
import { ReactComponent as TrendingUp } from '../assets/svg-icons/trending-up.svg';
import { ReactComponent as TrendingDown } from '../assets/svg-icons/trending-down.svg';
import AnalyticsLoader from './Loader';

const Styles = makeStyles(() => ({
  chartHeading: {
    fontSize: '12px',
    color: '#212121',
    textAlign: 'center',
  },
  chartHeadingFix: {
    fontSize: '12px',
    color: '#212121',
    textAlign: 'center',
    marginTop: '3px',
    marginBottom: '22px',
  },
  contentContainer: {
    display: 'flex',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    width: '100%',
  },
  amoutHeading: {
    fontSize: '35px',
    fontWeight: '600',
    color: '#434343',
  },
  upIcon: {
    fontSize: '2.5rem',
    color: '#619a63',
  },
  downIcon: {
    fontSize: '2.5rem',
    color: 'red',
  },
  hr: {
    height: '1px',
    backgroundColor: '#ccc',
    border: 'none',
  },
  cardsAnalytics: {
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 2%), 0px 8px 10px 1px rgb(0 0 0 / 2%), 0px 3px 14px 2px rgb(0 0 0 / 2%)',
  },
  labelSpan: {
    fontSize: '14px',
  },
}));

const SingleStatChart = ({
  status,
  title,
  amount,
  loading,
  hideLine,
  innerStyles,
  label,
  cssAdjustment,
}) => {
  const classes = Styles();
  return (
    <React.Fragment>
      <Card raised={true} className={classes?.cardsAnalytics}>
        <CardContent>
          <Grid container>
            <Grid item xs={12}>
              <Typography
                className={
                  cssAdjustment === 1
                    ? classes.chartHeadingFix
                    : classes.chartHeading
                }
              >
                {title}
              </Typography>
              {!hideLine && <hr className={classes.hr}></hr>}
            </Grid>
            {loading ? (
              <AnalyticsLoader />
            ) : (
              <Grid item sx={12} className={classes.contentContainer}>
                <Typography className={classes.amoutHeading}>
                  {amount} <span className={classes?.labelSpan}>{label}</span>
                </Typography>
                {status &&
                  (status === 'increasing' ? (
                    <TrendingUp className={classes.upIcon} />
                  ) : (
                    <TrendingDown className={classes.downIcon} />
                  ))}
              </Grid>
            )}
          </Grid>
        </CardContent>
      </Card>
    </React.Fragment>
  );
};

SingleStatChart.prototype = {
  data: PropTypes.object.isRequired,
  title: PropTypes.string.isRequired,
  amount: PropTypes.number.isRequired,
  status: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
  label: PropTypes.string,
};

export default SingleStatChart;
