import React from 'react';
import PropTypes from 'prop-types';

import { makeStyles, Typography, Card, CardContent } from '@material-ui/core';
import { Bar } from '@ant-design/plots';

import AnalyticsLoader from './Loader';

const Styles = makeStyles(() => ({
  hr: {
    margin: '0 16px',
    height: '1px',
    backgroundColor: '#ccc',
    border: 'none',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '14px',
    textAlign: 'left',
  },
  cardsAnalytics: {
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 2%), 0px 8px 10px 1px rgb(0 0 0 / 2%), 0px 3px 14px 2px rgb(0 0 0 / 2%)',
  },
}));

const BarChart = ({
  data,
  xLabel,
  yLabel,
  title,
  loading,
  height,
  plotCount,
}) => {
  const classes = Styles();
  const [refinedData, setRefinedData] = React.useState([]);

  React.useEffect(() => {
    if (data?.length > 0) {
      let maxCount = 0;
      data.forEach((element) => {
        maxCount = maxCount < element?.count ? element?.count : maxCount;
      });
      setRefinedData([
        ...data,
        { count: maxCount > 10 ? maxCount + 50 : maxCount + 3 },
      ]);
    }
  }, [data]);

  const config = {
    data: refinedData,
    yField: xLabel,
    xField: yLabel,
    seriesField: xLabel,
    // yAxis: false,
    barWidthRatio: plotCount && plotCount < 5 ? 0.1 : 0.9,
    height: height ? height : 200,
    label: {
      position: 'right',
      offset: 5,
      style: {
        fill: 'black',
        opacity: 0.6,
        // fontSize: 24,
      },
    },
    yAxis: {
      offset: 5,
      autoEllipsis: true,
      style: {
        fontSize: 24,
      },
    },
    tooltip: false,
    legend: false,
  };

  return (
    <Card raised={true} className={classes.cardsAnalytics}>
      <Typography className={classes.chartHeading}>{title}</Typography>
      <hr className={classes.hr}></hr>
      <CardContent>
        {loading || !(refinedData?.length > 0) ? (
          <AnalyticsLoader />
        ) : (
          <Bar {...config} />
        )}
      </CardContent>
    </Card>
  );
};

BarChart.prototype = {
  data: PropTypes.object.isRequired,
  xLabel: PropTypes.string.isRequired,
  yLabel: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
  height: PropTypes.number,
};

export default BarChart;
