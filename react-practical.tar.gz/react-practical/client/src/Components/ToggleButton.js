import * as React from 'react';

import { ToggleButton } from '@material-ui/lab';
import { ToggleButtonGroup } from '@material-ui/lab';
import { makeStyles } from '@material-ui/core';

const Styles = makeStyles(() => ({
  toggleButtonCustomWrapper: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    '& .MuiToggleButton-root': {
      padding: '10px',
      fontSize: '12px',
    },
    '& .Mui-selected': {
      background: '#397d33',
      color: '#ffffff',
    },
  },
}));
export default function ColorToggleButton({ initialValue, getValue, items }) {
  const [value, setValue] = React.useState(initialValue);
  const classes = Styles();
  const handleChange = (e, next) => {
    if (next) {
      setValue(next);
      getValue(next);
    }
  };

  return (
    <ToggleButtonGroup
      color='primary'
      value={value}
      exclusive
      onChange={handleChange}
      className={classes.toggleButtonCustomWrapper}
    >
      {items?.map((item) => (
        <ToggleButton value={item?.value} key={item?.value}>
          {item?.label}
        </ToggleButton>
      ))}
    </ToggleButtonGroup>
  );
}
