import React from 'react';

import { makeStyles, CircularProgress } from '@material-ui/core';

const useStyles = makeStyles(() => ({
  rootLoader: {
    width: '80px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    height: '100%',
  },
  cardsAnalytics: {
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 2%), 0px 8px 10px 1px rgb(0 0 0 / 2%), 0px 3px 14px 2px rgb(0 0 0 / 2%)',
  },
}));

const AnalyticsLoader = ({}) => {
  const classes = useStyles();

  return (
    <div className={classes.rootLoader}>
      <CircularProgress
        style={{ width: '50px', height: '50px', color: '#2F7D32' }}
      />
    </div>
  );
};

export default AnalyticsLoader;
