import React, { useEffect } from 'react';

import { makeStyles, Typography, Card, CardContent } from '@material-ui/core';

import { Column } from '@ant-design/plots';
import AnalyticsLoader from './Loader';

const Styles = makeStyles(() => ({
  hr: {
    margin: '0 16px',
    height: '1px',
    backgroundColor: '#ccc',
    border: 'none',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
  },
  chartHeadingFix: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
    marginTop: '2px',
    marginBottom: '13px',
  },
  cardsAnalytics: {
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 2%), 0px 8px 10px 1px rgb(0 0 0 / 2%), 0px 3px 14px 2px rgb(0 0 0 / 2%)',
  },
}));

const GroupBarChart = ({
  title,
  data,
  loading,
  xLabel,
  yLabel,
  seriesName,
}) => {
  const classes = Styles();

  useEffect(() => {
    prepareData();
  }, []);

  const prepareData = () => {};

  const config = {
    data,
    isGroup: true,
    xField: xLabel,
    yField: yLabel,
    seriesField: seriesName,
    dodgePadding: 1,
    intervalPadding: 10,
    label: {
      position: 'middle',
      layout: [
        {
          type: 'interval-adjust-position',
        },
        {
          type: 'interval-hide-overlap',
        },
        {
          type: 'adjust-color',
        },
      ],
    },
    legend: {
      layout: 'horizontal',
      position: 'top-right',
    },
  };

  return (
    <Card raised={false} className={classes.cardsAnalytics}>
      <Typography
        className={
          // title ===
          // 'Monthly Difference of Current vs Previous Month (Previous Year)'
          //   ? classes.chartHeadingFix :
          classes.chartHeading
        }
      >
        {title}
      </Typography>
      <CardContent>
        {loading ? <AnalyticsLoader /> : <Column {...config} />}
      </CardContent>
    </Card>
  );
};

// GroupBarChart = {
//   data: PropTypes.object.isRequired,
//   title: PropTypes.string.isRequired,
//   loading: PropTypes.bool.isRequired,
//   xLabel: PropTypes.string.isRequired,
//   yLabel: PropTypes.string.isRequired,
//   seriesName: PropTypes.string.isRequired,
// };

export default GroupBarChart;
