import React from 'react';
import { RingProgress } from '@ant-design/plots';
import { makeStyles, Typography } from '@material-ui/core';
import AnalyticsLoader from './Loader';

const Styles = makeStyles(() => ({
  circleProgressBarWrapper: {
    height: 'auto',
  },
  circleProgressBarOuter: {
    height: '150px',
  },
  titleCircleProgressBar: {
    fontSize: '15px',
    fontWeight: 'bold',
    marginTop: '12px',
  },
  descriptionCircleProgressBar: {
    margin: '12px 0px',
    fontSize: '13px',
  },
}));

const CircularProgressBar = React.memo(
  ({ percent, description, loading, mainColor, title, count }) => {
    const classes = Styles();
    const config = {
      height: '150px',
      width: '150px',
      autoFit: true,
      percent: percent,
      color: [mainColor, '#E8EDF3'],
      statistic: {
        title: {
          style: {
            color: 'black',
            fontSize: '18px',
            lineHeight: '25px',
          },
          formatter: () => `${count}`,
        },
        content: {
          style: { color: mainColor, fontSize: '16px', fontWeight: '700' },
        },
      },
    };
    if (loading) {
      return <AnalyticsLoader />;
    }
    return (
      <div className={classes.circleProgressBarWrapper}>
        <div className={classes.circleProgressBarOuter}>
          <RingProgress {...config} />
        </div>
        <div>
          <Typography className={classes.titleCircleProgressBar}>
            {title}
          </Typography>
        </div>
        <p className={classes.descriptionCircleProgressBar}>
          {description ? description : ''}
        </p>
      </div>
    );
  }
);
export default CircularProgressBar;
