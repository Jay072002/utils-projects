import clsx from 'clsx';
import format from 'date-fns/format';
import isValid from 'date-fns/isValid';
import isSameDay from 'date-fns/isSameDay';
import endOfWeek from 'date-fns/endOfWeek';
import React, { PureComponent } from 'react';
import startOfWeek from 'date-fns/startOfWeek';
import isWithinInterval from 'date-fns/isWithinInterval';
import { DatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';
import { createStyles } from '@material-ui/styles';
import { IconButton, withStyles } from '@material-ui/core';
import moment from 'moment';
import MomentUtils from '@date-io/moment';

class WeekPicker extends PureComponent {
  state = {
    selectedDate: new Date().setMonth(new Date().getMonth()),
    selectedDateEnd: new Date().setMonth(new Date().getMonth()),
  };
  makeJSDateObject = (date) => {
    return new Date(date);
  };

  handleWeekChange = (date) => {
    const currentMonth = this.makeJSDateObject(date).getMonth();
    let value = this.makeJSDateObject(date);
    let firstday = new Date(
      value.setDate(value.getDate() - value.getDay() + 1)
    );
    let firstDayObj = new Date(firstday);
    let lastDay = new Date(firstDayObj.setDate(firstDayObj.getDate() + 7));
    this.setState({
      selectedDate: firstday,
      selectedDateEnd: lastDay,
    });
    this.handleRangeOfWeekInAMonth(firstday, lastDay, currentMonth);
  };

  formatWeekSelectLabel = (date, invalidLabel) => {
    let dateClone = this.makeJSDateObject(date);
    let firstday = new Date(
      dateClone.setDate(dateClone.getDate() - dateClone.getDay() + 1)
    );

    return dateClone && isValid(dateClone)
      ? `Week of ${format(firstday, 'MMM do')}`
      : invalidLabel;
  };
  getDates(startDate, stopDate) {
    let dateArray = [];
    let currentDate = moment(startDate);
    let stopDat = moment(stopDate);
    while (currentDate <= stopDat) {
      dateArray.push(moment(currentDate).toDate());
      currentDate = moment(currentDate).add(1, 'days');
    }
    return dateArray;
  }
  getRangeOfDatesInMonth = (startDate, endDate, currentMonth) => {
    let datesArray = this.getDates(startDate, endDate);
    const filteredDates = datesArray.filter(
      (item) => item.getMonth() === currentMonth
    );
    return {
      newStartDate: filteredDates[0],
      newEndDate: filteredDates[filteredDates.length - 1],
    };
  };

  handleRangeOfWeekInAMonth = (startDate, endDate, currentMonth) => {
    const { newStartDate, newEndDate } = this.getRangeOfDatesInMonth(
      startDate,
      endDate,
      currentMonth
    );
    this.props.getRangeOfDate({
      fromDate: newStartDate,
      endDate: newEndDate,
    });
  };
  renderWrappedWeekDay = (date, selectedDate, dayInCurrentMonth) => {
    const { classes } = this.props;
    let dateClone = this.makeJSDateObject(date);
    let selectedDateClone = this.makeJSDateObject(selectedDate);

    let firstday = new Date(
      selectedDateClone.setDate(
        selectedDateClone.getDate() - selectedDateClone.getDay() + 1
      )
    );

    let firstDayObj = new Date(firstday);
    let lastDay = new Date(firstDayObj.setDate(firstDayObj.getDate() + 7));

    const start = firstday;
    const end = lastDay;

    const dayIsBetween = isWithinInterval(dateClone, { start, end });
    const isFirstDay = isSameDay(dateClone, start);
    const isLastDay = isSameDay(dateClone, end);

    const wrapperClassName = clsx({
      [classes.highlight]: dayIsBetween,
      [classes.firstHighlight]: isFirstDay,
      [classes.endHighlight]: isLastDay,
    });

    const dayClassName = clsx(classes.day, {
      [classes.nonCurrentMonthDay]: !dayInCurrentMonth,
      [classes.highlightNonCurrentMonthDay]: !dayInCurrentMonth && dayIsBetween,
    });

    return (
      <div className={wrapperClassName}>
        <IconButton className={dayClassName}>
          <span> {format(dateClone, 'd')} </span>
        </IconButton>
      </div>
    );
  };

  render() {
    const { selectedDate } = this.state;

    return (
      <MuiPickersUtilsProvider utils={MomentUtils}>
        <DatePicker
          label={'Week Picker'}
          value={selectedDate}
          onChange={this.handleWeekChange}
          renderDay={this.renderWrappedWeekDay}
          labelFunc={this.formatWeekSelectLabel}
          variant='inline'
          disableToolbar
          disableFuture
        />
      </MuiPickersUtilsProvider>
    );
  }
}

const styles = createStyles((theme) => ({
  dayWrapper: {
    position: 'relative',
  },
  day: {
    width: 36,
    height: 36,
    fontSize: theme.typography.caption.fontSize,
    margin: '0 2px',
    color: 'inherit',
  },
  customDayHighlight: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: '2px',
    right: '2px',
    border: `1px solid ${theme.palette.secondary.main}`,
    borderRadius: '50%',
  },
  nonCurrentMonthDay: {
    color: theme.palette.text.disabled,
  },
  highlightNonCurrentMonthDay: {
    color: '#676767',
  },
  highlight: {
    background: theme.palette.primary.main,
    color: theme.palette.common.white,
  },
  firstHighlight: {
    extend: 'highlight',
    borderTopLeftRadius: '50%',
    borderBottomLeftRadius: '50%',
  },
  endHighlight: {
    extend: 'highlight',
    borderTopRightRadius: '50%',
    borderBottomRightRadius: '50%',
  },
}));

export default withStyles(styles)(WeekPicker);
