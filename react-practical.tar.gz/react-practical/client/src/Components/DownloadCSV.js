import React from "react";
import moment from "moment";
import { CSVLink } from "react-csv";
import { Button } from "@material-ui/core";

const DownloadCSV = ({ headers, data, type }) => {
  let csvData = [];

  const headerTitles = headers.map((item) => {
    return item.title;
  });

  csvData.push(headerTitles);

  csvData.push(...data);

  return (
    <CSVLink
      style={{
        textDecoration: "none",
        color: "green",
      }}
      data={csvData}
      filename={`searched-${type}-${moment(new Date()).format(
        "DD-MM-YYYY h:mm:ss"
      )}.csv`}
    >
      <Button
        style={{ fontSize: "16px", padding: "5px 5px 0px 5px" }}
        color="primary"
      >
        Download
      </Button>
    </CSVLink>
  );
};

export default DownloadCSV;
