export { default as DetailLvl1 } from "./DetailLvl1";
export { default as DetailLvl2 } from "./DetailLvl2";
export { default as TabDetail } from "./TabDetail";
