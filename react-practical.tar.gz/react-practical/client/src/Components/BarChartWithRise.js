import React from 'react';
import PropTypes from 'prop-types';

import { makeStyles, Typography, Card, CardContent } from '@material-ui/core';
import { DualAxes } from '@ant-design/plots';
import AnalyticsLoader from './Loader';

const Styles = makeStyles(() => ({
  hr: {
    margin: '0 16px',
    height: '1px',
    backgroundColor: '#ccc',
    border: 'none',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
  },
  chartHeadingFix: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
    marginTop: '2px',
    marginBottom: '13px',
  },
  cardsAnalytics: {
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 2%), 0px 8px 10px 1px rgb(0 0 0 / 2%), 0px 3px 14px 2px rgb(0 0 0 / 2%)',
  },
}));

const BarChartWithRise = React.memo(
  ({
    title,
    data,
    loading,
    initialData,
    xLabel,
    yLabel,
    minValue,
    isYAxisPercentage,
    children,
    height,
    csWeeklySpills,
  }) => {
    const classes = Styles();

    const [chartData, setChartData] = React.useState(initialData);
    React.useEffect(() => {
      if (data?.length > 0) {
        setChartData(data);
      }
    }, [data]);
    const config = {
      data: [chartData, chartData],
      xField: xLabel,
      height: height ? height : 400,
      yField: [yLabel, yLabel],
      yAxis: {
        [yLabel]: {
          min: minValue,
          label: {
            formatter: (cou) => `${cou} ${isYAxisPercentage ? '%' : ''}`,
          },
        },
        count: false,
      },
      labels: {},
      tooltip: {
        showNil: true,
        showMarkers: false,
        showContent: false,
        animate: false,
        follow: false,
      },
      legend: false,
      geometryOptions: [
        {
          geometry: 'column',
          columnWidthRatio: 0.7,
          label: {
            position: 'middle',
          },
          color: '#16AAE6',
        },
        {
          geometry: 'line',
          smooth: true,
          color: '#5AD8A6',
          point: {
            size: 5,
            shape: 'circle',
            style: {
              fill: '#ffff',
              stroke: '#1AAF8B',
              lineWidth: 2,
            },
          },
        },
      ],
    };
    return (
      <Card raised={false} className={classes.cardsAnalytics}>
        <>
          {csWeeklySpills === true ? (
            <>{!loading && <Typography variant='h7'>{title}</Typography>}</>
          ) : (
            <Typography
              className={
                title ===
                'Monthly Difference of Current vs Previous Month (Previous Year)'
                  ? classes.chartHeadingFix
                  : classes.chartHeading
              }
            >
              {title}
            </Typography>
          )}
        </>
        <CardContent>
          {loading ? <AnalyticsLoader /> : <DualAxes {...config} />}
          {children}
        </CardContent>
      </Card>
    );
  }
);

BarChartWithRise.propTypes = {
  data: PropTypes.object.isRequired,
  title: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
  initialData: PropTypes.object.isRequired,
  xLabel: PropTypes.string.isRequired,
  yLabel: PropTypes.string.isRequired,
  isYAxisPercentage: PropTypes.bool.isRequired,
  minValue: PropTypes.string.isRequired,
  height: PropTypes.number,
};

export default BarChartWithRise;
