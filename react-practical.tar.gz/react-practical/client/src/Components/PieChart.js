import React from 'react';
import PropTypes from 'prop-types';

import { makeStyles, Typography, Card, CardContent } from '@material-ui/core';
import { Pie } from '@ant-design/plots';

import AnalyticsLoader from './Loader';

const Styles = makeStyles(() => ({
  hr: {
    margin: '0 16px',
    height: '1px',
    backgroundColor: '#ccc',
    border: 'none',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '14px',
    textAlign: 'left',
  },
}));

const PieChart = React.memo(
  ({ title, data, value, type, loading, withoutCard, legendPosition }) => {
    const classes = Styles();
    const config = {
      appendPadding: 10,
      data,
      angleField: value,
      colorField: type,
      radius: 0.9,
      label: {
        type: 'inner',
        offset: '-30%',
        content: ({ percent }) => `${(percent * 100).toFixed(0)}%`,
        style: {
          fontSize: 14,
          textAlign: 'center',
        },
      },
      interactions: [
        {
          type: 'element-active',
        },
      ],
      legend: {
        // layout: 'horizontal',
        position: legendPosition ? legendPosition : `right`,
      },
    };

    const getValue = () => {
      return !withoutCard ? (
        <Card raised={true}>
          <Typography className={classes.chartHeading}>{title}</Typography>
          <hr className={classes.hr}></hr>
          <CardContent>
            {loading ? <AnalyticsLoader /> : <Pie {...config} height={200} />}
          </CardContent>
        </Card>
      ) : (
        <>{loading ? <AnalyticsLoader /> : <Pie {...config} height={200} />}</>
      );
    };
    return getValue();
  }
);

PieChart.prototype = {
  data: PropTypes.object.isRequired,
  value: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
  withoutCard: PropTypes.bool.isRequired,
  title: PropTypes.string.isRequired,
};

export default PieChart;
