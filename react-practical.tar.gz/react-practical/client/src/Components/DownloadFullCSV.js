import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { withRouter } from "react-router-dom";
import { Button, makeStyles } from "@material-ui/core";

import { csvDownloader } from "../utils/csvDownloader";
import * as downloadActions from "../actionCreators/Download";
import { getSearchResultTableHeaders, ROLES, USER_TYPE } from "../utils";
import { CustomProgressLoader } from ".";

const useStyles = makeStyles(() => ({
  root: {
    fontSize: 16,
  },
}));
const DownloadFullCSV = ({
  type,
  loading,
  subType,
  showSpinner,
  currentUser,
  downloadType,
  downloadData,
  dataForSearch,
  searchFilters,
  clearDownload,
  searchQueryData,
  dataForDownload,
  simpleExportData,
  isSubrogationActive,
  isPendingDisposalActive
}) => {
  const classes = useStyles();
  const [disable, setDisable] = React.useState(false);
  const [downloadSubType, setDownloadSubType] = React.useState("");

  const timeZoneOffSet = Intl.DateTimeFormat().resolvedOptions().timeZone;

  React.useEffect(() => {
    setDisable(loading);
    showSpinner && showSpinner(loading);
  }, [loading]);

  React.useEffect(() => {
    if (dataForDownload?.data?.length > 0) {
      let mergedData = [];
      switch (type) {
        case "User": {
          const tableHeaders = [
            { title: "Name", key: "full_name" },
            { title: "E-Mail", key: "email" },
            { title: "Phone", key: "phone" },
            { title: "Role", key: "roleName" },
            { title: "Active", key: "active" },
          ];
          ["Contractor Admin"]?.includes(currentUser?.data?.role?.role) ||
            tableHeaders.splice(2, 0, {
              title: "Organization",
              key: "organizationName",
            }); //remove organization incase of ['contractor admin']

          const headerTitles = tableHeaders.map((item) => {
            return item.title;
          });

          const allData = dataForDownload.data.map((item) => {
            const tableItems = [
              item?.full_name,
              item?.email,
              item?.phone,
              item?.role?.role,
              item?.active,
            ];
            ["Contractor Admin"]?.includes(currentUser?.data?.role?.role) ||
              tableItems.splice(2, 0, item?.client_organization?.name); //remove organization incase of ['contractor admin']
            return tableItems;
          });

          mergedData = [headerTitles, ...allData];

          break;
        }
        case "Contractor": {
          const tableHeaders = [
            { title: "Contractor Name", key: "name" },
            { title: "E-Mail", key: "email" },
            { title: "Address", key: "address" },
            { title: "Phone", key: "phone" },
            { title: "Fax", key: "fax" },
            { title: "Zip Code", key: "zipCode" },
            { title: "City", key: "city" },
            { title: "State", key: "state" },
            { title: "Country", key: "country" },
          ];

          const headerTitles = tableHeaders.map((item) => {
            return item.title;
          });

          const allData = dataForDownload.data.map((item) => {
            const tableItems = [
              item?.name,
              item?.email,
              item?.address?.replace(/,/g, " "),
              item?.phone,
              item?.fax,
              item?.zipCode,
              item?.city,
              item?.state,
              item?.country,
            ];
            return tableItems;
          });

          mergedData = [headerTitles, ...allData];

          break;
        }
        case "Agency": {
          const tableHeaders = [
            { title: "Agency Name", key: "name" },
            { title: "Contact", key: "contact" },
            { title: "Jurisdiction", key: "jurisdiction" },
            { title: "Phone", key: "phone" },
            { title: "Fax", key: "fax" },
            { title: "Address", key: "address" },
            { title: "City", key: "city" },
            { title: "State", key: "state" },
            { title: "Country", key: "country" },
          ];

          const headerTitles = tableHeaders.map((item) => {
            return item.title;
          });

          const allData = dataForDownload.data.map((item) => {
            const tableItems = [
              item?.name,
              item?.contact,
              item?.jurisdiction,
              item?.phone,
              item?.fax,
              item?.address?.replace(/,/g, " "),
              item?.city,
              item?.state,
              item?.country,
            ];
            return tableItems;
          });

          mergedData = [headerTitles, ...allData];

          break;
        }
        case "Client": {
          const tableHeaders = [
            { title: "Organization Name", key: "name" },
            { title: "Code", key: "code" },
            { title: "Rate Type", key: "rate_type" },
            { title: "Rate", key: "rate" },
            { title: "Sales Person", key: "salesPerson" },
            { title: "Tax Id", key: "taxId" },
            { title: "Phone", key: "phone" },
            { title: "Address", key: "address" },
            { title: "City", key: "city" },
            { title: "State", key: "state" },
            { title: "Country", key: "country" },
          ];

          const headerTitles = tableHeaders.map((item) => {
            return item.title;
          });

          const allData = dataForDownload.data.map((item) => {
            const tableItems = [
              item?.name,
              item?.code,
              item?.rate_type,
              item?.rate,
              item?.salesPerson,
              item?.taxId,
              item?.phone,
              item?.address?.replace(/,/g, " "),
              item?.city,
              item?.state,
              item?.country,
            ];
            return tableItems;
          });

          mergedData = [headerTitles, ...allData];

          break;
        }
        case "SearchResults": {
          const tableHeaders = getSearchResultTableHeaders(
            downloadSubType,
            isSubrogationActive,
            currentUser,
            isPendingDisposalActive
          );

          mergedData = [tableHeaders, ...dataForDownload.data];
          break;
        }
        default: {
          break;
        }
      }
      let downloadName = "";
      if (type === "SearchResults") {
        downloadName =
          downloadSubType !== "Admin Download"
            ? "searched-data-spreadsheet"
            : "searched-data-spreadsheet(Admin)";
      } else {
        downloadName = `${dataForSearch ? "searched-" : ""}${type}${
          dataForSearch ? "-(" + dataForSearch + ")-" : ""
        }`;
      }

      if (type === "SearchResults") {
        if (downloadSubType === "Download") {
          if (isSubrogationActive) {
            csvDownloader(mergedData, downloadName);
          } else if (!isSubrogationActive) {
            csvDownloader(mergedData, downloadName);
          } else if (isPendingDisposalActive) {
            csvDownloader(mergedData, downloadName);
          }
        } else if (downloadSubType === "Admin Download") {
          csvDownloader(mergedData, downloadName);
        }
      } else {
        csvDownloader(mergedData, downloadName);
      }

      clearDownload();
      setDownloadSubType("");
    }
  }, [dataForDownload]);

  const fetchData = () => {
    setDownloadSubType(subType);
    let obj =
      type === "User"
        ? {
            type,
            searchText: dataForSearch ? dataForSearch.searchText ?? null : null,
            searchFilters,
          }
        : type === "SearchResults"
        ? { type, searchText: searchQueryData, subType: subType }
        : {
            type,
            searchText: dataForSearch ?? null,
          };

    obj = { ...obj, timeZoneOffSet };

    if (type === "SearchResults") {
      obj = {
        ...obj,
        userType: currentUser?.data?.test_user
          ? USER_TYPE.TEST
          : USER_TYPE.GENERAL,
      };
    }

    downloadData(obj);
  };

  return !loading ? (
    <Button
      color="primary"
      onClick={() => fetchData()}
      disabled={disable}
      className={classes.root}
    >
      {type === "SearchResults" ? subType + " Spreadsheet" : "Download"}
    </Button>
  ) : showSpinner ? (
    <> </>
  ) : (
    <CustomProgressLoader show={loading} />
  );
};

const mapStateToProps = ({
  user,
  download: { dataForDownload, downloadType, loading },
}) => ({
  currentUser: user.currentUser,
  dataForDownload,
  downloadType,
  loading,
});

const mapDispatchToProps = (dispatch) => ({
  downloadData: bindActionCreators(downloadActions.download, dispatch),
  clearDownload: bindActionCreators(downloadActions.clearDownload, dispatch),
});

DownloadFullCSV.prototype = {
  dataToDownload: PropTypes.object.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(DownloadFullCSV)
);
