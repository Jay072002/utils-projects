import Homepage from "./Homepage";
import LoginPage from "./LoginPage";
import Dashboard from "./Dashboard";

export { Homepage, LoginPage, Dashboard };
