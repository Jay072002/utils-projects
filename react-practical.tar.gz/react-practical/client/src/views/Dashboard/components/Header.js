import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { withRouter } from "react-router-dom";

import Tab from "@material-ui/core/Tab";
import Tabs from "@material-ui/core/Tabs";
import AppBar from "@material-ui/core/AppBar";
import HomeIcon from "@material-ui/icons/Home";
import { makeStyles } from "@material-ui/core/styles";
import WarningIcon from "@material-ui/icons/Warning";
import FolderSharedRoundedIcon from "@material-ui/icons/FolderSharedRounded";
import SettingsApplicationsRoundedIcon from "@material-ui/icons/SettingsApplicationsRounded";
import PollIcon from '@material-ui/icons/Poll';
import { getCurrentUser } from "../../../actionCreators/User";
import { isPESUser_2 } from "../../../utils";
import { ROLES } from "../../../utils/keyMappers";

const useStyles = makeStyles((theme) => ({
  secondaryBar: {
    zIndex: 0,
  },
}));

function Header(props) {
  const classes = useStyles();
  const { valueReturner } = props;
  const { currentUser } = props.user;

  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleMoveSection = (newValue) => {
    valueReturner(newValue);
  };

  return (
    <React.Fragment>
      <AppBar
        component="div"
        className={classes.secondaryBar}
        color="primary"
        position="static"
        elevation={0}
      ></AppBar>
      <AppBar
        component="div"
        className={classes.secondaryBar}
        color="primary"
        position="static"
        elevation={0}
      >
        <Tabs value={value} textColor="inherit" onChange={handleChange}>
          <Tab
            textColor="inherit"
            label={
              <div style={{ display: "flex" }}>
                <HomeIcon style={{ marginRight: 10 }} /> Home
              </div>
            }
            onClick={() => handleMoveSection(0)}
          />

          {/* <Tab
            textColor="inherit"
            label={
              <div style={{ display: "flex" }}>
                <ArrowUpwardRoundedIcon style={{ marginRight: 10 }} /> Top
              </div>
            }
            onClick={() => handleMoveSection(1)}
          /> */}
          
        </Tabs>
      </AppBar>
    </React.Fragment>
  );
}

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = (dispatch) => ({
  getCurrentUser: bindActionCreators(getCurrentUser, dispatch),
});

Header.propTypes = {
  user: PropTypes.object.isRequired,
  classes: PropTypes.object.isRequired,
  onDrawerToggle: PropTypes.func.isRequired,
  getCurrentUser: PropTypes.func.isRequired,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Header));
