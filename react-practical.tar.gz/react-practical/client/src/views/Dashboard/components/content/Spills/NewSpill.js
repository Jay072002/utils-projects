import React, { useState } from "react";
import Moment from "moment";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { useForm, FormProvider } from "react-hook-form";
import ReactSelect from "react-select";
import MomentUtils from "@date-io/moment";

import Grid from "@material-ui/core/Grid";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import Container from "@material-ui/core/Container";
import * as userActions from "../../../../../actionCreators/User";
import * as spillActions from "../../../../../actionCreators/Spill";
import * as clientActions from "../../../../../actionCreators/Client";

import {
  compare,
  orderAlphabaticallyByKey,
  ROLES,
  removeProbPMFromOptions,
  forceToCST,
} from "../../../../../utils";
import { CustomProgressLoader } from "../../../../../Components";

import { MuiPickersUtilsProvider, DateTimePicker } from "@material-ui/pickers";
import {
  Checkbox,
  FormControlLabel,
  Switch,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: green[500],
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
  checkBoxMisc: {
    display: "inline",
  },
  checkBoxAlignment: {
    paddingLeft: "0px",
  },
}));

const NewSpill = ({
  users,
  currentUser,
  admins,
  getAdmins,
  closeAddSpill,
  getOrganizationNames,
  clientOrganizationNames,
  getUsersByOrgId,
  createNewSpill,
  editSpill,
  currentSpill,
  loading,
  isTestSpill,
  getFacility,
  facilities,
  client,
}) => {
  const classes = useStyles();
  const year = Moment(new Date()).format("YY");
  const month = Moment(new Date()).format("MM");

  const code = `${year}-???-${month}`;

  let orgs = [];
  const organizationNames = clientOrganizationNames.data;
  const role = currentUser.data.role.role;

  const [selectedUsers, setSelectedUsers] = React.useState([]);
  const [selectedAdmins, setSelectedAdmins] = React.useState([]);
  const [adminOptions, setAdminOptions] = React.useState([]);
  const [manager, setManager] = React.useState("");
  const [organizationValue, setOrganizationValue] = React.useState("");
  const [attachment, setAttachment] = React.useState(false);
  const [defaultCode, setDefaultCode] = React.useState(code);
  const [selectState, setSelectState] = useState({
    organizationSelect: false,
  });
  const [isComplete, setIsComplete] = useState(false);
  const [currentManager, setCurrentManager] = useState([]);
  const [openedOn, setOpenedOn] = useState(new Date());
  const [openedErrorFlag, setOpenedErrorFlag] = useState(false);
  const [sendEmails, setSendEmails] = useState(true);
  const [isSpillEmergency, setIsSpillEmergency] = useState(false);
  const [facilityOption, setFacilityOption] = React.useState([]);
  const [selectedFacility, setSelectedFacility] = useState({});
  const [selectedOrganization, setSelectedOrganization] = useState("");
  const [isFacilityReset, setIsFacilityReset] = useState(true);

  const { success, data } = currentSpill;

  React.useEffect(() => {
    if (success && isComplete) {
      editSpill(data.spill.job_no);
    }
  }, [success, isComplete]);

  React.useEffect(() => {
    if (admins.data) {
      const adminOptions = removeProbPMFromOptions(admins.data).map((admin) => {
        const value = { value: admin.id, label: admin.full_name };
        const allOptions = { ...value };

        return allOptions;
      });

      setAdminOptions(adminOptions.sort(compare));
    }
  }, [admins]);

  const updateOpenedOn = async (value) => {
    const currentTime = value?._d?.getTime();
    if (currentTime <= new Date().getTime()) {
      setOpenedOn(value);
      setOpenedErrorFlag(false);
    } else setOpenedErrorFlag(true);
  };

  React.useEffect(() => {
    setFacilityOption([]);
    getOrganizationNames();
    getAdmins({ filter: "none" });
  }, []);

  organizationNames.filter((organization) => {
    organization.active &&
      (role !== ROLES.DEMO
        ? organization.id !== 9 && orgs.push(organization)
        : orgs.push(organization));
  });

  const [userOptions, setUserOptions] = React.useState([]);

  React.useEffect(() => {
    if (Array.isArray(users.data) && organizationValue) {
      const usersForEmailOptions = users.data
        .map((user) => {
          const value = {
            value: user.id,
            label: user.full_name,
            email: user.email,
            active: user.active,
            is_default: user.is_default,
          };
          const allOptions = { ...value };

          return allOptions;
        })
        .filter((user) => user.active);
      setUserOptions(usersForEmailOptions);

      const defaultUsers = usersForEmailOptions.filter(
        (user) => user.is_default
      );
      defaultUsers.length && setSelectedUsers(defaultUsers);
    }
  }, [users.data]);

  React.useEffect(() => {
    if (facilities?.success && Array.isArray(facilities?.data) && !isFacilityReset) {
      setFacilityOption([]);
      setSelectedFacility({});
      const facilityOptions = facilities?.data.map((facility) => {
          const value = {
            value: facility.id,
            label: facility.name
          };
          const allOptions = { ...value };
          return allOptions;
        });
        if (facilityOptions?.length) {
          setFacilityOption(facilityOptions);
        }
    }
  }, [facilities?.data, facilities?.success]);

  const handleSelectChange = (key) => {
    let tempObject = selectState;
    tempObject[key] = true;
    setSelectState(tempObject);
  };

  const selectValidator = () => {
    let flag = false;
    Object.values(selectState).forEach((val) => {
      if (val === false) {
        flag = true;
      }
    });

    if (selectedAdmins.length < 0) {
      flag = true;
    }

    return flag;
  };

  const { handleSubmit, register } = useForm();
  const methods = useForm({
    defaultValues: {
      job_no: defaultCode,
    },
  });

  const sendEmailsForSpillHandler = (isToSendEmail) => {
    setSendEmails(isToSendEmail);
  };

  const onFinish = (newSpill) => {
    if (selectValidator()) {
      return;
    }
    if (organizationValue !== "" && attachment !== "") {
      newSpill = {
        ...newSpill,
        user_id: selectedAdmins.value,
        org_id: organizationValue,
        send_attachment: attachment,
        status: "Open: Work In Progress",
        manager_id: currentManager.value,
        opened_on: forceToCST(openedOn),
        facility_id: selectedFacility ? selectedFacility?.value : null,
      };
    }

    newSpill = {
      ...newSpill,
      users: selectedUsers,
      is_test_spill: isTestSpill,
      send_email: sendEmails,
      is_emergency: isSpillEmergency,
    };
    createNewSpill(newSpill);
    setIsComplete(true);
  };

  const handleOrganizationSelect = async (org_id, event) => {
    event.preventDefault();
    setSelectedOrganization(org_id);
    setSelectedUsers([]);
    handleSelectChange("organizationSelect");
    const id = { id: org_id };
    getUsersByOrgId(id);
    setIsFacilityReset(false);
    getFacility({ org_id });
  };

  return (
    <React.Fragment>
      <Container maxWidth="sm">
        <div style={{ paddingTop: 10 }} />
        <Typography variant="subtitle1" gutterBottom>
          <div style={{ textAlign: "center" }}>
            <span>{isTestSpill ? "New Test Spill" : "New Spill"}</span>
          </div>
        </Typography>
        {loading ? (
          <CustomProgressLoader show={true} />
        ) : (
          <FormProvider {...methods}>
            <form onSubmit={handleSubmit((data) => onFinish(data))}>
              <Grid container spacing={3}>
                {role === ROLES.PROB_PM && (
                  <Grid item xs={6} style={{ textAlign: "left" }}>
                    <InputLabel id="manager-select-label">
                      Current Project Manager *
                    </InputLabel>
                    <ReactSelect
                      value={currentManager}
                      required
                      isMulti={false}
                      onChange={setCurrentManager}
                      options={orderAlphabaticallyByKey(adminOptions)}
                    />
                  </Grid>
                )}
                <Grid item xs={6} style={{ textAlign: "left" }}>
                  <InputLabel id="manager-select-label">
                    Project Manager *
                  </InputLabel>
                  <ReactSelect
                    value={selectedAdmins}
                    isMulti={false}
                    onChange={setSelectedAdmins}
                    options={orderAlphabaticallyByKey(adminOptions)}
                  />
                </Grid>

                <Grid item xs={12} style={{ textAlign: "left" }}>
                  <InputLabel id="organization-select-label">
                    Organization *
                  </InputLabel>
                  <Select
                    labelId="organization-select-label"
                    id="organization-select"
                    name="organization"
                    value={selectedOrganization}
                    inputProps={{
                      inputRef: (ref) => {
                        if (!ref) return;
                        setOrganizationValue(ref.value);
                      },
                      required: true,
                    }}
                    fullWidth
                    onChange={(event) =>
                      handleOrganizationSelect(event.target.value, event)
                    }
                  >
                    {orgs &&
                      orderAlphabaticallyByKey(orgs, "name").map((e, id) => {
                        return <MenuItem value={e.id}>{e.name}</MenuItem>;
                      })}
                  </Select>
                </Grid>
                {facilityOption.length > 0 ? (
                  <Grid item xs={12} style={{ textAlign: "left" }}>
                    <InputLabel id="users-for-email-label">Facility</InputLabel>
                    <ReactSelect
                      value={selectedFacility}
                      required
                      isMulti={false}
                      onChange={setSelectedFacility}
                      options={orderAlphabaticallyByKey(facilityOption)}
                      isClearable
                    />
                  </Grid>
                ) : null}
                <Grid item xs={12} style={{ textAlign: "left" }}>
                  <InputLabel id="users-for-email-label">
                    Users for Email
                  </InputLabel>
                  <ReactSelect
                    value={selectedUsers}
                    required
                    isMulti
                    onChange={setSelectedUsers}
                    options={orderAlphabaticallyByKey(userOptions)}
                  />
                </Grid>

                <Grid item xs={12} style={{ textAlign: "left" }}>
                  <MuiPickersUtilsProvider utils={MomentUtils}>
                    <DateTimePicker
                      maxDate={new Date()}
                      value={openedOn}
                      onChange={updateOpenedOn}
                      error={openedErrorFlag}
                      label={"Opened"}
                      showTodayButton
                    />
                  </MuiPickersUtilsProvider>
                </Grid>

                <Grid item xs={6} style={{ textAlign: "left" }}>
                  <InputLabel id="attachment-select-label">
                    Send Attachment *
                  </InputLabel>
                  <Select
                    labelId="attachment-select-label"
                    id="attachment-select"
                    name="attachment"
                    defaultValue={false}
                    fullWidth
                    onChange={(e) => setAttachment(e.target.value)}
                  >
                    <MenuItem value={true}>Yes</MenuItem>
                    <MenuItem value={false}>No</MenuItem>
                  </Select>
                </Grid>

                {isTestSpill ? (
                  <Grid item xs={6} style={{ textAlign: "right" }}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={sendEmails}
                          onChange={(event) =>
                            sendEmailsForSpillHandler(event.target.checked)
                          }
                          name="sendEmails"
                          color="primary"
                        />
                      }
                      label="Send Email"
                    />
                  </Grid>
                ) : (
                  <></>
                )}

                <Grid item xs={12} style={{ textAlign: "left" }}>
                  <Checkbox
                    color="primary"
                    className={classes.checkBoxAlignment}
                    checked={isSpillEmergency}
                    onChange={(event) =>
                      setIsSpillEmergency(event.target.checked)
                    }
                  />
                  <InputLabel
                    id="non_emergency"
                    className={classes.checkBoxMisc}
                  >
                    Mark incident as Non-Emergency
                  </InputLabel>
                </Grid>

                <Grid item xs={12} style={{ textAlign: "right" }}>
                  <Button
                    className={classes.button}
                    variant="contained"
                    color="primary"
                    type="submit"
                  >
                    Create and Edit
                  </Button>
                  <Button
                    className={classes.button}
                    variant="contained"
                    color="primary"
                    onClick={() => closeAddSpill()}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
            </form>
          </FormProvider>
        )}
      </Container>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  user: { users, admins, currentUser },
  client: { clientOrganizationNames, facilities },
  spill: { success, currentSpill },
  spill,
  client,
  user,
}) => ({
  users,
  admins,
  clientOrganizationNames,
  currentSpill,
  success,
  currentUser,
  loading: spill.loading || client.loading,
  facilities,
});

const mapDispatchToProps = (dispatch) => ({
  getAdmins: bindActionCreators(userActions.getAdmins, dispatch),
  createNewSpill: bindActionCreators(spillActions.createNewSpill, dispatch),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  getUsersByOrgId: bindActionCreators(userActions.getUsersByOrgId, dispatch),
  getFacility: bindActionCreators(clientActions.getFacility, dispatch),
});

NewSpill.propTypes = {
  users: PropTypes.object.isRequired,
  admins: PropTypes.object.isRequired,
  getAdmins: PropTypes.func.isRequired,
  closeAddSpill: PropTypes.func.isRequired,
  getOrganizationNames: PropTypes.func.isRequired,
  clientOrganizationNames: PropTypes.object.isRequired,
  getUsersByOrgId: PropTypes.func.isRequired,
  editSpill: PropTypes.func.isRequired,
  currentUser: PropTypes.object.isRequired,
  facilities: PropTypes.object.isRequired,
  // getFacility: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(NewSpill);
