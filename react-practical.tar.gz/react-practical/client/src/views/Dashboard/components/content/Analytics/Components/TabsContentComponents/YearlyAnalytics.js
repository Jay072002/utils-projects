import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';
import MomentUtils from '@date-io/moment';
import moment from 'moment';

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import {
  Grid,
  makeStyles,
  Typography,
  Paper,
  Box,
  Tabs,
  Tab,
  CardContent,
  Card,
} from '@material-ui/core';

import { CustomSnackBar } from '../../../../../../../Components';

import {
  getCurrentYearSpills,
  getPreviousYearSpills,
  getCurrentVsPreviousYearSpills,
  getSpillStatusCount,
  getAllMonthSpillsCountInYear,
  getCurrentVsPreviousMonthSpillAtMonth,
  getAllMonthSpillsCountInCurrentVSPreviousYear,
} from '../../../../../../../actionCreators/Analytics';
import SingleStatChart from '../../../../../../../Components/SingleStatChart';
import BarChartWithRise from '../../../../../../../Components/BarChartWithRise';
import OutsideSingleCard from '../../../../../../../Components/OutsideSingleCard';
import GroupBarChart from '../../../../../../../Components/GroupBarChart';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
  },
  amountHeading: {
    fontSize: '35px',
    fontWeight: '600',
    color: '#434343',
  },
  insideCard: {
    width: '50%',
    margin: '0 auto',
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 0%), 0px 8px 10px 1px rgb(0 0 0 / 0%), 0px 3px 14px 2px rgb(0 0 0 / 0%)',
    marginTop: '24px',
    border: '1px solid #ededed',
  },
}));

const SpillAnalytics = ({
  currentYearSpills,
  previousYearSpills,
  currentVsPreviousYearSpills,
  spillStatusCount,
  getCurrentYearSpills,
  getPreviousYearSpills,
  getCurrentVsPreviousYearSpills,
  getSpillStatusCount,
  getAllMonthSpillsCountInYear,
  allMonthSpillsCountInYear,
  getCurrentVsPreviousMonthSpillAtMonth,
  currentVsPreviousMonthSpillAtMonth,
  getAllMonthSpillsCountInCurrentVSPreviousYear,
  allMonthSpillsCountInCurrentVSPreviousYear,
}) => {
  const classes = Styles();
  const [currVsPrevSpillsAtMonth, setCurrVsPrevSpillsAtMonth] = useState([]);
  const [date, setDate] = useState(moment());
  const [groupBarPVCData, setGroupBarPVCData] = useState(null); //groupBarPreviousVsCurrent
  const [pVCPercentage, setPVCPercentage] = useState(null);
  const yearFormat = 'YYYY-MM-DD';
  const year = 'YYYY';

  React.useEffect(() => {
    getCurrentYearSpills();
    getPreviousYearSpills({ date: moment(new Date()).format(yearFormat) });
    getCurrentVsPreviousYearSpills({
      date: moment(new Date()).format(yearFormat),
    });
    getSpillStatusCount({ year: moment().format(year) });
    getAllMonthSpillsCountInYear({ date: moment().format(year) });
    getCurrentVsPreviousMonthSpillAtMonth(currentVsPreviousMonthCallData());
    getAllMonthSpillsCountInCurrentVSPreviousYear();
  }, []);

  React.useEffect(() => {
    if (currentVsPreviousMonthSpillAtMonth?.data?.length > 0) {
      let modifiedData = [];
      currentVsPreviousMonthSpillAtMonth?.data?.forEach((item) => {
        let newItem = [];
        if (item?.data) {
          newItem = item?.data?.map((curr) => ({
            ...curr,
            newDate: moment(curr?.date)?.format('YYYY-MMMM'),
            value: curr?.count,
          }));
        }
        modifiedData.push({
          percentage: item?.percentage,
          status: item?.status,
          data: newItem,
        });
      });
      setCurrVsPrevSpillsAtMonth(modifiedData);
    }
  }, [currentVsPreviousMonthSpillAtMonth]);

  const currentVsPreviousMonthCallData = () => {
    const date = moment();
    const month = date.format('MM');
    return { year: date.format('YYYY'), month: month };
  };
  const handleDateChange = (date) => {
    getCurrentYearSpills({ date: date });
    getPreviousYearSpills({ date: date });
    getCurrentVsPreviousYearSpills({ date: date });
    getSpillStatusCount({ year: date.split('-')[0] });
    getAllMonthSpillsCountInYear({ date: date.split('-')[0] });
  };

  const getAveragePerMonth = () => {
    const count = Math.floor(
      spillStatusCount?.data?.statusCount?.filter(
        (item) => item.status === 'Average per month'
      )[0].average
    );
    return Math.floor(count);
  };

  React.useEffect(() => {
    if (allMonthSpillsCountInCurrentVSPreviousYear.data) {
      handleGroupBarPVCData(allMonthSpillsCountInCurrentVSPreviousYear.data);
    }
  }, [allMonthSpillsCountInCurrentVSPreviousYear]);

  const handleGroupBarPVCData = (_data) => {
    let initialCurrentYear = {
      Jan: 0,
      Feb: 0,
      Mar: 0,
      Apr: 0,
      May: 0,
      Jun: 0,
      July: 0,
      Aug: 0,
      Sept: 0,
      Oct: 0,
      Nov: 0,
      Dec: 0,
    };
    let initialPrevYear = { ...initialCurrentYear };
    let initialPercentage = { ...initialCurrentYear };

    try {
      const currentYear = new Date()?.getFullYear();
      _data.forEach((x) => {
        if (x.date.slice(0, 4) === currentYear?.toString()) {
          initialCurrentYear[x?.id] = x?.count;
          initialPercentage[x?.id] = x?.percentage;
          //current
        } else if (x.date.slice(0, 4) === (currentYear - 1)?.toString()) {
          //previous
          initialPrevYear[x?.id] = x?.count;
        }
      });

      setGroupBarPVCData([
        ...Object.keys(initialPrevYear).map((x) => ({
          month: x,
          value: initialPrevYear[x],
          name: 'Previous Year',
        })),
        ...Object.keys(initialCurrentYear).map((x) => ({
          month: x,
          value: initialCurrentYear[x],
          name: 'Current Year',
        })),
      ]);
      setPVCPercentage([
        ...Object.keys(initialPercentage).map((x) => ({
          month: x,
          value: parseFloat(initialPercentage[x].toFixed(2)),
        })),
      ]);
    } catch (e) {
      setGroupBarPVCData(-1);
      setPVCPercentage(-1);
    }
  };

  return (
    <React.Fragment>
      <CustomSnackBar
        open={
          currentYearSpills.error ||
          previousYearSpills.error ||
          currentVsPreviousYearSpills.error ||
          spillStatusCount.error ||
          allMonthSpillsCountInYear.error
        }
        severity='error'
        snackBarMessage='Unable to fetch some stats.'
      />
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <Typography className={classes.analyticsHeading}>
              Yearly Spills Analytics
            </Typography>
          </Grid>
          <Grid
            item
            xs={6}
            md={6}
            className={classes.datePickerContainer}
          ></Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6} lg={4} xl={4}>
            <SingleStatChart
              title={'Average Spills Per Month '}
              amount={getAveragePerMonth()}
              // amount={currentYearSpills?.data?.NoOfSpills}
              loading={currentYearSpills?.loading}
              cssAdjustment={1}
              // status={singleStatChartIncreasingData.status}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={4} xl={4}>
            <SingleStatChart
              title={'Current Spills YTD'}
              amount={currentYearSpills?.data?.NoOfSpills}
              loading={currentYearSpills?.loading}
              cssAdjustment={1}
              // status={singleStatChartIncreasingData.status}
            />
          </Grid>
          <Grid item xs={12} md={12} lg={4} xl={4}>
            <SingleStatChart
              title={'Total Previous Year Spills @ Same Date/Time'}
              amount={previousYearSpills?.data?.NoOfSpills}
              loading={currentYearSpills?.loading}

              // status={singleStatChartDecreasingData.status}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={
                'Current Year VS Previous Year @ Same Date/Time Difference'
              }
              amount={currentVsPreviousYearSpills?.data?.count}
              loading={currentVsPreviousYearSpills?.loading}
              // status={currentVsPreviousYearSpills?.data?.status?.toLowerCase()}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'% Difference of Current vs Previous Year Spills'}
              amount={
                isNaN(Math.floor(currentVsPreviousYearSpills?.data?.percentage))
                  ? 0
                  : Math.floor(currentVsPreviousYearSpills?.data?.percentage) +
                    '%'
              }
              loading={currentVsPreviousYearSpills?.loading}
              status={currentVsPreviousYearSpills?.data?.status?.toLowerCase()}
            />
          </Grid>
        </Grid>
        <Grid
          container
          spacing={4}
          // justifyContent='center'
          direction='row'
          alignItems='center'
          justify='center'
        >
          <Grid item xs={12} md={10}>
            <BarChartWithRise
              title={
                'Monthly Total of Current Year vs Previous Year @ The Same Date/Time'
              }
              data={currVsPrevSpillsAtMonth[0]?.data}
              loading={currentVsPreviousMonthSpillAtMonth?.loading}
              initialData={[
                {
                  month: 'Jan',
                  count: 0,
                  value: 0,
                },
              ]}
              xLabel={'newDate'}
              yLabel={'value'}
              minValue={0}
            />
          </Grid>
          {/* <Grid item xs={12} md={6}>
            <BarChartWithRise
              title={
                'Monthly Difference of Current vs Previous Month (Previous Year)'
              }
              data={currVsPrevSpillsAtMonth[1]?.data}
              loading={currentVsPreviousMonthSpillAtMonth?.loading}
              initialData={[
                {
                  month: 'Jan',
                  count: 0,
                  value: 0,
                },
              ]}
              xLabel={'newDate'}
              yLabel={'value'}
              minValue={0}
            />{' '}
          </Grid> */}
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6} lg={6} xl={3}>
            <OutsideSingleCard
              title={
                'Monthly % Difference of Current vs Previous Month (Current Year)'
              }
              applyYearlyAnalyticsFlag={true}
              amount={
                isNaN(Math.floor(currVsPrevSpillsAtMonth[0]?.percentage))
                  ? 0
                  : Math.floor(currVsPrevSpillsAtMonth[0]?.percentage) + '%'
              }
              loading={currentVsPreviousMonthSpillAtMonth?.loading}
              status={currVsPrevSpillsAtMonth[0]?.status?.toLowerCase()}
              hideLine
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={3}>
            <OutsideSingleCard
              title={
                'Monthly % Difference of Current vs Previous Month (Previous Year)'
              }
              applyYearlyAnalyticsFlag={true}
              amount={
                isNaN(Math.floor(currVsPrevSpillsAtMonth[1]?.percentage))
                  ? 0
                  : Math.floor(currVsPrevSpillsAtMonth[1]?.percentage) + '%'
              }
              loading={currentVsPreviousMonthSpillAtMonth?.loading}
              status={currVsPrevSpillsAtMonth[1]?.status?.toLowerCase()}
              hideLine
            />
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          {groupBarPVCData !== -1 && (
            <Grid item xs={12} md={12}>
              <GroupBarChart
                title={'Spills Count Per Month (Previous vs Current Year)'}
                data={groupBarPVCData}
                loading={groupBarPVCData ? false : true} //{allMonthSpillsCountInYear?.loading}
                xLabel={'month'}
                yLabel={'value'}
                seriesName={'name'}
              />
            </Grid>
          )}
          {pVCPercentage !== -1 && (
            <Grid item xs={12} md={12}>
              <BarChartWithRise
                title={
                  'Percentage Difference Per Month (Previous vs Current Year)'
                }
                data={pVCPercentage}
                loading={pVCPercentage ? false : true}
                initialData={[
                  {
                    month: 'Jan',
                    count: 0,
                    value: 0,
                  },
                ]}
                xLabel={'month'}
                yLabel={'value'}
                minValue={0}
              />
            </Grid>
          )}
        </Grid>
      </Paper>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: {
    currentYearSpills,
    previousYearSpills,
    currentVsPreviousYearSpills,
    spillStatusCount,
    allMonthSpillsCountInYear,
    currentVsPreviousMonthSpillAtMonth,
    allMonthSpillsCountInCurrentVSPreviousYear,
  },
}) => ({
  currentYearSpills,
  previousYearSpills,
  currentVsPreviousYearSpills,
  spillStatusCount,
  allMonthSpillsCountInYear,
  currentVsPreviousMonthSpillAtMonth,
  allMonthSpillsCountInCurrentVSPreviousYear,
});

const mapDispatchToProps = (dispatch) => ({
  getAllMonthSpillsCountInCurrentVSPreviousYear: bindActionCreators(
    getAllMonthSpillsCountInCurrentVSPreviousYear,
    dispatch
  ),
  getCurrentYearSpills: bindActionCreators(getCurrentYearSpills, dispatch),
  getPreviousYearSpills: bindActionCreators(getPreviousYearSpills, dispatch),
  getCurrentVsPreviousYearSpills: bindActionCreators(
    getCurrentVsPreviousYearSpills,
    dispatch
  ),
  getSpillStatusCount: bindActionCreators(getSpillStatusCount, dispatch),
  getAllMonthSpillsCountInYear: bindActionCreators(
    getAllMonthSpillsCountInYear,
    dispatch
  ),
  getCurrentVsPreviousMonthSpillAtMonth: bindActionCreators(
    getCurrentVsPreviousMonthSpillAtMonth,
    dispatch
  ),
});

SpillAnalytics.prototype = {
  currentYearSpills: PropTypes.object.isRequired,
  getCurrentYearSpills: PropTypes.func.isRequired,
  previousYearSpills: PropTypes.object.isRequired,
  getPreviousYearSpills: PropTypes.func.isRequired,
  currentVsPreviousYearSpills: PropTypes.object.isRequired,
  getCurrentVsPreviousYearSpills: PropTypes.func.isRequired,
  spillStatusCount: PropTypes.object.isRequired,
  getSpillStatusCount: PropTypes.func.isRequired,
  allMonthSpillsCountInYear: PropTypes.object.isRequired,
  getCurrentVsPreviousMonthSpillAtMonth: PropTypes.object.isRequired,
  currentVsPreviousMonthSpillAtMonth: PropTypes.object.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SpillAnalytics)
);
