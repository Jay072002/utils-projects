import React, { useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import ReactSelect from "react-select";
import { bindActionCreators } from "redux";
import { withRouter, useHistory } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import Avatar from "@material-ui/core/Avatar";
import Select from "@material-ui/core/Select";
import Button from "@material-ui/core/Button";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Switch from "@material-ui/core/Switch";
import { green } from "@material-ui/core/colors";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import Typography from "@material-ui/core/Typography";
import SnackbarContent from "@material-ui/core/SnackbarContent";
import {
  Card,
  CardContent,
  Divider,
  List,
  ListItem,
  Checkbox,
} from "@material-ui/core";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import AppBar from "@material-ui/core/AppBar";
import Snackbar from "@material-ui/core/Snackbar";
import moment from "moment";
import { CustomSnackBar, MainAddressForm } from "../../../../../Components";
import * as clientActions from "../../../../../actionCreators/Client";
import {
  orderAlphabaticallyByKey,
  ROLES,
  generateContractorLabel,
} from "../../../../../utils";

const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: green[500],
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
  leftAlign: {
    textAlign: "left",
  },
  serviceLabel: {
    display: "flex",
    alignItems: "center",
  },
  root: {
    width: "100%",
    backgroundColor: theme.palette.background.paper,
    textTransform: "capitalize",
    padding: 0,
  },
  labelColor: {
    color: "#7F7F7F",
  },
  parentNames: {
    fontWeight: "bolder",
    paddingLeft: 10,
  },
}));

const EditClient = ({
  userRole,
  closeEditModal,
  clientId,
  editClient,
  clients,
  getParents,
  client,
  salePersonsData,
  servicesData,
  getOrganization,
  clientLoading,
  getOrganizationNames,
  clientObj,
  editFacility,
  deleteFacility,
  contractorsWithAddress,
  revision_date,
  org_id,
  address,
  city,
  state,
  zipCode,
  country,
  phone,
  fax,
  contact,
}) => {
  const classes = useStyles();
  const [rate, setRate] = React.useState("");
  const [services, setServices] = React.useState([]);
  const [salePersons, setSalePersons] = React.useState([]);
  const [parentOrgName, setParentOrgName] = React.useState(false);
  const [associatedClients, setAssociatedClients] = React.useState([]);
  const [associatedServices, setAssociatedServices] = React.useState([]);
  const [paymentTerms, setPaymentTerms] = React.useState("");
  const [errorText, setErrorText] = React.useState("");
  const [associatedClientOptions, setAssociatedClientOptions] = React.useState(
    []
  );
  const [canSeeTimestamp, setCanSeeTimestamp] = React.useState(false);
  const [canSeeMonetary, setCanSeeMonetary] = React.useState(false);
  const [reqSubmitted, setReqSubmitted] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState(false);
  const [canSeeParentDefaultUsers, setCanSeeParentDefaultUsers] =
    React.useState(false);
  const [selectedTab, setSelectedTab] = useState(0);
  const [facilities, setSelectedFacilitiesData] = useState([]);
  const [newFacilities, setNewFacilites] = useState([]);
  const [mainAddressFormData, setMainAddressFormData] = useState({
    address: client?.address || "",
    city: client?.city || "",
    state: client?.state || "",
    zipCode: client?.zipCode || "",
    country: client?.country || "",
    phone: client?.phone || "",
    fax: fax || "",
    contact: contact || "",
  });
  const [name, setName] = useState("");
  const [open, setOpen] = React.useState(false);
  const [deleteFacilityParams, setDeleteFacilityParams] = useState(null);
  const [facilityDuplicate, setFacilityDuplicate] = useState("");
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [checkedIcs, setIcsChecked] = useState(false);

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  const handleFormChange = (event) => {
    setName(event.target.value);
  };

  React.useEffect(() => {
    if (client) {
      setName(client?.name || "");
      setSelectedFacilitiesData([]);
      setCanSeeTimestamp(client.timestamp_visibility);
      setCanSeeMonetary(client.monetary_visibility);
      setRate(client ? client.rate : "");
      setPaymentTerms(client.payment_terms || "");
      setMainAddressFormData({
        address: client?.address || "",
        city: client?.city || "",
        state: client?.state || "",
        zipCode: client?.zipCode || "",
        country: client?.country || "",
        phone: client?.phone || "",
        fax: fax || "",
        contact: contact || "",
      });
      setCanSeeParentDefaultUsers(client.is_default_parent_users);
      let temp = [];
      let associatedOrgs = client?.associated_organizations?.map((item) => {
        const filteredOrg = clients?.data.filter(
          (x) => x.id === item.associated_org_id
        );
        let newObject = {
          id: item.id,
          value: item.associated_org_id,
          label: filteredOrg[0]?.name,
        };
        return newObject;
      });
      setAssociatedClients(associatedOrgs);
      if (clientObj.clientParent) {
        try {
          const parentsArray = clientObj.clientParent?.data?.parents;
          if (parentsArray?.length > 0) {
            const org_ids = parentsArray.map((x) => x.org_id);
            const parentOrgName = clients.data.filter((x) =>
              org_ids.includes(x.id)
            );
            setParentOrgName(parentOrgName.map((x) => x.name).join(" , "));
          } else {
            setParentOrgName(null);
          }
        } catch (e) {
          console.log(e);
        }
      }
      clients?.data?.forEach((client) => {
        if (clientId !== client.id) {
          const value = {
            value: client.id,
            label: client.name,
            active: client.active,
          };
          temp.push(value);
        }
      });
      setAssociatedClientOptions(
        orderAlphabaticallyByKey(temp.filter((x) => x.active))
      );
    }
  }, [client, clients, contractorsWithAddress]);

  React.useEffect(() => {
    let associatedServices = client?.client_organization_services?.map(
      (item) => {
        const filteredService = servicesData?.services?.data.filter(
          (x) => x.id === item.service_id
        );
        let newObject = {
          id: item.id,
          value: item.service_id,
          label: filteredService[0]?.name,
          type: item.type,
          rate: item.rate,
        };
        return newObject;
      }
    );
    setAssociatedServices(associatedServices);
  }, [client?.client_organization_services, servicesData?.services?.data]);

  React.useEffect(() => {
    if (servicesData?.services?.data) {
      const data = servicesData?.services?.data;

      setServices(data.filter((x) => x.active));
    }
  }, [servicesData]);

  React.useEffect(() => {
    if (salePersonsData?.data) {
      const data = salePersonsData?.data;

      setSalePersons(data);
    }
  }, [salePersonsData]);

  React.useEffect(() => {
    if (clientId) {
      getOrganization({ id: clientId });
      getParents({ id: clientId });
      getOrganizationNames();
    }
  }, [clientId]);

  const handleIcsChange = (event) => {
    setIcsChecked(event.target.checkedIcs);
  };
  const showSnackbar = (message) => {
    setSnackbarMessage(message);
    setSnackbarOpen(true);
  };
  const handleCloseSnackbar = () => {
    setSnackbarOpen(false);
  };
  const validate = () => {
    if ((paymentTerms > 1 && paymentTerms < 100) || paymentTerms === "") {
      return [true];
    } else {
      return [false, "Value must be between 2 and 99"];
    }
  };
  const clientServicesOptions = services?.map((service) => {
    const value = {
      value: service.id,
      label: service.name,
      type: "",
      rate: "",
    };
    const allOptions = { ...value };

    return allOptions;
  });
  const handleServicesSelect = async (data) => {
    await setAssociatedServices([]);
    setAssociatedServices(data);
  };
  const handleServiceChange = (id, key) => (event) => {
    let newAssociatedServices = [...associatedServices];

    let data = newAssociatedServices.findIndex((obj) => obj.value === id);

    newAssociatedServices[data][key] =
      key === "rate" ? +event.target.value : event.target.value;

    if (key === "type") {
      if (event.target.value === "hourly") {
        newAssociatedServices[data]["rate"] = +(
          rate || newAssociatedServices[data]["rate"]
        );
      } else {
        newAssociatedServices[data]["rate"] = +(
          newAssociatedServices[data]["rate"] || rate
        );
      }
    }

    newAssociatedServices[data]["type"] =
      newAssociatedServices[data]["type"] || "hourly";
    setAssociatedServices(newAssociatedServices);
  };
  const handleRateChange = (event) => {
    setRate(event.target.value);
    setAssociatedServices((val) =>
      val?.map((service) => {
        return {
          ...service,
          rate: service.type ? service.rate : event.target.value,
        };
      })
    );
  };
  const validateForm = (e) => {
    const errors = {};
    if (!name || name.trim() === "") {
      errors.name = "- Client Name should not be blank.";
    }
    if (!e.target.taxId?.value || e.target.taxId?.value.trim() === "") {
      errors.taxId = "- Tax Id should not be blank.";
    }
    if (!e.target.code?.value || e.target.code?.value.trim() === "") {
      errors.code = "- Code should not be blank.";
    }
    if (e.target.code?.value) {
      const regEx = /^[0-9a-zA-Z]+$/;
      if (e.target.code?.value?.trim()?.match(regEx) === null) {
        errors.code = "- Code: Please enter letters and numbers only.";
      }
    }
    if (!rate || rate.trim() === "") {
      errors.rate = "- Rate should not be blank.";
    }
    if (!e.target.paymentTerms?.value || e.target.paymentTerms?.value?.trim() === "") {
      errors.paymentTerms = "- Payment Terms should not be blank.";
    }
    if (!e.target.salesPerson?.value || e.target.salesPerson?.value?.trim() === "") {
      errors.selectedSalesPerson = "- Salesperson should not be blank.";
    }
    const facilityName = facilities?.find(item => !item?.name && 
      (item?.internal_id || 
      item?.generator_status ||
      item?.epa_id ||
      item?.phone_number ||
      item?.address ||
      item?.region ||
      item?.country ||
      item?.state ||
      item?.city ||
      item?.zip_code ||
      item?.is_active));
    if (facilityName) {
      errors.facilityName = "- Facility Name should not be blank.";
    }
    const facilityEpaId = facilities?.find(item => !item?.epa_id && (item?.generator_status === "SQG" || item?.generator_status === "LQG"));
    if (facilityEpaId) {
      errors.facilityEpaId = "- EPA ID# Name should not be blank.";
    }
    if (facilityDuplicate) {
      errors.duplicateFacility = "- Facilities names should not be same.";
    }
    const combinedMessage = [
      errors.name || "",
      errors.taxId || "",
      errors.code || "",
      errors.selectedSalesPerson || "",
      errors.rate || "",
      errors.paymentTerms || "",
      errors?.facilityName || "",
      errors?.facilityEpaId || "",
      errors?.duplicateFacility || ""
    ].filter((message) => message !== "")
      .join("\n");
    if (combinedMessage) {
      return combinedMessage;
    }
    const result = validate();
    if (!result[0]) {
      return "- Payment Terms Value must be between 2 and 99";
    }
  };
  const hideError = () => {
    setErrorMessage('');
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm(e);
    if (errors) {
      setErrorMessage(errors);
    } else {
      let obj = {
        id: clientId,
        name: name,
        salesPerson: e.target.salesPerson?.value ? e.target.salesPerson?.value : null,
        taxId: e.target.taxId?.value ? e.target.taxId?.value : "",
        code: e.target.code?.value ? e.target.code?.value?.trim() : "",
        active: e.target.active?.value ? e.target.active?.value : false,
        rate: rate,
        paymentTerms: e.target.paymentTerms?.value || "",
        associatedClients,
        associatedServices: associatedServices?.map((service) => ({
          ...service,
          type: service.type || "hourly",
          rate: service.type ? service.rate : rate,
        })),
        timestampVisibility: canSeeTimestamp,
        monetaryVisibility: canSeeMonetary,
        defaultParentUsers: canSeeParentDefaultUsers,
        ...mainAddressFormData,
      };
      editClient({...obj});
      setReqSubmitted(true);
    }
  };

  React.useEffect(() => {
    if (!clientObj.loading && reqSubmitted) {
      if (!clientObj.error) {
        closeEditModal();
      } else {
        setErrorMessage(clientObj.error);
      }
      setReqSubmitted(false);
    }
  }, [clientObj.loading]);

  if (clientLoading) {
    return <div>Loading....</div>;
  }

  return (
    <React.Fragment>
      <div style={{ display: clientObj.loading ? "none" : "unset" }}>
        <CustomSnackBar
          open={!!errorMessage}
          severity="error"
          snackBarMessage={errorMessage}
          onClose={hideError} 
        />
        <Snackbar
          open={snackbarOpen}
          autoHideDuration={3000}
          onClose={handleCloseSnackbar}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "right",
          }}
        >
          <SnackbarContent message={snackbarMessage} />
        </Snackbar>
        <form
          onSubmit={handleSubmit}
          style={{
            width: "100%",
            paddingTop: 10,
            paddingLeft: 30,
            paddingRight: 30,
          }}
        >
          <div className={selectedTab === 0 ? "" : "hidden"}>
            <>
              <Grid container spacing={3}>
                <Grid item xs={6}>
                  <TextField
                    id="name"
                    label="Name"
                    fullWidth
                    autoComplete="name"
                    value={name}
                    onChange={handleFormChange}
                  />
                </Grid>
                {userRole === ROLES.SUPER_USER ? (
                  <Grid item xs={6} className={classes.leftAlign}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkedIcs}
                          onChange={handleIcsChange}
                          name="myCheckbox"
                          className={classes.labelColor}
                        />
                      }
                      label="is ICS Client?"
                    />
                  </Grid>
                ) : null}
                {parentOrgName && (
                  <Grid item xs={6} className={classes.leftAlign}>
                    <Typography
                      variant="subtitle"
                      gutterBottom
                      className={classes.labelColor}
                    >
                      Parent Organization:
                    </Typography>
                    <span className={classes.parentNames}>{parentOrgName}</span>
                  </Grid>
                )}
                {parentOrgName && (
                  <Grid item xs={6} className={classes.leftAlign}>
                    <Switch
                      labelId="default-user-label"
                      id="default-switch-parent-user"
                      checked={canSeeParentDefaultUsers}
                      onChange={(event) =>
                        setCanSeeParentDefaultUsers(event.target.checked)
                      }
                      name="canSeeParentDefaultUsers"
                      color="primary"
                    />
                    <Typography variant="subtitle" gutterBottom>
                      Parent Organization User's as Default
                    </Typography>
                  </Grid>
                )}
                <Grid item xs={12} className={classes.leftAlign}>
                  <Typography
                    variant="subtitle"
                    gutterBottom
                    className={classes.labelColor}
                  >
                    Child Organizations
                  </Typography>
                  <ReactSelect
                    value={associatedClients}
                    required
                    isMulti
                    onChange={setAssociatedClients}
                    options={associatedClientOptions}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    id="taxId"
                    name="taxId"
                    label="Tax ID"
                    fullWidth
                    autoComplete="taxId"
                    defaultValue={client ? client.taxId : ""}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    id="code"
                    name="code"
                    label="Code"
                    fullWidth
                    autoComplete="code"
                    defaultValue={client ? client.code : ""}
                  />
                </Grid>

                <Grid item xs={12} className={classes.leftAlign}>
                  <InputLabel
                    id="salesPerson-select-label"
                    className={classes.labelColor}
                  >
                    Salesperson
                  </InputLabel>
                  <Select
                    labelId="salesPerson-select-label"
                    id="salesPerson-select"
                    name="salesPerson"
                    style={{ width: "100%" }}
                    defaultValue={client ? client.sales_person_id : ""}
                  >
                    <MenuItem value="">
                      <em>Select Salesperson</em>
                    </MenuItem>
                    {salePersons &&
                      orderAlphabaticallyByKey(salePersons, "full_name")?.map(
                        (e) => {
                          return (
                            <MenuItem
                              value={e.id}
                            >{`${e.full_name} (${e.client_organization.name}: ${e.role.role})`}</MenuItem>
                          );
                        }
                      )}
                  </Select>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    id="rate"
                    name="rate"
                    label="Rate"
                    fullWidth
                    autoComplete="rate"
                    onChange={handleRateChange}
                    value={rate}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    id="paymentTerms"
                    name="paymentTerms"
                    label="Payment Terms"
                    fullWidth
                    autoComplete="paymentTerms"
                    value={paymentTerms}
                    onChange={(e) => setPaymentTerms(e.target.value)}
                    onBlur={() => {
                      const result = validate();
                      if (result[0]) {
                        setErrorText("");
                      } else {
                        setErrorText(result[1]);
                      }
                    }}
                    error={errorText ? true : false}
                    helperText={errorText || ""}
                  />
                </Grid>

                {userRole === ROLES.SUPER_USER ? (
                  <>
                    <Grid item xs={4} className={classes.leftAlign}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={canSeeMonetary}
                            onChange={(event) =>
                              setCanSeeMonetary(event.target.checked)
                            }
                            name="monetaryAmountsVisible"
                            color="primary"
                          />
                        }
                        label="View Monetary Amounts"
                      />
                    </Grid>
                    <Grid item xs={8} className={classes.leftAlign}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={canSeeTimestamp}
                            onChange={(event) =>
                              setCanSeeTimestamp(event.target.checked)
                            }
                            name="timeStampVisibile"
                            color="primary"
                          />
                        }
                        label="View Timestamps"
                      />
                    </Grid>
                    <Grid item xs={12} className={classes.leftAlign}>
                      <Typography
                        variant="subtitle"
                        gutterBottom
                        className={classes.labelColor}
                      >
                        Services
                      </Typography>
                      <ReactSelect
                        value={associatedServices}
                        required
                        isMulti
                        onChange={(data) => handleServicesSelect(data)}
                        options={orderAlphabaticallyByKey(clientServicesOptions)}
                      />
                    </Grid>
                  </>
                ) : null}

                <Grid item xs={12}>
                  {associatedServices?.length > 0 ? (
                    <div>
                      <div>
                        <Card
                          className={classes.headerCard}
                          style={{ margin: "15px 0px 0px 0px", width: "100%" }}
                        >
                          <CardContent
                            style={{
                              padding: "10px",
                              backgroundColor: "#e6e6e6d6",
                              fontWeight: 600,
                              color: "#6aa16c",
                            }}
                          >
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "space-between",
                              }}
                            ></div>
                            <Grid container spacing={3}>
                              <Grid item xs={6}>
                                <div className={classes.leftAlign}>
                                  Service Name
                                </div>
                              </Grid>

                              <Grid item xs={3}>
                                <div className={classes.leftAlign}>
                                  Service Type
                                </div>
                              </Grid>
                              <Grid item xs={3}>
                                <div className={classes.leftAlign}>Rate</div>
                              </Grid>
                            </Grid>
                          </CardContent>
                        </Card>
                        {associatedServices &&
                          associatedServices?.map((service, i) => (
                            <List
                              component="nav"
                              className={classes.root}
                              aria-label="mailbox folders"
                            >
                              <ListItem>
                                <Grid container spacing={3}>
                                  <Grid
                                    item
                                    xs={6}
                                    className={classes.serviceLabel}
                                  >
                                    <div className={classes.leftAlign}>
                                      <span>{service.label}</span>
                                    </div>
                                  </Grid>
                                  <Grid item xs={3}>
                                    <div className={classes.leftAlign}>
                                      {
                                        <Select
                                          labelId="rate-type-select-label"
                                          id="rate-type-select"
                                          name="rateType"
                                          style={{ width: "100%" }}
                                          defaultValue={service?.type || "hourly"}
                                          onChange={handleServiceChange(
                                            service.value,
                                            "type"
                                          )}
                                          required
                                        >
                                          <MenuItem value={"fixed"}>
                                            Fixed
                                          </MenuItem>
                                          <MenuItem value={"hourly"}>
                                            Hourly
                                          </MenuItem>
                                        </Select>
                                      }
                                    </div>
                                  </Grid>
                                  <Grid item xs={3}>
                                    <div className={classes.leftAlign}>
                                      {
                                        <TextField
                                          id="rate"
                                          name="rate"
                                          fullWidth
                                          autoComplete="rate"
                                          required
                                          defaultValue={
                                            associatedServices[i].type
                                              ? associatedServices[i].rate || rate
                                              : rate
                                          }
                                          value={
                                            associatedServices[i].type
                                              ? associatedServices[i].rate
                                              : rate
                                          }
                                          onChange={handleServiceChange(
                                            service.value,
                                            "rate"
                                          )}
                                          type={"number"}
                                        />
                                      }
                                    </div>
                                  </Grid>
                                </Grid>
                              </ListItem>
                              <Divider />
                            </List>
                          ))}
                      </div>
                    </div>
                  ) : null}
                </Grid>

                <Grid item xs={6} className={classes.leftAlign}>
                  <InputLabel
                    id="active-select-label"
                    className={classes.labelColor}
                  >
                    Active
                  </InputLabel>
                  <Select
                    labelId="active-select-label"
                    id="active-select"
                    name="active"
                    defaultValue={client ? client.active : ""}
                    style={{ width: "100%" }}
                  >
                    <MenuItem value={true}>True</MenuItem>
                    <MenuItem value={false}>False</MenuItem>
                  </Select>
                </Grid>

                <Grid item xs={12}>
                  <MainAddressForm
                    mainAddformData={mainAddressFormData}
                    onChange={setMainAddressFormData}
                    isOrg={true}
                    showResponsePills={false}
                  ></MainAddressForm>
                </Grid>
              </Grid>
            </>
          </div>
          <Grid item xs={12} style={{ textAlign: "right" }}>
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              type="submit"
            >
              Update
            </Button>
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => closeEditModal()}
            >
              Cancel
            </Button>
          </Grid>
        </form>
      </div>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  client,
  contractor: { contractorsWithAddress },
}) => {
  return {
    clientObj: client,
    client: client.currentClient.data,
    clientLoading: client.currentClient.loading,
    clients: client.clientOrganizationNames,
    contractorsWithAddress,
  };
};

const mapDispatchToProps = (dispatch) => ({
  getParents: bindActionCreators(clientActions.getParents, dispatch),
  getOrganization: bindActionCreators(clientActions.getOrganization, dispatch),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  editFacility: bindActionCreators(clientActions.editFacility, dispatch),
  deleteFacility: bindActionCreators(clientActions.deleteFacility, dispatch),
  editClient: bindActionCreators(clientActions.editClient, dispatch),
});

EditClient.prototype = {
  client: PropTypes.object.isRequired,
  getParents: PropTypes.func.isRequired,
  getOrganization: PropTypes.func.isRequired,
  clientId: PropTypes.string.isRequired,
  editFacility: PropTypes.object.isRequired,
  deleteFacility: PropTypes.object.isRequired,
  editClient: PropTypes.func.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(EditClient)
);
