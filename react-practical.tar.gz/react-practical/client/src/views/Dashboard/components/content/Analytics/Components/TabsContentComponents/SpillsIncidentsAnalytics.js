import React, { useState } from 'react';
import { Grid, makeStyles, Paper, Typography } from '@material-ui/core';

import { styles } from '@material-ui/pickers/views/Calendar/Calendar';
import {
  get5800FormsDetails,
  getAvgTimeForExcavation,
  getDisposalIncidentsNumber,
  getEvacuationIncidentsNumber,
  getHazardousIncidents,
  getIncidentsAtLocationTypes,
  getNonHazardousIncidents,
  getEmergencyIncidents,
  getNonEmergencyIncidents,
} from '../../../../../../../actionCreators/Analytics';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import moment from 'moment';
import { withRouter } from 'react-router-dom';
import SingleStatChart from '../../../../../../../Components/SingleStatChart';
import PieChart from '../../../../../../../Components/PieChart';
import BarChartWithRise from '../../../../../../../Components/BarChartWithRise';
import CircularProgressBar from '../../../../../../../Components/CircularProgressBar';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from '@material-ui/pickers';
import MomentUtils from '@date-io/moment';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  paperInner: {
    backgroundColor: '#f7f7f7',
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
    background: 'none',
    boxShadow: 'none',
    border: '1px solid #b9b9b9',
    paddingLeft: '10px',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },

  datePickerContainer: {
    textAlign: 'end',
    display: 'flex',
    justifyContent: 'end',
  },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
  },
  amountHeading: {
    fontSize: '35px',
    fontWeight: '600',
    color: '#434343',
  },
  insideCard: {
    width: '50%',
    margin: '0 auto',
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 0%), 0px 8px 10px 1px rgb(0 0 0 / 0%), 0px 3px 14px 2px rgb(0 0 0 / 0%)',
    marginTop: '24px',
    border: '1px solid #ededed',
  },
}));

const SpillsIncidentsAnalytic = ({
  getNonHazardousIncidents,
  nonHazardousIncidents,
  getHazardousIncidents,
  hazardousIncidents,
  getEmergencyIncidents,
  emergencyIncidents,
  getNonEmergencyIncidents,
  nonEmergencyIncidents,
  getIncidentsAtLocationTypes,
  incidentsAtLocationTypes,
  evacuationIncidentsNumber,
  getEvacuationIncidentsNumber,
  disposalIncidentsNumber,
  getDisposalIncidentsNumber,
  getAvgTimeForExcavation,
  avgTimeForExcavation,
  formDetails5800,
  get5800FormsDetails,
}) => {
  const classes = Styles();
  const [hazardousVsNonHazardous, setHazardousVsNonHazardous] = useState([]);
  const [emergencyVsNonEmergency, setEmergencyVsNonEmergency] = useState([]);
  const [incidentsAtLocationTypesState, setIncidentsAtLocationTypesState] =
    useState([
      {
        name: 'Customer',
        count: 0,
        //value: 0,
      },
    ]);

  const minDate = '2011-01';
  const monthFormat = 'YYYY-MM';
  const yearFormat = 'YYYY';
  const [yearDate, setYearDate] = useState(moment().format(yearFormat));
  const [monthlyDate, setMonthlyDate] = useState(moment()?.format(monthFormat));
  const [toggleValue, setToggleValue] = useState('yearly');
  const toggleItems = [{ value: 'yearly', label: 'Yearly' }];

  React.useEffect(() => {
    getEmergencyIncidents();
    getNonEmergencyIncidents();
    getNonHazardousIncidents();
    getHazardousIncidents();
    getIncidentsAtLocationTypes({ date: moment(new Date()).format('YYYY') });
    getEvacuationIncidentsNumber();
    getDisposalIncidentsNumber();
    getAvgTimeForExcavation();
    get5800FormsDetails({ date: moment(new Date()).format('YYYY') });
  }, []);

  React.useEffect(() => {
    if (
      !hazardousIncidents?.data?.loading &&
      !nonHazardousIncidents?.data?.loading
    ) {
      const data = [
        {
          type: 'Hazardous',
          value: hazardousIncidents?.data?.data?.count,
        },
        {
          type: 'Non Hazardous',
          value: nonHazardousIncidents?.data?.data?.count,
        },
      ];
      setHazardousVsNonHazardous(data);
    }
  }, [hazardousIncidents, nonHazardousIncidents]);

  React.useEffect(() => {
    if (
      !emergencyIncidents?.data?.loading &&
      !nonEmergencyIncidents?.data?.loading
    ) {
      const data = [
        {
          type: 'Emergency',
          value: emergencyIncidents?.data?.data?.count,
        },
        {
          type: 'Non Emergency',
          value: nonEmergencyIncidents?.data?.data?.count,
        },
      ];
      setEmergencyVsNonEmergency(data);
    }
  }, [emergencyIncidents, nonEmergencyIncidents]);

  React.useEffect(() => {
    get5800FormsDetails({ date: moment(yearDate).format('YYYY') });
  }, [yearDate]);

  React.useEffect(() => {
    if (incidentsAtLocationTypes) {
      setIncidentsAtLocationTypesState(incidentsAtLocationTypes);
    }
  }, [incidentsAtLocationTypes]);

  React.useEffect(() => {
    if (incidentsAtLocationTypes) {
      setIncidentsAtLocationTypesState(incidentsAtLocationTypes);
    }
  }, [incidentsAtLocationTypes]);

  return (
    <React.Fragment>
      {' '}
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <Typography className={classes.analyticsHeading}>
              Spills Incidents
            </Typography>
          </Grid>
          <Grid
            item
            xs={6}
            md={6}
            className={classes.datePickerContainer}
          ></Grid>
        </Grid>
        <Grid container spacing={3}>
          <Grid item xs md={6}>
            {' '}
            <Paper elevation={2} className={classes.paperInner}>
              <Grid container spacing={2}>
                <Grid item xs md={6}>
                  <SingleStatChart
                    title={'Hazardous'}
                    amount={hazardousIncidents?.data?.data?.count}
                    loading={hazardousIncidents?.data?.data?.loading}
                  />{' '}
                </Grid>
                <Grid item xs md={6}>
                  <SingleStatChart
                    title={'Non Hazardous'}
                    loading={nonHazardousIncidents?.data?.data?.loading}
                    amount={nonHazardousIncidents?.data?.data?.count}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={4}>
                <Grid item xs md={12}>
                  {hazardousVsNonHazardous && (
                    <PieChart
                      withoutCard={true}
                      title={'Hazardous vs Non Hazardous'}
                      data={hazardousVsNonHazardous}
                      type={'type'}
                      value={'value'}
                    />
                  )}
                </Grid>
              </Grid>
            </Paper>
          </Grid>
          <Grid item xs md={6}>
            {' '}
            <Paper elevation={2} className={classes.paperInner}>
              <Grid container spacing={2}>
                <Grid item xs md={6}>
                  <SingleStatChart
                    title={'Emergency'}
                    amount={emergencyIncidents?.data?.data?.count}
                    loading={emergencyIncidents?.data?.data?.loading}
                  />{' '}
                </Grid>
                <Grid item xs md={6}>
                  <SingleStatChart
                    title={'Non Emergency'}
                    loading={nonEmergencyIncidents?.data?.data?.loading}
                    amount={nonEmergencyIncidents?.data?.data?.count}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={4}>
                <Grid item xs md={12}>
                  {emergencyVsNonEmergency && (
                    <PieChart
                      withoutCard={true}
                      title={'Emergency vs Non Emergency'}
                      data={emergencyVsNonEmergency}
                      type={'type'}
                      value={'value'}
                    />
                  )}
                </Grid>
              </Grid>
            </Paper>
          </Grid>
          <Grid
            item
            xs
            md={12}
            style={{ marginBottom: '10px' }}
            className={classes.datePickerContainer}
          >
            {/* <Paper elevation={2} className={classes.paperInner}> */}
            <Grid container spacing={2}>
              <Grid item md={12}>
                <BarChartWithRise
                  height={294}
                  title={'Incidents at Location Types YTD'}
                  data={incidentsAtLocationTypesState?.data}
                  loading={incidentsAtLocationTypesState?.loading}
                  initialData={incidentsAtLocationTypesState}
                  xLabel={'name'}
                  yLabel={'value'}
                  minValue={5}
                />
              </Grid>
            </Grid>
            {/* </Paper> */}
          </Grid>
        </Grid>
        <Paper className={classes.paperInner}>
          <Grid container spacing={4}>
            <Grid item xs={6} md={12} className={classes.datePickerContainer}>
              <Grid item xs={12} md={3}>
                <div className={classes.datesTypeWrapper}>
                  {toggleValue === toggleItems[0]?.value && (
                    <MuiPickersUtilsProvider
                      utils={MomentUtils}
                      className={classes.datePickerContainer}
                    >
                      <KeyboardDatePicker
                        disableToolbar
                        variant='inline'
                        label='Year Filter:'
                        views={['year']}
                        value={moment(yearDate)}
                        disableFuture
                        onChange={(event) => {
                          setYearDate(event.format(yearFormat));
                        }}
                        autoOk={true}
                        minDate={minDate}
                      />
                    </MuiPickersUtilsProvider>
                  )}
                  {toggleValue === toggleItems[1]?.value && (
                    <MuiPickersUtilsProvider
                      utils={MomentUtils}
                      className={classes.datePickerContainer}
                    >
                      <KeyboardDatePicker
                        disableToolbar
                        variant='inline'
                        label='Date Filter:'
                        views={['year', 'month']}
                        value={moment(monthlyDate)}
                        disableFuture
                        onChange={(event) => {
                          //handleDateChange(event.format(yearFormat));
                          setMonthlyDate(event.format(monthFormat));
                        }}
                        //onClose={handleDateChange}
                        autoOk={true}
                        minDate={minDate}
                      />
                    </MuiPickersUtilsProvider>
                  )}
                </div>
              </Grid>
            </Grid>

            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={
                  (formDetails5800?.data?.['total']?.percentage * 1) / 100
                }
                count={formDetails5800?.data?.['total']?.count}
                mainColor={'#F6C036'}
                title={'Required 5800'}
                loading={formDetails5800?.loading}
                description={'Total Incidents that required 5800 YTD'}
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={
                  (formDetails5800?.data?.['opened']?.percentage * 1) / 100
                }
                mainColor={'#647697'}
                title={'Open'}
                description={'Currently open incidents still requiring 5800'}
                loading={formDetails5800?.loading}
                count={formDetails5800?.data?.['opened']?.count}
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={
                  (formDetails5800?.data?.['completed']?.percentage * 1) / 100
                }
                count={formDetails5800?.data?.['completed']?.count}
                mainColor={'#5ED9AB'}
                title={'Completed'}
                loading={formDetails5800?.loading}
                description={
                  'Total incidents with 5800 form submitted/completed which required 5800 YTD'
                }
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={
                  (formDetails5800?.data?.['range']?.percentage * 1) / 100
                }
                count={formDetails5800?.data?.['range']?.count}
                mainColor={'#6694F7'}
                title={'Completed within 7 days of submission'}
                description={
                  'Incidents that are completed within 7 days (after their 23rd day from their creation) YTD'
                }
                loading={formDetails5800?.loading}
              />
            </Grid>
          </Grid>
        </Paper>
        <Grid container spacing={4}>
          <Grid item xs={6} md={4}>
            <SingleStatChart
              title={'Scheduled Excavation'}
              amount={evacuationIncidentsNumber?.data?.count}
              loading={evacuationIncidentsNumber?.loading}
            />{' '}
          </Grid>
          <Grid item xs={6} md={4}>
            <SingleStatChart
              title={'Avg time to Complete Excavation'}
              amount={avgTimeForExcavation?.data?.avg}
              loading={avgTimeForExcavation?.loading}
              label={'days'}
            />{' '}
          </Grid>
          <Grid item xs={6} md={4}>
            <SingleStatChart
              title={'Required Disposal'}
              amount={disposalIncidentsNumber?.data?.count}
              loading={disposalIncidentsNumber?.loading}
            />{' '}
          </Grid>
        </Grid>
      </Paper>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: {
    nonEmergencyIncidents,
    emergencyIncidents,
    nonHazardousIncidents,
    hazardousIncidents,
    incidentsAtLocationTypes,
    evacuationIncidentsNumber,
    disposalIncidentsNumber,
    avgTimeForExcavation,
    formDetails5800,
  },
}) => ({
  nonEmergencyIncidents,
  emergencyIncidents,
  nonHazardousIncidents,
  hazardousIncidents,
  incidentsAtLocationTypes,
  evacuationIncidentsNumber,
  disposalIncidentsNumber,
  avgTimeForExcavation,
  formDetails5800,
});

const mapDispatchToProps = (dispatch) => ({
  getNonHazardousIncidents: bindActionCreators(
    getNonHazardousIncidents,
    dispatch
  ),
  getHazardousIncidents: bindActionCreators(getHazardousIncidents, dispatch),
  getNonEmergencyIncidents: bindActionCreators(
    getNonEmergencyIncidents,
    dispatch
  ),
  getEmergencyIncidents: bindActionCreators(getEmergencyIncidents, dispatch),
  getIncidentsAtLocationTypes: bindActionCreators(
    getIncidentsAtLocationTypes,
    dispatch
  ),
  getEvacuationIncidentsNumber: bindActionCreators(
    getEvacuationIncidentsNumber,
    dispatch
  ),
  getDisposalIncidentsNumber: bindActionCreators(
    getDisposalIncidentsNumber,
    dispatch
  ),
  getAvgTimeForExcavation: bindActionCreators(
    getAvgTimeForExcavation,
    dispatch
  ),
  get5800FormsDetails: bindActionCreators(get5800FormsDetails, dispatch),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SpillsIncidentsAnalytic)
);
