import React, { useState } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { makeStyles, Typography, Box, Tabs, Tab } from '@material-ui/core';
import YearlyAnalytics from './Components/TabsContentComponents/YearlyAnalytics';
import DailySpillsAnalytics from './Components/TabsContentComponents/DailySpillsAnalytics';
import SpillsStatusAnalytics from './Components/TabsContentComponents/SpillsStatusAnalytics';
import SpillsIncidentsAnalytic from './Components/TabsContentComponents/SpillsIncidentsAnalytics';
import ContractorsAnalytics from './Components/TabsContentComponents/ContractorsAnalytics';
import CurrentStats from './Components/TabsContentComponents/CurrentStats';
import { ROLES } from '../../../../../utils';

const TabStyles = makeStyles((theme) => ({
  tabWrapper: {
    marginBottom: '12px',
    '& span.MuiTabs-indicator': {
      backgroundColor: '#397D33',
    },
  },
  singleTab: {
    fontWeight: 'bold',
    color: '#397D33',
    fontSize: '15px',
  },

  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
}));

const AnalyticsTabsWrapperAdmin = ({ currentUser }) => {
  const classes = TabStyles();
  const [value, setValue] = useState(0);
  const [userAllowed, setUserAllowed] = React.useState(null);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  React.useEffect(() => {
    const allowedRoles = [
      ROLES.SUPER_USER,
      ROLES.PROB_PM,
      ROLES.PES_ADMIN,
      ROLES.PES_USER,
      ROLES.PES_ACCOUNTING_ADMIN,
    ];
    setUserAllowed(allowedRoles.includes(currentUser?.data?.role?.role));
  }, [currentUser]);
  return (
    <React.Fragment>
      <Box sx={{ borderBottom: 1, borderColor: '#397d33' }}>
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label='basic tabs example'
          className={classes?.tabWrapper}
        >
          <Tab label='Yearly Spills' className={classes?.singleTab} />
          <Tab label='Daily Spills' className={classes?.singleTab} />
          <Tab label='Spills Status' className={classes?.singleTab} />
          <Tab label='Spills Incidents' className={classes?.singleTab} />
          <Tab label='Contractors' className={classes?.singleTab} />
          {userAllowed && (
            <Tab label='Current Stats' className={classes?.singleTab} />
          )}
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        <YearlyAnalytics />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <DailySpillsAnalytics />
      </TabPanel>
      <TabPanel value={value} index={2}>
        <SpillsStatusAnalytics />
      </TabPanel>
      <TabPanel value={value} index={3}>
        <SpillsIncidentsAnalytic />
      </TabPanel>
      <TabPanel value={value} index={4}>
        <ContractorsAnalytics />
      </TabPanel>
      {userAllowed && (
        <TabPanel value={value} index={5}>
          <CurrentStats />
        </TabPanel>
      )}
    </React.Fragment>
  );
};

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

const mapStateToProps = ({ user }) => ({
  currentUser: user.currentUser,
});

const mapDispatchToProps = (dispatch) => ({});

AnalyticsTabsWrapperAdmin.propTypes = {};
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(AnalyticsTabsWrapperAdmin)
);
