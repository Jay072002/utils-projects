import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import * as contractorAction from '../../../../../../../actionCreators/Contractor';

import {
  getAverageInvoicesClient,
  getSavingsClient,
} from '../../../../../../../actionCreators/Analytics';
import React, { useState } from 'react';
import { Grid, makeStyles, Paper } from '@material-ui/core';

import SingleStatChart from '../../../../../../../Components/SingleStatChart';

import MomentUtils from '@date-io/moment';
import moment from 'moment';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from '@material-ui/pickers';
const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  paperInner: {
    backgroundColor: '#f7f7f7',
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    margin: '20px 0px',
    background: 'none',
    boxShadow: 'none',
    border: '1px solid #b9b9b9',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  marginSelect: {
    marginTop: '12px',
  },
  filterIcon: {
    color: '#ffffffff',
    backgroundColor: '#397d33',
    fontSize: '40px',
    padding: '12px',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  filterBox: {
    textAlign: 'left',
    marginTop: '12px',
  },
  filterButtonSelect: {
    // textAlign: 'right',
    padding: '20px',
  },
}));
const InvoiceClient = ({
  averageInvoicesClient,
  getAverageInvoicesClient,
  savingsClient,
  getSavingsClient,
}) => {
  let dollarUSLocale = Intl.NumberFormat('en-US');
  const classes = Styles();
  React.useEffect(() => {
    getAverageInvoicesClient();
    getSavingsClient();
  }, []);
  const yearFormat = 'YYYY';
  const [yearDate, setYearDate] = useState(moment().format(yearFormat));
  const minDate = '2011-01';
  React.useEffect(() => {
    getSavingsClient({ date: moment(yearDate).format('YYYY') });
  }, [yearDate]);

  return (
    <React.Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={4} md={9}></Grid>
          <Grid item xs={10} md={3}>
            <MuiPickersUtilsProvider
              utils={MomentUtils}
              className={classes.datePickerContainer}
            >
              <KeyboardDatePicker
                disableToolbar
                variant='inline'
                label='Year Filter:'
                views={['year']}
                value={moment(yearDate)}
                disableFuture
                onChange={(event) => {
                  //handleDateChange(event.format(yearFormat));
                  setYearDate(event.format(yearFormat));
                }}
                //onClose={handleDateChange}
                autoOk={true}
                minDate={minDate}
              />
            </MuiPickersUtilsProvider>
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Avg Contractor Invoice'}
              amount={dollarUSLocale?.format(
                Math.round(averageInvoicesClient?.data?.[0]?.data?.avg)
              )}
              loading={averageInvoicesClient?.loading}
              label={'$'}
            />
          </Grid>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Avg PES Invoice'}
              amount={dollarUSLocale?.format(
                Math.round(averageInvoicesClient?.data?.[1]?.data?.avg)
              )}
              loading={averageInvoicesClient?.loading}
              label={'$'}
            />
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Annual Savings'}
              amount={dollarUSLocale?.format(
                savingsClient?.data?.[0]?.data?.count
              )}
              loading={savingsClient?.loading}
              label={'$'}
            />
          </Grid>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Savings Current YTD'}
              amount={dollarUSLocale?.format(
                Math.round(savingsClient?.data?.[1]?.data?.count)?.toFixed(2)
              )}
              loading={savingsClient?.loading}
              label={'$'}
            />
          </Grid>
        </Grid>
      </Paper>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: { averageInvoicesClient, savingsClient },
}) => ({
  averageInvoicesClient,
  savingsClient,
});

const mapDispatchToProps = (dispatch) => ({
  getAverageInvoicesClient: bindActionCreators(
    getAverageInvoicesClient,
    dispatch
  ),
  getSavingsClient: bindActionCreators(getSavingsClient, dispatch),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(InvoiceClient)
);
