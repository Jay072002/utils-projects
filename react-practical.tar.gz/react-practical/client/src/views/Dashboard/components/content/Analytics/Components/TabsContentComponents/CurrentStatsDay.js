import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';
import ColorToggleButton from '../../../../../../../Components/ToggleButton';

import { Grid, makeStyles, Typography, Paper, Button } from '@material-ui/core';

import {
  getWorkInProgress,
  getCSIncidentsSince8,
  getCSDailyBusinessHours,
  getCSDailyAfterHours,
  getTrackingFileIncidents,
  getIncidentsCompletionTypeStatuses,
  getPMList,
  getCurrentProjectCount,
  getSpillsBroughtIntoOffice,
  getDigsScheduledToday,
  getNonTrackingWithWorkInProgress,
  getNonTrackingFilesWIP,
  getDailyWeeklyGisMap,
  getPMOpenIncidents,
  getCSIncidentsTakenHome,
} from '../../../../../../../actionCreators/Analytics';
import SingleStatChart from '../../../../../../../Components/SingleStatChart';
import ReactSelect from 'react-select';
import { endOfWeek } from 'date-fns';
import { startOfWeek } from 'date-fns/esm';
import moment from 'moment';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from '@material-ui/pickers';
import MomentUtils from '@date-io/moment';
import WeekPicker from '../../../../../../../Components/WeekPicker';
import BarChartWithRise from '../../../../../../../Components/BarChartWithRise';
const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
  },
  amountHeading: {
    fontSize: '35px',
    fontWeight: '600',
    color: '#434343',
  },
  insideCard: {
    width: '50%',
    margin: '0 auto',
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 0%), 0px 8px 10px 1px rgb(0 0 0 / 0%), 0px 3px 14px 2px rgb(0 0 0 / 0%)',
    marginTop: '24px',
    border: '1px solid #ededed',
  },
  chartHeadingFix: {
    fontSize: '15px',
    color: '#212121',
    textAlign: 'center',
    marginTop: '3px',
    marginBottom: '2px',
  },
  gisContainer: {
    marginTop: '10px',
  },
}));

const contractorColorStyles = (ignorePadding) => {
  return {
    control: (styles) => ({ ...styles, backgroundColor: 'white' }),
    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
      return {
        fontWeight: data.isCategory && 'bolder',
        ...styles,
        cursor: isFocused && 'pointer',
        backgroundColor: isFocused ? '#31bc3687' : 'unset',
        borderBottom: '1px solid white',
        transition: 'all 0.4s',
        paddingLeft: !data.isCategory && !ignorePadding && 40,
        color: isSelected && 'black',
      };
    },
  };
};

const CurrentStats = ({
  workInProgress,
  getWorkInProgress,
  csIncidentsSince8,
  getCSIncidentsSince8,
  csDailyBusinessHours,
  csDailyAfterHours,
  nonTrackingFilesWIP,
  getCSDailyBusinessHours,
  getCSDailyAfterHours,
  getTrackingFileIncidents,
  trackingFileIncidents,
  getCurrentProjectCount,
  currentProjectCount,
  getPMList,
  pmList,
  getSpillsBroughtIntoOffice,
  spillsBroughtIntoOffice,
  getDigsScheduledToday,
  digsScheduledToday,
  getNonTrackingWithWorkInProgress,
  nonTrackingWithWorkInProgress,
  getNonTrackingFilesWIP,
  getPMOpenIncidents,
  pmOpenIncidents,
  getDailyWeeklyGisMap,
  dailyWeeklyGisMap,
  csIncidentsTakenHome,
  getCSIncidentsTakenHome,
}) => {
  const classes = Styles();
  const [projectManagerOptions, setProjectManagerOptions] =
    React.useState(null);
  const [currentProjectManager, setCurrentProjectManager] =
    React.useState(null);

  const minDate = '2011-01';
  const dateFormat = 'MM-DD-YYYY';
  const toggleItems = [
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
  ];

  const getCurrentWeek = () => {
    const currentMonth = moment(new Date()).format('M');
    let startDate = moment(startOfWeek(new Date()));
    let endDate = moment(endOfWeek(new Date())).add(2, 'days'); //for next monday,moment consider sat as last day of week
    if (startDate.format('M') !== currentMonth)
      startDate = moment().startOf('month');
    if (endDate.format('M') !== currentMonth) endDate = moment().endOf('month');
    return {
      fromDate: startDate.toDate(),
      endDate: endDate.toDate(),
    };
  };
  const handleChangeDate = ({ fromDate, endDate }) => {
    //trigger on date picker for daily/weekly and dispatch request
    const dateRange = {
      startDate: moment(fromDate).format('MM-DD-YYYY'),
      endDate: [undefined, null].includes(endDate)
        ? endDate
        : moment(endDate).format('MM-DD-YYYY'),
    };
    //make dispatch function
    getDailyWeeklyGisMap({ ...dateRange });
  };
  const getValueOfToggle = (val) => {
    //handle the toggle state for parent
    setToggleValue(val);
  };
  const handleDailyWeeklyToggleDefault = () => {
    if (toggleValue === 'weekly') {
      handleChangeDate(getCurrentWeek());
    } else {
      handleChangeDate({ fromDate: moment()?.format(dateFormat) });
    }
  };

  const [toggleValue, setToggleValue] = React.useState('daily');
  const [targetDate, setTargetDate] = React.useState(
    moment(new Date()).format('MM-DD-YYYY')
  );

  React.useEffect(() => {
    getWorkInProgress();
    getCSIncidentsSince8();
    getCSDailyAfterHours();
    getCSDailyBusinessHours();
    getCSIncidentsTakenHome();
    getPMList();
    getTrackingFileIncidents();
    getSpillsBroughtIntoOffice();
    getDigsScheduledToday();
    getNonTrackingWithWorkInProgress();
    getNonTrackingFilesWIP();
  }, []);

  React.useEffect(() => {
    setProjectManagerOptions(
      pmList?.data?.map((x) => ({ label: x?.full_name, value: x?.id }))
    );
    if (pmList?.data) {
      getCurrentProjectCount(pmList?.data[0]?.id);
      getPMOpenIncidents(pmList?.data[0]?.id);
    }
  }, [pmList]);

  const handlePMChange = () => {
    getCurrentProjectCount(currentProjectManager?.value);
    getPMOpenIncidents(currentProjectManager?.value);
  };

  React.useEffect(() => {
    //use for dispatching default request on change of toggle
    handleDailyWeeklyToggleDefault();
  }, [toggleValue]);

  return (
    <React.Fragment>
      <Grid container spacing={4}>
        <Grid item xs={6} md={6}>
          <Typography className={classes.analyticsHeading}>
            Current Stats
          </Typography>
        </Grid>
        <Grid item xs={6} md={6} className={classes.datePickerContainer}></Grid>
      </Grid>
      <Grid container spacing={4}>
        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Tracking Files Incidents'}
            amount={trackingFileIncidents?.data?.data?.count}
            loading={trackingFileIncidents?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Brought Into Office at 8:00 A.M.'}
            amount={spillsBroughtIntoOffice?.data?.data?.count}
            loading={spillsBroughtIntoOffice?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Digs Scheduled Today'}
            amount={digsScheduledToday?.data?.data?.count}
            loading={digsScheduledToday?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>
        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Non Tracking with Work in progess'}
            amount={nonTrackingWithWorkInProgress?.data?.data?.count}
            loading={nonTrackingWithWorkInProgress?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>

        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Incidents during Business Hours'}
            amount={csDailyBusinessHours?.data?.data?.count}
            loading={csDailyBusinessHours?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>

        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Incidents during After Hours'}
            amount={csDailyAfterHours?.data?.data?.count}
            loading={csDailyAfterHours?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>

        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Incidents Since 8:00 A.M.'}
            amount={csIncidentsSince8?.data?.data?.count}
            loading={csIncidentsSince8?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>

        <Grid item xs={12} md={6} lg={6} xl={6}>
          <SingleStatChart
            title={'Incidents Taken Home'}
            amount={csIncidentsTakenHome?.data?.data?.count}
            loading={csIncidentsTakenHome?.loading}
            cssAdjustment={1}
            // status={singleStatChartIncreasingData.status}
          />
        </Grid>
        {/*  */}
        <Grid container spacing={4}>
          <Grid item xs={12} md={12} lg={12} xl={12}>
            {[undefined, null].includes(projectManagerOptions) || (
              <div
                style={{
                  color: 'black',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  margin: '5px',
                }}
              >
                <div style={{ width: '100%' }}>
                  <Typography className={classes.chartHeadingFix}>
                    {`Project Manager`}
                  </Typography>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      width: '100%',
                      justifyContent: 'space-between',
                    }}
                  >
                    <div style={{ width: '90%' }}>
                      <ReactSelect
                        placeholder='Project Manager'
                        value={
                          [undefined, null].includes(currentProjectManager)
                            ? projectManagerOptions[0]
                            : currentProjectManager
                        }
                        isMulti={false}
                        onChange={setCurrentProjectManager}
                        styles={contractorColorStyles()}
                        closeMenuOnSelect
                        isLoading={[undefined, null].includes(
                          projectManagerOptions
                        )}
                        // defaultValue={projectManagerOptions[0]}
                        style={{ minWidth: '850px' }}
                        options={projectManagerOptions}
                      />
                    </div>
                    <Button
                      color='primary'
                      variant='contained'
                      onClick={() => handlePMChange()}
                      style={{ minWidth: '8%' }}
                    >
                      Apply
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Current Projects'}
              amount={currentProjectCount?.data?.data?.count}
              loading={currentProjectCount?.loading}
              cssAdjustment={1}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Open Incidents'}
              amount={pmOpenIncidents?.data?.data?.count}
              loading={pmOpenIncidents?.loading}
              cssAdjustment={1}
            />
          </Grid>
        </Grid>
        {/*  */}

        {/* <Grid item xs={6} md={12} className={classes.datePickerContainer}>
          <ColorToggleButton
            initialValue={'daily'}
            getValue={getValueOfToggle}
            items={toggleItems}
          />
        </Grid> */}

        <Grid container spacing={4} className={classes.gisContainer}>
          {/* button and date picker */}
          <Grid
            xs={6}
            sm={9}
            md={9}
            lg={9}
            xl={9}
            className={classes.marginSelect}
          ></Grid>
          <Grid item xs={12} md={3}>
            <div className={classes.datesTypeWrapper}>
              {toggleValue === toggleItems[0]?.value && (
                <MuiPickersUtilsProvider
                  utils={MomentUtils}
                  className={classes.datePickerContainer}
                >
                  <KeyboardDatePicker
                    disableToolbar
                    variant='inline'
                    label='Date Filter:'
                    views={['year', 'month', 'date']}
                    value={targetDate}
                    disableFuture
                    onChange={(event) => {
                      setTargetDate(event.format(dateFormat));
                      handleChangeDate({
                        fromDate: event.format(dateFormat),
                      });
                    }}
                    //onClose={handleDateChange}
                    autoOk={true}
                    minDate={minDate}
                  />
                </MuiPickersUtilsProvider>
              )}
              {toggleValue === toggleItems[1]?.value && (
                <WeekPicker
                  getRangeOfDate={handleChangeDate}
                  minDate={minDate}
                />
              )}
            </div>
          </Grid>
          <Grid item xs={12} md={12} lg={12} xl={12}>
            {toggleValue === 'daily' ? (
              <SingleStatChart
                title={'Daily Number of Gis Map'}
                amount={
                  Array.isArray(dailyWeeklyGisMap?.data?.data?.count)
                    ? undefined
                    : dailyWeeklyGisMap?.data?.data?.count
                }
                loading={dailyWeeklyGisMap?.loading}
                cssAdjustment={1}
              />
            ) : (
              <BarChartWithRise
                title='Weekly Numbers of Gis Map'
                data={
                  Array.isArray(dailyWeeklyGisMap?.data?.data?.count)
                    ? dailyWeeklyGisMap?.data?.data?.count
                        ?.map((x, index) => {
                          if (index > 0 && x?.day === 'Mon') return null;
                          return {
                            day: `${x?.day}`,
                            count: x?.count,
                            value: x?.count,
                          };
                        })
                        ?.filter((x) => x)
                    : [
                        {
                          day: 'Mon',
                          count: 0,
                          value: 0,
                        },
                      ]
                }
                loading={dailyWeeklyGisMap?.loading}
                initialData={[
                  {
                    day: 'Mon',
                    count: 0,
                    value: 0,
                  },
                ]}
                xLabel={'day'}
                yLabel={'value'}
                minValue={0}
              />
            )}
          </Grid>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: {
    workInProgress,
    csIncidentsSince8,
    csDailyAfterHours,
    csDailyBusinessHours,
    currentProjectCount,
    pmList,
    trackingFileIncidents,
    spillsBroughtIntoOffice,
    digsScheduledToday,
    nonTrackingWithWorkInProgress,
    nonTrackingFilesWIP,
    pmOpenIncidents,
    dailyWeeklyGisMap,
    csIncidentsTakenHome,
  },
}) => ({
  workInProgress,
  csIncidentsSince8,
  csDailyAfterHours,
  csDailyBusinessHours,
  currentProjectCount,
  pmList,
  trackingFileIncidents,
  spillsBroughtIntoOffice,
  digsScheduledToday,
  nonTrackingWithWorkInProgress,
  nonTrackingFilesWIP,
  pmOpenIncidents,
  dailyWeeklyGisMap,
  csIncidentsTakenHome,
});

const mapDispatchToProps = (dispatch) => ({
  getWorkInProgress: bindActionCreators(getWorkInProgress, dispatch),
  getCSIncidentsSince8: bindActionCreators(getCSIncidentsSince8, dispatch),
  getCSDailyAfterHours: bindActionCreators(getCSDailyAfterHours, dispatch),
  getCSDailyBusinessHours: bindActionCreators(
    getCSDailyBusinessHours,
    dispatch
  ),
  getPMList: bindActionCreators(getPMList, dispatch),
  getCurrentProjectCount: bindActionCreators(getCurrentProjectCount, dispatch),
  getTrackingFileIncidents: bindActionCreators(
    getTrackingFileIncidents,
    dispatch
  ),
  getSpillsBroughtIntoOffice: bindActionCreators(
    getSpillsBroughtIntoOffice,
    dispatch
  ),
  getDigsScheduledToday: bindActionCreators(getDigsScheduledToday, dispatch),
  getNonTrackingWithWorkInProgress: bindActionCreators(
    getNonTrackingWithWorkInProgress,
    dispatch
  ),
  getNonTrackingFilesWIP: bindActionCreators(getNonTrackingFilesWIP, dispatch),
  getDailyWeeklyGisMap: bindActionCreators(getDailyWeeklyGisMap, dispatch),
  getPMOpenIncidents: bindActionCreators(getPMOpenIncidents, dispatch),
  getCSIncidentsTakenHome: bindActionCreators(
    getCSIncidentsTakenHome,
    dispatch
  ),
});

CurrentStats.prototype = {
  workInProgress: PropTypes.object.isRequired,
  getWorkInProgress: PropTypes.func.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CurrentStats)
);

/**
 * Single Count Component
 * Bar Component
 */
