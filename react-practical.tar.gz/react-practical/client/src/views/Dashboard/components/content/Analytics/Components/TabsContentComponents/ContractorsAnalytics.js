import { Button, Grid, makeStyles, Paper, Typography } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import ReactSelect from 'react-select';

import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as contractorAction from '../../../../../../../actionCreators/Contractor';
import * as clientActions from '../../../../../../../actionCreators/Client';

import {
  convertToGroupedOptions,
  filterOption,
  getContractorOptions,
  isContractorUser,
  isCorporateUser,
  orderAlphabaticallyByKey as orderAlphabeticallyByKey,
  ROLES,
} from '../../../../../../../utils';

import * as analyticActions from '../../../../../../../actionCreators/Analytics';
import SingleStatChart from '../../../../../../../Components/SingleStatChart';
const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  marginSelect: {
    marginTop: '12px',
  },
  filterIcon: {
    color: '#ffffffff',
    backgroundColor: '#397d33',
    fontSize: '40px',
    padding: '12px',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  filterBox: {
    textAlign: 'left',
    marginTop: '12px',
  },
  filterButtonSelect: {
    // textAlign: 'right',
    padding: '20px',
  },
}));

const ContractorsAnalytics = ({
  contractorsWithAddress,
  clientChildren,
  currentUser,
  getContractorsWithAddress,
  clientOrganizationNames,
  loadingContractors,
  admins,
  organizationAdmins,
  getAllContractorTurnUsDown,
  allContractorTurnUsDown,
  getResponsePercentageContractors,
  responsePercentageContractors,
  particularContractorTurnedUsDown,
  getParticularContractorTurnedUsDown,
}) => {
  const [selectedContractors, setSelectedContractors] = React.useState({});
  const [contractorOptions, setContractorOptions] = React.useState([]);
  const userRole = currentUser?.data?.role.role;
  React.useEffect(() => {
    setSelectedContractors({});
    getContractorsWithAddress();
    getResponsePercentageContractors();
    getAllContractorTurnUsDown();
    getParticularContractorTurnedUsDown({ contractorId: '1' });
    // getOrganizationNames();
  }, []);
  React.useEffect(() => {
    let newContractors = getContractorOptions(contractorsWithAddress.data);
    if ([9, 10].includes(currentUser.data?.role_id)) {
      newContractors = newContractors.filter(
        (singleContractor) =>
          singleContractor.name === currentUser.data?.contractor?.name
      );
    }
    setSelectedContractors(convertToGroupedOptions(newContractors)?.[0]);
    setContractorOptions(convertToGroupedOptions(newContractors));
  }, [contractorsWithAddress]);

  const classes = Styles();

  const organizationNames = clientOrganizationNames.data;
  const organizationChildren = clientChildren.data;
  const managerNames = admins.data;
  const organizationManagerNames = organizationAdmins.data;

  let organizations = [];
  let managers = [];

  if (isCorporateUser(userRole) && userRole !== ROLES.CORPORATE_USER) {
    const organizationChildOptions = organizationChildren.map(
      (organization) => {
        const value = { value: organization.id, label: organization.name };
        const allOptions = { ...value };

        return allOptions;
      }
    );

    organizations = organizationChildOptions;
  } else if (userRole === ROLES.CORPORATE_USER) {
    const organizationFilter = organizationChildren.filter((organization) => {
      const org = organization.id === currentUser.data.org_id;

      return org;
    });

    const organizationOptions = organizationFilter.map((organization) => {
      const value = { value: organization.id, label: organization.name };
      const allOptions = { ...value };

      return allOptions;
    });

    organizations = organizationOptions;
  } else {
    const organizationOptions = organizationNames.map((organization) => {
      const value = { value: organization.id, label: organization.name };
      const allOptions = { ...value };

      return allOptions;
    });

    organizations = organizationOptions;
  }

  if (isCorporateUser(userRole)) {
    const managerOptions = organizationManagerNames.map((manager) => {
      const value = { value: manager.id, label: manager.full_name };
      const allOptions = { ...value };

      return allOptions;
    });

    managers = managerOptions;
  } else {
    const managerOptions = managerNames.map((manager) => {
      const value = { value: manager.id, label: manager.full_name };
      const allOptions = { ...value };

      return allOptions;
    });

    managers = managerOptions;
  }

  const onContractorSelectChange = (item) => {
    setSelectedContractors({ ...item });
  };

  const clickFilterHandler = () => {
    if (selectedContractors?.addressId) {
      getResponsePercentageContractors({
        subContractorId: selectedContractors?.addressId,
      });
      getParticularContractorTurnedUsDown({
        subContractorId: selectedContractors?.addressId,
      });
      return;
    } else {
      getResponsePercentageContractors({
        contractorId: selectedContractors?.contractor_id,
      });
      getParticularContractorTurnedUsDown({
        contractorId: selectedContractors?.contractor_id,
      });
    }
  };
  return (
    <React.Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <Typography className={classes.analyticsHeading}>
              Contractors
            </Typography>
          </Grid>
        </Grid>
        <Grid container spacing={4} alignItems='center'>
          <Grid xs={12} md={3} className={classes.marginSelect}></Grid>
        </Grid>

        <Grid container spacing={4} alignItems='center'>
          <Grid item xs={12} md={10} className={classes.marginSelect}>
            <ReactSelect
              placeholder='Contractors'
              value={selectedContractors}
              defaultValue={{ ...contractorOptions[0]?.label }}
              isMulti={false}
              isClearable={true}
              onChange={onContractorSelectChange}
              filterOption={filterOption}
              options={contractorOptions}
              styles={contractorColorStyles()}
              closeMenuOnSelect
              isLoading={loadingContractors}
            />
          </Grid>
          <Grid className={classes.marginSelect} md={2} xs={12}>
            <div className={classes.filterButtonSelect}>
              <Button
                color='primary'
                variant='contained'
                onClick={() => clickFilterHandler()}
              >
                Apply
              </Button>
            </div>
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'All Contractor Turned Us Down'}
              amount={allContractorTurnUsDown?.data?.data?.count}
              loading={allContractorTurnUsDown?.loading}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Particular Contractor Turned Us Down'}
              amount={particularContractorTurnedUsDown?.data?.data?.count}
              loading={particularContractorTurnedUsDown?.loading}
            />
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Response % On Both Scenarios'}
              amount={responsePercentageContractors?.data?.data?.percentage}
              loading={responsePercentageContractors?.loading}
              label={'%'}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Response % of Particular Contractor'}
              amount={
                responsePercentageContractors?.data?.data
                  ?.specificContractorPercentage
              }
              loading={responsePercentageContractors?.loading}
              label={'%'}
            />
          </Grid>
        </Grid>
      </Paper>
    </React.Fragment>
  );
};
const mapStateToProps = ({
  analytics: {
    allContractorTurnUsDown,
    responsePercentageContractors,
    particularContractorTurnedUsDown,
  },
  contractor,
  client,
  user,
}) => ({
  admins: user.admins,
  organizationAdmins: user.organizationAdmins,
  contractorsWithAddress: contractor.contractorsWithAddress,
  clientChildren: client.clientChildren,
  currentUser: user.currentUser,
  loadingContractors: contractor.loading,
  clientOrganizationNames: client.clientOrganizationNames,
  clientOrganizationLoading: client.loading,
  allContractorTurnUsDown,
  particularContractorTurnedUsDown,
  responsePercentageContractors,
});

const mapDispatchToProps = (dispatch) => ({
  getContractorsWithAddress: bindActionCreators(
    contractorAction.getContractorsWithAddress,
    dispatch
  ),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  getAllContractorTurnUsDown: bindActionCreators(
    analyticActions.getAllContractorTurnUsDown,
    dispatch
  ),
  getResponsePercentageContractors: bindActionCreators(
    analyticActions.getResponsePercentageContractors,
    dispatch
  ),
  getParticularContractorTurnedUsDown: bindActionCreators(
    analyticActions.getParticularContractorTurnedUsDown,
    dispatch
  ),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ContractorsAnalytics)
);

const contractorColorStyles = (ignorePadding) => {
  return {
    control: (styles) => ({ ...styles, backgroundColor: 'white' }),
    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
      return {
        fontWeight: data.isCategory && 'bolder',
        ...styles,
        cursor: isFocused && 'pointer',
        backgroundColor: isFocused ? '#31bc3687' : 'unset',
        borderBottom: '1px solid white',
        transition: 'all 0.4s',
        paddingLeft: !data.isCategory && !ignorePadding && 40,
        color: isSelected && 'black',
      };
    },
  };
};
