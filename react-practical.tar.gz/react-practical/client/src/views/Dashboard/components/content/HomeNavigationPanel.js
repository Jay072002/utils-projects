import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Typography from "@material-ui/core/Typography";
import { Grid, ListItemIcon, List } from "@material-ui/core";
import ListItem from "@material-ui/core/ListItem";
import SpillImage from "../../../../assets/spill-image.jpg";
import ProfileImage from "../../../../assets/profile-image.png";
import AdminImage from "../../../../assets/admin-image.jpg";
import HomeIcon from "@material-ui/icons/Home";
import { withRouter } from "react-router-dom";
import StarIcon from "@material-ui/icons/Star";

const useStyles = makeStyles({
  root: {
    maxWidth: 280,
  },
  alignRight: {
    textAlign: "right",
  },
});

const Component = ({ history }) => {
  const classes = useStyles();

  return (
    <div>
      <Grid container spacing={4}>
        <Grid item xs={24} md={8}>
          <Typography variant="subtitle1" paragraph align="left">
            Welcome to Premium Environmental Services.
          </Typography>
          <Typography variant="subtitle2" paragraph align="left">
            This Spill-tracking site can help you...
            <List component="ul">
              <ListItem>
                {" "}
                <ListItemIcon>
                  <StarIcon style={{ color: "#619a63" }} />
                </ListItemIcon>
                Maintain local, state and federal compliance
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <StarIcon style={{ color: "#619a63" }} />
                </ListItemIcon>
                Track your cost savings
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <StarIcon style={{ color: "#619a63" }} />
                </ListItemIcon>
                Keep up to date on waste incidents
              </ListItem>
            </List>
          </Typography>
        </Grid>
        <Grid item xs={24} md={4} className={classes.alignRight}>
          <HomeIcon style={{ fontSize: "90px" }} />
        </Grid>
      </Grid>
      <Grid container spacing={4}>
        <Grid item xs={24} md={4}>
          <Card
            className={classes.root}
            onClick={() => history.push("/dashboard/spills")}
          >
            <CardActionArea>
              <CardMedia
                component="img"
                alt="Spills"
                height="140"
                image={SpillImage}
                title="Spills"
              />
              <CardContent>
                <Typography gutterBottom variant="h5" component="h2">
                  Spills
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Spill Incident Management Portal
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
        <Grid item xs={24} md={4}>
          <Card
            className={classes.root}
            onClick={() => history.push("/dashboard/admin")}
          >
            <CardActionArea>
              <CardMedia
                component="img"
                alt="Admin"
                height="140"
                image={AdminImage}
                title="Admin"
              />
              <CardContent>
                <Typography gutterBottom variant="h5" component="h2">
                  Admin
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Agencies, Contractors, Users Management
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
        <Grid item xs={24} md={4}>
          {" "}
          <Card
            className={classes.root}
            onClick={() => history.push("/dashboard/profile")}
          >
            <CardActionArea>
              <CardMedia
                component="img"
                alt="My Profile"
                height="140"
                image={ProfileImage}
                title="My Profile"
              />
              <CardContent>
                <Typography gutterBottom variant="h5" component="h2">
                  My Profile
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Your profile view and update management portal
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
      </Grid>
    </div>
  );
};

export default withRouter(Component);
