import { Grid, makeStyles, Paper, Typography } from '@material-ui/core';
import React, { Fragment, useEffect, useState } from 'react';
import WeekPicker from '../../../../../../../Components/WeekPicker';
import ColorToggleButton from '../../../../../../../Components/ToggleButton';

import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import MomentUtils from '@date-io/moment';
import {
  getBusinessHoursSpills,
  getCurrentDailyTotal,
  getAveragePerDayPerWeek,
  getCurrentMonthSpillsProjection,
  getSpillsOnEachWeek,
  getSpillsOnEachWorkday,
  getSpillStatusCount,
  getWeeklySpillCountForAMonth,
  getAfterHoursSpills,
} from '../../../../../../../actionCreators/Analytics';
import { endOfWeek } from 'date-fns';
import { startOfWeek } from 'date-fns/esm';
import moment from 'moment';
import BarChartWithRise from '../../../../../../../Components/BarChartWithRise';
import SingleStatChart from '../../../../../../../Components/SingleStatChart';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from '@material-ui/pickers';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
}));

const DailySpillsAnalytics = ({
  businessHoursSpills,
  getBusinessHoursSpills,
  currentDailyTotal,
  getCurrentDailyTotal,
  spillsOnEachWorkDay,
  getSpillsOnEachWorkday,
  getSpillsOnEachWeek,
  spillsOnEachWeek,
  spillStatusCount,
  getSpillStatusCount,
  getCurrentMonthSpillsProjection,
  currentMonthSpillProjection,
  averagePerDayPerWeek,
  getAveragePerDayPerWeek,
  getWeeklySpillCountForAMonth,
  weeklySpillsForAMonth,
  afterHoursSpills,
  getAfterHoursSpills,
}) => {
  const monthFormat = 'YYYY-MM';

  let value = new Date();
  let firstday = moment(
    new Date(value.setDate(value.getDate() - value.getDay() + 1))
  ).format('YYYY-MM-DD');
  let firstDayObj = new Date(firstday);
  let lastDay = moment(
    new Date(firstDayObj.setDate(firstDayObj.getDate() + 7))
  ).format('YYYY-MM-DD');

  const lastDayMonth = lastDay.split('-')[1];
  const firstDayMonth = firstday.split('-')[1];

  if (lastDayMonth > firstDayMonth) {
    lastDay = moment(firstday).endOf('month').format('YYYY-MM-DD');
  }

  const dateRange = {
    startDate: firstday,
    endDate: lastDay,
  };
  const minDate = '2011-01';

  const [monthlyDate, setMonthlyDate] = useState(moment()?.format(monthFormat));

  useEffect(() => {
    getCurrentDailyTotal();
    getAfterHoursSpills();
    getSpillsOnEachWorkday({ ...dateRange });
    getSpillsOnEachWeek({ ...dateRange });
    getAveragePerDayPerWeek({ ...dateRange });
    getSpillStatusCount({ year: moment().format('YYYY') });
    getCurrentMonthSpillsProjection();
    getBusinessHoursSpills();
  }, []);

  useEffect(() => {
    getWeeklySpillCountForAMonth({ month: monthlyDate });
  }, [monthlyDate]);

  const getRangeOfDate = ({ fromDate, endDate }) => {
    const dateRange = {
      startDate: moment(fromDate).format('YYYY-MM-DD'),
      endDate: moment(endDate).format('YYYY-MM-DD'),
    };
    getSpillsOnEachWorkday({ ...dateRange });
    getSpillsOnEachWeek({ ...dateRange });
    getAveragePerDayPerWeek({ ...dateRange });
    getSpillStatusCount({ year: moment(fromDate).format('YYYY') });
  };
  const [toggleValue, setToggleValue] = useState('daily');
  const classes = Styles();

  const getValueOfToggle = (val) => {
    setToggleValue(val);
  };

  const toggleItems = [
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
  ];
  const getAveragePerMonth = () => {
    const count = Math.floor(
      spillStatusCount?.data?.statusCount?.filter(
        (item) => item.status === 'Average per month'
      )[0].average
    );
    return Math.floor(count);
  };
  const getAverageSpillsPerDay = () => {
    const result = Math.floor(averagePerDayPerWeek?.data?.[0]?.avgPerDay);
    if (!isNaN(result)) {
      return result;
    } else {
      return 0;
    }
  };
  const getAverageSpillsPerWeek = () => {
    const result = Math.floor(averagePerDayPerWeek?.data?.[1]?.avgPerWeek);
    if (!isNaN(result)) {
      return result;
    } else {
      return 0;
    }
  };
  const getProjectedSpillsForMonth = () => {
    const result = Math.floor(currentMonthSpillProjection?.data);
    if (!isNaN(result)) {
      return result;
    } else {
      return 0;
    }
  };
  return (
    <Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <Typography className={classes.analyticsHeading}>
              Daily Spills Analytics
            </Typography>
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Current Daily Total'}
              amount={currentDailyTotal?.data?.data.count}
              loading={currentDailyTotal?.loading}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Business Hour'}
              amount={businessHoursSpills?.data?.data.count}
              loading={businessHoursSpills?.loading}
              // status={currentVsPreviousYearSpills?.data?.status?.toLowerCase()}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Average Spills Per Week'}
              amount={getAverageSpillsPerWeek()}
              loading={averagePerDayPerWeek?.loading}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Average Spills Per Day'}
              amount={getAverageSpillsPerDay()}
              loading={averagePerDayPerWeek?.loading}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'Projected Spills For Month'}
              amount={getProjectedSpillsForMonth()}
              loading={currentMonthSpillProjection?.loading}
              // status={currentVsPreviousYearSpills?.data?.status?.toLowerCase()}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={6} xl={6}>
            <SingleStatChart
              title={'After Hour'}
              amount={afterHoursSpills?.data?.data.count}
              loading={afterHoursSpills?.loading}
              // status={currentVsPreviousYearSpills?.data?.status?.toLowerCase()}
            />
          </Grid>
        </Grid>
        <Grid
          container
          spacing={4}
          justifyContent='flex-end'
          direction='row'
          alignItems='center'
          className={classes.gridAlignEnd}
        >
          <Grid item xs={12} md={3}>
            <div className={classes.datesTypeWrapper}>
              {toggleValue === toggleItems[0]?.value && (
                <WeekPicker getRangeOfDate={getRangeOfDate} minDate={minDate} />
              )}
              {toggleValue === toggleItems[1]?.value && (
                <MuiPickersUtilsProvider
                  utils={MomentUtils}
                  className={classes.datePickerContainer}
                >
                  <KeyboardDatePicker
                    disableToolbar
                    variant='inline'
                    label='Date Filter:'
                    views={['month']}
                    value={moment(monthlyDate)}
                    disableFuture
                    onChange={(event) => {
                      setMonthlyDate(event.format(monthFormat));
                    }}
                    autoOk={true}
                  />
                </MuiPickersUtilsProvider>
              )}
            </div>
          </Grid>

          <Grid item xs={12} md={12} justifyContent='flex-end'>
            <ColorToggleButton
              initialValue={'daily'}
              getValue={getValueOfToggle}
              items={toggleItems}
            />
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={6} md={12}>
            {toggleValue === toggleItems[0]?.value && (
              <BarChartWithRise
                title='Spills Count Per Day In A Week (Week ~ Monday 8:00 AM - Monday 8:00 AM)'
                data={
                  !spillsOnEachWorkDay?.data?.message
                    ? spillsOnEachWorkDay?.data?.values
                    : [
                        {
                          day: 'Mon',
                          count: 0,
                          //value: 0,
                        },
                      ]
                }
                loading={spillsOnEachWorkDay?.loading}
                initialData={[
                  {
                    day: 'Mon',
                    count: 0,
                    //value: 0,
                  },
                ]}
                xLabel={'day'}
                yLabel={'value'}
                minValue={0}
              />
            )}
            {toggleValue === toggleItems[1]?.value && (
              <BarChartWithRise
                title={'Spills Count Per Week For Month'}
                data={
                  !weeklySpillsForAMonth?.data?.message
                    ? weeklySpillsForAMonth?.data?.values
                    : [{ week: 'One', count: 0,  }] 
                    //value: 0
                }
                loading={weeklySpillsForAMonth?.loading}
                initialData={[{ week: 'One', count: 0, }]}
                //value: 0 
                xLabel={'week'}
                yLabel={'value'}
                minValue={0}
              />
            )}
          </Grid>
        </Grid>
      </Paper>
    </Fragment>
  );
};
const mapStateToProps = ({
  analytics: {
    businessHoursSpills,
    currentDailyTotal,
    spillsOnEachWorkDay,
    spillsOnEachWeek,
    spillStatusCount,
    currentMonthSpillProjection,
    averagePerDayPerWeek,
    weeklySpillsForAMonth,
    afterHoursSpills,
  },
}) => ({
  businessHoursSpills,
  currentDailyTotal,
  spillsOnEachWorkDay,
  spillsOnEachWeek,
  spillStatusCount,
  currentMonthSpillProjection,
  averagePerDayPerWeek,
  weeklySpillsForAMonth,
  afterHoursSpills,
});

const mapDispatchToProps = (dispatch) => ({
  getCurrentDailyTotal: bindActionCreators(getCurrentDailyTotal, dispatch),
  getAfterHoursSpills: bindActionCreators(getAfterHoursSpills, dispatch),
  getSpillsOnEachWorkday: bindActionCreators(getSpillsOnEachWorkday, dispatch),
  getSpillsOnEachWeek: bindActionCreators(getSpillsOnEachWeek, dispatch),
  getSpillStatusCount: bindActionCreators(getSpillStatusCount, dispatch),
  getCurrentMonthSpillsProjection: bindActionCreators(
    getCurrentMonthSpillsProjection,
    dispatch
  ),
  getAveragePerDayPerWeek: bindActionCreators(
    getAveragePerDayPerWeek,
    dispatch
  ),
  getWeeklySpillCountForAMonth: bindActionCreators(
    getWeeklySpillCountForAMonth,
    dispatch
  ),
  getBusinessHoursSpills: bindActionCreators(getBusinessHoursSpills, dispatch),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(DailySpillsAnalytics)
);
