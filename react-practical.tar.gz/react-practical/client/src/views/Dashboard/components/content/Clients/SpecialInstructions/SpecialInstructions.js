import React from "react";

const SpecialInstructions = () => {
  return <div>SpecialInstructions</div>;
};

export default SpecialInstructions;
