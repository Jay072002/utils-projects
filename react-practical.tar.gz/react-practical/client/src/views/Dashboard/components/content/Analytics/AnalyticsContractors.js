import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import * as contractorAction from '../../../../../actionCreators/Contractor';
import * as clientActions from '../../../../../actionCreators/Client';
import {
  getCurrentYearSpills,
  getFetchSpillsStatusesCountRoleBased,
  getTurnedUsDownForContractor,
} from '../../../../../actionCreators/Analytics';
import React, { useState } from 'react';
import { Grid, makeStyles, Paper } from '@material-ui/core';
import BarChart from '../../../../../Components/BarChart';

import SingleStatChart from '../../../../../Components/SingleStatChart';
import BarChartWithRise from '../../../../../Components/BarChartWithRise';

import Typography from '@material-ui/core/Typography';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@material-ui/core';
import { useEffect } from 'react';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  marginSelect: {
    marginTop: '12px',
  },
  filterIcon: {
    color: '#ffffffff',
    backgroundColor: '#397d33',
    fontSize: '40px',
    padding: '12px',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  filterBox: {
    textAlign: 'left',
    marginTop: '12px',
  },
  filterButtonSelect: {
    // textAlign: 'right',
    padding: '20px',
  },
}));
const AnalyticsContractors = ({
  getCurrentYearSpills,
  currentYearSpills,
  getFetchSpillsStatusesCountRoleBased,
  fetchSpillsStatusesCountRoleBased,
  getTurnedUsDownForContractor,
  turnedUsDownForContractor,
  getContractorslocation,
  contractorsLocation,
  userCredentials,
}) => {
  const classes = Styles();
  const [barChartData, setBarChartData] = useState([
    [
      {
        status: 'Work In Progress',
        count: 0,
        value: 0,
      },
    ],
  ]);
  const [isAdmin, setIsAdmin] = useState(false);

  React.useEffect(() => {
    getCurrentYearSpills();
    getFetchSpillsStatusesCountRoleBased();
    getTurnedUsDownForContractor();
  }, []);

  React.useEffect(() => {
    if (userCredentials?.currentUser?.data?.role?.role === 'Contractor Admin') {
      getContractorslocation();
      setIsAdmin(true);
    }
  }, [userCredentials]);

  React.useEffect(() => {
    formattingDataForBarChart(fetchSpillsStatusesCountRoleBased?.data);
  }, [fetchSpillsStatusesCountRoleBased?.data]);

  const formattingDataForBarChart = (data) => {
    const requiredValues = [
      'Work In Progress',
      'Site Work Complete',
      'Extended Remediation',
      'Pending Excavation',
      'Pending Disposal',
      ' Documentation in Review',
      'Documentation Sent Back for Revisions',
    ];
    setBarChartData(
      data?.data
        ?.filter((item) => requiredValues.includes(item?.status))
        ?.map((item) => ({ ...item, value: item?.count }))
    );
  };

  return (
    <React.Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={12} md={12} lg={12} xl={12}>
            <Typography className={classes.analyticsHeading}>
              Spills Status Analysis
            </Typography>
          </Grid>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Current Year Spills to Date'}
              amount={currentYearSpills?.data?.NoOfSpills}
              loading={currentYearSpills?.loading}
              // status={singleStatChartIncreasingData.status}
            />
          </Grid>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Times Responded/Turned Us Down'}
              amount={turnedUsDownForContractor?.data?.data?.count}
              loading={turnedUsDownForContractor?.loading}
              // status={singleStatChartIncreasingData.status}
            />
          </Grid>
          <Grid item xs={12} md={12}>
            {isAdmin && contractorsLocation?.data && (
              <LocationResponseCountTable
                locationsRejectCounts={contractorsLocation?.data}
              />
            )}
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={12} lg={12} xl={12}>
            <BarChart
              title='Spills Status Count'
              data={barChartData || []}
              xLabel='status'
              yLabel='count'
              height={400}
              loading={fetchSpillsStatusesCountRoleBased?.loading}
            />
            {/* <BarChartWithRise
              title={
                'Monthly Difference of Current Month vs Previous Month @ Previous Year'
              }
              data={barChartData}
              loading={fetchSpillsStatusesCountRoleBased?.loading}
              initialData={barChartData}
              xLabel={'status'}
              yLabel={'value'}
              minValue={5}
            />{' '} */}
          </Grid>
        </Grid>
      </Paper>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: {
    spillsOnEachWorkDay,
    spillsOnEachWeek,
    spillStatusCount,
    currentMonthSpillProjection,
    averagePerDayPerWeek,
    currentYearSpills,
    fetchSpillsStatusesCountRoleBased,
    turnedUsDownForContractor,
  },
  contractor,
  client,
  user,
}) => ({
  admins: user.admins,
  organizationAdmins: user.organizationAdmins,
  spillsOnEachWorkDay,
  spillsOnEachWeek,
  spillStatusCount,
  currentMonthSpillProjection,
  averagePerDayPerWeek,
  contractorsWithAddress: contractor.contractorsWithAddress,
  clientChildren: client.clientChildren,
  currentUser: user.currentUser,
  loadingContractors: contractor.loading,
  clientOrganizationNames: client.clientOrganizationNames,
  clientOrganizationLoading: client.loading,
  currentYearSpills,
  fetchSpillsStatusesCountRoleBased,
  turnedUsDownForContractor,
  contractorsLocation: contractor.contractorsLocation,
  userCredentials: user,
});

const mapDispatchToProps = (dispatch) => ({
  getContractorslocation: bindActionCreators(
    contractorAction.getContractorsLocation,
    dispatch
  ),
  getContractorsWithAddress: bindActionCreators(
    contractorAction.getContractorsWithAddress,
    dispatch
  ),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  getFetchSpillsStatusesCountRoleBased: bindActionCreators(
    getFetchSpillsStatusesCountRoleBased,
    dispatch
  ),
  getCurrentYearSpills: bindActionCreators(getCurrentYearSpills, dispatch),
  getTurnedUsDownForContractor: bindActionCreators(
    getTurnedUsDownForContractor,
    dispatch
  ),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(AnalyticsContractors)
);

const LocationResponseCountTable = ({ locationsRejectCounts }) => {
  const [rows, setRows] = React.useState([]);

  const addRows = (rows) => {
    const mappedRows = rows.map((x) => ({
      location: x.address,
      count: x.reject_count,
    }));
    setRows(mappedRows);
  };

  React.useEffect(() => {
    addRows(locationsRejectCounts);
  }, [locationsRejectCounts]);

  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label='simple table'>
        <TableHead>
          <TableRow>
            <TableCell style={{ fontWeight: '700' }}>&nbsp;Locations</TableCell>
            <TableCell align='right' style={{ fontWeight: '700' }}>
              Turned Down &nbsp;
            </TableCell>
          </TableRow>
        </TableHead>
        {rows.length > 0 ? (
          <TableBody>
            {rows.map((row, index) => (
              <TableRow
                key={index}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell component='th' scope='row'>
                  &nbsp;{' '}
                  {row?.location ? row?.location : 'No Address Available'}
                </TableCell>
                <TableCell align='right'>
                  {row?.count ? row?.count : 0} &nbsp;
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        ) : (
          <TableBody
            style={{
              display: 'Flex',
              justifyContent: 'center',
              marginTop: '10px',
              marginBottom: '10px',
              paddingLeft: '10vw',
            }}
          >
            {'There are no locations avaliable.'}
          </TableBody>
        )}
      </Table>
    </TableContainer>
  );
};
