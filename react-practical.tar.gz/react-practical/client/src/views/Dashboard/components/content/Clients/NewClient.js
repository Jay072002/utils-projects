import React, { useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import ReactSelect from "react-select";
import { bindActionCreators } from "redux";
import { withRouter } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import Card from "@material-ui/core/Card";
import Button from "@material-ui/core/Button";
import Select from "@material-ui/core/Select";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Switch from "@material-ui/core/Switch";
import { green } from "@material-ui/core/colors";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import InputLabel from "@material-ui/core/InputLabel";
import CardContent from "@material-ui/core/CardContent";
import {
  AppBar,
  Divider,
  List,
  ListItem,
  Tabs,
  Tab,
  Checkbox,
  Snackbar,
  Container,
} from "@material-ui/core";
import { CustomSnackBar, MainAddressForm } from "../../../../../Components";
import * as clientActions from "../../../../../actionCreators/Client";
import { orderAlphabaticallyByKey, ROLES } from "../../../../../utils";
import Alert from "@material-ui/lab/Alert/Alert";
import Facilities from "./Facilities/Facilities";

const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: green[500],
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
  leftAlign: {
    textAlign: "left",
  },
  serviceLabel: {
    display: "flex",
    alignItems: "center",
  },
  root: {
    width: "100%",
    backgroundColor: theme.palette.background.paper,
    textTransform: "capitalize",
    padding: 0,
  },
  labelColor: {
    color: "#7F7F7F",
  },
  AddClientTabList: {
    fontSize: "16px",
    padding: "5px 5px 7px 5px",
    color: "#BACABA",
    cursor: "pointer",
    "&:active": {
      color: "#ffffff", // Change text color to white when button is active
    },
    "&:hover": {
      color: "#ffffff", // Change background color on hover
    },
    "&:focus": {
      color: "#ffffff", // Change background color on hover
    },
  },
  activeButton: {
    color: "#ffffff",
  },
}));

const NewClient = ({
  userRole,
  createNewClient,
  closeAddClientModal,
  clients,
  servicesData,
  salePersonsData,
  getOrganizationNames,
  clientObj,
}) => {
  const classes = useStyles();

  const [rate, setRate] = React.useState("");
  const [associatedClients, setAssociatedClients] = React.useState([]);
  const [associatedServices, setAssociatedServices] = React.useState([]);
  const [salePersons, setSalePersons] = React.useState([]);
  const [services, setServices] = React.useState([]);
  const [errorText, setErrorText] = React.useState("");
  const [associatedClientOptions, setAssociatedClientOptions] = React.useState(
    []
  );
  const [canSeeTimestamp, setCanSeeTimestamp] = React.useState(true);
  const [canSeeMonetary, setCanSeeMonetary] = React.useState(true);
  const [reqSubmitted, setReqSubmitted] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState(false);
  const [selectedTab, setSelectedTab] = useState(0);
  const [checkedIcs, setIcsChecked] = useState(false);
  const [inputValues, setInputValues] = useState({});
  const [whichTabToRender, setWhichTabToRender] = useState("NewClient");
  const [mainAddressFormData, setMainAddressFormData] = useState({
    address: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
    phone: "",
  });
  const [facilitiesAccordions, setFacilitiesAccordions] = React.useState([
    {
      id: 1,
      name: "",
      internal_id: "",
      generator_status: "",
      epa_id: "",
      address: "",
      region: "",
      phone_number: "",
    },
  ]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setInputValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };
  React.useEffect(() => {
    getOrganizationNames();
  }, []);

  React.useEffect(() => {
    if (servicesData?.services?.data) {
      const data = servicesData?.services?.data;

      setServices(data.filter((x) => x.active));
    }
  }, [servicesData]);

  React.useEffect(() => {
    if (salePersonsData?.data) {
      const data = salePersonsData?.data;

      setSalePersons(data);
    }
  }, [salePersonsData]);

  React.useEffect(() => {
    if (services) {
      let data = [];

      services.map((service) => {
        if (service.is_default) {
          const value = {
            value: service.id,
            label: service.name,
            type: "",
            rate: "",
          };
          data.push(value);
        }
      });

      setAssociatedServices(data);
    }
  }, [services]);

  React.useEffect(() => {
    let temp = clients?.data?.map((client) => {
      const value = {
        value: client.id,
        label: client.name,
        active: client.active,
      };
      const allOptions = { ...value };
      return allOptions;
    });
    setAssociatedClientOptions(temp.filter((x) => x.active));
  }, [clients]);

  const clientServicesOptions = services.map((service) => {
    const value = {
      value: service.id,
      label: service.name,
      type: "",
      rate: "",
    };
    const allOptions = { ...value };

    return allOptions;
  });

  const [selectedSalesPerson, setSelectedSalesPerson] = useState("");
  const handleSalesPersonChange = (event) => {
    setSelectedSalesPerson(event.target.value);
  };

  const [activeeSelect, setActiveSelect] = useState(true);
  const handleActiveChange = (event) => {
    setActiveSelect(event.target.value);
  };

  const validate = () => {
    if (
      (inputValues.paymentTerms > 1 && inputValues.paymentTerms < 100) ||
      inputValues.paymentTerms === ""
    ) {
      return [true];
    } else {
      return [false, "Value must be between 2 and 99"];
    }
  };

  const handleServicesSelect = async (data) => {
    setAssociatedServices(data);
  };

  const handleServiceChange = (id, key) => (event) => {
    let newAssociatedServices = [...associatedServices];

    let data = newAssociatedServices.findIndex((obj) => obj.value === id);

    newAssociatedServices[data][key] = event.target.value;

    if (key === "type") {
      if (event?.target?.value === "hourly") {
        newAssociatedServices[data]["rate"] =
          rate || newAssociatedServices[data]["rate"];
      } else {
        newAssociatedServices[data]["rate"] =
          newAssociatedServices[data]["rate"] || rate;
      }
    }

    newAssociatedServices[data]["type"] =
      newAssociatedServices[data]["type"] || "hourly";
    setAssociatedServices(newAssociatedServices);
  };

  const handleRateChange = (event) => {
    setRate(event?.target?.value);
    setAssociatedServices((val) =>
      val?.map((service) => {
        return {
          ...service,
          rate: service?.type ? service?.rate : event?.target?.value,
        };
      })
    );
  };

  const handleIcsChange = (event) => {
    setIcsChecked(event.target.checkedIcs);
  };
  // Function to hide the error message
  const hideError = () => {
    setErrorMessage("");
  };
  const validateForm = () => {
    const errors = {};
    if (!inputValues.name || inputValues.name?.trim() === "") {
      errors.name = "- Client Name should not be blank.";
    }
    if (!inputValues.taxId || inputValues.taxId?.trim() === "") {
      errors.taxId = "- Tax Id should not be blank.";
    }
    if (!inputValues.code || inputValues.code?.trim() === "") {
      errors.code = "- Code should not be blank.";
    }
    if (inputValues?.code) {
      const regEx = /^[0-9a-zA-Z]+$/;
      if (inputValues?.code?.trim()?.match(regEx) === null) {
        errors.code = "- Code: Please enter letters and numbers only.";
      }
    }
    if (!rate || rate?.trim() === "") {
      errors.rate = "- Rate should not be blank.";
    }
    if (!inputValues.paymentTerms || inputValues.paymentTerms?.trim() === "") {
      errors.paymentTerms = "- Payment Terms should not be blank.";
    }
    if (!selectedSalesPerson) {
      errors.selectedSalesPerson = "- Salesperson should not be blank.";
    }

    // Validate Accordions
    facilitiesAccordions.forEach((accordion, index) => {
      if (!accordion.name || accordion.name.trim() === "") {
        console.log("Name Should Not Be Blank");
        errors[`accordion${index + 1}`] = `- Name in Accordion ${
          index + 1
        } should not be blank.`;
      } else {
        const duplicateName = facilitiesAccordions
          .slice(0, index)
          .concat(facilitiesAccordions.slice(index + 1))
          .some(
            (otherAccordion) =>
              otherAccordion.name.trim().toLowerCase() ===
              accordion.name.trim().toLowerCase()
          );
        if (duplicateName) {
          console.log("Duplicate Name");
          errors[`accordion${index + 1}`] = `- Name in Accordion ${
            index + 1
          } should be unique.`;
        }
      }
    });

    const combinedMessage = [
      errors.name || "",
      errors.taxId || "",
      errors.code || "",
      errors.selectedSalesPerson || "",
      errors.rate || "",
      errors.paymentTerms || "",
      ...Object.values(errors),
    ]
      .filter((message) => message !== "")
      .join("\n");
    if (combinedMessage) {
      return combinedMessage;
    }
    const result = validate();
    if (!result[0]) {
      return "- Payment Terms Value must be between 2 and 99";
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    if (errors) {
      setErrorMessage(errors);
    } else {
      // remove the id field from the facilitiesAccordions
      const facilitiesAccordionsWithoutId = facilitiesAccordions.map(
        ({ id, ...rest }) => rest
      );

      let obj = {
        name: inputValues.name ? inputValues.name : "",
        salesPerson: selectedSalesPerson ? selectedSalesPerson : null,
        taxId: inputValues.taxId ? inputValues.taxId : "",
        code: inputValues.code ? inputValues.code?.trim() : "",
        active: activeeSelect ? activeeSelect : false,
        rate: rate,
        paymentTerms: inputValues.paymentTerms || "",
        associatedClients,
        associatedServices: associatedServices.map((service) => ({
          ...service,
          type: service.type || "hourly",
          rate: service.rate || rate,
        })),
        timestampVisibility: canSeeTimestamp,
        monetaryVisibility: canSeeMonetary,
        ...mainAddressFormData,
        facilities: facilitiesAccordionsWithoutId,
      };
      // createNewClient({ ...obj });
      // setReqSubmitted(true);
    }
  };

  React.useEffect(() => {
    if (!clientObj.loading && reqSubmitted) {
      if (!clientObj.error) {
        closeAddClientModal();
      } else {
        setErrorMessage(clientObj.error);
      }
      setReqSubmitted(false);
    }
  }, [clientObj.loading]);

  return (
    <React.Fragment>
      <Container
        style={{
          display: "flex",
          justifyContent: "left",
          backgroundColor: "#2F7D32",
          margin: "10px 0",
          gap: "10px",
        }}
      >
        <Button
          className={`${classes.AddClientTabList} ${
            whichTabToRender === "NewClient" ? classes.activeButton : ""
          }`}
          onClick={() => setWhichTabToRender("NewClient")}
        >
          NewClient
        </Button>
        <Button
          className={`${classes.AddClientTabList} ${
            whichTabToRender === "Facilities" ? classes.activeButton : ""
          }`}
          onClick={() => setWhichTabToRender("Facilities")}
        >
          Facilities
        </Button>
        <Button
          className={`${classes.AddClientTabList} ${
            whichTabToRender === "Contractors" ? classes.activeButton : ""
          }`}
          onClick={() => setWhichTabToRender("Contractors")}
        >
          Contractors
        </Button>
        <Button
          className={`${classes.AddClientTabList} ${
            whichTabToRender === "Special Instructions"
              ? classes.activeButton
              : ""
          }`}
          onClick={() => setWhichTabToRender("Special Instructions")}
        >
          Special Instructions
        </Button>
      </Container>
      <div style={{ display: clientObj.loading ? "none" : "unset" }}>
        <CustomSnackBar
          open={!!errorMessage}
          severity="error"
          snackBarMessage={errorMessage}
          onClose={hideError}
        />
        <div className={classes.paper}>
          <form onSubmit={handleSubmit} style={{ width: "100%" }}>
            {whichTabToRender === "NewClient" ? (
              <div className={selectedTab === 0 ? "" : "hidden"}>
                <>
                  <div
                    style={{
                      paddingLeft: 30,
                      paddingRight: 30,
                      paddingTop: 20,
                    }}
                  >
                    <Grid container spacing={3}>
                      <Grid item xs={12}>
                        <Grid
                          className={classes.nameFieldWrapper}
                          container
                          spacing={3}
                        >
                          <Grid item xs={6}>
                            <TextField
                              id="name"
                              name="name"
                              label="Name *"
                              fullWidth
                              autoComplete="name"
                              onChange={handleInputChange}
                              value={inputValues.name || ""}
                            />
                          </Grid>
                          {userRole === ROLES.SUPER_USER ? (
                            <Grid item xs={6} className={classes.leftAlign}>
                              <FormControlLabel
                                control={
                                  <Checkbox
                                    checked={checkedIcs}
                                    onChange={handleIcsChange}
                                    name="myCheckbox"
                                    className={classes.labelColor}
                                  />
                                }
                                label="is ICS Client?"
                              />
                            </Grid>
                          ) : null}
                        </Grid>
                      </Grid>
                      <Grid item xs={12} className={classes.leftAlign}>
                        <Typography
                          variant="subtitle"
                          gutterBottom
                          className={classes.labelColor}
                        >
                          Child Organizations
                        </Typography>
                        <ReactSelect
                          value={associatedClients}
                          isMulti
                          onChange={setAssociatedClients}
                          options={orderAlphabaticallyByKey(
                            associatedClientOptions
                          )}
                        />
                      </Grid>

                      <Grid item xs={6}>
                        <TextField
                          id="taxId"
                          name="taxId"
                          label="Tax Id *"
                          fullWidth
                          autoComplete="taxId"
                          onChange={handleInputChange}
                          value={inputValues.taxId || ""}
                        />
                      </Grid>

                      <Grid item xs={6}>
                        <TextField
                          id="code"
                          name="code"
                          label="Code *"
                          fullWidth
                          autoComplete="code"
                          onChange={handleInputChange}
                          value={inputValues.code || ""}
                        />
                      </Grid>

                      <Grid item xs={12} className={classes.leftAlign}>
                        <InputLabel
                          id="salesPerson-select-label"
                          className={classes.labelColor}
                        >
                          Salesperson
                        </InputLabel>
                        <Select
                          labelId="salesPerson-select-label"
                          id="salesPerson-select"
                          name="sales_person"
                          style={{ width: "100%" }}
                          onChange={(event) => {
                            handleSalesPersonChange(event);
                          }}
                          value={selectedSalesPerson}
                        >
                          {salePersons &&
                            orderAlphabaticallyByKey(
                              salePersons,
                              "full_name"
                            ).map((e) => {
                              return (
                                <MenuItem
                                  value={e.id}
                                >{`${e.full_name} (${e.client_organization.name}: ${e.role.role})`}</MenuItem>
                              );
                            })}
                        </Select>
                      </Grid>

                      <Grid item xs={6}>
                        <TextField
                          id="rate"
                          name="rate"
                          label="Rate"
                          fullWidth
                          autoComplete="rate"
                          onChange={handleRateChange}
                          value={rate}
                        />
                      </Grid>

                      <Grid item xs={6}>
                        <TextField
                          id="paymentTerms"
                          name="paymentTerms"
                          label="Payment Terms"
                          onChange={handleInputChange}
                          value={inputValues.paymentTerms || ""}
                          onBlur={() => {
                            const result = validate();
                            if (result[0]) {
                              setErrorText("");
                            } else {
                              setErrorText(result[1]);
                            }
                          }}
                          error={errorText ? true : false}
                          helperText={errorText || ""}
                          fullWidth
                          autoComplete="paymentTerms"
                        />
                      </Grid>

                      {userRole === ROLES.SUPER_USER ? (
                        <>
                          <Grid item xs={4} className={classes.leftAlign}>
                            <FormControlLabel
                              control={
                                <Switch
                                  checked={canSeeMonetary}
                                  onChange={(event) =>
                                    setCanSeeMonetary(event.target.checked)
                                  }
                                  name="monetaryAmountsVisibility"
                                  color="primary"
                                />
                              }
                              label="View Monetary Amounts"
                            />
                          </Grid>
                          <Grid item xs={8} className={classes.leftAlign}>
                            <FormControlLabel
                              control={
                                <Switch
                                  checked={canSeeTimestamp}
                                  onChange={(event) =>
                                    setCanSeeTimestamp(event.target.checked)
                                  }
                                  name="timeStampVisibile"
                                  color="primary"
                                />
                              }
                              label="View Timestamps"
                            />
                          </Grid>
                          <Grid item xs={12} className={classes.leftAlign}>
                            <Typography
                              variant="subtitle"
                              gutterBottom
                              className={classes.labelColor}
                            >
                              Services
                            </Typography>
                            <ReactSelect
                              value={associatedServices}
                              isMulti
                              onChange={(data) => handleServicesSelect(data)}
                              options={orderAlphabaticallyByKey(
                                clientServicesOptions
                              )}
                            />
                          </Grid>
                        </>
                      ) : null}

                      <Grid item xs={12}>
                        {associatedServices?.length > 0 ? (
                          <div>
                            <div>
                              <Card
                                className={classes.headerCard}
                                style={{
                                  margin: "15px 0px 0px 0px",
                                  width: "100%",
                                }}
                              >
                                <CardContent
                                  style={{
                                    padding: "10px",
                                    backgroundColor: "#e6e6e6d6",
                                    fontWeight: 600,
                                    color: "#6aa16c",
                                  }}
                                >
                                  <div
                                    style={{
                                      display: "flex",
                                      justifyContent: "space-between",
                                    }}
                                  ></div>
                                  <Grid container spacing={3}>
                                    <Grid item xs={6}>
                                      <div className={classes.leftAlign}>
                                        Service Name
                                      </div>
                                    </Grid>

                                    <Grid item xs={3}>
                                      <div className={classes.leftAlign}>
                                        Service Type
                                      </div>
                                    </Grid>
                                    <Grid item xs={3}>
                                      <div className={classes.leftAlign}>
                                        Rate
                                      </div>
                                    </Grid>
                                  </Grid>
                                </CardContent>
                              </Card>
                              {associatedServices &&
                                associatedServices.map((service, i) => (
                                  <List
                                    component="nav"
                                    className={classes.root}
                                    aria-label="mailbox folders"
                                  >
                                    <ListItem>
                                      <Grid container spacing={3}>
                                        <Grid
                                          item
                                          xs={6}
                                          className={classes.serviceLabel}
                                        >
                                          <div className={classes.leftAlign}>
                                            <span>{service.label}</span>
                                          </div>
                                        </Grid>
                                        <Grid item xs={3}>
                                          <div className={classes.leftAlign}>
                                            {
                                              <Select
                                                labelId="rate-type-select-label"
                                                id="rate-type-select"
                                                name="rateType"
                                                style={{ width: "100%" }}
                                                defaultValue={
                                                  service?.type || "hourly"
                                                }
                                                onChange={handleServiceChange(
                                                  service.value,
                                                  "type"
                                                )}
                                              >
                                                <MenuItem value={"fixed"}>
                                                  Fixed
                                                </MenuItem>
                                                <MenuItem value={"hourly"}>
                                                  Hourly
                                                </MenuItem>
                                              </Select>
                                            }
                                          </div>
                                        </Grid>
                                        <Grid item xs={3}>
                                          <div className={classes.leftAlign}>
                                            {
                                              <TextField
                                                id="rate"
                                                name="rate"
                                                type="number"
                                                fullWidth
                                                autoComplete="rate"
                                                value={
                                                  associatedServices[i].type
                                                    ? associatedServices[i].rate
                                                    : rate
                                                }
                                                onChange={handleServiceChange(
                                                  service.value,
                                                  "rate"
                                                )}
                                              />
                                            }
                                          </div>
                                        </Grid>
                                      </Grid>
                                    </ListItem>
                                    <Divider />
                                  </List>
                                ))}
                            </div>
                          </div>
                        ) : null}
                      </Grid>

                      <Grid item xs={6} className={classes.leftAlign}>
                        <InputLabel
                          id="active-select-label"
                          className={classes.labelColor}
                        >
                          Active *
                        </InputLabel>
                        <Select
                          labelId="active-select-label"
                          id="active-select"
                          name="active"
                          style={{ width: "100%" }}
                          defaultValue={true}
                          onChange={(event) => {
                            handleActiveChange(event);
                          }}
                          value={activeeSelect}
                        >
                          <MenuItem value={true}>True</MenuItem>
                          <MenuItem value={false}>False</MenuItem>
                        </Select>
                      </Grid>

                      <Grid item xs={12}>
                        <MainAddressForm
                          isOrg={true}
                          showResponsePills={true}
                          mainAddformData={mainAddressFormData}
                          onChange={setMainAddressFormData}
                        ></MainAddressForm>
                      </Grid>
                    </Grid>
                  </div>
                </>
              </div>
            ) : whichTabToRender === "Facilities" ? (
              <Facilities
                facilitiesAccordions={facilitiesAccordions}
                setFacilitiesAccordions={setFacilitiesAccordions}
              />
            ) : whichTabToRender === "Contractors" ? (
              <div>Contractors</div>
            ) : whichTabToRender === "Special Instructions" ? (
              <div>Special Instructions</div>
            ) : null}

            <Grid item xs={12} style={{ textAlign: "right" }}>
              <Button
                className={classes.button}
                variant="contained"
                color="primary"
                type="submit"
              >
                Create
              </Button>
              <Button
                className={classes.button}
                variant="contained"
                color="primary"
                onClick={() => closeAddClientModal()}
              >
                Cancel
              </Button>
            </Grid>
          </form>
        </div>
      </div>
    </React.Fragment>
  );
};

const mapStateToProps = ({ client }) => ({
  clients: client.clientOrganizationNames,
  clientObj: client,
});

const mapDispatchToProps = (dispatch) => ({
  createNewClient: bindActionCreators(clientActions.createNewClient, dispatch),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  deleteFacility: bindActionCreators(clientActions.deleteFacility, dispatch),
});

NewClient.prototype = {
  client: PropTypes.object.isRequired,
  createNewClient: PropTypes.func.isRequired,
  getOrganizationNames: PropTypes.func.isRequired,
  clients: PropTypes.object.isRequired,
  deleteFacility: PropTypes.object.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(NewClient)
);
