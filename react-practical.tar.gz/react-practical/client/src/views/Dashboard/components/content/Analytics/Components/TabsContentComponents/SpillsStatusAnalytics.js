import { Button, Grid, makeStyles, Paper, Typography } from '@material-ui/core';
import React, { useState, useEffect, useRef, Fragment } from 'react';
import ReactSelect from 'react-select';
import WeekPicker from '../../../../../../../Components/WeekPicker';
import ColorToggleButton from '../../../../../../../Components/ToggleButton';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as contractorAction from '../../../../../../../actionCreators/Contractor';
import * as clientActions from '../../../../../../../actionCreators/Client';
import * as analyticActions from '../../../../../../../actionCreators/Analytics';

import { endOfWeek } from 'date-fns';
import { startOfWeek } from 'date-fns/esm';
import moment from 'moment';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from '@material-ui/pickers';
import MomentUtils from '@date-io/moment';
import {
  convertToGroupedOptions,
  filterOption,
  getContractorOptions,
  isContractorUser,
  isCorporateUser,
  orderAlphabaticallyByKey as orderAlphabeticallyByKey,
  ROLES,
} from '../../../../../../../utils';
import { select } from 'redux-saga/effects';
import FilterListOutlinedIcon from '@material-ui/icons/FilterListOutlined';
import SpillsStatusAnalyticsYearly from './SpillsStatusAnalyticsYearly';
import SpillsStatusAnalyticsMonthly from './SpillsStatusAnalyticsMonthly';
import SpillsStatusAnalyticsWeekly from './SpillsStatusAnalyticsWeekly';
import SingleStatChart from '../../../../../../../Components/SingleStatChart';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  marginSelect: {
    marginTop: '12px',
  },
  filterIcon: {
    color: '#ffffffff',
    backgroundColor: '#397d33',
    fontSize: '40px',
    padding: '12px',
    borderRadius: '8px',
    cursor: 'pointer',
    marginLeft: '14px',
  },
  filterBox: {
    textAlign: 'left',
  },
  filterButtonSelect: {
    // textAlign: 'right',
    padding: '20px',
    marginTop: '19px',
  },
  filterButtonHeader: {
    fontSize: '14px',
    color: '#212121',
    textAlign: 'center',
  },
}));

const contractorColorStyles = (ignorePadding) => {
  return {
    control: (styles) => ({ ...styles, backgroundColor: 'white' }),
    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
      return {
        fontWeight: data.isCategory && 'bolder',
        ...styles,
        cursor: isFocused && 'pointer',
        backgroundColor: isFocused ? '#31bc3687' : 'unset',
        borderBottom: '1px solid white',
        transition: 'all 0.4s',
        paddingLeft: !data.isCategory && !ignorePadding && 40,
        color: isSelected && 'black',
      };
    },
  };
};

const SpillsStatusAnalytics = ({
  contractorsWithAddress,
  clientChildren,
  currentUser,
  getContractorsWithAddress,
  clientOrganizationNames,
  loadingContractors,
  getOrganizationNames,
  admins,
  organizationAdmins,
  clientOrganizationLoading,
  filteredSpillsStatusCount,
  getCurrentlyOpenSpills,
  currentlyOpenSpills,
  getCurrentlyOpenedSpillsInCurrentYear,
  currentOpenedSpillsInCurrentYear,
  getCurrentlyOpenedSpillsInPreviousYear,
  currentOpenedSpillsInPreviousYear,
  getSpillsClosedYTD,
  closedSpillsYTD,
  getCurrentlyClosedSpillsCurrentYear,
  currentlyClosedSpillsCurrentYear,
  getAvgDaysToCloseSpill,
  avgDaysToCloseSpill,
}) => {
  const monthFormat = 'YYYY-MM';
  const yearFormat = 'YYYY';
  const dateRange = {
    startDate: moment(startOfWeek(new Date()))
      .subtract(1, 'months')
      .format('MM-DD-YYYY'),
    endDate: moment(endOfWeek(new Date()))
      .subtract(1, 'months')
      .format('MM-DD-YYYY'),
  };
  const resetContractorSelectRef = useRef();
  const resetOrganizationSelectRef = useRef();
  const [yearDate, setYearDate] = useState(moment().format(yearFormat));
  const [monthlyDate, setMonthlyDate] = useState(moment()?.format(monthFormat));
  const [dateRangeState, setDateRangeState] = useState(dateRange);

  const [selectedContractors, setSelectedContractors] = useState({});
  const [contractorOptions, setContractorOptions] = useState([]);
  const [selectedOrganizations, setSelectedOrganizations] = useState({});
  const [openSpills, setOpenSpills] = useState({
    value: 0,
    error: null,
  });
  const [
    currentlyOpenedSpillsInCurrentYear,
    setCurrentlyOpenedSpillsInCurrentYear,
  ] = useState({
    value: 0,
    error: null,
  });
  const [
    currentlyOpenedSpillsInPreviousYear,
    setCurrentlyOpenedSpillsInPreviousYear,
  ] = useState({
    value: 0,
    error: null,
  });
  const [closedSpillsYearToDate, setClosedSpillsYearToDate] = useState({
    value: 0,
    error: null,
  });
  const [currentlyClosedSpillsThisYear, setCurrentlyClosedSpillsThisYear] =
    useState({
      value: 0,
      error: null,
    });
  const [averageDaysToCloseSpill, setAverageDaysToCloseSpill] = useState({
    value: 0,
    error: null,
  });
  const [filterStatus, setFilterStatus] = useState(false);
  const [filterValues, setFilterValues] = useState({});
  const userRole = currentUser?.data?.role.role;
  const minDate = '2011-01';
  useEffect(() => {
    //call to get contractors addresses
    getContractorsWithAddress();
    //get organization names
    getOrganizationNames();
    // get currently open spills
    getCurrentlyOpenSpills();
    // get currently opened spills in current year
    getCurrentlyOpenedSpillsInCurrentYear();
    // get currently opened spills in previous year
    getCurrentlyOpenedSpillsInPreviousYear();
    // get closed spills YTD
    getSpillsClosedYTD();
    // get closed spills opened this year
    getCurrentlyClosedSpillsCurrentYear();
    // get average days to close a spill
    getAvgDaysToCloseSpill();
  }, []);
  useEffect(() => {
    let newContractors = getContractorOptions(contractorsWithAddress.data);
    if ([9, 10].includes(currentUser.data?.role_id)) {
      newContractors = newContractors.filter(
        (singleContractor) =>
          singleContractor.name === currentUser.data?.contractor?.name
      );
    }
    setContractorOptions(convertToGroupedOptions(newContractors));
  }, [contractorsWithAddress]);

  useEffect(() => {
    const openSpillsCount = currentlyOpenSpills?.data?.data?.count;
    const error = currentlyOpenSpills?.error;

    if (openSpillsCount !== null) {
      setOpenSpills({ ...openSpills, value: openSpillsCount });
    }

    if (error) {
      setOpenSpills({ ...openSpills, error: error });
    }
  }, [currentlyOpenSpills]);

  useEffect(() => {
    const currentlyOpenSpillsThisYearCount =
      currentOpenedSpillsInCurrentYear?.data?.data?.count;
    const error = currentOpenedSpillsInCurrentYear?.error;

    if (currentlyOpenSpillsThisYearCount !== null) {
      setCurrentlyOpenedSpillsInCurrentYear({
        ...currentlyOpenedSpillsInCurrentYear,
        value: currentlyOpenSpillsThisYearCount,
      });
    }

    if (error) {
      setCurrentlyOpenedSpillsInCurrentYear({
        ...currentlyOpenedSpillsInCurrentYear,
        error: error,
      });
    }
  }, [currentOpenedSpillsInCurrentYear]);

  useEffect(() => {
    const currentlyOpenSpillsPreviousYearCount =
      currentOpenedSpillsInPreviousYear?.data?.data?.count;
    const error = currentOpenedSpillsInPreviousYear?.error;

    if (currentlyOpenSpillsPreviousYearCount !== null) {
      setCurrentlyOpenedSpillsInPreviousYear({
        ...currentlyOpenedSpillsInPreviousYear,
        value: currentlyOpenSpillsPreviousYearCount,
      });
    }

    if (error) {
      setCurrentlyOpenedSpillsInPreviousYear({
        ...currentlyOpenedSpillsInPreviousYear,
        error: error,
      });
    }
  }, [currentOpenedSpillsInPreviousYear]);

  useEffect(() => {
    const closedSpillsYTDCount = closedSpillsYTD?.data?.data?.count;
    const error = closedSpillsYTD?.error;

    if (closedSpillsYTDCount !== null) {
      setClosedSpillsYearToDate({
        ...closedSpillsYearToDate,
        value: closedSpillsYTDCount,
      });
    }

    if (error) {
      setClosedSpillsYearToDate({
        ...closedSpillsYearToDate,
        error: error,
      });
    }
  }, [closedSpillsYTD]);

  useEffect(() => {
    const currentlyClosedSpillsCurrentYearCount =
      currentlyClosedSpillsCurrentYear?.data?.data?.count;
    const error = currentlyClosedSpillsCurrentYear?.error;

    if (currentlyClosedSpillsCurrentYearCount !== null) {
      setCurrentlyClosedSpillsThisYear({
        ...currentlyClosedSpillsThisYear,
        value: currentlyClosedSpillsCurrentYearCount,
      });
    }

    if (error) {
      setCurrentlyClosedSpillsThisYear({
        ...currentlyClosedSpillsThisYear,
        error: error,
      });
    }
  }, [currentlyClosedSpillsCurrentYear]);

  useEffect(() => {
    const avgDaysToCloseSpillCount = avgDaysToCloseSpill?.data?.data?.avg;
    const error = avgDaysToCloseSpill?.error;

    if (avgDaysToCloseSpillCount !== null) {
      setAverageDaysToCloseSpill({
        ...averageDaysToCloseSpill,
        value: avgDaysToCloseSpillCount,
      });
    }

    if (error) {
      setAverageDaysToCloseSpill({
        ...averageDaysToCloseSpill,
        error: error,
      });
    }
  }, [avgDaysToCloseSpill]);

  const getRangeOfDate = ({ fromDate, endDate }) => {
    const dateRange = {
      startDate: moment(fromDate).format('MM-DD-YYYY'),
      endDate: moment(endDate).format('MM-DD-YYYY'),
    };
    setDateRangeState({ ...dateRange });
  };
  const [toggleValue, setToggleValue] = useState('yearly');
  const classes = Styles();

  const getValueOfToggle = (val) => {
    setToggleValue(val);
    setSelectedOrganizations({});
    setSelectedContractors({});
  };

  const toggleItems = [
    { value: 'yearly', label: 'Yearly' },
    { value: 'monthly', label: 'Monthly' },
    { value: 'weekly', label: 'Weekly' },
  ];

  const organizationNames = clientOrganizationNames.data;
  const organizationChildren = clientChildren.data;
  const managerNames = admins.data;
  const organizationManagerNames = organizationAdmins.data;

  let organizations = [];
  let managers = [];

  if (isCorporateUser(userRole) && userRole !== ROLES.CORPORATE_USER) {
    const organizationChildOptions = organizationChildren.map(
      (organization) => {
        const value = { value: organization.id, label: organization.name };
        const allOptions = { ...value };

        return allOptions;
      }
    );

    organizations = organizationChildOptions;
  } else if (userRole === ROLES.CORPORATE_USER) {
    const organizationFilter = organizationChildren.filter((organization) => {
      const org = organization.id === currentUser.data.org_id;

      return org;
    });

    const organizationOptions = organizationFilter.map((organization) => {
      const value = { value: organization.id, label: organization.name };
      const allOptions = { ...value };

      return allOptions;
    });

    organizations = organizationOptions;
  } else {
    const organizationOptions = organizationNames.map((organization) => {
      const value = { value: organization.id, label: organization.name };
      const allOptions = { ...value };

      return allOptions;
    });

    organizations = organizationOptions;
  }

  if (isCorporateUser(userRole)) {
    const managerOptions = organizationManagerNames.map((manager) => {
      const value = { value: manager.id, label: manager.full_name };
      const allOptions = { ...value };

      return allOptions;
    });

    managers = managerOptions;
  } else {
    const managerOptions = managerNames.map((manager) => {
      const value = { value: manager.id, label: manager.full_name };
      const allOptions = { ...value };

      return allOptions;
    });

    managers = managerOptions;
  }
  const onOrganizationSelectChange = (item) => {
    setSelectedOrganizations({ ...item });
  };
  const onContractorSelectChange = (item) => {
    setSelectedContractors({ ...item });
  };

  const clickFilterHandler = () => {
    if (selectedContractors?.addressId) {
      setFilterValues({
        subContractorId: selectedContractors?.addressId,
        clientId: selectedOrganizations?.value,
      });
      return;
    } else {
      setFilterValues({
        contractorId: selectedContractors?.contractor_id,
        clientId: selectedOrganizations?.value,
      });
    }
  };
  const resetSelectFilters = () => {
    resetContractorSelectRef.current.select.clearValue();
    resetOrganizationSelectRef.current.select.clearValue();
  };

  return (
    <Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <Typography className={classes.analyticsHeading}>
              Spills Status Analytics
            </Typography>
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6} lg={4} xl={4}>
            <SingleStatChart
              title={'Currently Open Spills'}
              amount={openSpills?.value}
              loading={currentlyOpenSpills?.loading}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={4} xl={4}>
            <SingleStatChart
              title={'Currently Opened Spills In Current Year'}
              amount={currentlyOpenedSpillsInCurrentYear?.value}
              loading={currentlyOpenedSpillsInCurrentYear?.loading}
            />
          </Grid>

          <Grid item xs={12} md={12} lg={4} xl={4}>
            <SingleStatChart
              title={'Currently Opened Spills In Previous Year'}
              amount={currentlyOpenedSpillsInPreviousYear?.value}
              loading={currentlyOpenedSpillsInPreviousYear?.loading}
            />
          </Grid>

          <Grid item xs={12} md={6} lg={4} xl={4}>
            <SingleStatChart
              title={'Spill Closed Year To Date'}
              amount={closedSpillsYearToDate?.value}
              loading={closedSpillsYearToDate?.loading}
            />
          </Grid>
          <Grid item xs={12} md={6} lg={4} xl={4}>
            <SingleStatChart
              title={'Currently Closed Spills Current Year'}
              amount={currentlyClosedSpillsThisYear?.value}
              loading={currentlyClosedSpillsThisYear?.loading}
            />
          </Grid>

          <Grid item xs={12} md={12} lg={4} xl={4}>
            <SingleStatChart
              title={'Average Days To Close A Spill'}
              amount={averageDaysToCloseSpill?.value}
              loading={averageDaysToCloseSpill?.loading}
            />
          </Grid>
        </Grid>

        <Grid container spacing={4}>
          <Grid item xs={6} md={12} className={classes.datePickerContainer}>
            <ColorToggleButton
              initialValue={'yearly'}
              getValue={getValueOfToggle}
              items={toggleItems}
            />
          </Grid>
        </Grid>
        <Grid
          container
          spacing={4}
          //   justifyContent='flex-end'
          //   direction='row'
          alignItems='center'
          //   className={classes.gridAlignEnd}
        >
          <Grid item xs={12} md={6} className={classes.filterBox}>
            <span
              style={{
                display: 'flex',
                flexDirection: 'column',
                fontSize: 12,
                color: 'grey',
                fontWeight: 550,
                paddingBottom: '2px',
              }}
            >
              Show Filters
              <FilterListOutlinedIcon
                className={classes.filterIcon}
                onClick={() => setFilterStatus(!filterStatus)}
              />
            </span>
          </Grid>
          <Grid xs={12} md={3} className={classes.marginSelect}></Grid>
          <Grid item xs={12} md={3}>
            <div className={classes.datesTypeWrapper}>
              {toggleValue === toggleItems[0]?.value && (
                <MuiPickersUtilsProvider
                  utils={MomentUtils}
                  className={classes.datePickerContainer}
                >
                  <KeyboardDatePicker
                    disableToolbar
                    variant='inline'
                    label='Date Filter:'
                    views={['year']}
                    value={moment(yearDate)}
                    disableFuture
                    onChange={(event) => {
                      //handleDateChange(event.format(yearFormat));
                      setYearDate(event.format(yearFormat));
                    }}
                    //onClose={handleDateChange}
                    autoOk={true}
                    minDate={minDate}
                  />
                </MuiPickersUtilsProvider>
              )}
              {toggleValue === toggleItems[1]?.value && (
                <MuiPickersUtilsProvider
                  utils={MomentUtils}
                  className={classes.datePickerContainer}
                >
                  <KeyboardDatePicker
                    disableToolbar
                    variant='inline'
                    label='Date Filter:'
                    views={['year', 'month']}
                    value={moment(monthlyDate)}
                    disableFuture
                    onChange={(event) => {
                      //handleDateChange(event.format(yearFormat));
                      setMonthlyDate(event.format(monthFormat));
                    }}
                    //onClose={handleDateChange}
                    autoOk={true}
                    minDate={minDate}
                  />
                </MuiPickersUtilsProvider>
              )}
              {toggleValue === toggleItems[2]?.value && (
                <WeekPicker getRangeOfDate={getRangeOfDate} minDate={minDate} />
              )}
            </div>
          </Grid>
        </Grid>
        {filterStatus && (
          <Grid container spacing={4} alignItems='center'>
            <Grid item xs={12} md={5} className={classes.marginSelect}>
              <div>
                <Typography className={classes.filterButtonHeader}>
                  {'Contractors'}
                </Typography>
              </div>
              <ReactSelect
                ref={resetContractorSelectRef}
                placeholder='Contractors'
                value={selectedContractors}
                isMulti={false}
                onChange={onContractorSelectChange}
                filterOption={filterOption}
                options={contractorOptions}
                styles={contractorColorStyles()}
                closeMenuOnSelect
                isLoading={loadingContractors}
                defaultValue={selectedContractors[0]}
              />
            </Grid>
            <Grid xs={12} md={4} className={classes.marginSelect}>
              <div>
                <Typography className={classes.filterButtonHeader}>
                  {'Organizations'}
                </Typography>
              </div>
              <ReactSelect
                ref={resetOrganizationSelectRef}
                placeholder='Organizations'
                value={selectedOrganizations}
                isMulti={false}
                onChange={onOrganizationSelectChange}
                options={orderAlphabeticallyByKey(organizations)}
                isDisabled={isContractorUser(currentUser?.data?.role?.role)}
                closeMenuOnSelect
                isLoading={clientOrganizationLoading}
              />
            </Grid>
            <Grid className={classes.marginSelect} xs={12} md={2}>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                }}
              >
                <div className={classes.filterButtonSelect}>
                  <Button
                    color='primary'
                    variant='contained'
                    onClick={() => clickFilterHandler()}
                  >
                    Apply
                  </Button>
                </div>
                <div className={classes.filterButtonSelect}>
                  <Button
                    color='primary'
                    variant='contained'
                    onClick={() => resetSelectFilters()}
                  >
                    Reset
                  </Button>
                </div>
              </div>
            </Grid>
          </Grid>
        )}

        <Grid container spacing={4}>
          <Grid item xs={6} md={12}>
            {toggleValue === toggleItems[0]?.value && (
              <SpillsStatusAnalyticsYearly
                yearlyValue={yearDate}
                filterValues={filterValues}
              />
            )}
            {toggleValue === toggleItems[1]?.value && (
              <SpillsStatusAnalyticsMonthly
                monthlyValue={monthlyDate}
                filterValues={filterValues}
              />
            )}
            {toggleValue === toggleItems[2]?.value && (
              <SpillsStatusAnalyticsWeekly
                dateRange={dateRangeState}
                filterValues={filterValues}
              />
            )}
          </Grid>
        </Grid>
      </Paper>
    </Fragment>
  );
};
const mapStateToProps = ({
  analytics: {
    closedSpillsYTD,
    spillsOnEachWeek,
    spillStatusCount,
    currentlyOpenSpills,
    avgDaysToCloseSpill,
    spillsOnEachWorkDay,
    averagePerDayPerWeek,
    filteredSpillsStatusCount,
    currentMonthSpillProjection,
    currentlyClosedSpillsCurrentYear,
    currentOpenedSpillsInCurrentYear,
    currentOpenedSpillsInPreviousYear,
  },
  contractor,
  client,
  user,
}) => ({
  admins: user.admins,
  organizationAdmins: user.organizationAdmins,
  spillsOnEachWorkDay,
  spillsOnEachWeek,
  spillStatusCount,
  currentMonthSpillProjection,
  averagePerDayPerWeek,
  contractorsWithAddress: contractor.contractorsWithAddress,
  clientChildren: client.clientChildren,
  currentUser: user.currentUser,
  loadingContractors: contractor.loading,
  clientOrganizationNames: client.clientOrganizationNames,
  clientOrganizationLoading: client.loading,
  filteredSpillsStatusCount,
  closedSpillsYTD,
  currentlyOpenSpills,
  avgDaysToCloseSpill,
  currentlyClosedSpillsCurrentYear,
  currentOpenedSpillsInCurrentYear,
  currentOpenedSpillsInPreviousYear,
});

const mapDispatchToProps = (dispatch) => ({
  getContractorsWithAddress: bindActionCreators(
    contractorAction.getContractorsWithAddress,
    dispatch
  ),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  getCurrentlyOpenSpills: bindActionCreators(
    analyticActions.getCurrentlyOpenSpills,
    dispatch
  ),
  getCurrentlyOpenedSpillsInCurrentYear: bindActionCreators(
    analyticActions.getCurrentlyOpenedSpillsInCurrentYear,
    dispatch
  ),
  getCurrentlyOpenedSpillsInPreviousYear: bindActionCreators(
    analyticActions.getCurrentlyOpenedSpillsInPreviousYear,
    dispatch
  ),
  getSpillsClosedYTD: bindActionCreators(
    analyticActions.getSpillsClosedYTD,
    dispatch
  ),
  getCurrentlyClosedSpillsCurrentYear: bindActionCreators(
    analyticActions.getCurrentlyClosedSpillsCurrentYear,
    dispatch
  ),
  getAvgDaysToCloseSpill: bindActionCreators(
    analyticActions.getAvgDaysToCloseSpill,
    dispatch
  ),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SpillsStatusAnalytics)
);
