import React, { useState, useEffect } from "react";

import { connect } from "react-redux";
import {
  Grid,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormControlLabel,
  Paper,
  Typography,
  Switch,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { pdf } from "@react-pdf/renderer";
import * as spillActions from "../../../../../actionCreators/Spill";
import CircularProgress from "@material-ui/core/CircularProgress";

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
  KeyboardDateTimePicker,
} from "@material-ui/pickers";
import MomentUtils from "@date-io/moment";
import moment from "moment";
import PropTypes from "prop-types";
import SpillPdf from "./SpillPdf";
import PesCoverLetter from "./PesCoverLetter";

import AttachmentGrid from "../../../../../Components/AttachmentGrid";
import RejectDialog from "./RejectionDialog";
import CompleteSubmissionDialog from "./CompleteSubmissionDialog";

import {
  orderAlphabaticallyByKey,
  getUploadTypes,
  getCompletedAttachmentUploadTypes,
  isContractorUser,
  getUploadTypesConditionally,
  specificAttachmentTypes,
  isPESUser,
  doPost,
  REQUEST_TYPE,
  uptoDecimalPlaces,
  extractFileExtensionFromString,
  getRequestedDocTypes,
} from "../../../../../utils";
import CurrencyFieldInput from "../../../../../Components/CurrencyFieldInput";
import * as downloadActions from "../../../../../actionCreators/Download";
import { bindActionCreators } from "redux";
import {
  RequestDocumentationPrompt,
  WholeScreenModal,
} from "../../../../../Components";
import { requestDocumentationModalText } from "../../../../../utils/language/english";
import Moment from "moment";

const useStyles = makeStyles((theme) => ({
  rightAlign: {
    textAlign: "right",
  },
  leftAlign: {
    textAlign: "left",
  },
  statusLabel: {
    color: "#616161",
    fontSize: "14px",
  },
  subHeading: {
    color: "#295115",
    fontWeight: 800,
  },
  button: {
    margin: "13px",
  },
  formControl: {
    minWidth: "200px",
  },
  groupButton: {
    margin: "0 3px",
  },
  fullWidth: {
    width: "100%",
  },
  adminFormWrapper: {
    padding: theme.spacing(1),
  },
  paper: {
    padding: theme.spacing(2),
    backgroundColor: "#F5F5F5",
  },
  adminField: {
    padding: "0 10px",
  },
  responseTime: {
    padding: "10px",
  },
  adminActionMessage: {
    color: "red",
    fontSize: "smaller",
    display: "flex",
    flexDirection: "row-reverse",
  },
  notRequestedSwitch: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: "10px",
    justifyContent: "end",
  },
  submissionCheckBox: {
    display: "flex",
    alignItems: "center",
    padding: "20px 0",
    justifyContent: "flex-end",
  },
}));

const AdminForm = ({
  admin,
  index,
  setAdmin,
  userName,
  download,
  isInactive,
  isUserAdmin,
  currentUser,
  currentSpill,
  downloadFile,
  selectedFiles,
  contractorInv,
  attachmentTypes,
  isCorporateUser,
  requestDocuments,
  setContractorInv,
  attachmentHistory,
  hasSpillBeenUpdated,
  onFileChangeHandler,
  onFileCancelHandler,
  missingInvoiceAlert,
  totalPrintableNotes,
  requestDocumentation,
  setSnackbarMessageCb,
  setMissingInvoiceAlert,
  updateRejectedAttachment,
  getTotalNotesForPrintSpill,
  viewAdminAttachmentHistory,
  spillAdminRequestedDocumentation,
  getSpillAdminRequestedDocumentation,
}) => {
  const classes = useStyles();
  const disableFields = admin[index]?.isNotRequiredCheck || false;
  const [isNotRequiredState, setIsNotRequiredState] = useState(
    admin[index]?.isNotRequiredCheck || false
  );
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [generatePDFReport, setGeneratePDFReport] = useState(false);
  const [uploadType, setUploadType] = useState("");
  const [selectedAttachments, setSelectedAttachments] = useState([]);
  const [isCompleteDialogOpen, setIsCompleteDialogOpen] = useState(false);
  const [adminAttachmentActions, setAdminAttachmentActions] = useState({
    display: false,
    message: "",
  });
  const [contractorInvNo, setContractorInvNo] = useState(admin[index].invNo);
  const [attachmentToDisableIds, setAttachmentToDisableIds] = useState([]);
  const [
    previouslyUploadedAttachmentTypes,
    setPreviouslyUploadedAttachmentsTypes,
  ] = useState([]);
  const [showReqDocModal, setshowReqDocModal] = useState(false);
  const [requestedDocuments, setRequestedDocuments] = useState({
    data: [],
    mappedLabels: [],
  });

  useEffect(() => {
    if (selectedAttachments?.length > 0 && admin[index]?.isComplete === false) {
      setAdminAttachmentActions({
        display: true,
        message: "Contractor has not yet submitted documents for review",
      });
    } else {
      setAdminAttachmentActions({
        display: false,
        message: "",
      });
    }

    if (admin[index]) {
      let disabledAttachments = admin[index]?.attachments_with_expiry?.filter(
        (attachment) => attachment?.disabled === 1
      );
      const disabledIds = disabledAttachments?.map(
        (attachment) => attachment?.attachment_id
      );

      const attachments = admin[index].attachments?.filter((attachment) =>
        specificAttachmentTypes?.includes(attachment?.type)
      );

      const attachmentTypesUploaded = [];

      attachments?.map((attachment) =>
        attachmentTypesUploaded.push({
          type: attachment?.type,
          user: attachment?.user?.role?.role,
        })
      );

      let uniqueAttachmentsTypeAndUsersList = attachmentTypesUploaded?.filter(
        (type, index, attachmentTypes) => {
          return (
            index ===
            attachmentTypes?.findIndex(
              (item) => item?.type === type?.type && item?.user === type?.user
            )
          );
        }
      );

      setPreviouslyUploadedAttachmentsTypes(uniqueAttachmentsTypeAndUsersList);

      setAttachmentToDisableIds(disabledIds);
    }
  }, [admin, index, selectedAttachments]);

  useEffect(() => {
    if (currentSpill?.data?.spill?.id) {
      getTotalNotesForPrintSpill({ spillId: currentSpill?.data?.spill?.id });
      getSpillAdminRequestedDocumentation({
        spill_id: currentSpill?.data?.spill?.id,
        spill_admin_id: admin[index]?.adminId,
      });
    }
  }, []);

  useEffect(() => {
    if (hasSpillBeenUpdated) {
      getSpillAdminRequestedDocumentation({
        spill_id: currentSpill?.data?.spill?.id,
        spill_admin_id: admin[index]?.adminId,
      });
    }
  }, [hasSpillBeenUpdated]);

  useEffect(() => {
    if (spillAdminRequestedDocumentation?.data?.length) {
      const labelsToRender = getRequestedDocTypes(
        spillAdminRequestedDocumentation?.data
      );
      if (labelsToRender?.length) {
        setRequestedDocuments({
          mappedLabels: labelsToRender,
          data: spillAdminRequestedDocumentation?.data,
        });
      }
    } else {
      setRequestedDocuments({
        mappedLabels: [],
        data: [],
      });
    }
  }, [spillAdminRequestedDocumentation]);

  useEffect(() => {
    if (
      download?.success === true &&
      download?.loading === false &&
      generatePDFReport === true
    ) {
      setSnackbarMessageCb("PDF is downloading", "success");
      setGeneratePDFReport(false);
    }
    if (
      download?.success === false &&
      download?.loading === false &&
      download.error === "File Not Found"
    ) {
      setSnackbarMessageCb("Your PDF is Empty", "error");
      download.error = "";
    }
    if (download?.loading === false) {
      setGeneratePDFReport(false);
    }
  }, [download]);

  const handleAdminChange = (index, key) => (event) => {
    let tempAdmin = JSON.parse(JSON.stringify(admin));
    if (
      uploadType === "contractorInv" &&
      ((key === "contractorInv" && !event?.target?.value) ||
        (key === "invNo" && !event?.target?.value))
    ) {
      setMissingInvoiceAlert(true);
      setUploadType("");
    } else {
      setMissingInvoiceAlert(false);
    }

    if (key === "invNo") {
      const value = event?.target?.value.replace(/\s+/g, "");
      if (value === "" || /^\d+$/.test(value)) {
        setContractorInvNo(value);
      }
    }

    if (key === "contractorInv") {
      setContractorInv(parseFloat(event?.target?.value));
    } else {
      tempAdmin[index][key] = event?.target?.value;
    }

    if (key === "isNotRequiredCheck") {
      tempAdmin[index][key] = event?.target?.checked;

      setIsNotRequiredState(event?.target?.checked);
    }

    setAdmin(tempAdmin);
  };

  const handleAdminDateChange = (index, key) => (date) => {
    if (date) {
      let tempAdmin = [...admin];
      tempAdmin[index][key] = date.format("MM-DD-YYYY");
      setAdmin(tempAdmin);
    }
  };

  const handleAgencyReport = (index, key) => async () => {
    setGeneratePDFReport(true);
    if (totalPrintableNotes?.data?.length) {
      let updatedSpill = {
        ...currentSpill,
        data: {
          ...currentSpill?.data,
          spill: {
            ...currentSpill?.data?.spill,
            spill_notes: totalPrintableNotes?.data?.filter(
              (note) => note?.deleted_at === null
            ),
          },
        },
      };

      await generatePdfDocument(updatedSpill, index, "Agency Report");
    }

    // downloadFile({
    //   url: "/download/pdfReport",
    //   spill_id: currentSpill?.data?.spill?.id,
    //   spill_job_no: currentSpill?.data?.spill?.job_no,
    //   spill_admin_id: currentSpill?.data?.admin[index]?.id,
    //   contractor_id: currentSpill?.data?.admin[index]?.contractor_id,
    //   fileName: "Agency Report",
    // });
  };

  const handleGenerateInvRepPkg = async (index, key) => {
    setGeneratePDFReport(true);
    if (totalPrintableNotes?.data?.length) {
      let updatedSpill = {
        ...currentSpill,
        data: {
          ...currentSpill?.data,
          spill: {
            ...currentSpill?.data?.spill,
            spill_notes: totalPrintableNotes?.data?.filter(
              (note) => note?.deleted_at === null
            ),
          },
        },
      };
      await generatePdfDocument(updatedSpill, index, "Invoice/Report Package");
    }

    // downloadFile({
    //   url: "/download/pdfReport",
    //   spill_id: currentSpill?.data?.spill?.id,
    //   spill_job_no: currentSpill?.data?.spill?.job_no,
    //   spill_admin_id: currentSpill?.data?.admin[index]?.id,
    //   contractor_id: currentSpill?.data?.admin[index]?.contractor_id,
    //   fileName: "Invoice/Report Package",
    // });
  };

  // const generatePdfDocument = async (updatedSpill) => {
  //   if (updatedSpill) {
  //     const blob = await pdf(
  //       <SpillPdf data={updatedSpill} userMetaData={currentUser} />
  //     ).toBlob();
  //     let currentDate = new Date();
  //     const blob2 = await pdf(<PesCoverLetter data={currentDate} />).toBlob();
  //     let formdata = new FormData();
  //     formdata.append("spill_id", currentSpill?.data?.spill?.id);
  //     formdata.append(`printspill`, blob);
  //     formdata.append(`pesCoverLetter`, blob2);
  //     return doPost(
  //       "/download/pdfPrintSpillDownload",
  //       formdata,
  //       null,
  //       REQUEST_TYPE.DOWNLOAD
  //     );
  //   }
  // };

  const generatePdfDocument = async (updatedSpill, index, fileName) => {
    try {
      if (updatedSpill) {
        const blob = await pdf(
          <SpillPdf data={updatedSpill} userMetaData={currentUser} />
        ).toBlob();
  
        let currentDate = new Date();
        const blob2 = await pdf(<PesCoverLetter data={currentDate} />).toBlob();
  
        let formdata = new FormData();
        formdata.append("spill_id", currentSpill?.data?.spill?.id);
        formdata.append(`printspill`, blob);
        formdata.append(`pesCoverLetter`, blob2);
        formdata.append(`spill_job_no`, currentSpill?.data?.spill?.job_no);
        formdata.append(`spill_admin_id`, currentSpill?.data?.admin[index]?.id);
        formdata.append(`contractor_id`, currentSpill?.data?.admin[index]?.contractor_id);
        formdata.append(`fileName`, fileName);

        const response = await doPost(
          "/download/pdfReport",
          formdata,
          null,
          REQUEST_TYPE.DOWNLOAD
        );
        setGeneratePDFReport(false);
        var element = document.createElement("a");
        element.setAttribute("href", response?.data?.url);
        element.style.display = "none";
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element); 
      }
    } catch (error) {
      setGeneratePDFReport(false);
      console.log(error);
    }
  };

  const handleAdminDateClear = (index, key) => {
    let tempAdmin = [...admin];
    tempAdmin[index][key] = "";
    setAdmin(tempAdmin);
  };

  const handleSetUploadType = (uploadType) => {
    if (uploadType === "contractorInv") {
      if (contractorInv && admin[index].invNo) {
        setUploadType(uploadType);
      } else {
        setUploadType("");
        setMissingInvoiceAlert(true);
      }
    } else {
      setUploadType(uploadType);
      setMissingInvoiceAlert(false);
    }
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
  };

  const handleDialogReject = (data) => {
    let date = new Date();
    setIsDialogOpen(false);
    let tempAdmin = [...admin];
    setAdmin(tempAdmin);
    for (const arrIndex in selectedAttachments) {
      tempAdmin[index].attachments[selectedAttachments[arrIndex]].status =
        "reject";
      tempAdmin[index].attachments[selectedAttachments[arrIndex]].updated_at =
        moment.utc(new Date(date)).format("MM-DD-YYYY HH:mm:ss");
      tempAdmin[index].attachments[selectedAttachments[arrIndex]].admin_note =
        data[arrIndex];
      tempAdmin[index].attachments[selectedAttachments[arrIndex]].first_time_rejection = true
    }
    setSelectedAttachments([]);
    setAdmin(tempAdmin);
  };

  const handleAttachmentEdit = (key, data, fileIndex) => {
    let tempAdmin = [...admin];
    tempAdmin[index].attachments[fileIndex][key] = data;
    setAdmin(tempAdmin);
  };

  const handleApprove = () => {
    let date = new Date();
    for (const fileIndex of selectedAttachments) {
      let tempAdmin = [...admin];
      tempAdmin[index].attachments[fileIndex].status = "approve";
      tempAdmin[index].attachments[fileIndex].updated_at = moment
        .utc(new Date(date))
        .format("MM-DD-YYYY HH:mm:ss");
      if (tempAdmin[index]?.attachments[fileIndex]?.type === "contractorInv") {
        const extension = extractFileExtensionFromString(
          tempAdmin[index]?.attachments[fileIndex]?.key
        );
        tempAdmin[index].attachments[
          fileIndex
        ].name = `Final Contractor Invoice.${extension}`;
      }
      setSelectedAttachments([]);
      setAdmin(tempAdmin);
    }
  };

  const handleDocumentRequest = () => {
    setshowReqDocModal(true);
  };

  const handleReqDocSubmit = async (response) => {
    if (response?.length > 0) {
      const adminObj = {
        spill_id: currentSpill?.data?.spill?.id,
        contractor_id: admin[index]?.contractorId,
        contractor_address_id: admin[index]?.contractorAddressId,
        spill_admin_id: admin[index]?.adminId,
        spill_job_no: currentSpill?.data?.spill?.job_no,
        spill_pm_user_id: currentSpill?.data?.spill?.user_id,
      };

      let currentDate = new Date();
      currentDate = Moment(currentDate).format("YYYY-MM-DDTHH:mm:ss.SSSSZ");

      for (let i = 0; i < response?.length; i++) {
        response[i].created_at = currentDate;
        response[i].updated_at = currentDate;
      }

      await requestDocumentation({
        requestedDocumentsData: response,
        adminData: adminObj,
      });
    }
  };

  const handleCompleteCheck = (index, value) => {
    if (value) {
      setIsCompleteDialogOpen(true);
    } else {
      let tempAdmin = [...admin];
      tempAdmin[index].isComplete = false;
      setAdmin(tempAdmin);
      setIsCompleteDialogOpen(false);
    }
  };

  const handleConfirmComplete = () => {
    let tempAdmin = [...admin];
    tempAdmin[index].isComplete = true;
    setIsCompleteDialogOpen(false);
    setAdmin(tempAdmin);
  };

  const handleRejection = () => {
    // look for any attachment that is already rejected
    let alreadyRejectedFiles = [];
    selectedAttachments.forEach((attachmentIndex) => {
      try {
        const fileToCheck =
          admin[index]?.attachments[selectedAttachments[attachmentIndex]];
        if (fileToCheck?.status === "reject") {
          alreadyRejectedFiles = [...alreadyRejectedFiles, fileToCheck];
        }
      } catch (err) {
        setSnackbarMessageCb("Something went wrong", "error");
      }
    });
    if (alreadyRejectedFiles.length > 0) {
      const fileNames = alreadyRejectedFiles.map(({ name }) => name);
      const filesCount = fileNames.length;
      const snackbarMessage = `${fileNames.join(",")} ${filesCount > 1 ? "are" : "is"
        } already rejected. Please uncheck ${filesCount > 1 ? "them" : "it"
        } to proceed`;
      setSnackbarMessageCb(snackbarMessage, "warning");
    } else {
      setIsDialogOpen(true);
    }
  };

  const isValidDecimal = (value, keyCode) => {
    if (keyCode === 8 && value[value.length - 1] === "." && value.length <= 2)
      return true;
    if (keyCode >= 48 && keyCode <= 57) value += String.fromCharCode(keyCode);
    else if (keyCode === 190) value += ".0"; //for skip immediate check of .
    else if (keyCode === 8 && value[value.length - 1] === ".")
      value = value.substring(0, value.length - 2); //for skip ,backspace with .

    let isValid = !/^\s*$/.test(value) && !isNaN(value);
    const initialArr = value.split(".");
    const firstHalf = initialArr[0];
    let secondHalf = initialArr[1];
    if (firstHalf === "") isValid = false;
    if (secondHalf === "") isValid = false;

    if (!isValid) return isValid;

    if (secondHalf !== undefined) {
      secondHalf = secondHalf.substring(0, 5); //for roundoff upto 5
      if (firstHalf + "." + secondHalf === value) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  };

  const handleBlur = (e) => {
    //e.target.name , e.target.value
    let prevVal = e.target.value;
    if (prevVal[prevVal.length - 1] === ".") prevVal = prevVal.slice(0, -1);
    e.target.value = prevVal;
    let decimalFix = handleAdminChange(index, e.target.name);
    decimalFix(e);
  };

  const restrictKey = (e) => {
    const code = e.keyCode;
    const flag = isValidDecimal(e.target.value, code);
    if (!flag) {
      e.preventDefault();
      return;
    }
    if ((code < 48 || code > 57) && code !== 190 && code !== 8)
      e.preventDefault();
  };

  return (
    <>
      <div className={classes.adminFormWrapper}>
        {generatePDFReport && <PDFPopUp />}
        <Grid container spacing={3}>
          {disableFields && (
            <Grid item xs={12}>
              <label style={{ color: "red", textAlign: "center" }}>
                No Invoice or Documents will be Submitted for this Response
              </label>
            </Grid>
          )}
          {requestedDocuments?.data?.length ? (
            <Grid item xs={12}>
              <label style={{ color: "red", textAlign: "center" }}>
                Following documents were requested from you:{" "}
                <b>
                  {requestedDocuments?.mappedLabels
                    ?.map((item) => item?.label)
                    .join(", ")}
                </b>
              </label>
            </Grid>
          ) : null}
          {isUserAdmin && (
            <Grid
              item
              xs={12}
              style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}
            >
              <Button
                style={{ textAlign: "center" }}
                variant="contained"
                color="primary"
                disabled={currentSpill?.data?.admin[index] === undefined}
                onClick={handleAgencyReport(index, "agencyReport")}
              >
                Generate Agency Report
              </Button>
              <Button
                style={{ textAlign: "center" }}
                variant="contained"
                color="primary"
                disabled={currentSpill?.data?.admin[index] === undefined}
                onClick={() =>
                  handleGenerateInvRepPkg(index, "InvoiceReportPkg")
                }
              >
                Generate Invoice/Report Package
              </Button>
            </Grid>
          )}
          {!isContractorUser(currentUser?.data?.role?.role) ? (
            <Grid item xs={12}>
              <TextField
                disabled={disableFields}
                id="info"
                name="info"
                label="Info"
                fullWidth
                autoComplete="info"
                multiline
                inputProps={{
                  value: admin[index].info,
                }}
                onChange={handleAdminChange(index, "info")}
              />
            </Grid>
          ) : null}

          <Grid item xs={6}>
            <CurrencyFieldInput
              decimalScale={5}
              name="contractorInv"
              value={uptoDecimalPlaces(contractorInv, 2)}
              allowNegative={false}
              label="Contractor Invoice $"
              onChange={handleAdminChange(index, "contractorInv")}
            />
          </Grid>

          <Grid item xs={6}>
            <TextField
              disabled={disableFields}
              id="invNo"
              name="invNo"
              label="Inv No"
              fullWidth
              autoComplete="invNo"
              inputProps={{
                value: contractorInvNo,
              }}
              onChange={handleAdminChange(index, "invNo")}
            />
          </Grid>
          <Grid item xs={12}>
            {isUserAdmin && (
              <Paper elevation={3} className={classes.paper}>
                <Grid container>
                  {currentUser?.data?.role.permission.edit_spill_admin &&
                    isUserAdmin && (
                      <>
                        <Grid item xs={6} className={classes.adminField}>
                          <TextField
                            onBlur={handleBlur}
                            onKeyDown={restrictKey}
                            id="finalContractorInv"
                            name="finalContractorInv"
                            label="Final Contractor Invoice"
                            fullWidth
                            autoComplete="finalContractorInv"
                            inputProps={{
                              value: admin[index].finalContractorInv,
                            }}
                            onChange={handleAdminChange(
                              index,
                              "finalContractorInv"
                            )}
                          />
                        </Grid>

                        <Grid item xs={6} className={classes.adminField}>
                          <TextField
                            id="savings"
                            name="savings"
                            label="Savings $"
                            fullWidth
                            autoComplete="savings"
                            inputProps={{
                              value: admin[index].savings,
                            }}
                            onChange={handleAdminChange(index, "savings")}
                          />
                        </Grid>

                        <Grid item xs={6} className={classes.adminField}>
                          <TextField
                            onBlur={handleBlur}
                            onKeyDown={restrictKey}
                            id="pesInvNo"
                            name="pesInvNo"
                            label="PES Inv No"
                            fullWidth
                            autoComplete="pesInvNo"
                            inputProps={{
                              value: admin[index].pesInvNo,
                            }}
                            onChange={handleAdminChange(index, "pesInvNo")}
                          />
                        </Grid>

                        <Grid item xs={6} className={classes.adminField}>
                          <TextField
                            onBlur={handleBlur}
                            onKeyDown={restrictKey}
                            id="pesInvAmount"
                            name="pesInvAmount"
                            label="PES Inv Amount"
                            fullWidth
                            autoComplete="pesInvAmount"
                            inputProps={{
                              value: admin[index].pesInvAmount,
                            }}
                            onChange={handleAdminChange(index, "pesInvAmount")}
                          />
                        </Grid>

                        <Grid item xs={6}>
                          <MuiPickersUtilsProvider utils={MomentUtils}>
                            <div>
                              <KeyboardDatePicker
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                margin="normal"
                                id="pesPaid_picker_inline"
                                label="Pes Paid"
                                inputProps={{
                                  value: admin[index].pesPaid
                                    ? moment(
                                      new Date(admin[index].pesPaid)
                                    ).format("MM-DD-YYYY")
                                    : admin[index].pesPaid,
                                }}
                                onChange={handleAdminDateChange(
                                  index,
                                  "pesPaid"
                                )}
                                KeyboardButtonProps={{
                                  aria_label: "change date",
                                }}
                                autoOk={true}
                              />
                            </div>
                            <Button
                              style={{ textAlign: "center" }}
                              variant="contained"
                              color="primary"
                              onClick={() =>
                                handleAdminDateClear(index, "pesPaid")
                              }
                            >
                              Clear
                            </Button>
                          </MuiPickersUtilsProvider>
                        </Grid>

                        <Grid item xs={6}>
                          <MuiPickersUtilsProvider utils={MomentUtils}>
                            <div>
                              <KeyboardDatePicker
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                margin="normal"
                                id="contractorPaid_picker_inline"
                                label="Contractor Paid"
                                inputProps={{
                                  value: admin[index].contractorPaid
                                    ? moment(
                                      new Date(admin[index].contractorPaid)
                                    ).format("MM-DD-YYYY")
                                    : admin[index].contractorPaid,
                                }}
                                onChange={handleAdminDateChange(
                                  index,
                                  "contractorPaid"
                                )}
                                KeyboardButtonProps={{
                                  aria_label: "change date",
                                }}
                                autoOk={true}
                              />
                            </div>
                            <Button
                              style={{ textAlign: "center" }}
                              variant="contained"
                              color="primary"
                              onClick={() =>
                                handleAdminDateClear(index, "contractorPaid")
                              }
                            >
                              Clear
                            </Button>
                          </MuiPickersUtilsProvider>
                        </Grid>

                        <Grid item xs={6}>
                          <MuiPickersUtilsProvider utils={MomentUtils}>
                            <div>
                              <KeyboardDatePicker
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                margin="normal"
                                id="transToCt_picker_inline"
                                label="Trans To CT"
                                inputProps={{
                                  value: admin[index].transToCt
                                    ? moment(
                                      new Date(admin[index].transToCt)
                                    ).format("MM-DD-YYYY")
                                    : admin[index].transToCt,
                                }}
                                onChange={handleAdminDateChange(
                                  index,
                                  "transToCt"
                                )}
                                KeyboardButtonProps={{
                                  aria_label: "change date",
                                }}
                                autoOk={true}
                              />
                            </div>
                            <Button
                              style={{ textAlign: "center" }}
                              variant="contained"
                              color="primary"
                              onClick={() =>
                                handleAdminDateClear(index, "transToCt")
                              }
                            >
                              Clear
                            </Button>
                          </MuiPickersUtilsProvider>
                        </Grid>

                        <Grid item xs={6}>
                          <MuiPickersUtilsProvider utils={MomentUtils}>
                            <div>
                              <KeyboardDatePicker
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                margin="normal"
                                id="payBy_picker_inline"
                                label="Pay By"
                                inputProps={{
                                  value: admin[index].payBy
                                    ? moment(
                                      new Date(admin[index].payBy)
                                    ).format("MM-DD-YYYY")
                                    : admin[index].payBy,
                                }}
                                onChange={handleAdminDateChange(index, "payBy")}
                                KeyboardButtonProps={{
                                  aria_label: "change date",
                                }}
                                autoOk={true}
                              />
                            </div>
                            <Button
                              style={{ textAlign: "center" }}
                              variant="contained"
                              color="primary"
                              onClick={() =>
                                handleAdminDateClear(index, "payBy")
                              }
                            >
                              Clear
                            </Button>
                          </MuiPickersUtilsProvider>
                        </Grid>

                        <Grid item xs={6} className={classes.responseTime}>
                          <TextField
                            disabled={disableFields}
                            id="responseTime"
                            name="responseTime"
                            label="Response Time (hh:mm)"
                            fullWidth
                            autoComplete="responseTime"
                            inputProps={{
                              value: admin[index].responseTime,
                            }}
                            onChange={handleAdminChange(index, "responseTime")}
                          />
                        </Grid>

                        <Grid
                          item
                          xs={6}
                          className={classes.notRequestedSwitch}
                        >
                          <Typography>No Invoice/Documents Required</Typography>
                          <Switch
                            color="primary"
                            checked={isNotRequiredState}
                            onChange={handleAdminChange(
                              index,
                              "isNotRequiredCheck"
                            )}
                          />
                        </Grid>
                      </>
                    )}
                </Grid>
              </Paper>
            )}
          </Grid>

          <Grid item xs={12}>
            <div className={classes.leftAlign}>
              <FormControl className={classes.formControl}>
                <InputLabel id="demo-simple-select-label">
                  I Want to Upload
                </InputLabel>
                <Select
                  disabled={disableFields}
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={uploadType}
                  onChange={(event) => handleSetUploadType(event.target.value)}
                >
                  <MenuItem value="">
                    <em>Select Upload Type</em>
                  </MenuItem>
                  {orderAlphabaticallyByKey(
                    admin[index]?.isComplete &&
                      isContractorUser(currentUser?.data?.role?.role)
                      ? requestedDocuments?.mappedLabels?.length
                        ? [
                          ...attachmentTypes?.completed,
                          ...requestedDocuments?.mappedLabels,
                        ]
                        : attachmentTypes?.completed
                      : getUploadTypesConditionally(
                        currentUser?.data?.role?.role,
                        attachmentTypes
                      ),
                    "label"
                  ).map((type, index) => {
                    return (
                      <MenuItem
                        key={index}
                        value={type.value}
                        disabled={
                          attachmentToDisableIds?.includes(type?.id) ||
                          previouslyUploadedAttachmentTypes?.some(
                            (attachment) => {
                              return (
                                attachment?.type === type?.value &&
                                currentUser?.data?.role?.role !==
                                attachment?.user
                              );
                            }
                          )
                        }
                      >
                        {type.label}
                      </MenuItem>
                    );
                  })}
                </Select>
              </FormControl>

              <Button
                variant="contained"
                component="label"
                color="primary"
                className={classes.button}
                disabled={disableFields || !uploadType}
              >
                + Select Files
                <input
                  type="file"
                  accept=".jpg, .png, .jpeg, .TIF, .pdf, .doc, .docx, .xls, .xlsx, .txt"
                  onChange={(event) => {
                    const requestedDocumentsMappedLables =
                      requestedDocuments?.mappedLabels;
                    const requestedDocumentsData = requestedDocuments?.data;
                    onFileChangeHandler(
                      event,
                      index,
                      uploadType,
                      index,
                      requestedDocumentsData,
                      requestedDocumentsMappedLables
                    );
                  }}
                  hidden
                  multiple
                  name="adminFiles"
                  id="adminFiles"
                />
              </Button>
            </div>
          </Grid>

          {missingInvoiceAlert && (
            <Grid item xs={12}>
              <span style={{ color: "red" }}>
                You need to add contractor invoice and amount in order to upload
                a Contractor Invoice
              </span>
            </Grid>
          )}

          {isUserAdmin && (
            <div className={classes.fullWidth}>
              <div className={classes.rightAlign}>
                {currentSpill?.data?.spill?.status ===
                  "Open: Documentation In Review" ||
                  currentSpill?.data?.spill?.status ===
                  "Open: Documentation Sent Back to Contractor for Revision" ? (
                  <Button
                    color="primary"
                    variant="contained"
                    onClick={() => handleDocumentRequest()}
                    className={classes.groupButton}
                  >
                    Request Documentation
                  </Button>
                ) : null}
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => handleApprove()}
                  className={classes.groupButton}
                  disabled={
                    selectedAttachments?.length < 1 ||
                    admin[index].isComplete === false ||
                    disableFields
                  }
                >
                  Approve
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={handleRejection}
                  className={classes.groupButton}
                  disabled={
                    selectedAttachments?.length < 1 ||
                    admin[index].isComplete === false ||
                    disableFields
                  }
                >
                  Reject
                </Button>
              </div>
              <div>
                {adminAttachmentActions?.display && (
                  <p className={classes.adminActionMessage}>
                    {adminAttachmentActions?.message}
                  </p>
                )}
              </div>
            </div>
          )}

          <Grid item xs={12}>
            <AttachmentGrid
              uploadType={uploadType}
              isNotRequired={disableFields}
              contractorInv={contractorInv}
              files={admin[index].attachments}
              adminIndex={index}
              preview={selectedFiles[index]}
              selectedFiles={selectedFiles}
              attachmentHistory={attachmentHistory}
              handleCancel={(fileIndex) =>
                onFileCancelHandler(index, fileIndex)
              }
              handleEdit={(key, data, fileIndex) => {
                handleAttachmentEdit(key, data, fileIndex);
              }}
              isEditable={true}
              isInactive={isInactive}
              isUserAdmin={isUserAdmin}
              contractorInvNo={contractorInvNo}
              isCorporateUser={isCorporateUser}
              userName={userName}
              selectedAttachments={selectedAttachments}
              updateRejectedAttachment={updateRejectedAttachment}
              setSelectedAttachments={setSelectedAttachments}
              isComplete={admin[index].isComplete}
              viewAdminAttachmentHistory={viewAdminAttachmentHistory}
            />
          </Grid>

          {!isUserAdmin && (
            <Grid item xs={12} className={classes.rightAlign}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={
                      typeof admin[index].isComplete === "undefined"
                        ? false
                        : admin[index].isComplete
                    }
                    disabled={
                      admin[index].isComplete ||
                      (!admin[index].attachments?.filter((o) => !o.isDelete)
                        ?.length &&
                        !selectedFiles[index]?.length) ||
                      disableFields
                    }
                    onChange={(event) => {
                      handleCompleteCheck(index, event.target.checked);
                    }}
                    name="checkedB"
                    color="primary"
                  />
                }
                label="Mark submission as complete"
              />
            </Grid>
          )}
        </Grid>
        {isDialogOpen && (
          <RejectDialog
            isOpen={isDialogOpen}
            handleDone={handleDialogReject}
            handleCancel={handleDialogClose}
            selectedAttachments={selectedAttachments}
            attachmentInfo={admin[index].attachments}
          ></RejectDialog>
        )}
        {isCompleteDialogOpen && (
          <CompleteSubmissionDialog
            isOpen={isCompleteDialogOpen}
            handleDone={handleConfirmComplete}
            handleCancel={() => setIsCompleteDialogOpen(false)}
          ></CompleteSubmissionDialog>
        )}
        {isPESUser(currentUser?.data?.role?.role) && (
          <div className={classes.submissionCheckBox}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={
                    typeof admin[index].isComplete === "undefined"
                      ? false
                      : admin[index].isComplete
                  }
                  disabled={admin[index].attachments?.every(
                    (o) => o.status === "approve"
                  )}
                  onChange={(event) => {
                    handleCompleteCheck(index, event.target.checked);
                  }}
                  name="checkedB"
                  color="primary"
                />
              }
              label="Mark submission as complete"
            />
          </div>
        )}
      </div>

      <WholeScreenModal
        show={showReqDocModal}
        hide={() => setshowReqDocModal(false)}
      >
        <RequestDocumentationPrompt
          attachmentTypes={attachmentTypes}
          response={(modalDisplay, requestedDocument) => {
            setshowReqDocModal(modalDisplay);
            handleReqDocSubmit(requestedDocument);
          }}
          headingText={requestDocumentationModalText.headingText}
          question={requestDocumentationModalText.question}
          acceptText={requestDocumentationModalText.acceptText}
          cancelText={requestDocumentationModalText.cancelText}
          rejectText={requestDocumentationModalText.rejectText}
          generateRequestText={
            requestDocumentationModalText.generateRequestText
          }
          noDocumentsSelectedText={
            requestDocumentationModalText.noDocumentsSelectedText
          }
          docsReadyForRequestText={
            requestDocumentationModalText.selectedDocumentsText
          }
          modalDefaultText={requestDocumentationModalText.modalDefaultText}
        />
      </WholeScreenModal>
    </>
  );
};

const PDFPopUp = () => {
  return (
    <div>
      <div
        style={{
          width: "100%",
          height: "100%",
          position: "fixed",
          background: "#00000070",
          display: "flex",
          justifyContent: "center",
          alignContent: "center",
          gap: 10,
          flexDirection: "column",
          zIndex: 1000,
          top: "0",
          left: "0",
          right: "0",
          bottom: "0",
        }}
      >
        <div
          style={{
            margin: "35%",
            padding: "50px",
            width: "500px",
            minHeight: "200px",
            gridTemplateRows: "20px 50px 1fr 50px",
            borderRadius: "10px",
            background: "#FFFFFF",
            justifyContent: "center",
            alignContent: "center",
            top: "0",
            left: "0",
            right: "0",
            bottom: "0",
            boxShadow: "0px 6px 10px rgba(0, 0, 0, 0.25)",
          }}
        >
          <div>
            <CircularProgress />
          </div>
          <h3>Your PDF is generating.</h3>
          <p>It may take a moment.</p>
        </div>
      </div>
    </div>
  );
};
const mapDispatchToProps = (dispatch) => ({
  downloadFile: bindActionCreators(downloadActions.downloadFile, dispatch),
  getTotalNotesForPrintSpill: bindActionCreators(
    spillActions.getTotalNotesForPrintSpill,
    dispatch
  ),
  getSpillAdminRequestedDocumentation: bindActionCreators(
    spillActions.getSpillAdminRequestedDocumentation,
    dispatch
  ),
  requestDocumentation: bindActionCreators(
    spillActions.requestDocumentation,
    dispatch
  ),
});

const mapStateToProps = ({ user, spill, download }) => ({
  download: download,
  currentUser: user.currentUser,
  currentSpill: spill.currentSpill,
  requestDocuments: spill.requestDocuments,
  totalPrintableNotes: spill.totalPrintableNotes,
  spillAdminRequestedDocumentation: spill.spillAdminRequestedDocumentation,
});

AdminForm.propTypes = {
  downloadFile: PropTypes.func,
  admin: PropTypes.array.isRequired,
  index: PropTypes.number.isRequired,
  setAdmin: PropTypes.func.isRequired,
  requestDocumentation: PropTypes.func,
  userName: PropTypes.string.isRequired,
  isUserAdmin: PropTypes.bool.isRequired,
  currentUser: PropTypes.object.isRequired,
  currentSpill: PropTypes.object.isRequired,
  requestDocuments: PropTypes.object.isRequired,
  handleCompleteClick: PropTypes.func.isRequired,
  totalPrintableNotes: PropTypes.object.isRequired,
  spillAdminRequestedDocumentation: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(AdminForm);