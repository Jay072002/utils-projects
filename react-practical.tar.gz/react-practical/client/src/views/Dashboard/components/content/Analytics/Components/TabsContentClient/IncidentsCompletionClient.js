import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import * as contractorAction from '../../../../../../../actionCreators/Contractor';

import {
  getAverageInvoicesClient,
  getIncidentsCompletionTypeStatuses,
  getSavingsClient,
  getAverageEta,
} from '../../../../../../../actionCreators/Analytics';
import React, { useState } from 'react';
import { Grid, makeStyles, Paper } from '@material-ui/core';
import BarChart from '../../../../../../../Components/BarChart';

import SingleStatChart from '../../../../../../../Components/SingleStatChart';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  paperInner: {
    backgroundColor: '#f7f7f7',
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    margin: '20px 0px',
    background: 'none',
    boxShadow: 'none',
    border: '1px solid #b9b9b9',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  marginSelect: {
    marginTop: '12px',
  },
  filterIcon: {
    color: '#ffffffff',
    backgroundColor: '#397d33',
    fontSize: '40px',
    padding: '12px',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  filterBox: {
    textAlign: 'left',
    marginTop: '12px',
  },
  filterButtonSelect: {
    // textAlign: 'right',
    padding: '20px',
  },
}));
const IncidentsCompletionClient = ({
  getIncidentsCompletionTypeStatuses,
  incidentCompletionTypeStatuses,
  getAverageEta,
  averageEta,
}) => {
  const [barChartData, setBarChartData] = useState([
    [
      {
        status: 'Work In Progress',
        count: 0,
        value: 0,
      },
    ],
  ]);

  const classes = Styles();
  React.useEffect(() => {
    getIncidentsCompletionTypeStatuses();
    getAverageEta();
  }, []);
  React.useEffect(() => {
    setBarChartData(incidentCompletionTypeStatuses?.data);
  }, [incidentCompletionTypeStatuses?.data]);
  return (
    <React.Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={12}>
            <SingleStatChart
              title={'Average ETA'}
              amount={Math.round(averageEta?.data?.data?.avg)}
              loading={averageEta?.loading}
            />
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={12}>
            <BarChart
              title='Incident Completion Statuses'
              data={barChartData || []}
              xLabel='status'
              yLabel='count'
              height={400}
              loading={incidentCompletionTypeStatuses?.loading}
            />
          </Grid>
        </Grid>
      </Paper>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: { incidentCompletionTypeStatuses, averageEta },
}) => ({
  incidentCompletionTypeStatuses,
  averageEta,
});

const mapDispatchToProps = (dispatch) => ({
  getIncidentsCompletionTypeStatuses: bindActionCreators(
    getIncidentsCompletionTypeStatuses,
    dispatch
  ),
  getAverageEta: bindActionCreators(getAverageEta, dispatch),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(IncidentsCompletionClient)
);
