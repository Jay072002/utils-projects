import * as React from "react";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Box, Container, Input, Button, makeStyles } from "@material-ui/core";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { green } from "@material-ui/core/colors";

const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: green[500],
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
  leftAlign: {
    textAlign: "left",
  },
  serviceLabel: {
    display: "flex",
    alignItems: "center",
  },
  root: {
    width: "100%",
    backgroundColor: theme.palette.background.paper,
    textTransform: "capitalize",
    padding: 0,
  },
  labelColor: {
    color: "#7F7F7F",
  },
}));

const Facilities = ({ accordions, setAccordions }) => {
  const [expanded, setExpanded] = React.useState(accordions[0].id); // Set the first

  const classes = useStyles();

  const addAccordion = () => {
    const newAccordionId = accordions.length + 1;
    const newAccordion = {
      id: newAccordionId,
      name: "",
      internal_id: "",
      generator_status: "",
      epa_id: "",
      address: "",
      region: "",
      phone_number: "",
    };
    setAccordions([...accordions, newAccordion]);
    setExpanded(newAccordionId);
  };

  // create a facility
  const createFacilities = async () => {
    try {
      console.log(accordions);
    } catch (error) {
      console.log(error);
    }
  };

  const handleInputChange = (field, item, value) => {
    setAccordions((prev) => {
      const updatedItems = prev.map((elem) => {
        if (elem.id === item.id) {
          // Update the specified field for the matching item
          return { ...elem, [field]: value };
        }
        return elem;
      });

      return updatedItems;
    });
  };

  const handleDelete = (item) => {
    if (item?.id !== 1) {
      const updatedAccordionItems = accordions.filter(
        (accItem) => accItem.id !== item?.id
      );

      // Update the expanded state if the deleted accordion was expanded
      if (expanded === item.id) {
        setExpanded(
          updatedAccordionItems.length > 0 ? updatedAccordionItems[0].id : null
        );
      }

      setAccordions(updatedAccordionItems);
    }
  };
  return (
    <>
      <Container
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "30px",
        }}
      >
        <Container
          style={{ display: "flex", justifyContent: "start", gap: "10px" }}
        >
          <EditIcon fontSize="large" style={{ color: "green" }} />
          <Box fontSize={"20px"}>Facilities</Box>
        </Container>
        <Container
          style={{ display: "flex", flexDirection: "column", gap: "20px" }}
        >
          {accordions?.map((item, index) => {
            return (
              <Container
                key={item.id} // Use item.id as the key
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Accordion
                  key={item?.id}
                  expanded={expanded === item?.id}
                  onChange={() => setExpanded(index + 1)}
                >
                  <AccordionSummary
                    style={{ backgroundColor: "#dedcdc" }}
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography>Accordian {index + 1}</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "20px",
                      }}
                    >
                      <Container
                        style={{
                          display: "flex",
                          gap: "10px",
                          flexWrap: "wrap",
                        }}
                      >
                        <Input
                          type="text"
                          onChange={(e) => {
                            handleInputChange("name", item, e.target.value);
                          }}
                          value={item?.name}
                          placeholder="Name"
                          style={{
                            padding: "7px",
                            flex: "1 1 49%",
                            margin: "10px 0",
                          }}
                        />
                        <Input
                          type="text"
                          placeholder="Internal ID"
                          onChange={(e) => {
                            handleInputChange(
                              "internal_id",
                              item,
                              e.target.value
                            );
                          }}
                          value={item?.internal_id}
                          style={{
                            padding: "7px",
                            flex: "1 1 49%",
                            margin: "10px 0",
                          }}
                        />
                        <Input
                          type="text"
                          placeholder="Generator Status"
                          onChange={(e) => {
                            handleInputChange(
                              "generator_status",
                              item,
                              e.target.value
                            );
                          }}
                          value={item?.generator_status}
                          style={{
                            padding: "7px",
                            flex: "1 1 49%",
                            margin: "10px 0",
                          }}
                        />
                        <Input
                          type="text"
                          placeholder="EPA ID#"
                          onChange={(e) => {
                            handleInputChange("epa_id", item, e.target.value);
                          }}
                          value={item?.epa_id}
                          style={{
                            padding: "7px",
                            flex: "1 1 49%",
                            margin: "10px 0",
                          }}
                        />
                        <Input
                          type="text"
                          placeholder="Address"
                          onChange={(e) => {
                            handleInputChange("address", item, e.target.value);
                          }}
                          value={item?.address}
                          style={{
                            padding: "7px",
                            flex: "1 1 49%",
                            margin: "10px 0",
                          }}
                        />
                        <Input
                          type="text"
                          placeholder="Region"
                          onChange={(e) => {
                            handleInputChange("region", item, e.target.value);
                          }}
                          value={item?.region}
                          style={{
                            padding: "7px",
                            flex: "1 1 49%",
                            margin: "10px 0",
                          }}
                        />
                        <Input
                          type="text"
                          placeholder="Phone Number"
                          onChange={(e) => {
                            handleInputChange(
                              "phone_number",
                              item,
                              e.target.value
                            );
                          }}
                          value={item?.phone_number}
                          style={{
                            padding: "7px",
                            flex: "1 1 49%",
                            margin: "10px 0",
                          }}
                        />
                      </Container>
                    </div>
                  </AccordionDetails>
                </Accordion>
                <DeleteIcon
                  style={{
                    marginLeft: "10px",
                    cursor: "pointer",
                    visibility: item?.id !== 1 ? "visible" : "hidden",
                  }}
                  onClick={() => handleDelete(item)}
                />
              </Container>
            );
          })}
        </Container>
        <Container style={{ textAlign: "center" }}>
          <Button
            style={{ backgroundColor: "#2f7d32", color: "white" }}
            onClick={addAccordion}
          >
            Add Another Facility
          </Button>
        </Container>
      </Container>
    </>
  );
};

export default Facilities;
