import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';

import { Grid, makeStyles, Typography, Paper, Button } from '@material-ui/core';

import {
  getCSCurrentWeekSpills,
  getCSCurrentWeekAfterHours,
  getCSCurrentWeekBusinessHours,
  getCSCurrentWeekBroughtIntoOffice,
  getCSCurrentWeekExcavation,
  getCSCurrentWeekIncidentsTakenHome,
  getDailyWeeklyGisMap,
} from '../../../../../../../actionCreators/Analytics';
import BarChartWithRise from '../../../../../../../Components/BarChartWithRise';
import { endOfWeek } from 'date-fns';
import { startOfWeek } from 'date-fns/esm';
import moment from 'moment';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from '@material-ui/pickers';
import MomentUtils from '@date-io/moment';
import WeekPicker from '../../../../../../../Components/WeekPicker';
const minDate = '2011-01';
const dateFormat = 'MM-DD-YYYY';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
  },
  amountHeading: {
    fontSize: '35px',
    fontWeight: '600',
    color: '#434343',
  },
  insideCard: {
    width: '50%',
    margin: '0 auto',
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 0%), 0px 8px 10px 1px rgb(0 0 0 / 0%), 0px 3px 14px 2px rgb(0 0 0 / 0%)',
    marginTop: '24px',
    border: '1px solid #ededed',
  },
  chartHeadingFix: {
    fontSize: '15px',
    color: '#212121',
    textAlign: 'center',
    marginTop: '3px',
    marginBottom: '2px',
  },
  componentWrapper: {
    marginTop: '20px',
  },
}));

const CurrentStats = ({
  getCSCurrentWeekSpills,
  csCurrentWeekSpills,
  getCSCurrentWeekAfterHours,
  csCurrentWeekAfterHours,
  getCSCurrentWeekBusinessHours,
  csCurrentWeekBusinessHours,
  getCSCurrentWeekBroughtIntoOffice,
  csCurrentWeekBroughtIntoOffice,
  getCSCurrentWeekExcavation,
  csCurrentWeekExcavation,
  getCSCurrentWeekIncidentsTakenHome,
  csCurrentWeekIncidentsTakenHome,
  getDailyWeeklyGisMap,
  dailyWeeklyGisMap,
}) => {
  const classes = Styles();

  const getCurrentWeek = () => {
    const currentMonth = moment(new Date()).format('M');
    let startDate = moment(startOfWeek(new Date()));
    let endDate = moment(endOfWeek(new Date())).add(2, 'days'); //for next monday,moment consider sat as last day of week
    if (startDate.format('M') !== currentMonth)
      startDate = moment().startOf('month');
    if (endDate.format('M') !== currentMonth) endDate = moment().endOf('month');
    return {
      fromDate: startDate.toDate(),
      endDate: endDate.toDate(),
    };
  };

  const handleDailyWeeklyToggleDefault = () => {
    handleChangeDate(getCurrentWeek());
  };

  React.useEffect(() => {
    getCSCurrentWeekSpills();
    getCSCurrentWeekAfterHours();
    getCSCurrentWeekBusinessHours();
    getCSCurrentWeekBroughtIntoOffice();
    getCSCurrentWeekExcavation();
    getCSCurrentWeekIncidentsTakenHome();
    // getDailyWeeklyGisMap();
  }, []);

  React.useEffect(() => {
    //use for dispatching default request on change of toggle
    handleDailyWeeklyToggleDefault();
  }, []);

  const handleChangeDate = ({ fromDate, endDate }) => {
    //trigger on date picker for daily/weekly and dispatch request
    const dateRange = {
      startDate: moment(fromDate).format('MM-DD-YYYY'),
      endDate: [undefined, null].includes(endDate)
        ? endDate
        : moment(endDate).format('MM-DD-YYYY'),
    };
    //make dispatch function
    getDailyWeeklyGisMap({ ...dateRange });
  };

  return (
    <div className={classes.componentWrapper}>
      <Grid container spacing={4}>
        <Grid item xs={6} md={12}>
          <BarChartWithRise
            csWeeklySpills={true}
            title={`Current Weekly Total  (Total: ${csCurrentWeekSpills?.data?.data?.count})`}
            data={csCurrentWeekSpills?.data?.data?.spillsDayCount.map(
              (x, index) => ({
                day: x?.day,
                count: x?.count,
                value: x?.count,
              })
            )}
            loading={csCurrentWeekSpills?.loading}
            initialData={[
              {
                day: 'Mon',
                count: 0,
                value: 0,
              },
            ]}
            xLabel={'day'}
            yLabel={'value'}
            minValue={0}
          />
        </Grid>
        <Grid item xs={6} md={12}>
          <BarChartWithRise
            csWeeklySpills={true}
            title={`Current Week Business Hours  (Total: ${csCurrentWeekBusinessHours?.data?.data?.count})`}
            data={csCurrentWeekBusinessHours?.data?.data?.spillsDayCount.map(
              (x, index) => ({
                day: x?.day,
                count: x?.count,
                value: x?.count,
              })
            )}
            loading={csCurrentWeekBusinessHours?.loading}
            initialData={[
              {
                day: 'Mon',
                count: 0,
                value: 0,
              },
            ]}
            xLabel={'day'}
            yLabel={'value'}
            minValue={0}
          />
        </Grid>
        <Grid item xs={6} md={12}>
          <BarChartWithRise
            csWeeklySpills={true}
            title={`Current Week After Hours  (Total: ${csCurrentWeekAfterHours?.data?.data?.count})`}
            data={csCurrentWeekAfterHours?.data?.data?.spillsDayCount.map(
              (x, index) => ({
                day: x?.day,
                count: x?.count,
                value: x?.count,
              })
            )}
            loading={csCurrentWeekAfterHours?.loading}
            initialData={[
              {
                day: 'Mon',
                count: 0,
                value: 0,
              },
            ]}
            xLabel={'day'}
            yLabel={'value'}
            minValue={0}
          />
        </Grid>
        {/* ----------- */}
        <Grid item xs={6} md={12}>
          <BarChartWithRise
            csWeeklySpills={true}
            title={`Current Week Brought Into Office  (Total: ${csCurrentWeekBroughtIntoOffice?.data?.data?.count})`}
            data={csCurrentWeekBroughtIntoOffice?.data?.data?.spillsDayCount.map(
              (x, index) => ({
                day: x?.day,
                count: x?.count,
                value: x?.count,
              })
            )}
            loading={csCurrentWeekBroughtIntoOffice?.loading}
            initialData={[
              {
                day: 'Mon',
                count: 0,
                value: 0,
              },
            ]}
            xLabel={'day'}
            yLabel={'value'}
            minValue={0}
          />
        </Grid>
        <Grid item xs={6} md={12}>
          <BarChartWithRise
            csWeeklySpills={true}
            title={`Current Week Incident Taken Home  (Total: ${csCurrentWeekIncidentsTakenHome?.data?.data?.count})`}
            data={csCurrentWeekIncidentsTakenHome?.data?.data?.spillsDayCount.map(
              (x, index) => ({
                day: x?.day,
                count: x?.count,
                value: x?.count,
              })
            )}
            loading={csCurrentWeekIncidentsTakenHome?.loading}
            initialData={[
              {
                day: 'Mon',
                count: 0,
                value: 0,
              },
            ]}
            xLabel={'day'}
            yLabel={'value'}
            minValue={0}
          />
        </Grid>
        <Grid item xs={6} md={12}>
          <BarChartWithRise
            csWeeklySpills={true}
            title={`Current Week Excavation  (Total: ${csCurrentWeekExcavation?.data?.data?.count})`}
            data={csCurrentWeekExcavation?.data?.data?.spillsDayCount.map(
              (x, index) => ({
                day: x?.day,
                count: x?.count,
                value: x?.count,
              })
            )}
            loading={csCurrentWeekExcavation?.loading}
            initialData={[
              {
                day: 'Mon',
                count: 0,
                value: 0,
              },
            ]}
            xLabel={'day'}
            yLabel={'value'}
            minValue={0}
          />
        </Grid>
        {/*  */}

        <Grid container spacing={4}>
          {/* button and date picker */}
          <Grid
            xs={6}
            sm={9}
            md={9}
            lg={9}
            xl={9}
            className={classes.marginSelect}
          ></Grid>
          <Grid item xs={12} md={3}>
            <div className={classes.datesTypeWrapper}>
              <WeekPicker getRangeOfDate={handleChangeDate} minDate={minDate} />
            </div>
          </Grid>
          <Grid item xs={12} md={12} lg={12} xl={12}>
            <BarChartWithRise
              title='Weekly Numbers of Gis Map'
              data={
                Array.isArray(dailyWeeklyGisMap?.data?.data?.count)
                  ? dailyWeeklyGisMap?.data?.data?.count
                      ?.map((x, index) => {
                        if (index > 0 && x?.day === 'Mon') return null;
                        return {
                          day: `${x?.day}`,
                          count: x?.count,
                          value: x?.count,
                        };
                      })
                      ?.filter((x) => x)
                  : [
                      {
                        day: 'Mon',
                        count: 0,
                        value: 0,
                      },
                    ]
              }
              loading={dailyWeeklyGisMap?.loading}
              initialData={[
                {
                  day: 'Mon',
                  count: 0,
                  value: 0,
                },
              ]}
              xLabel={'day'}
              yLabel={'value'}
              minValue={0}
            />
          </Grid>
        </Grid>

        {/*  */}
      </Grid>
    </div>
  );
};

const mapStateToProps = ({
  analytics: {
    csCurrentWeekSpills,
    csCurrentWeekAfterHours,
    csCurrentWeekBusinessHours,
    csCurrentWeekBroughtIntoOffice,
    csCurrentWeekExcavation,
    csCurrentWeekIncidentsTakenHome,
    dailyWeeklyGisMap,
  },
}) => ({
  csCurrentWeekSpills,
  csCurrentWeekAfterHours,
  csCurrentWeekBusinessHours,
  csCurrentWeekBroughtIntoOffice,
  csCurrentWeekExcavation,
  csCurrentWeekIncidentsTakenHome,
  dailyWeeklyGisMap,
});

const mapDispatchToProps = (dispatch) => ({
  getDailyWeeklyGisMap: bindActionCreators(getDailyWeeklyGisMap, dispatch),
  getCSCurrentWeekSpills: bindActionCreators(getCSCurrentWeekSpills, dispatch),
  getCSCurrentWeekAfterHours: bindActionCreators(
    getCSCurrentWeekAfterHours,
    dispatch
  ),
  getCSCurrentWeekBusinessHours: bindActionCreators(
    getCSCurrentWeekBusinessHours,
    dispatch
  ),
  getCSCurrentWeekBroughtIntoOffice: bindActionCreators(
    getCSCurrentWeekBroughtIntoOffice,
    dispatch
  ),
  getCSCurrentWeekExcavation: bindActionCreators(
    getCSCurrentWeekExcavation,
    dispatch
  ),
  getCSCurrentWeekIncidentsTakenHome: bindActionCreators(
    getCSCurrentWeekIncidentsTakenHome,
    dispatch
  ),
});

CurrentStats.prototype = {
  workInProgress: PropTypes.object.isRequired,
  getWorkInProgress: PropTypes.func.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(CurrentStats)
);
