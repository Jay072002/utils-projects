import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';
import moment from 'moment';

import { Grid } from '@material-ui/core';

import { CustomSnackBar } from '../../../../../../../Components';

import { getFilteredSpillsStatusCount } from '../../../../../../../actionCreators/Analytics';
import BarChart from '../../../../../../../Components/BarChart';

const SpillsStatusAnalyticsMonthly = ({
  monthlyValue,
  filterValues,
  filteredSpillsStatusCount,
  getFilteredSpillsStatusCount,
}) => {
  const monthFormat = 'YYYY-MM';
  const [SpillStatusCountAverageRemoved, setSpillStatusCountAverageRemoved] =
    useState([]);

  React.useEffect(() => {
    getFilteredSpillsStatusCount({
      month: moment().format(monthFormat),
      type: 'monthly',
    });
  }, []);
  React.useEffect(() => {
    if (monthlyValue?.length > 0 || Object.keys(filterValues)?.length > 0) {
      getFilteredSpillsStatusCount({
        month: monthlyValue ? monthlyValue : moment().format(monthFormat),
        ...filterValues,
        type: 'monthly',
      });
    }
  }, [monthlyValue, filterValues]);

  React.useEffect(() => {
    if (filteredSpillsStatusCount?.data) {
      const removedAvgFilter = filteredSpillsStatusCount?.data.filter(
        (x) => x.count != null
      );
      setSpillStatusCountAverageRemoved(removedAvgFilter);
    }
  }, [filteredSpillsStatusCount]);

  return (
    <React.Fragment>
      <CustomSnackBar
        open={filteredSpillsStatusCount?.error}
        severity='error'
        snackBarMessage='Unable to fetch some stats.'
      />

      <Grid container spacing={4}>
        <Grid item xs={12} md={12} lg={12} xl={12}>
          <BarChart
            title='Spills Status Count'
            data={SpillStatusCountAverageRemoved || []}
            xLabel='status'
            yLabel='count'
            height={400}
            loading={filteredSpillsStatusCount?.loading}
            plotCount={SpillStatusCountAverageRemoved?.length}
          />
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

const mapStateToProps = ({ analytics: { filteredSpillsStatusCount } }) => ({
  filteredSpillsStatusCount,
});

const mapDispatchToProps = (dispatch) => ({
  getFilteredSpillsStatusCount: bindActionCreators(
    getFilteredSpillsStatusCount,
    dispatch
  ),
});

SpillsStatusAnalyticsMonthly.prototype = {
  monthlyValue: PropTypes.string,
  filterValues: PropTypes.object,
  getFilteredSpillsStatusCount: PropTypes.func.isRequired,
  filteredSpillsStatusCount: PropTypes.object.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SpillsStatusAnalyticsMonthly)
);
