import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';

import { Grid, makeStyles, Typography, Paper, Button } from '@material-ui/core';
import ColorToggleButton from '../../../../../../../Components/ToggleButton';
import CurrentStatsDay from './CurrentStatsDay';
import CurrentStatsWeek from './CurrentStatsWeek';

const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  chartHeading: {
    padding: '16px',
    paddingBottom: '10px',
    fontSize: '12px',
    textAlign: 'left',
  },
  amountHeading: {
    fontSize: '35px',
    fontWeight: '600',
    color: '#434343',
  },
  insideCard: {
    width: '50%',
    margin: '0 auto',
    boxShadow:
      '0px 5px 5px -3px rgb(0 0 0 / 0%), 0px 8px 10px 1px rgb(0 0 0 / 0%), 0px 3px 14px 2px rgb(0 0 0 / 0%)',
    marginTop: '24px',
    border: '1px solid #ededed',
  },
  chartHeadingFix: {
    fontSize: '15px',
    color: '#212121',
    textAlign: 'center',
    marginTop: '3px',
    marginBottom: '2px',
  },
}));

const CurrentStats = ({}) => {
  const classes = Styles();

  const [toggle, setToggle] = React.useState(1);
  const toggleItems = [
    { value: 1, label: 'Today' },
    { value: 2, label: 'Current Week' },
  ];

  return (
    <React.Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <Typography className={classes.analyticsHeading}>
              {`Current Stats(${toggleItems[toggle - 1].label})`}
            </Typography>
          </Grid>
          <Grid
            item
            xs={6}
            md={6}
            className={classes.datePickerContainer}
          ></Grid>
        </Grid>
        <ColorToggleButton
          initialValue={toggle}
          getValue={setToggle}
          items={toggleItems}
        />
        {toggle === 2 ? <CurrentStatsWeek /> : <CurrentStatsDay />}
      </Paper>
    </React.Fragment>
  );
};

export default withRouter(CurrentStats);
