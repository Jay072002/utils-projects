import React, { useState, useEffect, Fragment } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import { withRouter } from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid, Accordion, AccordionSummary, AccordionDetails, Checkbox, FormControlLabel, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, InputLabel } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ReactSelect from "react-select";
import { DatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';
import MomentUtils from "@date-io/moment";
import Select from 'react-select';
import * as contractorAction from "../../../../../actionCreators/Contractor";
import ContractorAcceptance from "../../../../../Components/EditSpill/ContractorAcceptance";
import {
    filterOption,
    compareContractor,
    getContractorOptions,
    convertToGroupedOptions,
    contractorColourStyles as colourStyles,
} from "../../../../../utils";
import reactSelect from "react-select";

const useStyles = makeStyles((theme) => ({

    mainContainer: {
        textAlign: 'left',
        paddingRight: "10px",
        paddingLeft: "10px",
    },
    customLable: {
        color: '#444444',
        fontSize: '15px',
        marginTop: '16px',
        marginBottom: '0px',
        display: 'inline-block'
    },
    ptb: {
        paddingBottom: "0 !important",
        paddingTop: "0 !important"
    },
    header: {
        color: "green",
        textAlign: "left",
    },

}));

const ContractorClient = ({
    contractorsWithAddress,
    getContractorsWithAddress, currentSpill }) => {

    const classes = useStyles();
    const [selectedContractors, setSelectedContractors] = useState([]);
    const [contractorOptions, setContractorOptions] = useState([]);
    const [admin, setAdmin] = useState([]);
    const [rejectedContractors, setRejectedContractors] = useState([]);
    const [prevRejectedContractors, setPrevRejectedContractors] = useState([]);
    const [selectedContractorDetails, setSelectedContractorDetails] = useState(null);

    //  for table
    function createData(location, DoNotUse) {
        return { location, DoNotUse };
    }
    const rows = [
        createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
        createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
        createData('Eclair', 262, 16.0, 24, 6.0),
        createData('Cupcake', 305, 3.7, 67, 4.3),
        createData('Gingerbread', 356, 16.0, 49, 3.9),
    ];

    useEffect(() => {
        getContractorsWithAddress();
    }, []);

    useEffect(() => {
        const newContractors = getContractorOptions(contractorsWithAddress.data);
        setContractorOptions(convertToGroupedOptions(newContractors));
    }, [contractorsWithAddress]);

    const handleContractorChange = (values) => {
        let inActiveCount = 0;
        // Find the selected contractor details based on entity_id
        const selectedEntityId = values.find((value) => value.entity_id)?.entity_id;
        if (selectedEntityId) {
            const matchingContractors = selectedContractors.filter(
                (contractor) => contractor.entity_id === selectedEntityId
            );
            setSelectedContractorDetails(matchingContractors);
        } else {
            setSelectedContractorDetails([]);
        }

        const newlyRejectedCount =
            values?.filter((o) => o?.accepted === false).length || 0;

        const oldRejectedCount =
            selectedContractors?.filter((o) => o?.accepted === false).length || 0;

        selectedContractors.map((x) => x.is_inactive === true && inActiveCount++);

        if (!values) {
            for (const index in selectedContractors) {
                removeContractor(index);
            }

            if (admin && admin.length) {
                let tempAdmin = [];
                for (const index in admin) {
                    if (admin[index].isMain) {
                        tempAdmin = [...tempAdmin, admin[index]];
                    } else if (admin[index].adminId) {
                        tempAdmin = [...tempAdmin, { ...admin[index], isRemoved: true }];
                    }
                }
                setAdmin(tempAdmin);
            }
        } else if (
            values.length < selectedContractors.length - inActiveCount ||
            newlyRejectedCount !== oldRejectedCount
        ) {
            let removedContractor;

            //Iterate over all prev selected contractors
            for (const contractorIndex in selectedContractors) {
                if (
                    selectedContractors[contractorIndex].is_inactive !== true &&
                    values.findIndex((o) =>
                        compareContractor(o, selectedContractors[contractorIndex])
                    ) === -1
                ) {
                    //if prev active contractor is not found in the list
                    removedContractor = { ...selectedContractors[contractorIndex] };

                    removeContractor(contractorIndex);
                } else if (selectedContractors[contractorIndex].accepted !== false) {
                    // ^ if not rejected

                    // Finding index of contractor which was previously not rejected and now rejected
                    const index = values.findIndex(
                        (o) =>
                            compareContractor(o, selectedContractors[contractorIndex]) &&
                            o.accepted === false
                    );
                    //If found previously
                    if (index !== -1) {
                        // Remove from selected contractors
                        const tempContractors = [...selectedContractors];
                        tempContractors.splice(contractorIndex, 1);
                        setSelectedContractors(tempContractors);

                        //Add to rejected contractors
                        rejectedContractors.push(values[index]);
                        setRejectedContractors(rejectedContractors);
                    }
                }
            }
            if (removedContractor) {
                // If some contractor is removed completely delete relative admin
                // oterwise make it inactive
                let tempAdmin = [...admin];
                for (const item in admin) {
                    if (compareContractor(admin[item], removedContractor)) {
                        if (tempAdmin[item].adminId) {
                            //In active
                            tempAdmin[item].isRemoved = true;
                        } else {
                            //Complete Removal
                            tempAdmin.splice(item, 1);
                        }
                    }
                }
                setAdmin(tempAdmin);
            }
        } else {
            //if not removed
            let addedContractor = null;
            let tempContractors = [...selectedContractors];

            //iterate over the updated array of contractors
            for (const contractorIndex in values) {
                //find index of element if it is newly added
                const index = selectedContractors.findIndex((o) =>
                    compareContractor(o, values[contractorIndex])
                );
                //Newly Added: set that to addedContractor
                if (index === -1) {
                    addedContractor = values[contractorIndex];
                    tempContractors = [
                        ...tempContractors,
                        { ...addedContractor, accepted: null },
                    ];
                } else {
                    //It was present before: Check if it was inactive then set to active or if it is newly accepted
                    if (
                        tempContractors[index].is_inactive ||
                        (values[contractorIndex].accepted &&
                            !tempContractors[index].accepted)
                    ) {
                        addedContractor = values[contractorIndex];
                        tempContractors[index].is_inactive = false;
                        tempContractors[index].accepted =
                            values[contractorIndex].accepted ?? null;
                        tempContractors[index].previouslyInactive =
                            values[contractorIndex]?.previouslyInactive === false
                                ? false
                                : true;
                    }
                }
            }
            if (!addedContractor) {
                //No newly added, exit the method
                return;
            }
            //Find the relevant admin if present
            let selection = admin.findIndex((o) =>
                compareContractor(o, addedContractor)
            );
            if (selection !== -1) {
                //Relevant admin found
                let tempAdmins = [...admin];
                tempAdmins[selection].isRemoved = false;
                setAdmin(tempAdmins);
            } else if (addedContractor.accepted) {
                //Check if added contractor is accepted, if not, donot create admin for it
                let tempAdmins = [
                    ...admin,
                    {
                        contractorId: addedContractor.contractor_id,
                        contractorAddressId: addedContractor.addressId,
                        adminId: null,
                        info: "",
                        pix: null,
                        spillSummary: null,
                        contractorInv: null,
                        wasteDoc: null,
                        contractorInvoice: "",
                        invNo: "",
                        finalContractorInv: "",
                        savings: "",
                        pesPaid: null,
                        contractorPaid: null,
                        transToCt: null,
                        payBy: null,
                        responseTime: "00:00",
                        isRemoved: false,
                        isMain: false,
                        isComplete: false,
                        pesInvNo: null,
                        pesInvAmount: null,
                        isNotRequired: false,
                        isNotRequiredCheck: false,
                    },
                ];
                setAdmin(tempAdmins);
            }
            setSelectedContractors(tempContractors);
        }
    };

    const removeContractor = (index) => {
        let tempContractors = [...selectedContractors];
        if (
            currentSpill.data.spillContractors.findIndex(
                (o) => o.value === selectedContractors[index].value
            ) === -1
        ) {
            //If contractor was not present in original list on spill fetching, then remove it completely
            tempContractors.splice(index, 1);
        } else {
            //If contractor to be removed was present in list when spill was fetched
            //make it inactive
            tempContractors[index].is_inactive = true;
        }
        setSelectedContractors(tempContractors);
    };

    const disableContractor = (contractorOptions) => {

        if (contractorOptions.tier_level === "Do Not Use") {
            return true;
        } else if (contractorOptions?.contractor_attachments_expiries?.length) {
            if (contractorOptions?.contractor_attachments_expiries[0].expiry_date === null) {
                return false;
            }
            const today = new Date();
            const expDate = new Date(contractorOptions?.contractor_attachments_expiries[0]?.expiry_date);
            // Set time components to 0
            expDate.setHours(0, 0, 0, 0);
            today.setHours(0, 0, 0, 0);
            if (expDate <= today) {
                return true; // expiry date has passed or is today
            } else {
                return false; // expiry date is in the future
            }
        }
    };

    return (
        <>
            <Grid container spacing={2} className={classes.mainContainer} style={{ textAlign: "left", paddingTop: 30, paddingLeft: 30, paddingRight: 30 }}>
                <Grid item xs={12} style={{ textAlign: "left" }} >
                    <InputLabel id="contractos_label" style={{marginBottom: 10}}>
                        Contractors
                    </InputLabel>

                    <ReactSelect
                        value={selectedContractors.filter(
                            (o) => !o.is_inactive
                        )}
                        isMulti
                        onChange={handleContractorChange}
                        filterOption={filterOption}
                        options={contractorOptions}
                        isOptionDisabled={disableContractor}
                        styles={colourStyles()} />
                </Grid>

                <Grid item xs={12}>
                    {selectedContractors
                        .filter((contractor) => !contractor.is_inactive && !contractor.entity_id).map((contractor, index) => {
                            const matchingContractors = selectedContractors.filter((con) => con.id === contractor.entity_id && !con.entity_id);
                            return (
                                <Accordion key={index} className="custom-accordion">
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-label="Expand"
                                        aria-controls={`additional-actions1-content-${index}`}
                                        id={`additional-actions1-header-${index}`}
                                    >
                                        <FormControlLabel
                                            aria-label="Acknowledge"
                                            onClick={(event) => event.stopPropagation()}
                                            onFocus={(event) => event.stopPropagation()}
                                            control={<Checkbox />}
                                            label={contractor.name}
                                        />
                                    </AccordionSummary>
                                    <AccordionDetails>
                                        <Grid xs={12}>
                                            {selectedContractorDetails !== null && selectedContractorDetails.length > 0 && (
                                                <TableContainer component={Paper}>
                                                    <Table className="customTable" aria-label="simple table">
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell>Location</TableCell>
                                                                <TableCell align="right">Do not Use</TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            {selectedContractorDetails.map((contractor, index) => (
                                                                <TableRow key={index}>
                                                                    <TableCell>{contractor.address}</TableCell>
                                                                    <TableCell align="right">
                                                                        {contractor.tier_level}
                                                                    </TableCell>
                                                                </TableRow>
                                                            ))}
                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                            )}
                                        </Grid>
                                    </AccordionDetails>
                                </Accordion>);
                        })}
                </Grid>
            </Grid>
        </>
    );
};

const mapStateToProps = ({
    contractor: { contractorsWithAddress },
}) => {
    return {
        contractorsWithAddress,
    };
};
const mapDispatchToProps = (dispatch) => ({
    getContractorsWithAddress: bindActionCreators(
        contractorAction.getContractorsWithAddress,
        dispatch
    ),
});
ContractorClient.propTypes = {
    getContractorsWithAddress: PropTypes.func.isRequired,
};
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ContractorClient)
);