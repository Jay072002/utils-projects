import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { withRouter } from "react-router-dom";

import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import SearchIcon from "@material-ui/icons/Search";
import TextField from "@material-ui/core/TextField";
import IconButton from "@material-ui/core/IconButton";
import InputAdornment from "@material-ui/core/InputAdornment";
import ClearIcon from "@material-ui/icons/Clear";

import * as searchActions from "../../../../../actionCreators/Search";

const SearchUser = ({ type, userRole, search, clearSearch }) => {
  const [searchText, setSearchText] = React.useState("");
  const [showClearButton, setShowClearButton] = React.useState(false);

  const handleClickClearSearchText = () => {
    setSearchText("");
    clearSearch();
    setShowClearButton(false);
  };

  const handleSubmit = async (e, searchText) => {
    e.preventDefault();

    let dataForSearch = {
      searchText,
      role: userRole,
      type,
    };

    search(dataForSearch);
  };

  return (
    <Grid container spacing={3}>
      <Grid item xs={6}>
        <TextField
          id="search_field"
          name="search_field"
          fullWidth
          autoComplete="search_field"
          onChange={(e) => {
            setShowClearButton(true);
            setSearchText(e.target.value);
          }}
          value={searchText}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle close visibility"
                  onClick={handleClickClearSearchText}
                >
                  {showClearButton ? <ClearIcon /> : null}
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      </Grid>
      <Grid item xs={2}>
        <Button
          color="primary"
          variant="text"
          onClick={(e) => handleSubmit(e, searchText)}
        >
          search
        </Button>
      </Grid>
    </Grid>
  );
};

const mapStateToProps = ({ user }) => ({
  user,
});

const mapDispatchToProps = (dispatch) => ({
  search: bindActionCreators(searchActions.search, dispatch),
  clearSearch: bindActionCreators(searchActions.clearSearch, dispatch),
});

SearchUser.prototype = {
  user: PropTypes.object.isRequired,
  searchUser: PropTypes.func.isRequired,
  clearSearch: PropTypes.func.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SearchUser)
);
