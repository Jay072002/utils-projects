// import React from 'react';
// import { connect } from 'react-redux';
// import { bindActionCreators } from 'redux';
// import { withRouter } from 'react-router-dom';
// import Moment from 'moment';
// import MomentUtils from '@date-io/moment';

// import Grid from '@material-ui/core/Grid';
// import { makeStyles } from '@material-ui/core/styles';
// import Typography from '@material-ui/core/Typography';
// import TextField from '@material-ui/core/TextField';
// import Avatar from '@material-ui/core/Avatar';
// import { green } from '@material-ui/core/colors';
// import Button from '@material-ui/core/Button';
// import InputAdornment from '@material-ui/core/InputAdornment';
// import AlternateEmailIcon from '@material-ui/icons/AlternateEmail';

// import * as userActions from '../../../../actionCreators/User';
// import {
//   KeyboardDateTimePicker,
//   MuiPickersUtilsProvider,
// } from '@material-ui/pickers';
// import { FormControlLabel, Switch } from '@material-ui/core';

// const useStyles = makeStyles((theme) => ({
//   avatar: {
//     backgroundColor: green[500],
//   },
//   button: {
//     marginTop: theme.spacing(3),
//     marginLeft: theme.spacing(1),
//   },
// }));

// function EditEmail({
//   closeModal,
//   editUserLicense,
//   userIsHazardous,
//   userInformation,
//   setUserIsHazardous,
//   setUserLicenseNumber,
//   setUserLicenseNumberExpiry,
// }) {
//   const classes = useStyles();

//   const { userLicenseNumber, userLicenseNumberExpiry } = userInformation;

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const obj = {
//       license_number: userLicenseNumber,
//       license_number_expiry: Moment(new Date(userLicenseNumberExpiry)).format(
//         'MM-DD-YYYY h:mm a'
//       ),
//       haz_waste_hauler: userIsHazardous,
//     };

//     await editUserLicense(obj);

//     await closeModal();
//   };

//   const handlerToggleHazWasteHauler = () => {
//     setUserIsHazardous(!userIsHazardous);
//   };

//   const handleLicenseNumberExpiryChange = (newValue) => {
//     setUserLicenseNumberExpiry(newValue);
//   };

//   const handleLicenseNumberChange = (e) => {
//     setUserLicenseNumber(e?.target?.value);
//   };

//   return (
//     <React.Fragment>
//       <Typography variant='h5' gutterBottom>
//         <div style={{ display: 'flex', justifyContent: 'space-between' }}>
//           <span style={{ display: 'flex' }}>
//             <Avatar className={classes.avatar}>
//               <AlternateEmailIcon />
//             </Avatar>
//             <div style={{ marginLeft: '10px' }} />
//             My License
//           </span>
//           <span>
//             <FormControlLabel
//               control={
//                 <Switch
//                   labelId='haz-waster-hauler'
//                   id='haz-waster-hauler'
//                   checked={userIsHazardous}
//                   onChange={handlerToggleHazWasteHauler}
//                   name='userIsHazardous'
//                   color='primary'
//                 />
//               }
//               label='Haz Waste Hauler'
//             />
//           </span>
//         </div>
//       </Typography>

//       <div style={{ paddingTop: 30 }} />

//       {userIsHazardous ? (
//         <form onSubmit={handleSubmit}>
//           <Grid container spacing={3}>
//             <Grid item xs={6}>
//               <TextField
//                 id='license_number'
//                 name='license_number'
//                 label='License Number'
//                 fullWidth
//                 defaultValue={userLicenseNumber}
//                 onChange={handleLicenseNumberChange}
//                 autoComplete='license_number'
//                 InputProps={{
//                   startAdornment: (
//                     <InputAdornment position='start'></InputAdornment>
//                   ),
//                 }}
//                 required
//               />
//             </Grid>
//             <Grid item xs={6}>
//               <MuiPickersUtilsProvider utils={MomentUtils}>
//                 <KeyboardDateTimePicker
//                   style={{ margin: '0px 10px' }}
//                   variant='inline'
//                   format='MM-DD-YYYY hh:mm a'
//                   id='license_number_expiry'
//                   label='License Expiration Date'
//                   showTodayButton
//                   ampmInClock={true}
//                   clearable={true}
//                   value={userLicenseNumberExpiry}
//                   onChange={handleLicenseNumberExpiryChange}
//                   KeyboardButtonProps={{
//                     aria_label: 'change date',
//                   }}
//                 />
//               </MuiPickersUtilsProvider>
//             </Grid>
//             <Grid item xs={12} style={{ textAlign: 'right' }}>
//               <Button
//                 className={classes.button}
//                 variant='contained'
//                 color='primary'
//                 type='submit'
//               >
//                 Update
//               </Button>
//               <Button
//                 className={classes.button}
//                 variant='contained'
//                 color='primary'
//                 onClick={() => closeModal()}
//               >
//                 Cancel
//               </Button>
//             </Grid>
//           </Grid>
//         </form>
//       ) : (
//         <Grid item xs={12} style={{ textAlign: 'right' }}>
//           <Button
//             className={classes.button}
//             variant='contained'
//             color='primary'
//             onClick={() => closeModal()}
//           >
//             Cancel
//           </Button>
//         </Grid>
//       )}
//     </React.Fragment>
//   );
// }

// const mapStateToProps = ({ user }) => ({ user });

// const mapDispatchToProps = (dispatch) => ({
//   editUserLicense: bindActionCreators(userActions.editUserLicense, dispatch),
// });

// export default withRouter(
//   connect(mapStateToProps, mapDispatchToProps)(EditEmail)
// );
