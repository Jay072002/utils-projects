import React, { useState } from 'react';

import { makeStyles, Typography, Box, Tabs, Tab } from '@material-ui/core';

import SpillsStatusClient from './Components/TabsContentClient/SpillsStatusClient';
import SpillsIncidentClient from './Components/TabsContentClient/SpillsIncidentClient';
import InvoiceClient from './Components/TabsContentClient/InvoiceClient';
import IncidentsCompletionClient from './Components/TabsContentClient/IncidentsCompletionClient';

const TabStyles = makeStyles((theme) => ({
  tabWrapper: {
    marginBottom: '12px',
    '& span.MuiTabs-indicator': {
      backgroundColor: '#397D33',
    },
  },
  singleTab: {
    fontWeight: 'bold',
    color: '#397D33',
    fontSize: '15px',
  },

  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
}));

const AnalyticsClientTabWrapper = () => {
  const classes = TabStyles();
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <React.Fragment>
      <Box sx={{ borderBottom: 1, borderColor: '#397d33' }}>
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label='basic tabs example'
          className={classes?.tabWrapper}
        >
          <Tab label='Spills Status' className={classes?.singleTab} />
          <Tab label='Spills Incidents' className={classes?.singleTab} />
          <Tab label='Incidents Completion' className={classes?.singleTab} />
          <Tab label='Invoice' className={classes?.singleTab} />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
        <SpillsStatusClient />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <SpillsIncidentClient />
      </TabPanel>
      <TabPanel value={value} index={2}>
        <IncidentsCompletionClient />
      </TabPanel>
      <TabPanel value={value} index={3}>
        <InvoiceClient />
      </TabPanel>
    </React.Fragment>
  );
};

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
export default AnalyticsClientTabWrapper;
