import React, { useState, useEffect } from "react";
import MomentUtils from "@date-io/moment";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import moment from "moment";

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
  KeyboardTimePicker,
  DateTimePicker,
  TimePicker,
} from "@material-ui/pickers";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Container,
  FormControl,
} from "@material-ui/core";
import { green } from "@material-ui/core/colors";
import NoteAttachmentTable from "../../../../../Components/NoteAttachmentTable";
import SalvageContainer from "./SalvageContainer";
import {
  Constants,
  getAttachmentTypes,
  photoTypes,
  roundOff,
  getAttachmentsTypeCount,
  getTotalExcavationTime,
  convertServicesObj,
  orderAlphabatically,
  timeConvertHHMMtoMins,
} from "../../../../../utils";
import { TextBox } from "../../../../../Components";
import { CustomSelect } from "../../../../../Components/MultiLvlSelect";
import FileUploader from "../../../../../Components/FileUploader";

const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: green[500],
  },
  root: {
    "& .MuiTextField-root": {
      margin: theme.spacing(1),
      width: 200,
    },
  },
  button: {
    marginTop: theme.spacing(2),
    marginLeft: theme.spacing(1),
  },
  alignRight: {
    textAlign: "right",
    paddingRight: "20px",
  },
  topMargin: {
    marginTop: "0px",
  },
  formControl: {
    minWidth: "150px",
    margin: "10px 5px 0 5px",
  },
}));

const CreateNote = ({
  closeNoteFrom,
  submitNote,
  Notes,
  currentUser,
  spillRate,
  currentSpill,
  setSelectedVideoFiles,
  checkSelectedServiceHandler,
}) => {
  const classes = useStyles();

  const [containers, setContainers] = useState([]);
  const [note, setNote] = useState({
    userId: currentUser?.data?.id,
    noteId: true,
    serviceId: "",
    serviceType: "",
    rate: "",
    hour: "",
    amount: "",
    description: "",
    reportNo: "",
    ipAddressIdentifier: "",
    owner: "",
    samples: "",
    cost: "",
    establishLaneClosure: "",
    excavationBegun: "",
    excavationCompleted: "",
    date: null,
    time: "",
    taskAssociatedRelevance: "",
    type: "",
    projected_eta: null,
    actual_eta: null,
  });
  const [attachmentTypesCount, setAttachmentTypesCount] = useState(null);
  const [selectedService, setSelectedService] = useState();
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [customPhotoType, setCustomPhotoType] = useState("");
  const [filesList, setFilesList] = useState([]);
  const [fileInfo, setFileInfo] = useState([]);
  const [fileType, setFileType] = useState("");
  const [miscType, setMiscType] = useState("");
  const [photoType, setPhotoType] = useState("");

  useEffect(() => {
    if (note.serviceId) {
      const [service] = Notes.filter(
        (service) => service.id === note.serviceId
      );
      const serviceObject = {
        ...service,
        rate: service.type ? service.rate || spillRate : spillRate,
        type: service.type || "hourly",
      };
      checkSelectedServiceHandler(serviceObject);
      setSelectedService(serviceObject);
    }
  }, [note.serviceId]);

  useEffect(() => {
    const attachedFilesNameList = [];
    currentSpill?.data?.spill?.spill_notes?.map((spillNote) =>
      spillNote?.note_attachments?.map((attachment) => {
        attachedFilesNameList.push(attachment.name);
      })
    );
    setFilesList([...attachedFilesNameList]);

    setAttachmentTypesCount(getAttachmentsTypeCount(currentSpill));
  }, [currentSpill]);

  const handleNoteChange = (key) => (event) => {
    let fieldVal = event?.target?.value;

    if (key === "serviceId") {
      const service = Notes.find((obj) => obj.id === fieldVal);
      const rate = service?.type ? service.rate || spillRate : spillRate;
      const type = service?.type || "hourly";
      setNote((val) => ({
        ...val,
        rate: roundOff(rate, 2),
        type,
        amount: roundOff(type === "fixed" ? rate : rate * val.hour, 2),
        hour: roundOff(type === "fixed" ? 0 : val.hour || 0, 2),
      }));
    }
    if (
      key === "rate" ||
      key === "amount" ||
      key === "hour" ||
      key === "samples" ||
      key === "cost"
    ) {
      if (key === "hour" && fieldVal === ".") fieldVal = 0 + ".";

      if (isNaN(fieldVal)) return;
    }
    setNote((val) => ({ ...val, [key]: fieldVal }));

    if (key === "rate" && note?.hour) {
      setNote((val) => ({
        ...val,
        amount: roundOff(fieldVal * (note.type === "fixed" ? 1 : note.hour), 2),
        rate: roundOff(fieldVal, 2),
      }));
    }

    if (key === "hour" && note?.rate) {
      setNote((val) => ({
        ...val,
        amount: roundOff(note.rate * (+fieldVal).toFixed(2), 2),
        hour: roundOff(fieldVal, 2),
      }));
    }
  };

  const handleSubmit = () => {
    if (selectedService?.name === Constants.EXCAVATION_COMPLETED_SERVICE_NAME) {
      note.excavation_time = getTotalExcavationTime(currentSpill?.data?.spill);
    }

    const videoAttachmentTypes = selectedFiles?.filter((file) =>
      file?.type?.includes("video")
    );

    setSelectedVideoFiles([...videoAttachmentTypes]);

    if (currentUser.data.role.permission.edit_own_notes) {
      if (note.description === "") {
        return;
      }
      const completeNote = {
        ...note,
        attachments: selectedFiles,
        type: "Custom Note",
      };
      submitNote(completeNote, selectedService.email_notifications);
      closeNoteFrom();
    } else {
      if (
        note.serviceId === "" ||
        note.rate === "" ||
        note.amount === "" ||
        note.description === "" ||
        !note.type
      ) {
        return;
      }
      const completeNote = {
        ...note,
        containers: containers,
        serviceType: selectedService.name,
        attachments: selectedFiles,
        projected_eta: selectedService?.projected_eta
          ? timeConvertHHMMtoMins(note?.projected_eta)
          : null,
        actual_eta: null,
      };
      submitNote(completeNote, selectedService.email_notifications);
      closeNoteFrom();
    }
  };

  const updateFileType = (type) => {
    switch (type) {
      case "Photo":
        return photoType;
      case "Custom":
        return customPhotoType;
      default:
        return type;
    }
  };

  const onFileChangeHandler = (event) => {
    let tempFiles = [...selectedFiles];
    let type = "";
    let fileName = "";

    const includeIncidentNo = [
      "Response Authorization",
      "Response Authorization Email",
      "Invoice & Report Package",
    ];

    const uniqueAttachment = [
      "Situational Analysis",
      "Invoice & Report Package",
    ];

    const tempFilesList = filesList;
    let totalFiles = [];
    for (let file of event?.target?.files) {
      type = updateFileType(fileType);

      attachmentTypesCount[type] = attachmentTypesCount[type] + 1;

      let ext = file.name.split(".");
      ext = ext[ext.length - 1];

      fileName = `${
        includeIncidentNo.includes(type)
          ? `${currentSpill.data.spill.job_no} `
          : ""
      }${type}${
        uniqueAttachment.includes(type)
          ? `-${attachmentTypesCount[type]}`
          : `-${attachmentTypesCount[type]}`
      }.${ext}`;

      let updatedFileName;
      if (
        (miscType && miscType !== "") ||
        (customPhotoType && customPhotoType !== "")
      ) {
        const parts = file?.name?.split(".");

        let newFileName = `${miscType || customPhotoType}.${
          parts[parts.length - 1]
        }`;

        newFileName = newFileName?.split(".")[0];

        if (tempFilesList.find((file) => file === newFileName)) {
          totalFiles = tempFilesList.filter((file) =>
            file.includes(miscType || customPhotoType)
          );

          newFileName = `${newFileName}-${totalFiles.length + 1}`;

          updatedFileName = `${newFileName}.${parts[parts.length - 1]}`;
          tempFilesList.push(updatedFileName);
        } else {
          updatedFileName = `${newFileName}.${parts[parts.length - 1]}`;
          tempFilesList.push(newFileName);
        }

        fileName = updatedFileName;
      }
      Object.defineProperty(file, "name", {
        writable: true,
        value: fileName,
      });
      tempFiles = [...tempFiles, file];
    }

    setFilesList(tempFilesList);

    setAttachmentTypesCount(attachmentTypesCount);
    setSelectedFiles(tempFiles);

    setMiscType("");
    setCustomPhotoType("");

    event.target.value = "";
  };

  const onFileCancelHandler = (index) => {
    let tempFile = [...selectedFiles];
    tempFile.splice(index, 1);
    setSelectedFiles(tempFile);
  };

  return (
    <React.Fragment>
      {/* {selectedFiles.length > 0 && <FileUploader files={selectedFiles} />} */}
      <Container maxWidth="sm">
        <form
          style={{ width: "100%", margin: "30px, 20px" }}
          onSubmit={() => handleSubmit()}
        >
          <Grid container spacing={3} style={{ marginTop: "10px" }}>
            {/* {currentUser?.data?.role?.permission.edit_own_notes && ( */}
            <>
              <Grid item xs={12} style={{ textAlign: "left" }}>
                <InputLabel id="services_select_label">Service</InputLabel>
                <CustomSelect
                  options={convertServicesObj(Notes)}
                  onChange={handleNoteChange("serviceId")}
                />
              </Grid>
              {/* {!currentUser?.data?.role?.permission.edit_own_notes && ( */}
              <>
                <Grid item xs={4}>
                  <TextField
                    id="rate"
                    name="rate"
                    label="Rate"
                    fullWidth
                    autoComplete="rate"
                    required
                    disabled={note.type === "fixed"}
                    inputProps={{
                      value: note.rate,
                      min: 0,
                      step: 0.01,
                    }}
                    type={"number"}
                    onChange={handleNoteChange("rate")}
                  />
                </Grid>
                <Grid item xs={4}>
                  <TextField
                    id="hour"
                    name="hour"
                    label="Hour"
                    fullWidth
                    autoComplete="hour"
                    required
                    inputProps={{
                      value: note.hour,
                      min: 0,
                      step: 0.01,
                    }}
                    type={"number"}
                    onChange={handleNoteChange("hour")}
                  />
                </Grid>
                <Grid item xs={4}>
                  <TextField
                    id="amount"
                    name="amount"
                    label="Amount"
                    fullWidth
                    autoComplete="amount"
                    required
                    inputProps={{
                      value: note.amount,
                      min: 0,
                      step: 0.01,
                    }}
                    type={"number"}
                    onChange={handleNoteChange("amount")}
                    min={0}
                  />
                </Grid>
              </>
              {/* )} */}

              <Grid item xs={12}>
                <TextField
                  id="description"
                  name="description"
                  label="Description"
                  fullWidth
                  autoComplete="description"
                  required
                  multiline
                  inputProps={{
                    value: note.description,
                  }}
                  onChange={handleNoteChange("description")}
                />
              </Grid>
              {selectedService && selectedService.report_number && (
                <Grid item xs={6}>
                  <TextField
                    id="reportNo"
                    name="reportNo"
                    label="Report #"
                    fullWidth
                    autoComplete="reportNo"
                    required
                    inputProps={{
                      value: note.reportNo,
                    }}
                    onChange={handleNoteChange("reportNo")}
                  />
                </Grid>
              )}
              {selectedService && selectedService.state_incident_no && (
                <Grid item xs={6}>
                  <TextField
                    id="state_incident_no"
                    name="state_incident_no"
                    label="State Incident No"
                    fullWidth
                    autoComplete="state_incident_no"
                    required
                    inputProps={{
                      value: note.state_incident_no,
                    }}
                    onChange={handleNoteChange("state_incident_no")}
                  />
                </Grid>
              )}
              {selectedService && selectedService.national_incident_no && (
                <Grid item xs={6}>
                  <TextField
                    id="incident_no"
                    name="incident_no"
                    label="National Incident No"
                    fullWidth
                    autoComplete="incident_no"
                    required
                    inputProps={{
                      value: note.incident_no,
                    }}
                    onChange={handleNoteChange("incident_no")}
                  />
                </Grid>
              )}
              {selectedService && selectedService.ip_address_identifier && (
                <Grid item xs={6}>
                  <TextField
                    id="ipAddressIdentifier"
                    name="ipAddressIdentifier"
                    label="IP Address Identifier"
                    fullWidth
                    autoComplete="ipAddressIdentifier"
                    required
                    inputProps={{
                      value: note.ipAddressIdentifier,
                    }}
                    onChange={handleNoteChange("ipAddressIdentifier")}
                  />
                </Grid>
              )}
              {selectedService && selectedService.owner && (
                <Grid item xs={6}>
                  <TextField
                    id="owner"
                    name="owner"
                    label="Owner"
                    fullWidth
                    autoComplete="owner"
                    required
                    inputProps={{
                      value: note.owner,
                    }}
                    onChange={handleNoteChange("owner")}
                  />
                </Grid>
              )}
              {selectedService && selectedService.salvage_containers && (
                <Grid item xs={12}>
                  <SalvageContainer
                    containers={containers}
                    setContainers={setContainers}
                  />
                </Grid>
              )}
              {selectedService && selectedService.samples && (
                <Grid item xs={6}>
                  <TextField
                    id="samples"
                    name="samples"
                    label="No of Samples"
                    fullWidth
                    autoComplete="samples"
                    required
                    inputProps={{
                      value: note.samples,
                    }}
                    onChange={handleNoteChange("samples")}
                  />
                </Grid>
              )}
              {selectedService &&
                selectedService.cost &&
                (selectedService.name === "Schedule Excavation" ? (
                  <Grid item xs={6}>
                    <TextField
                      id="cost"
                      name="cost"
                      label="Project Cost"
                      fullWidth
                      autoComplete="cost"
                      required
                      inputProps={{
                        value: note.cost,
                      }}
                      onChange={handleNoteChange("cost")}
                    />
                  </Grid>
                ) : (
                  <Grid item xs={6}>
                    <TextField
                      id="cost"
                      name="cost"
                      label="Estimated Cost"
                      fullWidth
                      autoComplete="cost"
                      required
                      inputProps={{
                        value: note.cost,
                      }}
                      onChange={handleNoteChange("cost")}
                    />
                  </Grid>
                ))}
              {selectedService && selectedService.establish_lane_closure && (
                <Grid item xs={6} style={{ textAlign: "left" }}>
                  <InputLabel id="establishLaneClosure_select_label">
                    Lane Closure Established
                  </InputLabel>
                  <Select
                    labelId="establishLaneClosure_select_label"
                    id="establishLaneClosure_select"
                    name="establishLaneClosure"
                    style={{ width: "100%" }}
                    inputProps={{
                      value: note.establishLaneClosure,
                    }}
                    onChange={handleNoteChange("establishLaneClosure")}
                  >
                    <MenuItem value={true}>Yes</MenuItem>
                    <MenuItem value={false}>No</MenuItem>
                  </Select>
                </Grid>
              )}
              {selectedService?.name ===
                Constants.EXCAVATION_COMPLETED_SERVICE_NAME && (
                <Grid item xs={6} style={{ textAlign: "left" }}>
                  <TextBox
                    text={getTotalExcavationTime(currentSpill?.data?.spill)}
                    heading="Total Time"
                  />
                </Grid>
              )}
              {selectedService && selectedService.excavation_begun && (
                <Grid item xs={6} style={{ textAlign: "left" }}>
                  <InputLabel id="excavationBegun_select_label">
                    Excavation Begun
                  </InputLabel>
                  <Select
                    labelId="excavationBegun_select_label"
                    id="excavationBegun_select"
                    name="excavationBegun"
                    style={{ width: "100%" }}
                    inputProps={{
                      value: note.excavationBegun,
                    }}
                    onChange={handleNoteChange("excavationBegun")}
                  >
                    <MenuItem value={true}>Yes</MenuItem>
                    <MenuItem value={false}>No</MenuItem>
                  </Select>
                </Grid>
              )}
              {selectedService && selectedService.excavation_completed && (
                <Grid item xs={6} style={{ textAlign: "left" }}>
                  <InputLabel id="excavationCompleted_select_label">
                    Excavation Completed
                  </InputLabel>
                  <Select
                    labelId="excavationCompleted_select_label"
                    id="excavationCompleted_select"
                    name="excavationCompleted"
                    style={{ width: "100%" }}
                    inputProps={{
                      value: note.excavationCompleted,
                    }}
                    onChange={handleNoteChange("excavationCompleted")}
                  >
                    <MenuItem value={true}>Yes</MenuItem>
                    <MenuItem value={false}>No</MenuItem>
                  </Select>
                </Grid>
              )}
              {selectedService && selectedService.task_associated_relevance && (
                <Grid item xs={12}>
                  <TextField
                    id="taskAssociatedRelevance"
                    name="taskAssociatedRelevance"
                    label="Task Associated Relevance"
                    fullWidth
                    autoComplete="taskAssociatedRelevance"
                    required
                    inputProps={{
                      value: note.taskAssociatedRelevance,
                    }}
                    onChange={handleNoteChange("taskAssociatedRelevance")}
                  />
                </Grid>
              )}
              {selectedService && selectedService.time && (
                <Grid item xs={6}>
                  <MuiPickersUtilsProvider utils={MomentUtils}>
                    <KeyboardTimePicker
                      variant="inline"
                      margin="normal"
                      id="time_picker_inline"
                      label="Time"
                      inputProps={{
                        value: note.time,
                      }}
                      onChange={(time) =>
                        setNote((val) => ({
                          ...val,
                          ["time"]: time.format("hh:mmA"),
                        }))
                      }
                      KeyboardButtonProps={{
                        aria_label: "change time",
                      }}
                    />
                    <Button
                      style={{ textAlign: "center" }}
                      variant="contained"
                      color="primary"
                      onClick={() =>
                        setNote((val) => ({ ...val, ["time"]: "" }))
                      }
                    >
                      Clear
                    </Button>
                  </MuiPickersUtilsProvider>
                </Grid>
              )}
              {selectedService && selectedService.date && (
                <Grid item xs={6}>
                  <MuiPickersUtilsProvider utils={MomentUtils}>
                    {selectedService.name === "Schedule Excavation" ? (
                      <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="MM-DD-YYYY"
                        margin="normal"
                        id="date_picker_inline"
                        label="Scheduled Date"
                        inputProps={{
                          value: note.date
                            ? moment(note.date).format("MM-DD-YYYY")
                            : "",
                        }}
                        className={classes.topMargin}
                        onChange={(date) =>
                          setNote((val) => ({
                            ...val,
                            ["date"]: date.format("MM-DD-YYYY"),
                          }))
                        }
                        KeyboardButtonProps={{
                          aria_label: "change date",
                        }}
                      />
                    ) : (
                      <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="MM-DD-YYYY"
                        margin="normal"
                        id="date_picker_inline"
                        label="Date"
                        inputProps={{
                          value: note?.date
                            ? moment(note.date)?.format("MM-DD-YYYY")
                            : "",
                        }}
                        className={classes.topMargin}
                        onChange={(date) =>
                          setNote((val) => ({
                            ...val,
                            ["date"]: date?.format("MM-DD-YYYY"),
                          }))
                        }
                        KeyboardButtonProps={{
                          aria_label: "change date",
                        }}
                      />
                    )}

                    <Button
                      style={{ textAlign: "center" }}
                      variant="contained"
                      color="primary"
                      onClick={() =>
                        setNote((val) => ({ ...val, ["date"]: "" }))
                      }
                    >
                      Clear
                    </Button>
                  </MuiPickersUtilsProvider>
                </Grid>
              )}
            </>
            {/* )} */}
            {((selectedService && selectedService?.upload_attachment) ||
              currentUser?.data?.role?.permission?.edit_own_notes) && (
              <Grid container>
                <Grid item xs={12}>
                  <NoteAttachmentTable
                    files={[]}
                    preview={selectedFiles}
                    handleCancel={onFileCancelHandler}
                  ></NoteAttachmentTable>
                </Grid>
                <Grid item xs={12} className={classes.alignRight}>
                  <FormControl className={classes.formControl}>
                    <InputLabel id="form-control-file-type">
                      Attachment Type
                    </InputLabel>
                    <Select
                      labelId="select-file-type-label"
                      id="select-file-type"
                      value={fileType}
                      onChange={(event) => setFileType(event?.target?.value)}
                    >
                      <MenuItem value="">
                        <em>Select Attachment Type</em>
                      </MenuItem>
                      {orderAlphabatically(
                        getAttachmentTypes(selectedService?.name)
                      ).map((val, index) => (
                        <MenuItem key={index} value={val}>
                          {val}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>

                  {fileType === "Misc" ? (
                    <FormControl className={classes.formControl}>
                      <TextField
                        id="miscType"
                        name="miscType"
                        label="Misc Type"
                        autoComplete="miscType"
                        onChange={(event) =>
                          setMiscType(`${event.target.value}`)
                        }
                      />
                    </FormControl>
                  ) : null}

                  {fileType === "Photo" ? (
                    <FormControl className={classes.formControl}>
                      <InputLabel id="form-control-file-type">
                        Photo Type
                      </InputLabel>
                      <Select
                        labelId="select-file-type-label"
                        id="select-photo-type"
                        value={photoType}
                        disabled={fileType !== "Photo"}
                        onChange={(event) => setPhotoType(event.target.value)}
                      >
                        <MenuItem value="">
                          <em>Select Photo Type</em>
                        </MenuItem>
                        {orderAlphabatically(photoTypes).map((val, index) => (
                          <MenuItem key={index} value={val}>
                            {val}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  ) : null}
                  {fileType === "Photo" && photoType === "Custom" ? (
                    <FormControl className={classes.formControl}>
                      <TextField
                        id="customPhotoType"
                        name="customPhotoType"
                        label="Custom Photo Type"
                        autoComplete="customPhotoType"
                        onChange={(event) =>
                          setCustomPhotoType(`${event.target.value}`)
                        }
                      />
                    </FormControl>
                  ) : null}
                </Grid>
                <Grid item xs={12} className={classes.alignRight}>
                  <div>
                    <Button
                      variant="contained"
                      component="label"
                      color="primary"
                      className={classes.button}
                      disabled={
                        !fileType || (fileType === "Photo" && !photoType)
                      }
                    >
                      + Select Files
                      <input
                        type="file"
                        accept={
                          fileType === 'Video'
                            ? 'video/mp4, video/x-m4v, video/*'
                            : '.jpg, .png, .jpeg, .TIF, .pdf, .doc, .docx, .xls, .xlsx'
                        }
                        onChange={onFileChangeHandler}
                        hidden
                        multiple
                      />
                    </Button>
                  </div>
                </Grid>
              </Grid>
            )}
            {selectedService &&
              (selectedService.projected_eta || selectedService.actual_eta) && (
                <Grid item xs={12} textAlign={"center"}>
                  <MuiPickersUtilsProvider utils={MomentUtils}>
                    {/* <DateTimePicker
                      value={
                        selectedService?.projected_eta
                          ? note?.projected_eta
                          : note?.actual_eta
                      }
                      disablePast={
                        selectedService?.projected_eta ? true : false
                      }
                      ampm={false}
                      onChange={(time) =>
                        setNote((val) => ({
                          ...val,
                          [selectedService?.projected_eta
                            ? "projected_eta"
                            : "actual_eta"]: time,
                        }))
                      }
                      label={
                        selectedService?.projected_eta
                          ? "Projected ETA"
                          : "Actual ETA"
                      }
                      showTodayButton
                    /> */}
                    <KeyboardTimePicker
                      ampm={false}
                      keyboardIcon={null}
                      disableIgnoringDatePartForTimeValidation
                      disableOpenPicker
                      disablePast={
                        selectedService?.projected_eta ? true : false
                      }
                      disabled={selectedService?.actual_eta}
                      error={false}
                      helperText={
                        selectedService?.actual_eta &&
                        (note?.actual_eta === null ||
                          note?.actual_eta === undefined)
                          ? "Actual ETA will be calculated once the contractor has arrived on site"
                          : null
                      }
                      variant="inline"
                      placeholder="HH:MM"
                      label={
                        selectedService?.projected_eta
                          ? "Projected ETA"
                          : "Actual ETA"
                      }
                      mask="__:__"
                      views={["hours", "minutes"]}
                      format="HH:mm"
                      value={
                        selectedService?.projected_eta
                          ? note?.projected_eta
                          : note?.actual_eta
                      }
                      onChange={(time) =>
                        setNote((val) => ({
                          ...val,
                          [selectedService?.projected_eta
                            ? "projected_eta"
                            : "actual_eta"]: time && Object.entries(time)[1][1],
                        }))
                      }
                      // onChange={(time) => {
                      //   if (selectedService?.projected_eta) {
                      //     setNote((val) => ({
                      //       ...val,
                      //       projected_eta: time && Object.entries(time)[1][1],
                      //     }));
                      //   }

                      //   if (selectedService?.actual_eta) {
                      //     setNote((val) => ({
                      //       ...val,
                      //       actual_eta: null,
                      //     }));
                      //   }
                      // }}
                    />
                  </MuiPickersUtilsProvider>
                </Grid>
              )}
            {/* {currentUser?.data?.role?.permission.edit_own_notes && (
              <>
                <Grid item xs={12}>
                  <TextField
                    id="description"
                    name="description"
                    label="Description"
                    fullWidth
                    autoComplete="description"
                    required
                    multiline
                    inputProps={{
                      value: note.description,
                    }}
                    onChange={handleNoteChange("description")}
                  />
                </Grid>
              </>
            )} */}
            <Grid item xs={12} style={{ textAlign: "right" }}>
              <Button
                className={classes.button}
                variant="contained"
                color="primary"
                type={"submit"}
              >
                Create Note
              </Button>
              <Button
                className={classes.button}
                variant="contained"
                color="primary"
                onClick={() => closeNoteFrom()}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        </form>
      </Container>
    </React.Fragment>
  );
};

const mapStateToProps = ({ spill: { currentSpill }, user }) => ({
  currentUser: user.currentUser,
  currentSpill,
});

CreateNote.proptype = {
  closeNoteFrom: PropTypes.func.isRequired,
  submitNote: PropTypes.func.isRequired,
  currentUser: PropTypes.object.isRequired,
  currentSpill: PropTypes.object.isRequired,
};

export default connect(mapStateToProps)(CreateNote);
