import React from "react";
import PropTypes from "prop-types";
import { withRouter } from "react-router-dom";
import { useForm, Controller, FormProvider } from "react-hook-form";

import Grid from "@material-ui/core/Grid";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import TextField from "@material-ui/core/TextField";
import { green } from "@material-ui/core/colors";
import Container from "@material-ui/core/Container";

const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: green[500],
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
}));

const EditNewAddress = ({ addressData, onSubmit, editMultipleAddressType }) => {
  const classes = useStyles();

  const { handleSubmit, register } = useForm();
  const methods = useForm({
    defaultValues: {
      address: addressData.address,
      city: addressData.city,
      contact: addressData.contact,
      country: addressData.country,
      fax: addressData.fax,
      phone: addressData.phone,
      state: addressData.state,
      zipCode: addressData.zipCode,
    },
  });

  const onFinish = async (newAddress) => {
    if (editMultipleAddressType === "editExistingAddresses") {
      const editedData = {
        ...newAddress,
        id: addressData?.id,
        entity_id: addressData?.entity_id,
        entity_type: addressData?.entity_type,
      };

      await onSubmit(editedData);
    } else {
      await onSubmit(newAddress);
    }
  };

  return (
    <React.Fragment>
      <Container maxWidth="sm">
        <div style={{ paddingTop: 10 }} />
        <Typography variant="subtitle1" gutterBottom>
          <div style={{ textAlign: "center" }}>
            <span>Edit Location</span>
          </div>
        </Typography>
        <FormProvider {...methods}>
          <form
            onBlur={handleSubmit((data) => onFinish(data))}
            style={{ width: "100%" }}
          >
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Controller
                  as={TextField}
                  id="address"
                  name="address"
                  label="Address"
                  fullWidth
                  autoComplete="address"
                  inputRef={register({ required: true })}
                />
              </Grid>
              <Grid item xs={6}>
                <Controller
                  as={TextField}
                  id="city"
                  name="city"
                  label="City"
                  fullWidth
                  autoComplete="city"
                  inputRef={register({ required: true })}
                />
              </Grid>
              <Grid item xs={6}>
                <Controller
                  as={TextField}
                  id="state"
                  name="state"
                  label="State"
                  fullWidth
                  autoComplete="state"
                  inputRef={register({ required: true })}
                />
              </Grid>
              <Grid item xs={6}>
                <Controller
                  as={TextField}
                  id="zipCode"
                  name="zipCode"
                  label="Zip Code"
                  fullWidth
                  autoComplete="zipCode"
                  inputRef={register({ required: true })}
                />
              </Grid>
              <Grid item xs={6}>
                <Controller
                  as={TextField}
                  id="country"
                  name="country"
                  label="Country"
                  fullWidth
                  autoComplete="country"
                  inputRef={register({ required: true })}
                />
              </Grid>
              <Grid item xs={6}>
                <Controller
                  as={TextField}
                  id="phone"
                  name="phone"
                  label="Phone"
                  fullWidth
                  autoComplete="phone"
                  inputRef={register({ required: true })}
                />
              </Grid>
              <Grid item xs={6}>
                <Controller
                  as={TextField}
                  id="fax"
                  name="fax"
                  label="Fax"
                  fullWidth
                  autoComplete="fax"
                  inputRef={register({ required: true })}
                />
              </Grid>
              <Grid item xs={12}>
                <Controller
                  as={TextField}
                  id="contact"
                  name="contact"
                  label="Contact"
                  fullWidth
                  autoComplete="contact"
                  inputRef={register({ required: true })}
                />
              </Grid>
            </Grid>
          </form>
        </FormProvider>
      </Container>
    </React.Fragment>
  );
};

EditNewAddress.propTypes = {
  closeEditAddressModal: PropTypes.func.isRequired,
  addressData: PropTypes.object.isRequired,
  editMultipleAddressType: PropTypes.string,
};

export default withRouter(EditNewAddress);
