import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import * as contractorAction from '../../../../../../../actionCreators/Contractor';
import * as clientActions from '../../../../../../../actionCreators/Client';
import {
  getCurrentYearSpills,
  getFetchSpillsStatusesCountRoleBased,
  getHazIncidentsClient,
} from '../../../../../../../actionCreators/Analytics';
import React, { useState } from 'react';
import { Grid, makeStyles, Paper } from '@material-ui/core';
import BarChart from '../../../../../../../Components/BarChart';

import SingleStatChart from '../../../../../../../Components/SingleStatChart';
import BarChartWithRise from '../../../../../../../Components/BarChartWithRise';
const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  marginSelect: {
    marginTop: '12px',
  },
  filterIcon: {
    color: '#ffffffff',
    backgroundColor: '#397d33',
    fontSize: '40px',
    padding: '12px',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  filterBox: {
    textAlign: 'left',
    marginTop: '12px',
  },
  filterButtonSelect: {
    // textAlign: 'right',
    padding: '20px',
  },
}));
const SpillsStatusClient = ({
  getCurrentYearSpills,
  currentYearSpills,
  getFetchSpillsStatusesCountRoleBased,
  fetchSpillsStatusesCountRoleBased,
  getTurnedUsDownForContractor,
  getHazIncidentsClient,
}) => {
  const classes = Styles();
  const [barChartData, setBarChartData] = useState([
    [
      {
        status: 'Work In Progress',
        count: 0,
        value: 0,
      },
    ],
  ]);
  React.useEffect(() => {
    getCurrentYearSpills();
    getFetchSpillsStatusesCountRoleBased();
    getHazIncidentsClient();
  }, []);
  React.useEffect(() => {
    formattingDataForBarChart(fetchSpillsStatusesCountRoleBased?.data);
  }, [fetchSpillsStatusesCountRoleBased?.data]);
  const formattingDataForBarChart = (data) => {
    const requiredValues = [
      'Work In Progress',
      'Site Work Complete',
      'Extended Remediation',
      'Pending Excavation',
      'Pending Disposal',
      ' Documentation in Review',
    ];
    setBarChartData(
      data?.data
        ?.filter((item) => requiredValues.includes(item?.status))
        ?.map((item) => ({ ...item, value: item?.count }))
    );
  };

  return (
    <React.Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Spills YTD'}
              amount={currentYearSpills?.data?.NoOfSpills}
              loading={currentYearSpills?.loading}
              // status={singleStatChartIncreasingData.status}
            />
          </Grid>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Spills Closed YTD'}
              amount={
                fetchSpillsStatusesCountRoleBased?.data?.data?.[13]?.count
              }
              loading={fetchSpillsStatusesCountRoleBased?.loading}
              // status={singleStatChartIncreasingData.status}
            />
          </Grid>
        </Grid>
        <Grid container spacing={4}>
          <Grid item xs={12} md={12} lg={12} xl={12}>
            <BarChart
              title='Spills Status Count'
              data={barChartData || []}
              xLabel='status'
              yLabel='count'
              height={400}
              loading={fetchSpillsStatusesCountRoleBased?.loading}
            />
            {/* <BarChartWithRise
              title={
                'Monthly Difference of Current Month vs Previous Month @ Previous Year'
              }
              data={barChartData}
              loading={fetchSpillsStatusesCountRoleBased?.loading}
              initialData={barChartData}
              xLabel={'status'}
              yLabel={'value'}
              minValue={5}
            />{' '} */}
          </Grid>
        </Grid>
      </Paper>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: {
    spillsOnEachWorkDay,
    spillsOnEachWeek,
    spillStatusCount,
    currentMonthSpillProjection,
    averagePerDayPerWeek,
    currentYearSpills,
    fetchSpillsStatusesCountRoleBased,
    turnedUsDownForContractor,
  },
  contractor,
  client,
  user,
}) => ({
  admins: user.admins,
  organizationAdmins: user.organizationAdmins,
  spillsOnEachWorkDay,
  spillsOnEachWeek,
  spillStatusCount,
  currentMonthSpillProjection,
  averagePerDayPerWeek,
  contractorsWithAddress: contractor.contractorsWithAddress,
  clientChildren: client.clientChildren,
  currentUser: user.currentUser,
  loadingContractors: contractor.loading,
  clientOrganizationNames: client.clientOrganizationNames,
  clientOrganizationLoading: client.loading,
  currentYearSpills,
  fetchSpillsStatusesCountRoleBased,
  turnedUsDownForContractor,
});

const mapDispatchToProps = (dispatch) => ({
  getContractorsWithAddress: bindActionCreators(
    contractorAction.getContractorsWithAddress,
    dispatch
  ),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  getFetchSpillsStatusesCountRoleBased: bindActionCreators(
    getFetchSpillsStatusesCountRoleBased,
    dispatch
  ),
  getCurrentYearSpills: bindActionCreators(getCurrentYearSpills, dispatch),
  getHazIncidentsClient: bindActionCreators(getHazIncidentsClient, dispatch),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SpillsStatusClient)
);
