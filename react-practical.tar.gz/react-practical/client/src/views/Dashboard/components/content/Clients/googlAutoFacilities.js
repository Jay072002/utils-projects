import React, { useState, useEffect } from "react";
import { makeStyles } from '@material-ui/core/styles';
import { TextField, Grid, Typography, Accordion, AccordionSummary, AccordionDetails, Button, FormControlLabel, Checkbox } from '@material-ui/core';
import { DatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';
import MomentUtils from "@date-io/moment";
import NoteCardAccordion from '../../../../Dashboard/components/content/Spills/NoteCardAccordion';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import SettingsIcon from '@material-ui/icons/Settings';
// import PlacesAutocomplete, { geocodeByAddress, getLatLng } from 'react-google-places-autocomplete';
import GooglePlacesAutocomplete, { geocodeByPlaceId } from "react-google-places-autocomplete"

const useStyles = makeStyles((theme) => ({

    mainContainer: {
        textAlign: 'left',
        paddingRight: "10px",
        paddingLeft: "10px",
        marginTop: "10px"
    },
    customLable: {
        color: '#444444',
        fontSize: '15px',
        marginTop: '16px',
        marginBottom: '0px',
        display: 'inline-block'
    },
    header: {
        color: "green",
        textAlign: "left",
    },

}));

const Facilities = ({ onSubmit, facilitiesFormData, onChange }) => {
    const classes = useStyles();
    const [facilitiesCount, setFacilitiesCount] = useState(1);
    const [facilities, setFacilities] = useState([{ id: 1 }]);
    const [predictions, setPredictions] = useState([]);
    const [inputDisabled, setInputDisabled] = useState(false);
    const handleAddFacility = () => {
        const newFacilityId = facilitiesCount + 1;
        setFacilitiesCount(newFacilityId);
        setFacilities([...facilities, { id: newFacilityId }]);
    };

    const handleChangeFacilityData = (index, newData) => {
        const updatedFacilities = [...facilities];
        updatedFacilities[index] = { ...updatedFacilities[index], ...newData };
        setFacilities(updatedFacilities);
    };
    // const handleChange = (e) => {
    //     const { name, value } = e.target;
    //     onChange((prevFormData) => ({
    //         ...prevFormData,
    //         [name]: value,
    //     }));
    // };
    // const [selectedAddress, setSelectedAddress] = useState({
    //     country: '',
    //     state: '',
    //     city: '',
    //     zipcode: ''
    // });
    // const handleSelect = async (selected) => {
    //     try {
    //         const results = await geocodeByAddress(selected.label);
    //         const latLng = await getLatLng(results[0]);

    //         // Extract address components
    //         const addressComponents = results[0].address_components;
    //         const country = addressComponents.find(component => component.types.includes('country')).long_name;
    //         const state = addressComponents.find(component => component.types.includes('administrative_area_level_1')).long_name;
    //         const city = addressComponents.find(component => component.types.includes('locality')).long_name;
    //         const zipcode = addressComponents.find(component => component.types.includes('postal_code')).long_name;

    //         setSelectedAddress({
    //             address: selected.label,
    //             country,
    //             state,
    //             city,
    //             zipcode
    //         });
    //     } catch (error) {
    //         console.error('Error in handleSelect:', error);
    //     }
    // };
    const [value, setValue] = useState(null);
    const [selectedCountry, setSelectedCountry] = useState("");
    const [selectedCity, setSelectedCity] = useState("");
    const [selectedState, setSelectedState] = useState("");
    const [selectedPostalCode, setSelectedPostalCode] = useState("");

    //our default data
    console.log("value", value)
    console.log(value?.value?.place_id);
    useEffect(() => {
        if (value?.value?.place_id) {
            geocodeByPlaceId(value?.value?.place_id)
                .then(results => {
                    console.log(results);
                    const addressComponents = results[0].address_components;
                    const country = addressComponents.find(component => component.types.includes('country')).short_name;
                    const city = addressComponents.find(component => component.types.includes('locality')).long_name;
                    const state = addressComponents.find(component => component.types.includes('administrative_area_level_1')).long_name;
                    const postalCode = addressComponents.find(component => component.types.includes('postal_code')).long_name;

                    const countryName = country === "US" ? "United States of America" :
                    country === "CA" ? "Canada" : country;

                    setSelectedCountry(countryName);

                    setSelectedCity(city);
                    setSelectedState(state);
                    setSelectedPostalCode(postalCode);
                })
                .catch(error => console.error(error));
        }
    }, [value]);

    // updating our default data
    const [prediction, setPrediction] = useState(null);

    const handlePlaceSelected = (place) => {
        setPrediction(place);
        console.log("place", place);
    };


    return (
        <>
            <Grid container spacing={2} className={classes.mainContainer}  >
                <Grid item xs={12} style={{ textAlign: "right" }}>
                    <Button
                        className={classes.button}
                        variant='contained'
                        color='primary'
                        type='submit'
                    >
                        Upload file
                    </Button>

                </Grid>
                <Grid item md={12}>
                    {facilities.map((facility, index) => (
                        <Accordion key={facility.id} className="custom-accordion">
                            <AccordionSummary
                                aria-controls={`panel${index}a-content`}
                                id={`panel${index}a-header`}
                                expandIcon={<ExpandMoreIcon />}
                            >
                                {/* <SettingsIcon className="facilities-icon" /> */}
                                <FormControlLabel
                                    aria-label="Facilities Name"
                                    onClick={(event) => event.stopPropagation()}
                                    onFocus={(event) => event.stopPropagation()}
                                    control={<Checkbox />}
                                    label="Facilities Name"
                                />
                                {/* <Typography>Facilities Name</Typography> */}
                            </AccordionSummary>
                            <AccordionDetails>
                                <Grid container spacing={2} style={{ paddingLeft: 30, paddingRight: 30 }}>
                                    <Grid item sm={6}>
                                        {/* <TextField
                                            id="name"
                                            label="Name"
                                            fullWidth
                                            autoComplete="off"
                                            defaultValue={facilitiesData.name ?? ''}
                                            onChange={(e) =>
                                                setSelectedfacilitiesData({
                                                    ...facilitiesData,
                                                    name: e.target.value,
                                                })
                                            }
                                        /> */}
                                        <TextField
                                            id="name"
                                            name="name"
                                            label="Name"
                                            fullWidth
                                            size="small"
                                            value={facilitiesFormData?.name}
                                            onChange={e => onChange('name', e.target.value)}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            className={classes.customFormcontrol}
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        {/* <TextField
                                            id="internal_id"
                                            label="Internal ID"
                                            fullWidth
                                            size="small"
                                            defaultValue={facilitiesData.internal_id ?? ''}
                                            onChange={(e) =>
                                                setSelectedfacilitiesData({
                                                    ...facilitiesData,
                                                    internal_id: e.target.value,
                                                })
                                            }
                                        /> */}
                                        <TextField
                                            id="internal_id"
                                            name="internal_id"
                                            label="Internal ID"
                                            fullWidth
                                            size="small"
                                            value={facilitiesFormData?.internal_id}
                                            onChange={e => onChange('internal_id', e.target.value)}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            className={classes.customFormcontrol}
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        {/* <TextField
                                            id="generator_status"
                                            label="Generator Status"
                                            fullWidth
                                            size="small"
                                            defaultValue={facilitiesData.generator_status ?? ''}
                                            onChange={(e) =>
                                                setSelectedfacilitiesData({
                                                    ...facilitiesData,
                                                    generator_status: e.target.value,
                                                })
                                            }
                                        /> */}
                                        <TextField
                                            id="generator_status"
                                            name="generator_status"
                                            label="Generator Status"
                                            fullWidth
                                            size="small"
                                            value={facilitiesFormData?.generator_status}
                                            onChange={e => onChange('generator_status', e.target.value)}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            className={classes.customFormcontrol}
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        {/* <TextField
                                        id="epa_id"
                                            label="EPA ID#"
                                            fullWidth
                                            size="small"
                                            defaultValue={facilitiesData.epa_id ?? ''}
                                            onChange={(e) =>
                                                setSelectedfacilitiesData({
                                                    ...facilitiesData,
                                                    epa_id: e.target.value,
                                                })
                                            }
                                        /> */}
                                        <TextField
                                            id="epa_id"
                                            name="epa_id"
                                            label="EPA ID#"
                                            fullWidth
                                            size="small"
                                            value={facilitiesFormData?.epa_id}
                                            onChange={e => onChange('epa_id', e.target.value)}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            className={classes.customFormcontrol}
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        {/* <TextField
                                        id="phone_number"
                                            label="Phone Number"
                                            fullWidth
                                            size="small"
                                            type="number"
                                            defaultValue={facilitiesData.phone_number ?? ''}
                                            onChange={(e) =>
                                                setSelectedfacilitiesData({
                                                    ...facilitiesData,
                                                    phone_number: e.target.value,
                                                })
                                            }
                                        /> */}
                                        <TextField
                                            id="phone_number"
                                            name="phone_number"
                                            label="Phone Number"
                                            fullWidth
                                            size="small"
                                            value={facilitiesFormData?.phone_number}
                                            onChange={e => onChange('phone_number', e.target.value)}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            className={classes.customFormcontrol}
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        {/* <TextField
                                        id="region"
                                            label="Region"
                                            fullWidth
                                            defaultValue={facilitiesData.region ?? ''}
                                            onChange={(e) =>
                                                setSelectedfacilitiesData({
                                                    ...facilitiesData,
                                                    region: e.target.value,
                                                })
                                            }
                                            size="small"
                                        /> */}
                                        <TextField
                                            id="region"
                                            name="region"
                                            label="Region"
                                            fullWidth
                                            size="small"
                                            value={facilitiesFormData?.region}
                                            onChange={e => onChange('region', e.target.value)}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            className={classes.customFormcontrol}
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        {/* <TextField
                                        id="address"
                                            label="Address"
                                            fullWidth
                                            size="small"
                                            defaultValue={facilitiesData.address ?? ''}
                                            onChange={(e) =>
                                                setSelectedfacilitiesData({
                                                    ...facilitiesData,
                                                    address: e.target.value,
                                                })
                                            }
                                        /> */}
                                        {/* <TextField
                                            id="address"
                                            name="address"
                                            label="Address"
                                            fullWidth
                                            size="small"
                                            value={facilitiesFormData?.address}
                                            onChange={e => onChange('address', e.target.value)}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            className={classes.customFormcontrol}
                                        /> */}
                                        <GooglePlacesAutocomplete
                                            // apiKey="AIzaSyBW0FiE14960yj88XZTdbOlYA_JUKlmNMM"
                                            placeholder="Enter a location"
                                            // onPlaceSelected={handlePlaceSelected}
                                            selectProps={{
                                                value,
                                                onChange: setValue,
                                            }}
                                            autocompletionRequest={{
                                                componentRestrictions: {
                                                    country: ['us', 'ca'],
                                                },
                                            }}
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        <TextField
                                            label="Country"
                                            fullWidth
                                            size="small"
                                            className={classes.customFormcontrol}
                                            value={selectedCountry}
                                            disabled // Disable the field to prevent user input
                                        />
                                    </Grid>
                                    <Grid item sm={6}>
                                        <TextField
                                            label="State"
                                            fullWidth
                                            size="small"
                                            className={classes.customFormcontrol}
                                            value={selectedState}
                                            disabled // Disable the field to prevent user input
                                        />
                                    </Grid>
                                    <Grid item sm={6}>
                                        <TextField
                                            label="City"
                                            fullWidth
                                            size="small"
                                            className={classes.customFormcontrol}
                                            value={selectedCity}
                                            disabled // Disable the field to prevent user input
                                        />

                                    </Grid>
                                    <Grid item sm={6}>
                                        <TextField
                                            label="Postal Code"
                                            fullWidth
                                            size="small"
                                            className={classes.customFormcontrol}
                                            value={selectedPostalCode}
                                            disabled // Disable the field to prevent user input
                                        />
                                    </Grid>

                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                    ))}
                </Grid>

                <Grid item xs={12} style={{ textAlign: "center" }}>
                    <Button
                        className={classes.button}
                        variant='contained'
                        color='primary'
                        type='submit'
                        onClick={handleAddFacility}
                    >
                        Add Another Facilities
                    </Button>

                </Grid>
            </Grid>

        </>
    );
};

export default Facilities;