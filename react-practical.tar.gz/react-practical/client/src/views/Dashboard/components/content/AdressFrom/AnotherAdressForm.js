/* NOT BEING USED ANYMORE */
import React from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { useForm } from "react-hook-form";

import Grid from "@material-ui/core/Grid";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import TextField from "@material-ui/core/TextField";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import Container from "@material-ui/core/Container";


const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: green[500],
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
}));

function NewAddress({ agency, onSubmit, closeAddressModal }) {
  const classes = useStyles();

  const { handleSubmit, register } = useForm();

  const onFinish = async (newAddress) => {
    await onSubmit(newAddress);
    await closeAddressModal();
  };

  return (
    <React.Fragment>
      <Container maxWidth="sm">
        <div style={{ paddingTop: 10 }} />
        <Typography variant="subtitle1" gutterBottom>
          <div style={{ textAlign: "center" }}>
            <span>Other Location</span>
          </div>
        </Typography>
        <form
          onSubmit={handleSubmit((data) => onFinish(data))}
          style={{ width: "100%" }}
        >
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                id="address"
                name="address"
                label="Address"
                fullWidth
                autoComplete="address"
                required
                inputRef={register}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="city"
                name="city"
                label="City"
                fullWidth
                autoComplete="city"
                required
                inputRef={register}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="state"
                name="state"
                label="State"
                fullWidth
                autoComplete="state"
                inputRef={register}
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="zipCode"
                name="zipCode"
                label="Zip Code"
                fullWidth
                autoComplete="zipCode"
                inputRef={register}
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="country"
                name="country"
                label="Country"
                fullWidth
                autoComplete="country"
                inputRef={register}
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="phone"
                name="phone"
                label="Phone"
                fullWidth
                autoComplete="phone"
                inputRef={register}
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="fax"
                name="fax"
                label="Fax"
                fullWidth
                inputRef={register}
                autoComplete="fax"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                id="contact"
                name="contact"
                label="Contact"
                inputRef={register}
                fullWidth
                autoComplete="contact"
                required
              />
            </Grid>
          </Grid>
          <Grid item xs={12} style={{ textAlign: "right" }}>
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              type="submit"
            >
              Create
            </Button>
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => closeAddressModal()}
            >
              Cancel
            </Button>
          </Grid>
        </form>
      </Container>
    </React.Fragment>
  );
}

const mapStateToProps = ({ agency }) => ({ agency });

export default withRouter(
  connect(mapStateToProps)(NewAddress)
);
