import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import ReactSelect from 'react-select';
import { useForm } from 'react-hook-form';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';

import MomentUtils from '@date-io/moment';

import {
  MuiPickersUtilsProvider,
  KeyboardDateTimePicker,
} from '@material-ui/pickers';
import {
  Grid,
  Button,
  Container,
  Typography,
  InputLabel,
} from '@material-ui/core';
import { green } from '@material-ui/core/colors';
import { makeStyles } from '@material-ui/core/styles';

import * as spillActions from '../../../../../actionCreators/Spill';

import { forceToCST } from '../../../../../utils';
import { CustomProgressLoader } from '../../../../../Components';
import { USER_TYPE } from '../../../../../utils/keyMappers';

const useStyles = makeStyles((theme) => ({
  root: {
    '&$checked': {
      color: '#2F7D32',
    },
  },
  checked: {},
  avatar: {
    backgroundColor: green[500],
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
  hide: {
    visibility: 'none',
  },
  clearSearchButton: {
    textAlign: 'right',
  },
  alignLeft: {
    textAlign: 'left',
  },
  checkboxColor: {
    color: '#2F7D32',
  },
  radioGroupDisplay: {
    display: 'inline',
  },
  leftAlign: {
    textAlign: 'left',
  },
}));

const SearchSpillReports = ({
  history,
  loading,
  reportType,
  currentUser,
  goToSpills,
  getStatuses,
  searchSpills,
  reportsAllow,
  switchReportsHandler,
  setSpillFilters,
  batchUpdateAllow,
  setSelectedSpills,
  spillFiltersState,
  setSpillDataForFilter,
  setFinalSpillsSearchData,
}) => {
  const classes = useStyles();

  const location = history.location;

  const { handleSubmit, register } = useForm();

  const userRole = currentUser?.data?.role.role;

  document.title = 'Search';

  const [spillSelectData, setSpillSelectData] = React.useState({
    date_to: null,
    date_from: null,
  });
  const [status, setStatus] = React.useState({
    open: { value: false, label: 'Open: Open', name: 'open' },
    work_in_progress: {
      value: false,
      label: 'Open: Work in Progress',
      name: 'work_in_progress',
    },
    site_work_complete: {
      value: false,
      label: 'Open: Site Work Complete',
      name: 'site_work_complete',
    },
    extended_remediation: {
      value: false,
      label: 'Open: Extended Remediation',
      name: 'extended_remediation',
    },
    pending_excavation: {
      value: false,
      label: 'Open: Pending Excavation',
      name: 'pending_excavation',
    },
    documentation_in_review: {
      value: false,
      label: 'Open: Documentation In Review',
      name: 'documentation_in_review',
    },
    pending_disposal: {
      value: false,
      label: 'Open: Pending Disposal',
      name: 'pending_disposal',
    },
    close: { value: false, label: 'Closed: any', name: 'close' },
    invoiced_but_not_paid: {
      value: false,
      label: 'Closed: Invoice Submitted to Client',
      name: 'invoiced_but_not_paid',
    },
    paid_but_contractor_not_yet_paid: {
      value: false,
      label: 'Closed: Payment Pending',
      name: 'paid_but_contractor_not_yet_paid',
    },
    documentation_sent_back_to_contractor_for_revision: {
      value: false,
      label: 'Open: Documentation Sent Back to Contractor for Revision',
      name: 'documentation_sent_back_to_contractor_for_revision',
    },
    ready_to_invoice: {
      value: false,
      label: 'Open: Ready to Invoice',
      name: 'ready_to_invoice',
    },
    final_review: {
      value: false,
      label: 'Open: Final Review',
      name: 'final_review',
    },
    ready_to_close: {
      value: false,
      label: 'Open: Ready to Close',
      name: 'ready_to_close',
    },
    closed: { value: false, label: 'Closed: Closed', name: 'closed' },
  });
  const [spillQuestions, setSpillQuestions] = React.useState({
    map_needed: {
      value: false,
      name: 'map_needed',
      key: 0,
      label: 'Map Needed?',
    },
    need_5800: {
      value: false,
      name: 'need_5800',
      key: 0,
      label: 'Need 5800?',
    },
    is_waste: { value: false, name: 'is_waste', key: 0, label: 'Is Waste?' },
    has_msds: { value: false, name: 'has_msds', key: 0, label: 'Has Msds?' },
    is_hazmat: {
      value: false,
      name: 'is_hazmat',
      key: 0,
      label: 'Is Hazmat?',
    },
    response_sent: {
      value: false,
      name: 'response_sent',
      key: 0,
      label: 'Response Sent?',
    },
    drain_impacted: {
      value: false,
      name: 'drain_impacted',
      key: 0,
      label: 'Drain Impacted?',
    },
    waterway_impacted: {
      value: false,
      name: 'waterway_impacted',
      key: 0,
      label: 'Waterway Impacted?',
    },
  });
  React.useEffect(() => {
    handleClearSearch();
  }, [location.key]);

  React.useEffect(() => {
    if (spillFiltersState?.data) {
      maintainFiltersHandler();
    }
  }, [spillFiltersState?.data]);

  const handleSearchDateChange = (key) => (date) => {
    setSpillSelectData((val) => ({
      ...val,
      [key]: date,
    }));
  };

  const handleChangeQuestionCheckbox = (event) => {
    setSpillQuestions({
      ...spillQuestions,
      [event.target.name]: {
        value: event.target.checked,
        name: event.target.name,
        key: 1,
        label: spillQuestions[event.target.name].label,
      },
    });
  };
  const {
    open,
    work_in_progress,
    site_work_complete,
    extended_remediation,
    pending_excavation,
    documentation_in_review,
    pending_disposal,
    invoiced_but_not_paid,
    paid_but_contractor_not_yet_paid,
    documentation_sent_back_to_contractor_for_revision,
    closed,
    ready_to_invoice,
    final_review,
    ready_to_close,
    close,
  } = status;

  const onFinish = async (searchData) => {
    getStatuses();
    let statusData = [];
    let questionsData = {};

    for (let data in status) {
      if (status[data].value !== false) {
        statusData.push(status[data].label);
      }
    }
    searchData = {
      ...searchData,
      ...spillSelectData,
      statusData,
      id: currentUser?.data?.id,
      role: currentUser?.data?.role?.role,
      permission: currentUser?.data?.role?.permission?.view_related_spills,
      page: 0,
      isReport: true,
    };

    const dataForFilter = [
      spillSelectData.date_to ? `Date To: ${spillSelectData.date_to}, ` : null,
      spillSelectData.date_from
        ? `Opened From: ${spillSelectData.date_from}, `
        : null,
    ];

    const appliedFilters = {
      dateTo: spillSelectData.date_to ? spillSelectData.date_to : null,
      dateFrom: spillSelectData.date_from ? spillSelectData.date_from : null,
      status: status,
      questions: spillQuestions || null,
    };

    setSpillFilters(appliedFilters);

    setSpillDataForFilter(dataForFilter);

    setFinalSpillsSearchData({
      ...searchData,
      date_to: forceToCST(searchData.date_to),
      date_from: forceToCST(searchData.date_from),
    });
    searchSpills({
      ...searchData,
      date_to: forceToCST(searchData.date_to),
      date_from: forceToCST(searchData.date_from),
      userType: currentUser?.data?.test_user
        ? USER_TYPE.TEST
        : USER_TYPE.GENERAL,
    });

    for (let question in spillQuestions) {
      if (spillQuestions[question].value !== false) {
        questionsData = {
          ...questionsData,
          [question]: spillQuestions[question].key,
        };
      }
    }

    setSelectedSpills([]);
    history.push(
      `/dashboard/search-results?token=${batchUpdateAllow}&report=${reportsAllow}`
    );
  };

  const handleClearSearch = () => {
    setSpillSelectData({
      date_to: null,
      date_from: null,
    });
    let statusData = {};
    let questionData = {};

    for (const [key, value] of Object.entries(status)) {
      statusData = {
        ...statusData,
        [key]: { ...value, value: false },
      };
    }
    for (const [key, value] of Object.entries(spillQuestions)) {
      questionData = {
        ...questionData,
        [key]: { ...value, value: false },
      };
    }
  };

  const maintainFiltersHandler = () => {
    const initialFiltersData = spillFiltersState?.data;

    if (Object.keys(initialFiltersData).length !== 0) {
      setSpillSelectData({
        date_to: initialFiltersData?.dateTo,
        date_from: initialFiltersData?.dateFrom,
      });
      setStatus(initialFiltersData?.status);
    }
  };

  return (
    <React.Fragment>
      <div style={{ paddingTop: 10 }} />

      <Container maxWidth='lg'>
        <form
          onSubmit={handleSubmit((data) => onFinish(data))}
          style={{ width: '100%' }}
        >
          <Grid container spacing={3}>
            <Grid item xs={8} style={{ textAlign: 'left' }}>
              <Typography variant='h5' gutterBottom>
                Report Invoice Submitted to Client
              </Typography>
            </Grid>
            <Grid item xs={4} style={{ textAlign: 'right' }}>
              <Button
                variant='contained'
                color='primary'
                type='reset'
                onClick={() => handleClearSearch()}
              >
                Clear filters
              </Button>
            </Grid>
          </Grid>
          {loading ? (
            <CustomProgressLoader show={true} />
          ) : (
            <Grid container spacing={3}>
              <Grid item xs={12} className={classes.leftAlign}>
                <InputLabel
                  id='location_type_label'
                  className={classes.locationTypeLabel}
                >
                  By giving the "date from" and "date to" you can filter the
                  spills whose status is in "Invoice Submitted to Client".
                  (Spill status may be changed now).
                </InputLabel>
              </Grid>
              <Grid item xs={12}>
                <Typography variant='subtitle2'>
                  Date Range (and format) (MM-DD-YYYY hh:mm am/pm)
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <MuiPickersUtilsProvider utils={MomentUtils}>
                  <KeyboardDateTimePicker
                    value={spillSelectData?.date_to}
                    onChange={handleSearchDateChange('date_to')}
                    label={'Date To'}
                    showTodayButton
                    ampmInClock={true}
                    clearable={true}
                    format='MM-DD-YYYY hh:mm a'
                  />
                </MuiPickersUtilsProvider>
              </Grid>
              <Grid item xs={6}>
                <MuiPickersUtilsProvider utils={MomentUtils}>
                  <KeyboardDateTimePicker
                    value={spillSelectData?.date_from}
                    onChange={handleSearchDateChange('date_from')}
                    label={'Date From'}
                    showTodayButton
                    ampmInClock={true}
                    clearable={true}
                    format='MM-DD-YYYY hh:mm a'
                  />
                </MuiPickersUtilsProvider>
              </Grid>

              <Grid item xs={12} style={{ textAlign: 'right' }}>
                <Button
                  className={classes.button}
                  variant='contained'
                  color='primary'
                  type='submit'
                >
                  Search
                </Button>
                <Button
                  className={classes.button}
                  variant='contained'
                  color='primary'
                  onClick={() => switchReportsHandler && switchReportsHandler(null) || goToSpills()}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          )}
        </form>
      </Container>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  user,
  spill: {
    status: { statuses },
    success,
    spillFiltersState,
    loading,
  },
  client,
  agency,
  contractor,
  service,
}) => ({
  admins: user.admins,
  users: user.users,
  organizationAdmins: user.organizationAdmins,
  currentUser: user.currentUser,
  success: success,
  clientChildren: client.clientChildren,
  clientOrganizationNames: client.clientOrganizationNames,
  agencies: agency.agencies,
  spillFiltersState,
  contractorsWithAddress: contractor.contractorsWithAddress,
  loading:
    user.loading ||
    loading ||
    client.loading ||
    agency.loading ||
    contractor.loading,
  service,
  spillsLoading: loading,
  statuses: statuses,
});

const mapDispatchToProps = (dispatch) => ({
  searchSpills: bindActionCreators(spillActions.searchSpills, dispatch),

  clearSpillsSearch: bindActionCreators(
    spillActions.clearSpillsSearch,
    dispatch
  ),
  getStatuses: bindActionCreators(spillActions.getStatuses, dispatch),
  updateStatus: bindActionCreators(spillActions.updateStatus, dispatch),
  setSpillFilters: bindActionCreators(spillActions.setSpillFilters, dispatch),
  setSpillDataForFilter: bindActionCreators(
    spillActions.setSpillDataForFilter,
    dispatch
  ),
  setFinalSpillsSearchData: bindActionCreators(
    spillActions.setFinalSpillsSearchData,
    dispatch
  ),
  setSelectedSpills: bindActionCreators(
    spillActions.setSelectedSpills,
    dispatch
  ),
});

SearchSpillReports.propTypes = {
  user: PropTypes.object.isRequired,
  spills: PropTypes.object.isRequired,
  admins: PropTypes.object.isRequired,
  success: PropTypes.bool.isRequired,
  searchSpills: PropTypes.func.isRequired,
  getOrganizationNames: PropTypes.func.isRequired,
  clientOrganizationNames: PropTypes.object.isRequired,
  agencies: PropTypes.func.isRequired,
  getAgencies: PropTypes.func.isRequired,
  getContractorsWithAddress: PropTypes.func.isRequired,
  contractors: PropTypes.func.isRequired,
  clearSpillsSearch: PropTypes.func.isRequired,
  getUsersForEmail: PropTypes.func.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SearchSpillReports)
);
