import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';
import moment from 'moment';

import { Grid } from '@material-ui/core';

import { CustomSnackBar } from '../../../../../../../Components';

import {
  getFilteredSpillsStatusCount,
  getSpillStatusCount,
} from '../../../../../../../actionCreators/Analytics';
import { endOfWeek, startOfWeek } from 'date-fns';
import BarChart from '../../../../../../../Components/BarChart';

const SpillsStatusAnalyticsWeekly = ({
  dateRange,
  filterValues,
  filteredSpillsStatusCount,
  getFilteredSpillsStatusCount,
}) => {
  const [SpillStatusCountAverageRemoved, setSpillStatusCountAverageRemoved] =
    useState([]);
  React.useEffect(() => {
    const dateRange = {
      startDate: moment(startOfWeek(new Date()))
        .subtract(1, 'months')
        .format('YYYY-MM-DD'),
      endDate: moment(endOfWeek(new Date()))
        .subtract(1, 'months')
        .format('YYYY-MM-DD'),
    };
    getFilteredSpillsStatusCount({
      ...dateRange,
      type: 'weekly',
    });
  }, []);
  React.useEffect(() => {
    if (
      Object?.keys(dateRange)?.length > 0 ||
      Object?.keys(filterValues)?.length > 0
    ) {
      getFilteredSpillsStatusCount({
        startDate: dateRange?.startDate,
        endDate: dateRange?.endDate,
        ...filterValues,
        type: 'weekly',
      });
    }
  }, [dateRange, filterValues]);
  React.useEffect(() => {
    if (filteredSpillsStatusCount?.data) {
      const removedAvgFilter = filteredSpillsStatusCount?.data.filter(
        (x) => x.count != null
      );
      setSpillStatusCountAverageRemoved(removedAvgFilter);
    }
  }, [filteredSpillsStatusCount]);

  return (
    <React.Fragment>
      <CustomSnackBar
        open={filteredSpillsStatusCount?.error}
        severity='error'
        snackBarMessage='Unable to fetch some stats.'
      />

      <Grid container spacing={4}>
        <Grid item xs={12} md={12} lg={12} xl={12}>
          <BarChart
            title='Spills Status Count'
            data={SpillStatusCountAverageRemoved || []}
            xLabel='status'
            yLabel='count'
            loading={filteredSpillsStatusCount?.loading}
            height={400}
            plotCount={SpillStatusCountAverageRemoved?.length}
          />
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

const mapStateToProps = ({ analytics: { filteredSpillsStatusCount } }) => ({
  filteredSpillsStatusCount,
});

const mapDispatchToProps = (dispatch) => ({
  getSpillStatusCount: bindActionCreators(getSpillStatusCount, dispatch),
  getFilteredSpillsStatusCount: bindActionCreators(
    getFilteredSpillsStatusCount,
    dispatch
  ),
});

SpillsStatusAnalyticsWeekly.prototype = {
  dateRange: PropTypes.string,
  filterValues: PropTypes.object,
  getFilteredSpillsStatusCount: PropTypes.func.isRequired,
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SpillsStatusAnalyticsWeekly)
);
