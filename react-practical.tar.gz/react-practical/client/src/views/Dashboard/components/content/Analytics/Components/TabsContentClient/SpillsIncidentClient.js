import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';

import {
  get5800CompletedClient,
  getAverageIncidentSameContractor,
  getCurrentYearSpills,
  getEvacuationIncidentsNumber,
  getFetchSpillsStatusesCountRoleBased,
  getIncidentsAtLocationTypes,
  getIncidentsReportedClient,
  getTurnedUsDownForContractor,
  getVehicleIncidents,
} from '../../../../../../../actionCreators/Analytics';
import React, { useState } from 'react';
import { Grid, makeStyles, Paper } from '@material-ui/core';

import SingleStatChart from '../../../../../../../Components/SingleStatChart';

import CircularProgressBar from '../../../../../../../Components/CircularProgressBar';
const Styles = makeStyles((theme) => ({
  paper: {
    backgroundColor: '#f7f7f7',
    boxShadow: theme.shadows[4],
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    marginBottom: '20px',
  },
  paperInner: {
    backgroundColor: '#f7f7f7',
    padding: theme.spacing(2, 4, 3),
    width: '100%',
    margin: '20px 0px',
    background: 'none',
    boxShadow: 'none',
    border: '1px solid #b9b9b9',
  },
  gridAlignEnd: {
    justifyContent: 'flex-end',
  },
  analyticsHeading: {
    fontSize: '20px',
    fontWeight: '800',
    color: '#212121',
    textAlign: 'left',
  },
  datePickerContainer: { textAlign: 'end' },
  headerCard: {
    backgroundColor: '#f7f7f7',
  },
  datesTypeWrapper: {
    textAlign: 'right',
  },
  marginSelect: {
    marginTop: '12px',
  },
  filterIcon: {
    color: '#ffffffff',
    backgroundColor: '#397d33',
    fontSize: '40px',
    padding: '12px',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  filterBox: {
    textAlign: 'left',
    marginTop: '12px',
  },
  filterButtonSelect: {
    // textAlign: 'right',
    padding: '20px',
  },
}));
const SpillsIncidentClient = ({
  hazIncidentsClient,
  getIncidentsReportedClient,
  incidentsReportedClient,
  getEvacuationIncidentsNumber,
  evacuationIncidentsNumber,
  getIncidentsAtLocationTypes,
  incidentsAtLocationTypes,
  getVehicleIncidents,
  vehicleAccidents,
  get5800CompletedClient,
  completed5800Client,
  getAverageIncidentSameContractor,
  averageIncidentSameContractor,
}) => {
  const classes = Styles();

  React.useEffect(() => {
    getIncidentsReportedClient();
    getEvacuationIncidentsNumber();
    getIncidentsAtLocationTypes();
    getVehicleIncidents();
    get5800CompletedClient();
    getAverageIncidentSameContractor();
  }, []);

  return (
    <React.Fragment>
      <Paper elevation={2} className={classes.paper}>
        <Grid container spacing={4}>
          <Grid item xs={6} md={4}>
            <SingleStatChart
              title={'Hazardous Incidents'}
              amount={hazIncidentsClient?.data?.count}
              loading={hazIncidentsClient?.loading}
            />
          </Grid>
          <Grid item xs={6} md={4}>
            <SingleStatChart
              title={'Reported To State Agencies'}
              amount={incidentsReportedClient?.data?.[0]?.data?.count}
              loading={incidentsReportedClient?.loading}
            />
          </Grid>
          <Grid item xs={6} md={4}>
            <SingleStatChart
              title={'Reported To NRC'}
              amount={incidentsReportedClient?.data?.[1]?.data?.count}
              loading={incidentsReportedClient?.loading}
            />
          </Grid>
        </Grid>
        <Paper className={classes.paperInner}>
          <Grid container spacing={4}>
            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={
                  (evacuationIncidentsNumber?.data?.percentage * 1) / 100
                }
                count={evacuationIncidentsNumber?.data?.count}
                mainColor={'#F6C036'}
                title={'Schedule Excavations'}
                loading={evacuationIncidentsNumber?.loading}
                description={'Incidents that required Excavations'}
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={
                  (incidentsAtLocationTypes?.data?.[0].percentage * 1) / 100
                }
                count={incidentsAtLocationTypes?.data?.[0]?.count}
                mainColor={'#5ED9AB'}
                title={'@ Client'}
                loading={incidentsAtLocationTypes?.loading}
                description={'Incidents at the client facilities'}
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={
                  (incidentsAtLocationTypes?.data?.[1].percentage * 1) / 100
                }
                count={incidentsAtLocationTypes?.data?.[1]?.count}
                mainColor={'#6694F7'}
                title={'@ Customer'}
                loading={incidentsAtLocationTypes?.loading}
                description={'Incidents at the Customer Locations'}
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CircularProgressBar
                percent={(vehicleAccidents?.data?.data?.percentage * 1) / 100}
                count={vehicleAccidents?.data?.data?.count}
                mainColor={'#647697'}
                title={'Vehicle Accidents'}
                loading={vehicleAccidents?.loading}
                description={'Vehicle Accidents Incidents'}
              />
            </Grid>
          </Grid>
        </Paper>
        <Grid container spacing={4}>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Completed 5800'}
              amount={completed5800Client?.data?.data?.count}
              loading={completed5800Client?.loading}
              // status={singleStatChartIncreasingData.status}
            />
          </Grid>
          <Grid item xs={6} md={6}>
            <SingleStatChart
              title={'Incidents Involving Same Contractor'}
              amount={Math.round(averageIncidentSameContractor?.data?.data)}
              loading={averageIncidentSameContractor?.loading}
            />
          </Grid>
        </Grid>
      </Paper>
    </React.Fragment>
  );
};

const mapStateToProps = ({
  analytics: {
    spillsOnEachWorkDay,
    spillsOnEachWeek,
    spillStatusCount,
    currentMonthSpillProjection,
    averagePerDayPerWeek,
    currentYearSpills,
    fetchSpillsStatusesCountRoleBased,
    turnedUsDownForContractor,
    hazIncidentsClient,
    incidentsReportedClient,
    evacuationIncidentsNumber,
    incidentsAtLocationTypes,
    vehicleAccidents,
    completed5800Client,
    averageIncidentSameContractor,
  },
  contractor,
  client,
  user,
}) => ({
  admins: user.admins,
  organizationAdmins: user.organizationAdmins,
  spillsOnEachWorkDay,
  spillsOnEachWeek,
  spillStatusCount,
  currentMonthSpillProjection,
  averagePerDayPerWeek,
  contractorsWithAddress: contractor.contractorsWithAddress,
  clientChildren: client.clientChildren,
  currentUser: user.currentUser,
  loadingContractors: contractor.loading,
  clientOrganizationNames: client.clientOrganizationNames,
  clientOrganizationLoading: client.loading,
  currentYearSpills,
  fetchSpillsStatusesCountRoleBased,
  turnedUsDownForContractor,
  hazIncidentsClient,
  incidentsReportedClient,
  evacuationIncidentsNumber,
  incidentsAtLocationTypes,
  vehicleAccidents,
  completed5800Client,
  averageIncidentSameContractor,
});

const mapDispatchToProps = (dispatch) => ({
  getFetchSpillsStatusesCountRoleBased: bindActionCreators(
    getFetchSpillsStatusesCountRoleBased,
    dispatch
  ),
  getCurrentYearSpills: bindActionCreators(getCurrentYearSpills, dispatch),
  getTurnedUsDownForContractor: bindActionCreators(
    getTurnedUsDownForContractor,
    dispatch
  ),
  getIncidentsReportedClient: bindActionCreators(
    getIncidentsReportedClient,
    dispatch
  ),
  getEvacuationIncidentsNumber: bindActionCreators(
    getEvacuationIncidentsNumber,
    dispatch
  ),
  getIncidentsAtLocationTypes: bindActionCreators(
    getIncidentsAtLocationTypes,
    dispatch
  ),
  getVehicleIncidents: bindActionCreators(getVehicleIncidents, dispatch),
  get5800CompletedClient: bindActionCreators(get5800CompletedClient, dispatch),
  getAverageIncidentSameContractor: bindActionCreators(
    getAverageIncidentSameContractor,
    dispatch
  ),
});

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SpillsIncidentClient)
);
