import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { ROLES } from '../../../../../utils';
import AnalyticsTabsWrapperAdmin from './AnalyticsTabsWrapperAdmin';
import AnalyticsContractors from './AnalyticsContractors';
import AnalyticsClientTabWrapper from './AnalyticsClientTabWrapper';

const views = {
  PES_ADMIN: 'PES_ADMIN',
  CLIENT: 'CLIENT',
  CONTRACTOR: 'CONTRACTOR',
};
document.title = 'Analytics';
const Analytics = ({ currentUser }) => {
  const [viewToShow, setViewToShow] = React.useState(null);
  React.useEffect(() => {
    checkForRoles();
  }, [currentUser]);

  const checkForRoles = () => {
    if (
      checkForAdminRoles() ||
      checkForContractorRole() ||
      checkForClientRoles()
    ) {
      return;
    }
  };
  const checkForContractorRole = () => {
    const contractorRoles = [
      ROLES['CONTRACTOR_ADMIN'],
      ROLES['CONTRACTOR_USER'],
    ];
    if (contractorRoles.includes(currentUser?.data?.role?.role)) {
      setViewToShow(views['CONTRACTOR']);
      return true;
    }
  };
  const checkForAdminRoles = () => {
    const adminRoles = [
      ROLES['SUPER_USER'],
      ROLES['PES_ACCOUNTING_ADMIN'],
      ROLES['PES_ADMIN'],
      ROLES['PES_USER'],
    ];
    if (adminRoles.includes(currentUser?.data?.role?.role)) {
      setViewToShow(views['PES_ADMIN']);
      return true;
    }
  };

  const checkForClientRoles = () => {
    const clientRoles = [
      ROLES['CORPORATE_ADMIN'],
      ROLES['CORPORATE_LOGGER'],
      ROLES['CORPORATE_ACCOUNTING'],
      ROLES['CORPORATE_USER'],
    ];
    if (clientRoles.includes(currentUser?.data?.role?.role)) {
      setViewToShow(views['CLIENT']);
      return true;
    }
  };
  return (
    <>
      {viewToShow === views['PES_ADMIN'] && <AnalyticsTabsWrapperAdmin />}
      {viewToShow === views['CONTRACTOR'] && <AnalyticsContractors />}
      {viewToShow === views['CLIENT'] && <AnalyticsClientTabWrapper />}
    </>
  );
};

const mapStateToProps = ({ user }) => ({
  currentUser: user.currentUser,
});

const mapDispatchToProps = (dispatch) => ({});

Analytics.propTypes = {};
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Analytics)
);
