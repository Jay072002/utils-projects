import React, { useState } from "react";
import PropTypes from "prop-types";

import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import ReactSelect from "react-select";
import {
  Grid,
  TextField,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Avatar,
  Button,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import AlternateEmailIcon from "@material-ui/icons/AlternateEmail";
import { green } from "@material-ui/core/colors";

import * as userActions from "../../../../../actionCreators/User";
import * as clientActions from "../../../../../actionCreators/Client";
import { orderAlphabaticallyByKey } from "../../../../../utils/contractorLabel";

const useStyles = makeStyles((theme) => ({
  fullWidth: {
    width: "100%",
  },
  avatar: {
    backgroundColor: green[500],
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
}));

const EditAction = ({
  admins,
  clientOrganizationNames,
  getOrganizationNames,
  getAdmins,
  selectedAction,
  onCancel,
  onEdit,
  users,
  getUsersByOrgId,
}) => {
  const classes = useStyles();
  const [manager, setManager] = useState("");
  const [organization, setOrganization] = useState("");
  const [attachment, setAttachment] = useState("");
  const [selectedUsers, setSelectedUsers] = useState("");

  React.useEffect(() => {
    getOrganizationNames();
    getAdmins({ filter: "none" });
  }, []);

  React.useEffect(() => {
    if (selectedAction) {
      setManager(selectedAction.data.user_id);
      setOrganization(selectedAction.data.org_id);
      setSelectedUsers(selectedAction.data.users);
      setAttachment(selectedAction.data.send_attachment);
    }
  }, [selectedAction]);

  React.useEffect(() => {
    if (organization) {
      getUsersByOrgId({ id: organization });
    }
  }, [organization]);

  const handleEdit = () => {
    onEdit({
      id: selectedAction.id,
      data: {
        ...selectedAction.data,
        user_id: manager,
        org_id: organization,
        users: selectedUsers,
        send_attachment: attachment,
      },
    });
    onCancel();
  };

  const orgs = clientOrganizationNames.data;

  const userOptions = users.data.map((user) => {
    const value = { value: user.id, label: user.full_name, email: user.email };
    const allOptions = { ...value };

    return allOptions;
  });

  return (
    <div>
      <div style={{ display: "flex", marginBottom: "30px" }}>
        <Avatar className={classes.avatar}>
          <AlternateEmailIcon />
        </Avatar>
        <span style={{ paddingLeft: "20px" }}>
          <Typography variant="h5" gutterBottom>
            Edit Project
          </Typography>
        </span>
      </div>
      <React.Fragment>
        <Grid container spacing={5}>
          <Grid item xs={6}>
            <InputLabel id="manager-select-label">Project Manager *</InputLabel>
            <Select
              className={classes.fullWidth}
              labelId="manager-select-label"
              id="manager-select"
              name="manager"
              value={manager}
              onChange={(event) => setManager(event.target.value)}
            >
              {orderAlphabaticallyByKey(admins?.data, "full_name").map((e) => {
                return <MenuItem value={e.id}>{e.full_name}</MenuItem>;
              })}
            </Select>
          </Grid>

          <Grid item xs={6}>
            <InputLabel id="organization-select-label">
              Organization *
            </InputLabel>
            <Select
              className={classes.fullWidth}
              labelId="organization-select-label"
              id="organization-select"
              name="organization"
              value={organization}
              onChange={(event) => setOrganization(event.target.value)}
            >
              {orderAlphabaticallyByKey(orgs, "name").map((e, id) => {
                return <MenuItem value={e.id}>{e.name}</MenuItem>;
              })}
            </Select>
          </Grid>

          <Grid item xs={12}>
            <InputLabel id="users-for-email-label">Users for Email</InputLabel>
            <ReactSelect
              value={selectedUsers}
              required
              isMulti
              onChange={setSelectedUsers}
              options={orderAlphabaticallyByKey(userOptions)}
            />
          </Grid>

          <Grid item xs={6}>
            <InputLabel id="attachment-select-label">
              Send Attachment *
            </InputLabel>
            <Select
              className={classes.fullWidth}
              labelId="attachment-select-label"
              id="attachment-select"
              name="attachment"
              value={attachment}
              onChange={(event) => setAttachment(event.target.value)}
            >
              <MenuItem value={true}>Yes</MenuItem>
              <MenuItem value={false}>No</MenuItem>
            </Select>
          </Grid>
          <Grid item xs={12} style={{ textAlign: "right" }}>
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => handleEdit()}
            >
              Update
            </Button>
            <Button
              className={classes.button}
              variant="contained"
              color="primary"
              onClick={() => onCancel()}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </React.Fragment>
    </div>
  );
};

const mapStateToProps = ({
  user: { admins, users },
  client: { clientOrganizationNames },
}) => ({
  admins,
  users,
  clientOrganizationNames,
});

const mapDispatchToProps = (dispatch) => ({
  getAdmins: bindActionCreators(userActions.getAdmins, dispatch),
  getOrganizationNames: bindActionCreators(
    clientActions.getOrganizationNames,
    dispatch
  ),
  getUsersByOrgId: bindActionCreators(userActions.getUsersByOrgId, dispatch),
});

EditAction.propTypes = {
  admins: PropTypes.object.isRequired,
  getAdmins: PropTypes.func.isRequired,
  getOrganizationNames: PropTypes.func.isRequired,
  getUsersByOrgId: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EditAction);
