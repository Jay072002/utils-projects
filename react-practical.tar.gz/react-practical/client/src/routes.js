import React from "react";
import { Switch, Route } from "react-router-dom";

import { Homepage, LoginPage, Dashboard } from "./views";

const Routes = () => {
  const [destinationPath, setDestinationPath] = React.useState(
    window.location.pathname
  );

  return (
    <Switch>
      <Route
        exact
        path="/"
        component={(props) => (
          <Homepage destinationPath={destinationPath} {...props} />
        )}
      />
        <Route exact path="/dashboard/spills/edit/:id?"    component={(props) => {
        return ( 
          <Dashboard   isEdit {...props} />
        )}} />
      <Route exact path="/dashboard/spills/view/:id?"    component={(props) => {
        return ( 
          <Dashboard   isView {...props} />
        )}} />
      <Route exact path="/dashboard/:tab?/:id?" component={Dashboard} />
      <Route
        exact
        path="/login"
        component={(props) => (
          <Homepage destinationPath={"/dashboard"} {...props} />
        )}
      />
    </Switch>
  );
};

export default Routes;
