export function compare(a, b) {
  return a.label > b.label ? 1 : b.label > a.label ? -1 : 0;
}
