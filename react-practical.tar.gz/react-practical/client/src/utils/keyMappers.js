export const genericKeyMapper = (key) => {
  return key
    .split('_')
    .map((word) => word[0].toUpperCase() + word.slice(1))
    .join(' ');
};
export const noteFieldsMapper = {
  actual_eta: 'Actual ETA',
  amount: 'Amount',
  created_at: 'Created At',
  date: 'Date',
  description: 'Description',
  established_lane_closure: 'Established Lane Closure',
  estimated_cost: 'Estimated Cost',
  excavation_begun: 'Excavation Begun',
  excavation_completed: 'Excavation Completed',
  hour: 'Hour',
  ip_address_identifier: 'Ip Address Identifier',
  no_of_salvage_container: 'No Of Salvage Container',
  no_of_samples: 'No Of Samples',
  note_attachments: 'Note Attachments',
  owner: 'Owner',
  projected_eta: 'Projected ETA',
  rate: 'Rate',
  report_no: 'Report No',
  salvage_containers: 'Salvage Containers',
  service_type: 'Service Type',
  task_associated_relevance: 'Task Associated Relevance',
  time: 'Time',
  type: 'Type',
  excavation_time: 'Total Excavation Time',
  state_incident_no: 'State Incident No',
  incident_no: 'National Incident No',
};

export const salvageContainersVisibleFields = [
  'content',
  'created_at',
  'drum_weight',
  'is_hazmat',
  'sc_no',
  'type',
  'disposal_handled_by',
  'container_disposition',
];

export const ROLES = {
  SUPER_USER: 'Super User',
  PES_ACCOUNTING_ADMIN: 'PES Accounting Admin',
  PES_ADMIN: 'PES Admin',
  PES_USER: 'PES User',
  DEMO: 'Demo',
  CORPORATE_ADMIN: 'Corporate Admin',
  CORPORATE_LOGGER: 'Corporate Logger',
  CORPORATE_ACCOUNTING: 'Corporate Accounting',
  CORPORATE_USER: 'Corporate User',
  CONTRACTOR_ADMIN: 'Contractor Admin',
  CONTRACTOR_USER: 'Contractor User',
  PROB_PM: 'Probationary PM',
};

export const USER_TYPE = {
  TEST: 'TEST',
  GENERAL: 'GENERAL',
};
