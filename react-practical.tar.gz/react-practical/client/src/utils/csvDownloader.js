import moment from "moment";
import XlsxPopulate from "xlsx-populate";
export const csvDownloader = async (data, type) => {
  const processedData = [data[0]];
  for (let index = 0; index < data.length; index++) {
    if (index !== 0) {
      const itemArray = []
      const element = data[index];
      for (let i = 0; i < element.length; i++) {
        const item = element[i];
        if (item) {
          itemArray.push(item?.toString()?.replace(/#/g, "").replace(/,/g, " "));
        } else {
          itemArray.push(item);
        }
      }
      if (itemArray.length) {
        processedData.push(itemArray);
      }
    }
  }

  const workbook = await XlsxPopulate.fromBlankAsync();

  // Get the first sheet
  const sheet = workbook.sheet(0);

  // Apply styling to the header row
  const headerRow = sheet.row(1);
  headerRow.style({
    bold: true,
    fill: {
      type: "pattern",
      pattern: "darkDown",
      foreground: {
        rgb: "2F7D32",
      },
    },
    fontColor: "000000", // Text color (white)
    border: {
      style: "thin",
      color: "000000",
      size: 1,
    },
  });

  // Set the data in the sheet
  sheet.cell("A1").value(processedData);

  // Calculate column widths based on content
  const maxColumnWidths = calculateMaxColumnWidths(processedData);
  setColumnWidths(sheet, maxColumnWidths);

  // Generate the Excel file
  const excelData = await workbook.outputAsync();

  // Convert the Excel data to a Blob object
  const blob = new Blob([excelData], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });

  // Create a download link and trigger the download
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${type}-${moment(new Date()).format("DD-MM-YYYY h:mm:ss")}.xlsx`;
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Calculate maximum content length for each column
const calculateMaxColumnWidths = (processedData) => {
  const maxColumnWidths = [];
  for (let i = 0; i < processedData[0].length; i++) {
    let maxLength = 0;
    for (let j = 0; j < processedData.length; j++) {
      const cellValue = processedData[j][i];
      const cellLength = cellValue ? cellValue.toString().length : 0;
      if (cellLength > maxLength) {
        maxLength = cellLength;
      }
    }
    maxColumnWidths.push(maxLength);
  }
  return maxColumnWidths;
};

// Set column widths based on maximum content length
const setColumnWidths = (sheet, maxColumnWidths) => {
  for (let i = 0; i < maxColumnWidths.length; i++) {
    const columnWidth = maxColumnWidths[i] + 2; // Add extra padding
    sheet.column(i + 1).width(columnWidth);
  }
};