import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router-dom';

import './styles/App.css';

import * as userActions from './actionCreators/User';
import HeaderComponent from './Components/HeaderComponent';
import FooterComponent from './Components/FooterComponent';
// import FileUploader from "./Components/FileUploader";

function App({ children, getCurrentUser }) {
  React.useEffect(() => {
    getCurrentUser();
  }, []);

  return (
    <div className='App'>
      <HeaderComponent />
      <main style={{ backgroundColor: '#fff' }}>{children}</main>
      <FooterComponent />
    </div>
  );
}

const mapStateToProps = ({ user }) => ({ user });

const mapDispatchToProps = (dispatch) => ({
  getCurrentUser: bindActionCreators(userActions.getCurrentUser, dispatch),
});

App.propTypes = {
  user: PropTypes.object.isRequired,
  getCurrentUser: PropTypes.func.isRequired,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));
