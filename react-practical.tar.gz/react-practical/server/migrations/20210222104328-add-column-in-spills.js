'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("spills", "is_demo", {
        type: Sequelize.BOOLEAN,
      }),
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("spills", "is_demo"),
    ]);
  }
};
