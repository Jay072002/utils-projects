/** @format */

'use strict';
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn("client_organizations", "hazardous_waste", {
      type: Sequelize.TEXT,
      after: "active"
    });
    await queryInterface.addColumn("client_organizations", "non_hazardous_waste", {
      type: Sequelize.TEXT,
      after: "hazardous_waste"
    });
    await queryInterface.addColumn("client_organizations", "revision_date", {
      type: Sequelize.DATEONLY,
      after: "non_hazardous_waste"
    });
    await queryInterface.addColumn("client_organizations", "reporting", {
      type: Sequelize.BOOLEAN,
      after: "revision_date"
    });
    await queryInterface.addColumn("client_organizations", "reporting_instruction", {
      type: Sequelize.TEXT,
      after: "reporting"
    });
    await queryInterface.addColumn("client_organizations", "report_5800", {
      type: Sequelize.BOOLEAN,
      after: "reporting_instruction"
    });
    await queryInterface.addColumn("client_organizations", "instruction_5800", {
      type: Sequelize.TEXT,
      after: "report_5800"
    });
    await queryInterface.addColumn("client_organizations", "miscellaneous", {
      type: Sequelize.TEXT,
      after: "instruction_5800"
    });
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("client_organizations", "hazardous_waste"),
      queryInterface.removeColumn("client_organizations", "non_hazardous_waste"),
      queryInterface.removeColumn("client_organizations", "revision_date"),
      queryInterface.removeColumn("client_organizations", "reporting"),
      queryInterface.removeColumn("client_organizations", "reporting_instruction"),
      queryInterface.removeColumn("client_organizations", "report_5800"),
      queryInterface.removeColumn("client_organizations", "instruction_5800"),
      queryInterface.removeColumn("client_organizations", "miscellaneous"),
    ]);
  }
};