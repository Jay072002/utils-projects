module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spills", "amount_released", {
        type: Sequelize.DECIMAL,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spills", "amount_released", {
        type: Sequelize.INTEGER,
        allowNull: true,
      }),
    ]);
  },
};
