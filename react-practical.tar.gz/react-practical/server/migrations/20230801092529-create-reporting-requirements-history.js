'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("reporting_requirements_history", {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      agency_id: {
        type: Sequelize.INTEGER,
      },
      petroleum_release_amount: {
        type: Sequelize.DECIMAL,
      },
      petroleum_release: {
        type: Sequelize.TEXT,
      },
      hazardous_material_amount: {
        type: Sequelize.DECIMAL,
      },
      hazardous_material: {
        type: Sequelize.TEXT,
      },
      water_impact_amount: {
        type: Sequelize.DECIMAL,
      },
      water_impact: {
        type: Sequelize.TEXT,
      },
      soil_impact_amount: {
        type: Sequelize.DECIMAL,
      },
      soil_impact: {
        type: Sequelize.TEXT,
      },
      revision_date: {
        type: Sequelize.DATEONLY,
      },
      created_at: {
        type: Sequelize.DATE,
      },
      updated_at: {
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    }).then(() => queryInterface.addIndex('reporting_requirements_history', ['agency_id']))
    .then(() => queryInterface.addIndex('reporting_requirements_history', ['revision_date']));
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("reporting_requirements_history");
  },
};