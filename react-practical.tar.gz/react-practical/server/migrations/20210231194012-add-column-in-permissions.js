"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("permissions", "view_agencies", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("permissions", "edit_agencies", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("permissions", "create_agencies", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("permissions", "view_client", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("permissions", "edit_client", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("permissions", "create_client", {
        type: Sequelize.BOOLEAN,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("permissions", "view_agencies"),
      queryInterface.removeColumn("permissions", "edit_agencies"),
      queryInterface.removeColumn("permissions", "create_agencies"),
      queryInterface.removeColumn("permissions", "view_client"),
      queryInterface.removeColumn("permissions", "edit_client"),
      queryInterface.removeColumn("permissions", "create_client"),
    ]);
  },
};
