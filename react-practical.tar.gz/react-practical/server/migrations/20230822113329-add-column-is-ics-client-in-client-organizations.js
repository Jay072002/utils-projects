/** @format */

'use strict';
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn("client_organizations", "is_ics_client", {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      after: "miscellaneous"
    });
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("client_organizations", "is_ics_client"),
    ]);
  }
};