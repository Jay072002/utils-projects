module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spill_admins", "pes_inv_amount", {
        type: Sequelize.STRING,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spill_admins", "pes_inv_amount", {
        type: Sequelize.INTEGER,
        allowNull: true,
      }),
    ]);
  },
};
