"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("services", "report_number", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "ip_address_identifier", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "owner", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "salvage_containers", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "samples", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "cost", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "establish_lane_closure", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "excavation_begun", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "excavation_completed", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "task_associated_relevance", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "time", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "date", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("services", "upload_attachment", {
        type: Sequelize.BOOLEAN,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("services", "report_number"),
      queryInterface.removeColumn("services", "ip_address_identifier"),
      queryInterface.removeColumn("services", "owner"),
      queryInterface.removeColumn("services", "salvage_containers"),
      queryInterface.removeColumn("services", "samples"),
      queryInterface.removeColumn("services", "cost"),
      queryInterface.removeColumn("services", "establish_lane_closure"),
      queryInterface.removeColumn("services", "excavation_begun"),
      queryInterface.removeColumn("services", "excavation_completed"),
      queryInterface.removeColumn("services", "task_associated_relevance"),
      queryInterface.removeColumn("services", "time"),
      queryInterface.removeColumn("services", "date"),
      queryInterface.removeColumn("services", "upload_attachment"),
    ]);
  },
};
