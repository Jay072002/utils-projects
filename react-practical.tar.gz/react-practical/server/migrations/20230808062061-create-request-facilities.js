'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('request_facilities', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      org_id: {
        type: Sequelize.INTEGER,
      },
      user_id: {
        type: Sequelize.INTEGER,
      },
      file_name: {
        type: Sequelize.STRING,
      },
      key: {
        type: Sequelize.STRING,
      },
      url_link: {
        type: Sequelize.STRING,
      },
      status: {
        type: Sequelize.ENUM,
        values: ['not_processed', 'in_progress', 'completed', 'failed']
      },
      process_start: {
        type: Sequelize.DATE,
      },
      process_end: {
        type: Sequelize.DATE,
      },
      created_at: {
        type: Sequelize.DATE,
      },
      updated_at: {
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    }).then(() => queryInterface.addIndex('request_facilities', ['org_id']))
    .then(() => queryInterface.addIndex('request_facilities', ['user_id']));
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('request_facilities');
  }
};