/** @format */

'use strict';
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn("contractors", "do_not_use", {
      type: Sequelize.BOOLEAN,
      defaultValue: false
    });
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("contractors", "do_not_use"),
    ]);
  }
};