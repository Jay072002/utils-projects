"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("client_organization_services", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      org_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      service_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      type: {
        type: Sequelize.STRING,
      },
      rate: {
        type: Sequelize.DECIMAL,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("client_organization_services");
  },
};
