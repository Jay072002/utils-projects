'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn('spill_contractors', 'contractor_role', {
        type: Sequelize.STRING(255),
        allowNull: true,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn('spill_contractors', 'contractor_role'),
    ]);
  },
};
