"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("note_attachments", "spill_note_id", {
        type: Sequelize.INTEGER,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("note_attachments", "spill_note_id"),
    ]);
  },
};
