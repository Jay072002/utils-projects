/** @format */

'use strict';
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn("spills", "facility_id", {
      type: Sequelize.UUID,
      after: "claim_no"
    });
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("spills", "facility_id"),
    ]);
  }
};