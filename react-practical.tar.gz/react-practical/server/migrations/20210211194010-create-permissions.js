"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("permissions", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      create_spills: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      edit_spills: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      view_spills: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      create_users: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      edit_users: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      view_users: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      create_contractors: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      edit_contractors: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      view_contractors: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      create_location: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      edit_location: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      view_location: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      create_status: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      edit_status: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      view_status: {
        allowNull: false,
        type: Sequelize.BOOLEAN,
      },
      created_at: {
        type: Sequelize.DATE,
      },
      updated_at: {
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("permissions");
  },
};
