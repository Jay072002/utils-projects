"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("user_services_notifications", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      user_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      service_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      notification: {
        type: Sequelize.BOOLEAN,
      },
      
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("user_services_notifications");
  },
};
