/** @format */

'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn('spill_admins', 'is_not_required', {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn('spill_admins', 'is_not_required'),
    ]);
  },
};
