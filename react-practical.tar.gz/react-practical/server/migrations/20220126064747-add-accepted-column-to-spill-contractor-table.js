"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("spill_contractors", "accepted", {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("spill_contractors", "accepted"),
    ]);
  },
};
