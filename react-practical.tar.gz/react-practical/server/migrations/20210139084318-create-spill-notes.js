"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("spill_notes", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      spill_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      user_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      legacy_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      service_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      service_type: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      rate: {
        type: Sequelize.DECIMAL,
      },
      hour: {
        type: Sequelize.DECIMAL,
      },
      amount: {
        type: Sequelize.DECIMAL,
      },
      description: {
        type: Sequelize.TEXT,
      },
      report_no: {
        type: Sequelize.STRING,
      },
      ip_address_identifier: {
        type: Sequelize.STRING,
      },
      owner: {
        type: Sequelize.STRING,
      },
      no_of_salvage_container: {
        type: Sequelize.INTEGER,
      },
      no_of_samples: {
        type: Sequelize.INTEGER,
      },
      date: {
        type: Sequelize.DATE,
      },
      estimated_cost: {
        type: Sequelize.INTEGER,
      },
      established_lane_closure: {
        type: Sequelize.BOOLEAN,
      },
      excavation_begun: {
        type: Sequelize.BOOLEAN,
      },
      excavation_copleted: {
        type: Sequelize.BOOLEAN,
      },
      time: {
        type: Sequelize.TIME,
      },
      task_associated_relevance: {
        type: Sequelize.STRING,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("spill_notes");
  },
};
