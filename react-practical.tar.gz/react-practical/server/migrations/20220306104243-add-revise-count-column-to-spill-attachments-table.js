"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("spill_attachments", "revise_count", {
        type: Sequelize.INTEGER,
        defaultValue: 0,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("spill_attachments", "revise_count"),
    ]);
  },
};
