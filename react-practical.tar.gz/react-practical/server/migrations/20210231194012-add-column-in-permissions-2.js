"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("permissions", "view_services", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("permissions", "edit_services", {
        type: Sequelize.BOOLEAN,
      }),
      queryInterface.addColumn("permissions", "create_services", {
        type: Sequelize.BOOLEAN,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("permissions", "view_services"),
      queryInterface.removeColumn("permissions", "edit_services"),
      queryInterface.removeColumn("permissions", "create_services"),
    ]);
  },
};
