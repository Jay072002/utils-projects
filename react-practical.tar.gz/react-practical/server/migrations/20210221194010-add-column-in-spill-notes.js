"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("spill_notes", "user_id", {
        type: Sequelize.INTEGER,
      }),
      queryInterface.addColumn("spill_notes", "spill_id", {
        type: Sequelize.INTEGER,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("spill_notes", "user_id"),
      queryInterface.removeColumn("spill_notes", "spill_id"),
    ]);
  },
};
