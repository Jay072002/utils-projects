"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("contractors", "respond_count", {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      }),
      queryInterface.addColumn("contractors", "reject_count", {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("contractors", "respond_count"),
      queryInterface.removeColumn("contractors", "reject_count"),
    ]);
  },
};
