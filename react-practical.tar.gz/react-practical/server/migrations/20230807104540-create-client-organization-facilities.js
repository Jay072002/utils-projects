'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('client_organization_facilities', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      org_id: {
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING
      },
      internal_id: {
        type: Sequelize.STRING(100)
      },
      generator_status: {
        type: Sequelize.STRING(100)
      },
      epa_id: {
        type: Sequelize.STRING(155)
      },
      address: {
        type: Sequelize.STRING
      },
      city: {
        type: Sequelize.STRING(100)
      },
      state: {
        type: Sequelize.STRING(100)
      },
      country: {
        type: Sequelize.STRING(100)
      },
      zip_code: {
        type: Sequelize.STRING(20)
      },
      phone_number: {
        type: Sequelize.STRING(25)
      },
      region: {
        type: Sequelize.STRING(155)
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      },
      created_at: {
        type: Sequelize.DATE,
      },
      updated_at: {
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    }).then(() => queryInterface.addIndex('client_organization_facilities', ['org_id']));
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('client_organization_facilities');
  }
};