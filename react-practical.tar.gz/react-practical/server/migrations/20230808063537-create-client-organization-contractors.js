'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('client_organization_contractors', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      org_id: {
        type: Sequelize.INTEGER,
      },
      contractor_id: {
        type: Sequelize.INTEGER,
      },
      address_id: {
        type: Sequelize.INTEGER,
      },
      created_at: {
        type: Sequelize.DATE,
      },
      updated_at: {
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    }).then(() => queryInterface.addIndex('client_organization_contractors', ['org_id']))
    .then(() => queryInterface.addIndex('client_organization_contractors', ['contractor_id']))
    .then(() => queryInterface.addIndex('client_organization_contractors', ['address_id']));
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('client_organization_contractors');
  }
};