"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("salvage_containers", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      note_id: {
        type: Sequelize.INTEGER,
      },
      sc_no: {
        type: Sequelize.STRING,
      },
      type: {
        type: Sequelize.STRING,
      },
      content: {
        type: Sequelize.STRING,
      },
      haz: {
        type: Sequelize.BOOLEAN,
      },
      un_no: {
        type: Sequelize.STRING,
      },
      drum_weight: {
        type: Sequelize.STRING,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("salvage_containers");
  },
};
