module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spill_attachments", "name", {
        type: Sequelize.STRING(255),
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spill_attachments", "name", {
        type: Sequelize.STRING(45),
        allowNull: true,
      }),
    ]);
  },
};
