"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn("addresses", "respond_count", {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      }),
      queryInterface.addColumn("addresses", "reject_count", {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      }),
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("addresses", "respond_count"),
      queryInterface.removeColumn("addresses", "reject_count"),
    ]);
  },
};
