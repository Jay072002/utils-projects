'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('client_organization_waste_handlings', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      org_id: {
        type: Sequelize.INTEGER,
      },
      hazardous_waste: {
        type: Sequelize.TEXT
      },
      non_hazardous_waste: {
        type: Sequelize.TEXT
      },
      revision_date: {
        type: Sequelize.DATEONLY,
      },
      created_at: {
        type: Sequelize.DATE,
      },
      updated_at: {
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    }).then(() => queryInterface.addIndex('client_organization_waste_handlings', ['org_id']));
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('client_organization_waste_handlings');
  }
};