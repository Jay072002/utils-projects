"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return queryInterface.createTable("spill_notes_history", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      spill_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      note_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      note_edit_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      change_owner: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      change_owner_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      edited_field: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      prev_val: {
        type: Sequelize.STRING,
      },
      new_val: {
        type: Sequelize.STRING,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    });
  },

  down: async (queryInterface, Sequelize) => {
    return queryInterface.dropTable("spill_notes_history");
  },
};
