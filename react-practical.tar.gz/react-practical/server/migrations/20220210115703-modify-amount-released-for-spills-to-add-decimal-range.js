module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spills", "amount_released", {
        type: Sequelize.DECIMAL(10, 4),
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spills", "amount_released", {
        type: Sequelize.INTEGER,
        allowNull: true,
      }),
    ]);
  },
};
