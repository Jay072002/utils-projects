"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("spills", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      user_id: {
        type: Sequelize.INTEGER,
      },
      org_id: {
        type: Sequelize.INTEGER,
      },
      opened_on: {
        type: Sequelize.STRING,
      },
      job_no: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      send_attachment: {
        type: Sequelize.BOOLEAN,
      },
      status: {
        type: Sequelize.STRING,
      },
      conditions: {
        type: Sequelize.TEXT,
      },
      address: {
        type: Sequelize.STRING,
      },
      city: {
        type: Sequelize.STRING,
      },
      state: {
        type: Sequelize.STRING,
      },
      zip_code: {
        type: Sequelize.STRING,
      },
      country: {
        type: Sequelize.STRING,
      },
      contact: {
        type: Sequelize.STRING,
      },
      type: {
        type: Sequelize.STRING,
      },
      responsible: {
        type: Sequelize.STRING,
      },
      need_5800: {
        type: Sequelize.BOOLEAN,
      },
      is_waste: {
        type: Sequelize.BOOLEAN,
      },
      has_msds: {
        type: Sequelize.BOOLEAN,
      },
      is_hazmat: {
        type: Sequelize.BOOLEAN,
      },
      response_sent: {
        type: Sequelize.BOOLEAN,
      },
      claim_no: {
        type: Sequelize.STRING,
      },
      material: {
        type: Sequelize.STRING,
      },
      status_id: {
        type: Sequelize.INTEGER,
      },
      assignment_no: {
        type: Sequelize.STRING,
      },
      freight_bill: {
        type: Sequelize.STRING,
      },
      money_saved_mgt: {
        type: Sequelize.DECIMAL,
      },
      money_saved_waste: {
        type: Sequelize.DECIMAL,
      },
      rate: {
        type: Sequelize.DECIMAL,
      },
      material_id: {
        type: Sequelize.INTEGER,
      },
      latitude: {
        type: Sequelize.DECIMAL,
      },
      longitude: {
        type: Sequelize.DECIMAL,
      },
      tractor: {
        type: Sequelize.STRING,
      },
      trailer: {
        type: Sequelize.STRING,
      },
      onsite_poc_name: {
        type: Sequelize.STRING,
      },
      onsite_poc_phone: {
        type: Sequelize.STRING,
      },
      driver_name: {
        type: Sequelize.STRING,
      },
      driver_phone: {
        type: Sequelize.STRING,
      },
      pro: {
        type: Sequelize.STRING,
      },
      map_needed: {
        type: Sequelize.BOOLEAN,
      },
      amount_released: {
        type: Sequelize.INTEGER,
      },
      quantity_type_released: {
        type: Sequelize.STRING,
      },
      damaged_container_type: {
        type: Sequelize.STRING,
      },
      damage_type: {
        type: Sequelize.STRING,
      },
      location_type: {
        type: Sequelize.STRING,
      },
      drain_impacted: {
        type: Sequelize.BOOLEAN,
      },
      waterway_impacted: {
        type: Sequelize.BOOLEAN,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("spills");
  },
};
