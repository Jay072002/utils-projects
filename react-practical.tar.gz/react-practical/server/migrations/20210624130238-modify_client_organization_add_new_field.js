"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn(
        "client_organizations", // table name
        "timestamp_visibility", // new field name
        {
          type: Sequelize.BOOLEAN,
          allowNull: true,
        }
      ),
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn(
        "client_organizations",
        "timestamp_visibility"
      ),
    ]);
  },
};
