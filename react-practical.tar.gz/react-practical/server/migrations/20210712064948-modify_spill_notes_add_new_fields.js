"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn(
        "spill_notes", // table name
        "projected_eta", // new field name
        {
          type: Sequelize.DATE,
          allowNull: true,
        }
      ),
      queryInterface.addColumn(
        "spill_notes", // table name
        "actual_eta", // new field name
        {
          type: Sequelize.TIME,
          allowNull: true,
        }
      ),
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("spill_notes", "projected_eta"),
      queryInterface.removeColumn("spill_notes", "actual_eta"),
    ]);
  },
};
