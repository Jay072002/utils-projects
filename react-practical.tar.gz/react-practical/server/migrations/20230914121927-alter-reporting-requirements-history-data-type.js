'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('reporting_requirements_history', 'petroleum_release_amount', {
      type: Sequelize.DOUBLE(10, 2)
    });
    await queryInterface.changeColumn('reporting_requirements_history', 'hazardous_material_amount', {
      type: Sequelize.DOUBLE(10, 2)
    });
    await queryInterface.changeColumn('reporting_requirements_history', 'water_impact_amount', {
      type: Sequelize.DOUBLE(10, 2)
    });
    await queryInterface.changeColumn('reporting_requirements_history', 'soil_impact_amount', {
      type: Sequelize.DOUBLE(10, 2)
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.changeColumn('reporting_requirements_history', 'petroleum_release_amount', {
      type: Sequelize.DECIMAL,
    });
    await queryInterface.changeColumn('reporting_requirements_history', 'hazardous_material_amount', {
      type: Sequelize.DECIMAL,
    });
    await queryInterface.changeColumn('reporting_requirements_history', 'water_impact_amount', {
      type: Sequelize.DECIMAL,
    });
    await queryInterface.changeColumn('reporting_requirements_history', 'soil_impact_amount', {
      type: Sequelize.DECIMAL,
    });
  },
};
