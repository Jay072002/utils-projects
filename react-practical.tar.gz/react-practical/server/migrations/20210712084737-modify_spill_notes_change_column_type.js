module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spill_notes", "actual_eta", {
        type: Sequelize.DATE,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn("spill_notes", "actual_eta", {
        type: Sequelize.TIME,
        allowNull: true,
      }),
    ]);
  },
};
