"use strict";

"use strict";

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn(
        "services", // table name
        "projected_eta", // new field name
        {
          type: Sequelize.BOOLEAN,
          allowNull: true,
        }
      ),
      queryInterface.addColumn(
        "services", // table name
        "actual_eta", // new field name
        {
          type: Sequelize.BOOLEAN,
          allowNull: true,
        }
      ),
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn("services", "projected_eta"),
      queryInterface.removeColumn("services", "actual_eta"),
    ]);
  },
};
