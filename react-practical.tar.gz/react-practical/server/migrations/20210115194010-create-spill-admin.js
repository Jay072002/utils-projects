"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("spill_admins", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      spill_id: {
        type: Sequelize.INTEGER,
      },
      info: {
        type: Sequelize.TEXT,
      },
      pix: {
        type: Sequelize.DATE,
      },
      spill_summary: {
        type: Sequelize.DATE,
      },
      contractor_inv: {
        type: Sequelize.DATE,
      },
      waste_doc: {
        type: Sequelize.DATE,
      },
      contractor_invoice: {
        type: Sequelize.STRING,
      },
      inv_no: {
        type: Sequelize.STRING,
      },
      final_contractor_invoice: {
        type: Sequelize.STRING,
      },
      savings: {
        type: Sequelize.STRING,
      },
      pes_paid: {
        type: Sequelize.DATE,
      },
      contractor_paid: {
        type: Sequelize.DATE,
      },
      trans_to_ct: {
        type: Sequelize.DATE,
      },
      pay_by: {
        type: Sequelize.DATE,
      },
      response_time: {
        type: Sequelize.STRING,
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      deleted_at: {
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("spill_admins");
  },
};
