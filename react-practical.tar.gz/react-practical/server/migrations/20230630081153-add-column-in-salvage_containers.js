/** @format */

'use strict';
module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("salvage_containers", "disposal_handled_by", {
        type: Sequelize.STRING,
      }),
      queryInterface.addColumn("salvage_containers", "container_disposition", {
        type: Sequelize.STRING,
      }),
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("salvage_containers", "disposal_handled_by"),
      queryInterface.removeColumn("salvage_containers", "container_disposition"),
    ]);
  }
};
