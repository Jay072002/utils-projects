export const htmlSafe = (str) => {
  const tempStr = str || "";
  return tempStr
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
};

export const convertToTableData = (headings, data) => {
  let dataToReturn = { headings: headings.map((x) => x.heading), rows: [] };

  for (const attachment of data) {
    dataToReturn.rows.push(
      headings.map((heading) => attachment[heading.key] || "N/A")
    );
  }
  return dataToReturn;
};

export const getTableViewForEmail = (data) => {
  const tableToReturn = `<div class=" tableView "> <div class=" tableRow borderBottom2 ">${data.headings
    .map((heading) => `<div class=" tableHeading boldFont"> ${heading} </div>`)
    .join("")}</div>
     ${data.rows
       .map(
         (row) =>
           `<div class=" tableRow borderBottom ">
           ${row
             .map((val) => `<div class=" tableValue "> ${val}</div>`)
             .join("")}
           </div>`
       )
       .join("")}   </div>`;

  return tableToReturn;
};
