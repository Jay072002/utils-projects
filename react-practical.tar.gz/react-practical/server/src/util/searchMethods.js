import Moment from "moment";
import { convertStatuses } from "./preProcessors";
import { ROLES, DATETYPES, USER_TYPE, CONSTANTS } from "./constants";
import { forceToCSTForRawQuery } from "./convertDateRange";
import models, { sequelize } from "../models";

export const buildSearchQuery = async (
  searchText,
  type,
  role,
  searchFields,
  activeFilter,
  contractor_id,
  client_organization
) => {
  let query = {};
  switch (type) {
    case "User": {
      let where = {};
      let query = {
        include: [
          {
            model: models.ClientOrganizations,
            attributes: ["name"],
          },
          {
            model: models.Roles,
            required: false,
            include: [
              {
                model: models.Permissions,
                required: false,
              },
            ],
          },
          {
            model: models.Contractors,
            required: false,
          },
          {
            model: models.Addresses,
            required: false,
          },
        ],
      };

      if (role === ROLES.DEMO) {
        where = { ...where, is_demo: true };
      }

      if (role === ROLES.CONTRACTOR_ADMIN) {
        where = {
          ...where,
          contractor_id: contractor_id,
        };
      }
      if (role === ROLES.CORPORATE_ADMIN) {
        where = {
          ...where,
          "$role.id$": [5, 6, 7, 8],
          "$client_organization.id$": client_organization.id,
        };
      }
      if (!searchText || searchText === "") {
        return { ...query, where };
      }

      let associatedOrgsData = await models.AssociatedOrganizations.findAll();
      associatedOrgsData = associatedOrgsData.map((x) => x.dataValues);

      if (searchFields) {
        switch (searchFields) {
          case "Parent Organization": {
            const orgsToShow = [];
            searchText.map((parentOrg) => {
              orgsToShow.push(parentOrg.value);
              associatedOrgsData.map(
                (x) =>
                  x?.org_id === parentOrg.value &&
                  !orgsToShow.includes(x.associated_org_id) &&
                  orgsToShow.push(x.associated_org_id)
              );
            });
            where = {
              ...where,
              org_id: orgsToShow,
            };
            break;
          }
          case "Child Organization": {
            const orgsToShow = [];
            searchText.map((childOrg) => {
              orgsToShow.push(childOrg.value);
              associatedOrgsData.map(
                (x) =>
                  x.associated_org_id === childOrg.value &&
                  !orgsToShow.includes(x?.org_id) &&
                  orgsToShow.push(x?.org_id)
              );
            });
            where = {
              ...where,
              org_id: orgsToShow,
            };
            break;
          }
          case "Client": {
            where = {
              ...where,
              org_id: searchText.map((org) => org.value),
            };
            break;
          }
          case "Email": {
            where = {
              ...where,
              email: {
                $like: `%${searchText}%`,
              },
            };
            break;
          }
          default:
            where = {
              ...where,
              full_name: {
                $like: `%${searchText}%`,
              },
            };
            null;
        }
      } else {
        where = {
          ...where,
          $or: [
            {
              full_name: {
                $like: `%${searchText}%`,
              },
            },
            {
              email: {
                $like: `%${searchText}%`,
              },
            },
          ],
        };
      }
      if (activeFilter != "N/A") {
        where = {
          ...where,
          active: activeFilter === "Active" ? true : false,
        };
      }

      query = {
        ...query,
        where,
      };
      return query;

      break;
    }
    default: {
      null;
    }
  }

  return query;
};

const include = [
  {
    model: models.Reserves,
    required: false,
    include: [
      {
        model: models.User,
        required: false,
      },
    ],
  },

  {
    model: models.ClientOrganizations,
    required: false,
  },
  {
    model: models.User,
    required: false,
    attributes: ["full_name", "email"],
  },
  {
    model: models.Connections,
    as: "connections",
    include: {
      model: models.SpillContractors,
    },
  },
  {
    model: models.SpillAdmins,
  },
];

export const getSpill = async (key, name = "id", order = []) => {
  const spillToReturn = await models.Spills.findOne({
    include,
    where: {
      [name]: key,
    },
    order,
  });
  return spillToReturn;
};

export const getRejectedSpillIds = async (rejectedIds) => {
  const haveIds =
    rejectedIds.addresses_id.length || rejectedIds.contractors_id.length;
  const spillIds = await models.ContractorHistory.findAll({
    attributes: ["spill_id"],
    where: {
      $or: [
        {
          contractor_id: rejectedIds.contractors_id,
        },
        {
          address_id: rejectedIds.addresses_id,
        },
      ],
    },
  });
  return [
    ...spillIds.map((x) => x.dataValues.spill_id),
    ...(haveIds ? [0] : []),
  ];
};

export const getSpills = async (keys, name = "id") => {
  const spillToReturn = await models.Spills.findAll({
    include,
    where: {
      [name]: { in: keys },
    },
  });
  return spillToReturn;
};

export const getContractorsBySpill = async (spill_id) => {
  const connections = await models.Contractors.findAll({
    include: [
      {
        model: models.SpillContractors,
        required: true,
        include: [
          {
            model: models.Connections,
            required: true,
            where: {
              spill_id,
            },
          },
        ],
      },
    ],
  });
  return connections;
};

export const getContractorsBySpills = async (spill_ids) => {
  const connections = await models.Contractors.findAll({
    include: [
      {
        model: models.SpillContractors,
        required: false,
        include: [
          {
            model: models.Connections,
            required: false,
            where: {
              spill_id: spill_ids,
            },
          },
        ],
      },
    ],
  });
  return connections;
};

export const getAdminsBySpill = async (spill_id) => {
  const admins = await models.SpillAdmins.findAll({
    where: { spill_id },
  });
  return admins;
};
export const buildIncludeQueryForConnections = async (
  agencies_id,
  addresses_id,
  contractors_id,
  role
) => {
  let include = [];
  let where = {};
  if (agencies_id.length) {
    where = {
      $or: [{ agency_id: agencies_id }, { agency_national: agencies_id }],
    };
  }
  if (contractors_id.length || addresses_id.length) {
    include.push({
      model: models.SpillContractors,
      required: true,
      attributes: ["contractor_id", "address_id"],
      where: {
        $or: [{ contractor_id: contractors_id }, { address_id: addresses_id }],
      },
    });
  }
  const spills = await models.Connections.findAll({
    attributes: ["spill_id"],
    where,
    include,
  });

  let finalResult = spills.map((x) => x.dataValues.spill_id) || [];

  return finalResult;
};

export const adminsForCSV = (admins) => {
  const adminsToReturn = [];

  admins?.map((admin) => {
    let relevantContractor = {
      name: "",
      location: "",
    };

    if (admin.contractor_address_id) {
      relevantContractor = {
        name: admin?.contractor?.name,
        location: `${admin?.address?.address}, ${admin?.address?.city}, ${admin?.address?.state}, ${admin?.address?.country}`.replace(
          /,/g,
          "-"
        ),
      };
    } else {
      relevantContractor = {
        name: admin?.contractor?.name,
        location: `${admin?.contractor?.address}, ${admin?.contractor?.city}, ${admin?.contractor?.state}, ${admin?.contractor?.country}`.replace(
          /,/g,
          "-"
        ),
      };
    }

    if (admin?.contractor_id) {
      if (relevantContractor) {
        const contractorObj = {
          name: relevantContractor?.name,
          location: relevantContractor?.location,
          pix: admin?.pix,
          spill_summary: admin?.spill_summary,
          waste_doc: admin?.waste_doc,
          contractor_invoice_date: admin?.contractor_inv,
          contractor_invoice: admin?.contractor_invoice,
          pes_inv_amount: admin?.pes_inv_amount,
          inv_no: admin?.inv_no,
          final_inv: admin?.final_contractor_invoice,
          pay_by: admin?.pay_by,
          pes_paid: admin?.pes_paid,
          contractor_paid: admin?.contractor_paid,
          trans_to_ct: admin?.trans_to_ct,
          response_time: admin?.response_time,
        };
        adminsToReturn?.push(contractorObj);
      }
    }
  });
  return adminsToReturn;
};

export const utcToTimeZoneDateConverter = (
  date,
  timeZone,
  dateType,
  dontConvertTimeZone = false
) => {
  if (date === "Still Open" || date === "Re-Opened" || date === "Closed") {
    return date;
  } else {
    var m = Moment.utc(new Date(date));

    !dontConvertTimeZone && m.tz(timeZone);

    var s =
      dateType === DATETYPES.NORMAL
        ? m.format("MM/DD/YYYY HH:mm:ss")
        : m.format("MM/DD/YYYY");

    return s;
  }
};

export const formatAmount = (amount, characterToRemove) => {
  let updatedAmount = amount?.split(`${characterToRemove}`).join("");

  if (updatedAmount?.includes("$")) {
    updatedAmount = updatedAmount
      .split("$")
      .join("")
      .trim();
  }

  return updatedAmount;
};

export const searchSingleObj = (subType, obj, contractor, timeZoneOffSet) => {
  return subType === "Admin Download"
    ? [
        utcToTimeZoneDateConverter(
          obj?.opened_on,
          timeZoneOffSet,
          "Normal",
          true
        ),
        utcToTimeZoneDateConverter(
          obj?.closed_on,
          timeZoneOffSet,
          "Normal",
          true
        ),
        obj?.job_no,
        obj?.claim_no,
        obj?.user?.full_name,
        obj?.client_organization?.name,
        obj?.onsite_poc_name || obj?.contact,
        obj?.material,
        obj?.un_no,
        obj?.amount_released,
        obj?.quantity_type_released,
        obj?.job_no
          ? `${obj?.address || "N/A"} ${obj?.city} ${obj?.state} ${
              obj?.country
            }, `.replace(/,/g, "-")
          : null,
        obj?.latitude,
        obj?.longitude,
        contractor?.name,
        contractor?.location,
        obj?.reserves[obj?.reserves?.length - 1]?.amount || 0,
        obj?.status,
        contractor?.pix &&
          utcToTimeZoneDateConverter(
            contractor?.pix,
            timeZoneOffSet,
            "Other",
            true
          ),
        contractor?.spill_summary &&
          utcToTimeZoneDateConverter(
            contractor?.spill_summary,
            timeZoneOffSet,
            "Other",
            true
          ),
        contractor?.waste_doc &&
          utcToTimeZoneDateConverter(
            contractor?.waste_doc,
            timeZoneOffSet,
            "Other",
            true
          ),
        contractor?.contractor_invoice_date &&
          utcToTimeZoneDateConverter(
            contractor?.contractor_invoice_date,
            timeZoneOffSet,
            "Other",
            true
          ),
        formatAmount(contractor?.contractor_invoice, ","),
        formatAmount(obj?.total_notes_sum, ","), //pes_inv_amount calculated from notes
        contractor?.inv_no,
        formatAmount(contractor?.final_inv, ","),
        (contractor?.pay_by &&
          utcToTimeZoneDateConverter(
            contractor?.pay_by,
            timeZoneOffSet,
            "Payment",
            true
          )) ||
          "N/A",
        (contractor?.pes_paid &&
          utcToTimeZoneDateConverter(
            contractor?.pes_paid,
            timeZoneOffSet,
            "Payment",
            true
          )) ||
          "N/A",
        (contractor?.contractor_paid &&
          utcToTimeZoneDateConverter(
            contractor?.contractor_paid,
            timeZoneOffSet,
            "Payment",
            true
          )) ||
          "N/A",
        (contractor?.trans_to_ct &&
          utcToTimeZoneDateConverter(
            contractor?.trans_to_ct,
            timeZoneOffSet,
            "Payment",
            true
          )) ||
          "N/A",
        obj?.type,
        contractor?.response_time,
      ]
    : [
        utcToTimeZoneDateConverter(
          obj?.opened_on,
          timeZoneOffSet,
          "Normal",
          true
        ),
        utcToTimeZoneDateConverter(
          obj?.closed_on,
          timeZoneOffSet,
          "Normal",
          true
        ),
        obj?.job_no,
        obj?.claim_no,
        obj?.user?.full_name,
        obj?.client_organization?.name,
        obj?.onsite_poc_name || obj?.contact,
        obj?.material,
        obj?.un_no,
        obj?.amount_released,
        obj?.quantity_type_released,
        `${obj?.address} ${obj?.city} ${obj?.state} ${obj?.country}, `.replace(
          /,/g,
          "-"
        ),
        obj?.latitude,
        obj?.longitude,
        contractor?.name,
        contractor?.location,
        obj?.reserves[obj?.reserves?.length - 1]?.amount || 0,
        // reserves?.reduce((sum, reserve) => sum + +reserve?.amount, 0) || 0,
        obj?.status,
      ];
};

export const searchDownloadObj = (obj, subType, timeZoneOffSet) => {
  const admins = adminsForCSV(obj?.spill_admins);
  let csvRecords = [];
  if (admins?.length > 1) {
    csvRecords?.push(
      ...admins.map((admin) =>
        searchSingleObj(subType, obj, admin, timeZoneOffSet)
      )
    );
  } else if (admins?.length > 0) {
    csvRecords?.push(searchSingleObj(subType, obj, admins[0], timeZoneOffSet));
  } else {
    csvRecords?.push(searchSingleObj(subType, obj, null, timeZoneOffSet));
  }
  return csvRecords.map((record) =>
    record.map((val) => {
      if (val === "Still Open" || val === "Re-Opened") {
        return null;
      } else {
        return val || "N/A";
      }
    })
  );
};

export const searchDownloadObjects = (subType, timeZoneOffSet, data) => {
  const toReturn = [];
  data.map((instance) =>
    toReturn.push(
      ...searchDownloadObj(instance.dataValues, subType, timeZoneOffSet)
    )
  );
  return toReturn;
};

export const getSpillCountForContractorUsers = async (
  id,
  role,
  spillData,
  contractor_id,
  spillIdsContractorFilter,
  rejectSpillIds,
  organizationsId,
  userType,
  contractorInvoiceNo
) => {
  let statusData = spillData?.statusData;
  if (spillData?.pendingdisposal === 1 && !spillData?.disposal_handled_by && !spillData?.container_disposition_type) {
    statusData = [CONSTANTS.PENDING_DISPOSAL_STATUS];
  }
  let userData = {};
  const managers_id = [];
  let usersForEmail_id = [];
  let packetReviewUsers_id = [];

  if (role === ROLES.CONTRACTOR_USER) {
    userData = await models.User.findOne({
      where: { id },
    });
  }

  if (spillData?.managers && spillData?.managers?.length >= 0) {
    await Promise.all(
      spillData?.managers?.map((manager) => {
        managers_id.push(manager?.value);
      })
    );
  }

  if (spillData?.usersForEmail && spillData?.usersForEmail?.length >= 0) {
    const temp = [];
    spillData?.usersForEmail?.map((user) => {
      temp.push(user?.spill_ids);
    });
    usersForEmail_id = temp.flat();
  }

  if (
    spillData?.packetReviewUsers &&
    spillData?.packetReviewUsers?.length >= 0
  ) {
    const temp = [];
    spillData?.packetReviewUsers?.map((user) => {
      temp.push(user?.value);
    });
    packetReviewUsers_id = temp.flat();
  }

  let query = `
  SELECT spills.job_no
  FROM
      spills AS spills
      ${
        spillData?.contractorInvoiceNo
          ? `LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.inv_no = ${contractorInvoiceNo} AND spill_admin.deleted_at is NULL`
          : ""
      }
          LEFT OUTER JOIN
      client_organizations AS client_organization ON spills.org_id = client_organization.id
      AND client_organization.deleted_at IS NULL
          LEFT OUTER JOIN
      connections AS connections ON spills.id = connections.spill_id
      AND  connections.deleted_at IS NULL
          LEFT OUTER JOIN
      spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
      AND spill_contractors.deleted_at IS NULL
          AND spill_contractors.contractor_id = ${contractor_id}
          ${
            userData?.dataValues?.contractor_address_id
              ? `AND spill_contractors.address_id = ${userData?.dataValues?.contractor_address_id}`
              : role === ROLES.CONTRACTOR_USER
              ? "AND spill_contractors.address_id is NULL"
              : ""
          }
          LEFT OUTER JOIN
      contractors AS contractor ON spill_contractors.contractor_id = contractor.id
      AND contractor.deleted_at IS NULL
          AND contractor.id = ${contractor_id}
      ${ (spillData?.disposal_handled_by || spillData?.container_disposition_type) ? `
        LEFT OUTER JOIN spill_notes AS sn ON sn.spill_id = spills.id AND sn.deleted_at IS NULL
        LEFT OUTER JOIN salvage_containers AS sc ON sn.id = sc.note_id AND sc.deleted_at IS NULL
        ` : " "
      }
  WHERE
      spills.is_approved = TRUE
          AND spills.is_demo = FALSE
          AND contractor.id = ${contractor_id}
          ${
            userData?.dataValues?.contractor_address_id
              ? `AND spill_contractors.address_id = ${userData?.dataValues?.contractor_address_id}`
              : ""
          }
          AND (spill_contractors.accepted = TRUE )
          ${
            spillData?.is_hazmat
              ? `AND spills.is_hazmat = ${
                  spillData?.is_hazmat === 1 ? `TRUE` : `FALSE`
                }`
              : " "
          }
          ${
            spillData?.contractorInvoiceNo
              ? `AND spill_admin.inv_no = ${spillData?.contractorInvoiceNo}`
              : " "
          }
            ${
              spillData?.job_no
                ? `AND spills.job_no LIKE '%${spillData?.job_no}%'`
                : " "
            }
            ${
              spillData?.opened_on && spillData?.opened_to
                ? `AND
            (spills.opened_on >= '${forceToCSTForRawQuery(
              spillData?.opened_on
            )}' AND spills.opened_on <= '${forceToCSTForRawQuery(
                    spillData?.opened_to
                  )}')`
                : " "
            }
             ${
               spillData?.opened_on
                 ? `AND spills.opened_on >= '${forceToCSTForRawQuery(
                     spillData?.opened_on
                   )}'`
                 : " "
             }
             ${
               spillData?.opened_to
                 ? `AND spills.opened_on <= '${forceToCSTForRawQuery(
                     spillData?.opened_to
                   )}'`
                 : " "
             }
             ${
               spillData?.close_on && spillData?.close_to
                 ? `AND
            (spills.closed_on >= '${forceToCSTForRawQuery(
              spillData?.close_on
            )}' AND spills.closed_on <= '${forceToCSTForRawQuery(
                     spillData?.close_to
                   )}')`
                 : " "
             }
             ${
               spillData?.close_on
                 ? `AND spills.closed_on >= '${forceToCSTForRawQuery(
                     spillData?.close_on
                   )}'`
                 : " "
             }
             ${
               spillData?.close_to
                 ? `AND spills.closed_on <= '${forceToCSTForRawQuery(
                     spillData?.close_to
                   )}'`
                 : " "
             }
            ${
              spillData?.city
                ? `AND spills.city LIKE '%${spillData?.city}%'`
                : " "
            }
            ${
              spillData?.state
                ? `AND spills.state LIKE '${spillData?.state}'`
                : " "
            }
            ${
              spillData?.country
                ? `AND spills.country LIKE '${spillData?.country}'`
                : " "
            }
            ${
              spillData?.claim_no
                ? `AND spills.claim_no LIKE '%${spillData?.claim_no}%'`
                : " "
            }
            ${
              spillData?.type
                ? `AND spills.type LIKE '${spillData?.type}'`
                : " "
            }
            ${
              spillData?.contact
                ? `AND spills.contact LIKE '%${spillData?.contact}%'`
                : " "
            }
            ${
              spillData?.responsible
                ? `AND spills.responsible LIKE '%${spillData?.responsible}%'`
                : " "
            }
            ${
              spillData?.address
                ? `AND spills.address LIKE '%${spillData?.address}%'`
                : " "
            }
            ${
              spillData?.conditions
                ? `AND spills.conditions LIKE '%${spillData?.conditions}%'`
                : " "
            }
            ${
              spillData?.material
                ? `AND spills.material LIKE '%${spillData?.material}%'`
                : " "
            }
            ${
              spillData?.map_needed
                ? `AND spills.map_needed LIKE '${spillData?.map_needed}'`
                : " "
            }
            ${
              spillData?.need_5800
                ? `AND spills.need_5800 = ${
                    spillData?.need_5800 === 1 ? `TRUE` : `FALSE`
                  }`
                : " "
            }
            ${
              spillData?.is_waste
                ? `AND spills.is_waste = ${
                    spillData?.is_waste === 1 ? `TRUE` : `FALSE`
                  }`
                : " "
            }
            ${
              spillData?.has_msds
                ? `AND spills.has_msds = ${
                    spillData?.has_msds === 1 ? `TRUE` : `FALSE`
                  }`
                : " "
            }
            ${
              spillData?.un_no
                ? `AND spills.un_no = '${spillData?.un_no}'`
                : " "
            }
            ${
              spillData?.response_sent
                ? `AND spills.response_sent = ${
                    spillData?.response_sent === 1 ? `TRUE` : `FALSE`
                  }`
                : " "
            }
            ${
              spillData?.subrogation
                ? `AND spills.subrogation = ${
                    spillData?.subrogation === 1 ? `TRUE` : `FALSE`
                  }`
                : " "
            }
            ${
              statusData?.length
                ? `AND spills.status IN (${convertStatuses(
                  statusData,
                    userData?.dataValues?.role?.role
                  ).map((status) => "'" + status + "'")})
                  ${
                    managers_id?.length
                      ? `AND spills.user_id IN (${managers_id})`
                      : " "
                  }
                  `
                : " "
            }
            ${
              managers_id?.length
                ? `AND spills.user_id IN (${managers_id})`
                : " "
            }
           ${
             spillData?.amount_released
               ? `AND spills.amount_released = ${+spillData?.amount_released}`
               : " "
           }
           ${
             spillData?.quantity_type_released
               ? `AND spills.quantity_type_released LIKE '${spillData?.quantity_type_released}'`
               : " "
           }
           ${
             spillData?.damaged_container_type
               ? `AND spills.damaged_container_type LIKE '${spillData?.damaged_container_type}'`
               : " "
           }
           ${
             spillData?.damaged_type
               ? `AND spills.damage_type LIKE '${spillData?.damaged_type}'`
               : " "
           }
          ${
            spillData?.location_type
              ? `AND spills.location_type LIKE '${spillData?.location_type}'`
              : " "
          }
          ${wasteGeneratedCondition(spillData)}
          ${
            usersForEmail_id?.length
              ? `
           AND spills.id IN (${usersForEmail_id})
           `
              : " "
          }
          ${
            packetReviewUsers_id?.length
              ? `
            AND spills.user_id IN (${packetReviewUsers_id})
            `
              : " "
          }
          ${
            spillData?.drain_impacted
              ? `AND spills.drain_impacted = ${
                  spillData?.drain_impacted === 1 ? `TRUE` : `FALSE`
                }`
              : " "
          }
          ${
            spillData?.waterway_impacted
              ? `AND spills.waterway_impacted = ${
                  spillData?.waterway_impacted === 1 ? `TRUE` : `FALSE`
                }`
              : " "
          }
          ${
            spillData?.is_emergency
              ? `AND spills.is_emergency = ${
                  spillData?.is_emergency === 1 ? `TRUE` : `FALSE`
                }`
              : " "
          }
          ${
            spillData?.trailer
              ? `AND spills.trailer LIKE '${spillData?.trailer}'`
              : " "
          }
          ${
            spillData?.tractor
              ? `AND spills.tractor LIKE '${spillData?.tractor}'`
              : " "
          }
          ${spillData?.pro ? `AND spills.pro LIKE '${spillData?.pro}'` : " "}
          ${
            spillIdsContractorFilter?.length || rejectSpillIds?.length
              ? `AND spills.id IN (${[
                  ...spillIdsContractorFilter,
                  ...rejectSpillIds,
                ]})`
              : " "
          }
          ${
            organizationsId?.length
              ? `AND spills.org_id IN (${organizationsId}) `
              : " "
          }
          ${
            userType === USER_TYPE.GENERAL
              ? `AND (spills.job_no NOT LIKE 'TEMP%'
         AND spills.job_no NOT LIKE '%TEST%')`
              : " "
          }
          AND (spill_contractors.is_inactive = FALSE
          OR spill_contractors.activity_performed = TRUE OR spill_contractors.is_inactive IS NULL)
  GROUP BY spills.id , connections.id , spill_contractors.id;`;

  let result = await sequelize.query(query);
  let count = result[0]?.length;
  return count;
};

export const getSpillCountForGeneralUsers = async (
  spillData,
  user,
  spillIdsContractorFilter,
  rejectSpillIds,
  organizationsId,
  userType,
  isReport
) => {
  let statusData = spillData?.statusData;
  if (spillData?.pendingdisposal === 1 && !spillData?.disposal_handled_by && !spillData?.container_disposition_type) {
    statusData = [CONSTANTS.PENDING_DISPOSAL_STATUS];
  }
  const managers_id = [];
  let usersForEmail_id = [];
  let packetReviewUsers_id = [];

  if (spillData?.managers && spillData?.managers?.length >= 0) {
    await Promise.all(
      spillData?.managers?.map((manager) => {
        managers_id.push(manager?.value);
      })
    );
  }

  if (spillData?.usersForEmail && spillData?.usersForEmail?.length >= 0) {
    const temp = [];
    spillData?.usersForEmail?.map((user) => {
      temp.push(user?.spill_ids);
    });
    usersForEmail_id = temp.flat();
  }

  if (
    spillData?.packetReviewUsers &&
    spillData?.packetReviewUsers?.length >= 0
  ) {
    const temp = [];
    spillData?.packetReviewUsers?.map((user) => {
      temp.push(user?.value);
    });
    packetReviewUsers_id = temp.flat();
  }

  const query = `SELECT spills.job_no
   FROM
    spills AS spills
        LEFT OUTER JOIN
    client_organizations AS client_organization ON spills.org_id = client_organization.id
        AND client_organization.deleted_at IS NULL
        LEFT OUTER JOIN
    spill_admins AS spill_admins ON spills.id = spill_admins.spill_id
        AND (spill_admins.is_removed = FALSE OR spill_admins.is_removed IS NULL)
        AND spill_admins.deleted_at IS NULL
        ${
          isReport
            ? `
          LEFT OUTER JOIN
      spill_statuses_history ON spills.id = spill_statuses_history.spill_id
          `
            : ""
        }
        ${
          spillData?.haz_waste_hauler
            ? `        
        LEFT OUTER JOIN                
            connections AS connections ON spills.id = connections.spill_id
            AND connections.deleted_at IS NULL
        LEFT OUTER JOIN
            spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
            AND spill_contractors.deleted_at IS NULL
        LEFT OUTER JOIN
            contractors AS contractor ON spill_contractors.contractor_id = contractor.id
            AND contractor.deleted_at IS NULL`
            : " "
        }
        LEFT OUTER JOIN
            packet_reviewer_assignments AS pra ON spills.id = pra.assigned_spill_id
            AND pra.deleted_at IS NULL
      ${ (spillData?.disposal_handled_by || spillData?.container_disposition_type) ? `
        LEFT OUTER JOIN spill_notes AS sn ON sn.spill_id = spills.id AND sn.deleted_at IS NULL
        LEFT OUTER JOIN salvage_containers AS sc ON sn.id = sc.note_id AND sc.deleted_at IS NULL
        ` : " "
      }
WHERE
    spills.is_approved = TRUE
                ${
                  spillData?.pesInvoiceNo
                    ? `AND spill_admins.pes_inv_no LIKE ${spillData?.pesInvoiceNo}`
                    : " "
                }
                ${
                  spillData?.contractorInvoiceNo
                    ? `AND spill_admins.inv_no LIKE ${spillData?.contractorInvoiceNo}`
                    : " "
                }
                ${
                  spillData?.isReport
                    ? `
                  AND spill_statuses_history.status LIKE 'Closed: Invoice Submitted to Client'
                  ${
                    spillData?.date_to
                      ? `
                      AND spill_statuses_history.started_at >= '${forceToCSTForRawQuery(
                        spillData?.date_to
                      )}'
                      ${
                        spillData?.date_from
                          ? `AND spill_statuses_history.started_at <= '${forceToCSTForRawQuery(
                              spillData?.date_from
                            )}'`
                          : " "
                      } 
                      
                      `
                      : " " || spillData?.date_from
                      ? `
                  AND spills.opened_on <= '${forceToCSTForRawQuery(
                    spillData?.date_from
                  )}'
                  `
                      : " "
                  }
                  `
                    : " "
                }
                ${
                  spillData?.haz_waste_hauler
                    ? `AND contractor.haz_waste_hauler = ${spillData?.haz_waste_hauler}`
                    : " "
                }
                ${
                  spillData?.is_hazmat
                    ? `AND spills.is_hazmat = ${
                        spillData?.is_hazmat === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                  ${
                    spillData?.job_no
                      ? `AND spills.job_no LIKE '%${spillData?.job_no}%'`
                      : " "
                  }
                  ${
                    spillData?.opened_on && spillData?.opened_to
                      ? `AND
                  (spills.opened_on >= '${forceToCSTForRawQuery(
                    spillData?.opened_on
                  )}' AND spills.opened_on <= '${forceToCSTForRawQuery(
                          spillData?.opened_to
                        )}')`
                      : " "
                  }
                   ${
                     spillData?.opened_on
                       ? `AND spills.opened_on >= '${forceToCSTForRawQuery(
                           spillData?.opened_on
                         )}'`
                       : " "
                   }
                   ${
                     spillData?.opened_to
                       ? `AND spills.opened_on <= '${forceToCSTForRawQuery(
                           spillData?.opened_to
                         )}'`
                       : " "
                   }
                   ${
                     spillData?.close_on && spillData?.close_to
                       ? `AND
                  (spills.closed_on >= '${forceToCSTForRawQuery(
                    spillData?.close_on
                  )}' AND spills.closed_on <= '${forceToCSTForRawQuery(
                           spillData?.close_to
                         )}')`
                       : " "
                   }
                   ${
                     spillData?.close_on
                       ? `AND spills.closed_on >= '${forceToCSTForRawQuery(
                           spillData?.close_on
                         )}'`
                       : " "
                   }
                   ${
                     spillData?.close_to
                       ? `AND spills.closed_on <= '${forceToCSTForRawQuery(
                           spillData?.close_to
                         )}'`
                       : " "
                   }
                  ${
                    spillData?.city
                      ? `AND spills.city LIKE '%${spillData?.city}%'`
                      : " "
                  }
                  ${
                    spillData?.state
                      ? `AND spills.state LIKE '${spillData?.state}'`
                      : " "
                  }
                  ${
                    spillData?.country
                      ? `AND spills.country LIKE '${spillData?.country}'`
                      : " "
                  }
                  ${
                    spillData?.claim_no
                      ? `AND spills.claim_no LIKE '%${spillData?.claim_no}%'`
                      : " "
                  }
                  ${
                    spillData?.type
                      ? `AND spills.type LIKE '${spillData?.type}'`
                      : " "
                  }
                  ${
                    spillData?.contact
                      ? `AND spills.contact LIKE '%${spillData?.contact}%'`
                      : " "
                  }
                  ${
                    spillData?.responsible
                      ? `AND spills.responsible LIKE '%${spillData?.responsible}%'`
                      : " "
                  }
                  ${
                    spillData?.address
                      ? `AND spills.address LIKE '%${spillData?.address}%'`
                      : " "
                  }
                  ${
                    spillData?.conditions
                      ? `AND spills.conditions LIKE '%${spillData?.conditions}%'`
                      : " "
                  }
                  ${
                    spillData?.material
                      ? `AND spills.material LIKE '%${spillData?.material}%'`
                      : " "
                  }
                  ${
                    spillData?.map_needed
                      ? `AND spills.map_needed LIKE '${spillData?.map_needed}'`
                      : " "
                  }
                  ${
                    spillData?.need_5800
                      ? `AND spills.need_5800 = ${
                          spillData?.need_5800 === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    spillData?.is_waste
                      ? `AND spills.is_waste = ${
                          spillData?.is_waste === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    spillData?.has_msds
                      ? `AND spills.has_msds = ${
                          spillData?.has_msds === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    spillData?.un_no
                      ? `AND spills.un_no = '${spillData?.un_no}'`
                      : " "
                  }
                  ${
                    spillData?.response_sent
                      ? `AND spills.response_sent = ${
                          spillData?.response_sent === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    spillData?.subrogation
                      ? `AND spills.subrogation = ${
                          spillData?.subrogation === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    statusData?.length
                      ? `AND spills.status IN (${convertStatuses(
                        statusData,
                          user?.role?.role
                        ).map((status) => "'" + status + "'")})
                        ${
                          managers_id?.length > 0
                            ? `AND spills.user_id IN (${managers_id})`
                            : " "
                        }
                        `
                      : " "
                  }
                  ${
                    managers_id?.length > 0
                      ? `AND spills.user_id IN (${managers_id})`
                      : " "
                  }
                 ${
                   spillData?.amount_released
                     ? `AND spills.amount_released = ${+spillData?.amount_released}`
                     : " "
                 }
                 ${
                   spillData?.quantity_type_released
                     ? `AND spills.quantity_type_released LIKE '${spillData?.quantity_type_released}'`
                     : " "
                 }
                 ${
                   spillData?.damaged_container_type
                     ? `AND spills.damaged_container_type LIKE '${spillData?.damaged_container_type}'`
                     : " "
                 }
                 ${
                   spillData?.damaged_type
                     ? `AND spills.damage_type LIKE '${spillData?.damaged_type}'`
                     : " "
                 }
                ${
                  spillData?.location_type
                    ? `AND spills.location_type LIKE '${spillData?.location_type}'`
                    : " "
                }
                ${wasteGeneratedCondition(spillData)}
                ${
                  spillData?.drain_impacted
                    ? `AND spills.drain_impacted = ${
                        spillData?.drain_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  usersForEmail_id?.length
                    ? `
                 AND spills.id IN (${usersForEmail_id})
                 `
                    : " "
                }
                ${
                  packetReviewUsers_id?.length
                    ? `
                    AND pra.packet_reviewer_user_id IN (${packetReviewUsers_id})
                    `
                    : " "
                }
                ${
                  spillData?.waterway_impacted
                    ? `AND spills.waterway_impacted = ${
                        spillData?.waterway_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  user?.role?.role === ROLES.CORPORATE_USER && user?.org_id
                    ? `AND spills.org_id = ${user?.org_id}`
                    : " "
                }

                ${
                  spillData?.is_emergency
                    ? `AND spills.is_emergency = ${
                        spillData?.is_emergency === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  spillData?.trailer
                    ? `AND spills.trailer LIKE '${spillData?.trailer}'`
                    : " "
                }
                ${
                  spillData?.tractor
                    ? `AND spills.tractor LIKE '${spillData?.tractor}'`
                    : " "
                }
                ${
                  spillData?.pro
                    ? `AND spills.pro LIKE '${spillData?.pro}'`
                    : " "
                }
                ${
                  spillIdsContractorFilter?.length || rejectSpillIds?.length
                    ? `AND spills.id IN (${[
                        ...spillIdsContractorFilter,
                        ...rejectSpillIds,
                      ]})`
                    : " "
                }
                ${
                  organizationsId?.length
                    ? `AND spills.org_id IN (${organizationsId}) `
                    : " "
                }
                ${
                  userType === USER_TYPE.GENERAL
                    ? `AND (spills.job_no NOT LIKE 'TEMP%'
                      AND spills.job_no NOT LIKE '%TEST%')`
                    : " "
                }
        GROUP BY spills.id;`;

  const result = await sequelize.query(query);
  let count = result[0]?.length;
  return count;
};

export const getDocumentationInReviewSpillsCount = async () => {
  const query = `
  SELECT spills.job_no
   FROM
    spills AS spills
    LEFT OUTER JOIN client_organizations AS client_organization ON spills.org_id = client_organization.id AND client_organization.deleted_at IS NULL
    LEFT OUTER JOIN spill_statuses_history ssh ON spills.id = ssh.spill_id AND ssh.status IN ('Open: Documentation In Review') AND ssh.ended_at is NULL and ssh.deleted_at is NULL
   WHERE
    spills.is_approved = TRUE
    AND spills.status IN ('Open: Documentation In Review')
    AND (
      spills.job_no NOT LIKE 'TEMP%'
    AND 
      spills.job_no NOT LIKE '%TEST%'
      )
    GROUP BY spills.id;
  `;
  const result = await sequelize.query(query);
  let count = result[0]?.length;
  return count;
};

export const wasteGeneratedCondition = (spillData) => {
  if (spillData?.disposal_handled_by && spillData?.container_disposition_type) {
    return `AND sc.disposal_handled_by = '${spillData?.disposal_handled_by}' AND sc.container_disposition = '${spillData?.container_disposition_type}'`
  } else if (spillData?.disposal_handled_by) {
    return `AND sc.disposal_handled_by = '${spillData?.disposal_handled_by}'`;
  } else if (spillData?.container_disposition_type) {
    return `AND sc.container_disposition = '${spillData?.container_disposition_type}'`;
  }
  return ``;
}