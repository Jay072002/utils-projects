const fs = require("fs");
const AWS = require("aws-sdk");
const path = require("path");

const accessKey = process.env.AWS_S3_ACCESS_KEY_ID;
const secretKey = process.env.AWS_S3_SECRET_ACCESS_KEY;
const bucketName = process.env.AWS_S3_BUCKET;

const s3 = new AWS.S3({
  accessKeyId: accessKey,
  secretAccessKey: secretKey,
});

export const uploadFileToS3Bucket = async (file, fileName) => {
  const fileContent = fs.readFileSync(file);
  const params = {
    Bucket: bucketName,
    Key: fileName,
    Body: fileContent,
  };

  try {
    const stored = await s3.upload(params).promise();
    return stored;
  } catch (err) {
    return err;
  }
};

export const downloadFileFromS3Bucket = async (key) => {
  try {
    const fileStream = await s3
      .getObject({ Bucket: process.env.AWS_S3_BUCKET, Key: key })
      .createReadStream();
    return fileStream;
  } catch (err) {
    return err;
  }
};
