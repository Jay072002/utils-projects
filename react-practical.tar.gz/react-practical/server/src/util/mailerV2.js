import nodemailer from "nodemailer";
import fs from "fs";
import path from "path";
import moment from "moment";
const sgMail = require("@sendgrid/mail");
const SENDGRID_API_KEY =
  "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";

sgMail.setApiKey(SENDGRID_API_KEY);

const FOOTER = fs
  .readFileSync(path.resolve(__dirname, "email-templates", "footer.html"))
  .toString();
const WELCOME = fs
  .readFileSync(path.resolve(__dirname, "email-templates", "welcome.html"))
  .toString()
  .replace("*|FOOTER|*", FOOTER);

const EMAIL = {
  notification: {
    subject: (type) => `Quant-BOE - Your ${type} reports are here!`,
    html: (user) =>
      WELCOME.replace("*|DATE|*", moment().format("DD MMMM YYYY"))
        .replace("*|REASON|*", "Welcome to Quant BOE")
        .replace("*|FULL_NAME|*", user.full_name)
        .replace("*|DAILY_WEEKLY|*", user.reportViewPref)
        .replace("*|EMAIL|*", user.email)
        .replace("*|DAILY_WEEKLY|*", user.reportViewPref)
        .replace("*|DOCS|*", user.docs),
  },
};

var helper = require("sendgrid").mail;
var fromEmail = new helper.Email("test@snsassociates.com.pk");

export default function(type, userObj, obj) {
  const from = 'Quant BOE <test@snsassociates.com.pk>';
  const msg = {
    to: userObj.email,
    from, // Use the email address or domain you verified above
    subject: EMAIL[type].subject(userObj.reportViewPref), // Subject line',
    html: EMAIL[type].html(userObj, obj), // html body
  };
  //ES6
  sgMail.send({
    to: userObj.email,
    from, // Use the email address or domain you verified above
    subject: EMAIL[type].subject(userObj.reportViewPref), // Subject line',
    html: EMAIL[type].html(userObj, obj), // html body
  }).then(
    () => {},
    (error) => {
      console.error(error);

      if (error.response) {
        console.error(error.response.body);
      }
    }
  );
}
