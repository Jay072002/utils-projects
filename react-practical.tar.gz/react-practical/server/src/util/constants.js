export const Permissions = {
  AllowedRoles: ["Super User"],
};

export const ContractorStatusVisibility = {
  "Open: Documentation In Review": [
    "Open: Documentation In Review",
    "Open: Ready to Invoice",
    "Open: Final Review",
    "Open: Ready to Close",
  ],
};

export const CorporateStatusVisibility = {
  "Open: Documentation In Review": [
    "Open: Documentation In Review",
    "Open: Ready to Invoice",
    "Open: Final Review",
    "Open: Ready to Close",
  ],
  "Closed: Closed": ["Closed: Payment Pending", "Closed: Closed"],
};

export const fieldMapper = {
  client_organization: { label: "Client Org Name", value_key: "name" },
  role: { label: "Role", value_key: "role" },
  contractor: { label: "Contractor", value_key: "name" },
};

export const USER_TYPE = {
  TEST: "TEST",
  GENERAL: "GENERAL",
};

export const nestedFieldMapper = {
  org_id: {
    label: "Client Org Name",
    value_key: "name",
    key: "client_organization",
  },
  role_id: {
    label: "Role",
    value_key: "role",
    key: "role",
  },
  contractor_id: {
    label: "Contractor",
    value_key: "name",
    key: "contractor",
  },
  user_id: {
    label: "Manager",
    value_key: "full_name",
    key: "user",
  },
};

export const ROLES = {
  SUPER_USER: "Super User",
  PES_ACCOUNTING_ADMIN: "PES Accounting Admin",
  PES_ADMIN: "PES Admin",
  PES_USER: "PES User",
  DEMO: "Demo",
  CORPORATE_ADMIN: "Corporate Admin",
  CORPORATE_LOGGER: "Corporate Logger",
  CORPORATE_ACCOUNTING: "Corporate Accounting",
  CORPORATE_USER: "Corporate User",
  CONTRACTOR_ADMIN: "Contractor Admin",
  CONTRACTOR_USER: "Contractor User",
  PROB_PM: "Probationary PM",
};

export const DATETYPES = {
  NORMAL: "Normal",
  PAYMENT: "Payment",
  OTHER: "Other",
};

export const ACTIONS = {
  CREATE_SPILL: "CREATE_SPILL",
  CREATE_SPILL_APPROVAL: "CREATE_SPILL_APPROVAL_REQUESTED",
  CREATE_SPILL_REJECTED: "CREATE_SPILL_REJECTED",
  EDIT_SPILL: "EDIT_SPILL",
  EDIT_SPILL_APPROVAL: "EDIT_SPILL_APPROVAL",
  EDIT_SPILL_REJECTED: "EDIT_SPILL_REJECTED",
  EDIT_USER: "EDIT_USER",
  ADD_NOTE_LOGGER: "ADD_NOTE_LOGGER",
  ADD_NOTE: "ADD_NOTE",
  DELETE_ATTACHMENT: "DELETE_ATTACHMENT",
  REPLACE_REJECTED_FILES: "REPLACE_REJECTED_FILES",
  REJECT_DOCUMENTS: "REJECT_DOCUMENTS",
  STATUS_CHANGE: "STATUS_CHANGE",
  DOCUMENTS_SUBMITTED: "DOCUMENTS_SUBMITTED",
  EDIT_NOTE: "EDIT_NOTE",
  EDIT_SPILL_CLIENT_ORGANIZATION: "EDIT_SPILL_CLIENT_ORGANIZATION",
  EDIT_SPILL_MAP_NEEDED: "EDIT_SPILL_MAP_NEEDED",
  PACKET_REVIEWER_ASSIGNMENT: "PACKET_REVIEWER_ASSIGNMENT",
  REQUEST_DOCUMENTATION: "REQUEST_DOCUMENTATION",
  REQUEST_DOCUMENTATION_SUBMISSION: "REQUEST_DOCUMENTATION_SUBMISSION",
};

export const CONSTANTS = {
  CONTRACTOR_INV_TYPE_NAME: "contractorInv",
  APPROVED: "approve",
  ASSIGNMENT_SERVICE_NAME: "Receipt of Assignment From Client",
  DELETION_ATTACHMENT_SERVICE_NAME: "Deletion Of File Attachment",
  DOWNLOAD_ATTACHMENT_SERVICE_NAME: "File/Attachment Download",
  CLOSURE_PACKET_FOR_PAYMENT_SERVICE_NAME: "Closure Packet For Payment",
  IGNORED_FIELDS_NOTE_ADDITION: [
    "rate",
    "hour",
    "amount",
    "attachments",
    "type",
  ],
  DEFAULT_EMAIL: "spills@premiumenvironmentalservices.com",
  OFFICIAL_EMAIL_DOMAIN: "@premiumenvironmentalservices.com",
  READY_TO_INVOICE_STATUS: "Open: Ready to Invoice",
  FINAL_REVIEW_STATUS: "Open: Final Review",
  READY_TO_CLOSE_STATUS: "Open: Ready to Close",
  DOCUMENTATION_IN_REVIEW_STATUS: "Open: Documentation In Review",
  DOCUMENTATION_SENT_BACK_FOR_REVISION:
    "Open: Documentation Sent Back to Contractor for Revision",
  WORK_IN_PROGRESS: "Open: Work In Progress",
  INVOICE_EMAIL: "invoice@premiumenvironmentalservices.com",
  FINAL_REVIEW_EMAIL: "FinalRev@premiumenvironmentalservices.com",
  PACKET_REVIEW_EMAIL: "PacketReview@premiumenvironmentalservices.com",
  NO_REPLY_EMAIL: "no-reply@premiumenvironmentalservices.com",
  OPEN_STATUS_TYPE: "Open",
  CLOSED_STATUS_TYPE: "Closed",
  CLOSED_STATUS: "Closed: Closed",
  SITEWORK_COMPLETE_STATUS: "Open: Site Work Complete",
  EXTENDED_REMEDATION_STATUS: "Open: Extended Remediation",
  PENDING_EXCAVATION_STATUS: "Open: Pending Excavation",
  PENDING_DISPOSAL_STATUS: "Open: Pending Disposal",
  INVOICE_SUBMITTED_TO_CLIENT_STATUS: "Closed: Invoice Submitted to Client",
  PAYMENT_PENDING_STATUS: "Closed: Payment Pending",
};

export const SPILL_CONTRACTOR_ROLES = {
  HEAD_CONTRACTOR: "Head Contractor",
  SUB_CONTRACTOR: "Sub Contractor",
};

export const certificateTypes = [
  {
    attachment_id: 1,
    label: "Contractor Liability Certificate of Insurance",
    value: "contractorLiability",
  },
  {
    attachment_id: 2,
    label: "Contractor Workers Comp Certificate of Insurance",
    value: "contractorWorkers",
  },
  { attachment_id: 3, label: "Contractor W-9", value: "contractorW9" },
  {
    attachment_id: 4,
    label: "Haz Waste Haulers License",
    value: "hasWasteHauler",
  },
  { attachment_id: 5, label: "Rate Sheet", value: "rateSheet" },
];

export const uploadTypes = [
  { label: "Spill Summary", value: "spillSummary" },
  { label: "Contractor Invoice", value: "contractorInv" },
  { label: "Waste Doc", value: "wasteDoc" },
  { label: "NRC Report", value: "nrcReport" },
  { label: "State Report", value: "stateReport" },
  { label: "Initial State Report", value: "initialStateReport" },
  { label: "Scope of Work", value: "scopeOfWork" },
  { label: "Estimate", value: "estimate" },
  { label: "Scale Ticket", value: "scaleTicket" },
  { label: "Email Conversation", value: "emailConversation" },
  { label: "Pictures", value: "pictures" },
];

export const pesRestrictedTypes = [
  { label: "PES Cover Letter", value: "coverLetter" },
  { label: "PES Invoice", value: "pesInvoice" },
  {
    label: "Contractor Liability Certificate of Insurance",
    value: "contractorLiability",
  },
  {
    label: "Rate Sheet",
    value: "rateSheet",
  },
  {
    label: "Contractor Workers Comp Certificate of Insurance",
    value: "contractorWorkers",
  },
  { label: "Contractor W-9", value: "contractorW9" },
  { label: "Misc/Other", value: "miscOther" },
  { label: "Haz Waste Haulers License", value: "hasWasteHauler" },
];

export const getAdminAttachmentTypes = () => {
  return [...uploadTypes, ...pesRestrictedTypes];
};

export const userWithOutExternalDataUrls = [
  "/api/agency/agencies",
  "/api/services/all",
  "/api/contractors/withAddress",
  "/api/user/getPacketReviewers",
  "/api/spill/statuses",
  "/api/user/admins",
  "/api/spill/submitted"
];

export const roleExternalDataUrls = [
  "/api/client/allOrganizationNames",
  "/api/user/getUsersForEmail",
  "/api/spill/summary",
];

export const JURISDICTION = {
  NATIONAL: 'National',
  STATE: 'State',
  LOCAL: 'Local'
};

export const TIER_LEVEL = {
  DO_NOT_USE: "Do Not Use"
}