import keys from "lodash/keys";
import { createWriteStream } from "fs";
import { Readable } from "stream";
import { Op } from "sequelize";
import {
  htmlSafe,
  convertToTableData,
  getTableViewForEmail,
} from "./htmlHelpers";
import { ACTIONS, CONSTANTS, nestedFieldMapper, userWithOutExternalDataUrls, roleExternalDataUrls, JURISDICTION } from "./constants";
import {
  isObject,
  boolToString,
  keyToName,
  isBoolean,
  convertRowsToHtml,
  getAddedHtml,
  generateBackgroundInfoBlock,
  getRefNumber,
  getSpillLink,
  generateList,
  getRequestedDocTypes,
} from "./preProcessors";
import models, { sequelize } from "../models";

const { URL_FOR_EMAIL } = process.env;

export function convertBase64ToBinary(base64, path = null) {
  return new Promise((resolve, reject) => {
    try {
      if (base64 && path) {
        const buffer = Buffer.from(base64, "base64");
        const readable = new Readable();
        readable.push(buffer);
        readable.push(null);
        readable.pipe(createWriteStream(path)).on("close", () => resolve(path));
      } else {
        reject(new Error("Invalid or missing parameters"));
      }
    } catch (err) {
      reject(err);
    }
  });
}
export function getSanitizedObject(object, whitelist) {
  try {
    return keys(object)
      .filter((key) => whitelist.includes(key))
      .reduce(
        (obj, key) => ({
          ...obj,
          [key]: object[key],
        }),
        {}
      );
  } catch (err) {
    console.error(err);
    return object;
  }
}
export function mergeDuplicates(arr, key) {
  try {
    const duplicates = [];

    for (let i = 0, len = arr.length; i < len; i += 1) {
      if (arr.find((item) => item[key] === arr[i][key])) {
        duplicates.push(i);
      }
    }

    return arr;
  } catch (err) {
    console.error(err);
    return arr;
  }
}
export function generateRandomString() {
  return Math.random()
    .toString(36)
    .slice(-8);
}
export function getComparedNotes(
  previousNote,
  updatedNote,
  history,
  changeOwner
) {
  const parser = {
    amount: "Amount",
    change_owner: null,
    change_owner_id: null,
    created_at: null,
    date: "Date",
    deleted_at: null,
    description: "Description",
    established_lane_closure: "Established lane closure",
    estimated_cost: "Estimated cost",
    excavation_begun: "Excavation begun",
    excavation_completed: "Excavation completed",
    hour: "No. of Hours",
    id: null,
    ip_address_identifier: null,
    no_of_salvage_container: "Number of salvage containers",
    no_of_samples: "Number of samples",
    note_id: null,
    rate: "Rate",
    report_no: "Report No",
    service_id: null,
    service_type: "Service",
    task_associated_relevance: null,
    time: "Time",
    type: "Type",
    updated_at: null,
    containers: null,
    projected_eta: "Projected ETA",
    actual_eta: "Actual ETA",
  };

  const { attachments, ...newNoteTrimmed } = updatedNote;
  const noteToReturn = {
    ...newNoteTrimmed,
    change_owner: "",
    change_owner_id: previousNote.dataValues.user_id,
  };
  const newHistoryObj = {
    spill_id: previousNote.dataValues.spill_id,
    note_id: previousNote.dataValues.id,
    note_edit_id: null,
    edited_field: null,
    prev_val: null,
    new_val: null,
    change_owner: changeOwner,
    change_owner_id: previousNote.dataValues.user_id,
    created_at: null,
    updated_at: null,
    deleted_at: null,
  };
  if (history && history.length > 0) {
    newHistoryObj.note_edit_id = history[history.length - 1].note_edit_id + 1;
  } else {
    newHistoryObj.note_edit_id = 0;
  }
  const changes = [];

  Object.keys(newNoteTrimmed).forEach((key) => {
    noteToReturn[key] = null;

    let newVal = isBoolean(newNoteTrimmed[key])
      ? newNoteTrimmed[key]
        ? "Yes"
        : "No"
      : ["date", "projected_eta", "actual_eta"].includes(key)
      ? new Date(newNoteTrimmed[key])
      : newNoteTrimmed[key];
    let prevVal =
      isBoolean(newNoteTrimmed[key]) && newNoteTrimmed[key]
        ? previousNote.dataValues[key]
          ? "Yes"
          : "No"
        : previousNote.dataValues[key];

    prevVal = prevVal ? prevVal.toString() : prevVal;
    newVal = newVal === 0 ? "0.00" : newVal ? newVal.toString() : newVal;

    if (
      prevVal !== newVal &&
      (previousNote.dataValues[key] || newNoteTrimmed[key]) &&
      parser[key]
    ) {
      newHistoryObj.edited_field = parser[key];

      newHistoryObj.prev_val = prevVal;
      newHistoryObj.new_val = newVal;
      noteToReturn[key] = newNoteTrimmed[key];
      changes.push({ ...newHistoryObj });
    }
  });
  noteToReturn.spill_id = previousNote.dataValues.spill_id;
  noteToReturn.note_id = previousNote.dataValues.id;
  return changes;
}
String.prototype.replaceAt = function(index, replacement) {
  return (
    this.substr(0, index) +
    replacement +
    this.substr(index + replacement.length)
  );
};

//Used to get the fields which are updated.
export function getChanges(prevObj, newObj) {
  const changeObject = [];
  Object.keys(prevObj).map((key) => {
    const nestedFieldMapperObj = nestedFieldMapper[key];
    const prevVal = prevObj[key];
    const newVal = newObj[key];
    if (
      isObject(prevVal) ||
      isObject(newVal) ||
      Array.isArray(newVal) ||
      Array.isArray(prevVal)
    ) {
    } else if (
      nestedFieldMapperObj &&
      (prevVal || newVal) &&
      prevVal != newVal
    ) {
      changeObject.push({
        old_val:
          (prevVal
            ? prevObj[nestedFieldMapperObj.key]
              ? prevObj[nestedFieldMapperObj.key][
                  nestedFieldMapperObj.value_key
                ]
              : null
            : null) || "N/A",
        new_val:
          (newVal
            ? newObj[nestedFieldMapperObj.key]
              ? newObj[nestedFieldMapperObj.key][nestedFieldMapperObj.value_key]
              : null
            : null) || "N/A",
        name: nestedFieldMapperObj.label,
      });
    } else if (
      !nestedFieldMapperObj &&
      !key.endsWith("_id") &&
      prevVal !== newVal &&
      (isBoolean(newVal) || newVal)
    ) {
      changeObject.push({
        old_val:
          key === "password"
            ? "dontShow"
            : isBoolean(prevVal)
            ? boolToString(prevVal)
            : prevVal ?? "N/A",
        new_val: isBoolean(newVal) ? boolToString(newVal) : newVal ?? "N/A",
        name: keyToName(key),
      });
    }
  });

  return changeObject;
}

//Used to extract dataValues only recursively from objects returned from DB
export const getDataValues = (objToExtract) => {
  let obj = objToExtract?.dataValues;
  obj &&
    Object?.keys(obj)?.map((key) => {
      if (isObject(obj[key])) {
        obj[key] = obj[key] && getDataValues(obj[key]);
      } else if (Array?.isArray(obj[key])) {
        obj[key]?.map((val, index) => {
          obj[key][index] = val && getDataValues(val);
        });
      }
    });
  return obj ?? objToExtract;
};

export const getAddedObj = (objAdded) => {
  const objToReturn = [];

  if (isObject(objAdded)) {
    Object.keys(objAdded).map((key) => {
      !key.endsWith("Id") &&
        !CONSTANTS.IGNORED_FIELDS_NOTE_ADDITION.includes(key) &&
        objToReturn.push({
          key: keyToName(key),
          value: getAddedObj(objAdded[key]),
        });
    });
  } else if (Array.isArray(objAdded)) {
    objAdded.map((obj) => objToReturn.push(getAddedObj(obj)));
  } else {
    return objAdded;
  }
  return objToReturn;
};

export const generateHtml = (info, type) => {
  let bodyToReturn = "";
  let wholeEmailData = null;
  let details = [];
  let spillLink = "";
  let backgroundInfo = [];

  switch (type) {
    case ACTIONS.EDIT_SPILL_MAP_NEEDED:
      const spillObjInfo = info.spill;
      const refNumberInfo = getRefNumber(spillObjInfo);
      spillLink = getSpillLink(URL_FOR_EMAIL, spillObjInfo.job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Location",
          value: `${(spillObjInfo.address || "N/A") +
            ", " +
            (spillObjInfo.city || "N/A") +
            ", " +
            (spillObjInfo.state || "N/A") +
            ", " +
            (spillObjInfo.country || "N/A")}`,
        },
        {
          key: "Latitude",
          value: `${spillObjInfo.latitude || "N/A"}`,
        },
        {
          key: "Longitude",
          value: `${spillObjInfo.longitude || "N/A"}`,
        },
        {
          key: "Point of Contact",
          value: `${spillObjInfo.contact || "N/A"}`,
        },
        {
          key: "Onsite POC Name",
          value: `${spillObjInfo.onsite_poc_name || "N/A"}`,
        },
        {
          key: "Onsite POC Phone",
          value: `${spillObjInfo.onsite_poc_phone || "N/A"}`,
        },
        {
          key: "Project Manager",
          value: `${spillObjInfo.user.full_name || "N/A"}`,
        },
      ];
      spillObjInfo.conditions &&
        backgroundInfo.push({
          key: "Site Conditions",
          value: spillObjInfo.conditions,
        });
      bodyToReturn = `
      <div class='note-header'>Incident #${spillObjInfo.job_no} ${
        refNumberInfo !== "" ? "(" + refNumberInfo + ")" : ""
      } </div> <br />
      <p class='sub-header'>
      This is a journal note regarding <a href="${spillLink}">spill incident #${
        spillObjInfo.job_no
      } </a> managed by PES on behalf of <strong>${
        spillObjInfo.client_organization.name
      }</strong>
       </p> 
       <br />

        ${generateBackgroundInfoBlock(backgroundInfo)}
      `;

      wholeEmailData = {
        header: ``,
        subject: `Map Needed for Spill Incident #${spillObjInfo.job_no}`,
      };
      break;

    case ACTIONS.EDIT_USER:
      bodyToReturn =
        `Hi your information was updated. Please see the updated values below : <br>` +
        `<div class="changesContainer" style="flex-direction: column;"> ${convertRowsToHtml(
          info
        )} </div>`;

      wholeEmailData = {
        header: `Information Updated`,
        subject: `Information Updated`,
      };

      break;

    case ACTIONS.ADD_NOTE_LOGGER:
      details = [
        { name: "Logger Name", new_val: info.user.full_name },
        {
          name: "Organization",
          new_val: info.user.client_organization.name,
        },
        { name: "Note description", new_val: info.desc },
        { name: "Job Number", new_val: info.spill.jobNo },
        { name: "File Names", new_val: info.fileNames.join(", ") },
      ];

      bodyToReturn = ` A note was added by Corporate Logger to a <a href="${
        info.spill.url
      }">spill</a>.<br>
             <div class="changesContainer" style="flex-direction: column;"> ${details
               .map(
                 (change) =>
                   `<div class="flex">
            <span class="fieldBasic fieldHeading">
                 ${change.name} :
            </span>
           
           
            <span class="fieldBasic fieldValueTo">
                ${change.new_val}  
            </span>

        </div>`
               )
               .join("")} </div> `;

      wholeEmailData = {
        header: `Note Added`,
        subject: `Note Added`,
      };

      break;

    case ACTIONS.CREATE_SPILL_APPROVAL:
      bodyToReturn = `A new spill was created by <span class="fieldBasic fieldValueTo">${info.userName}</span> with <strong>Organization :</strong> <span class="fieldBasic fieldValueTo">${info.orgName}</span> that requires your approval.Click <a class="button" href=${info.origin}/dashboard/spills/${info.jobNo}>here</a> to view spill or you can see all <a class="button" href=${info.origin}/dashboard/actions>pending projects.</a>`;

      wholeEmailData = {
        header: `Creation of new project requires your approval.`,
        subject: `Creation of new project`,
      };

      break;

    case ACTIONS.CREATE_SPILL:
      bodyToReturn = `The project you created has been accepted by the Project Manager. Click <a class="button" href=${info.origin}/dashboard/spills/${info.newJobNo}>here</a> to view spill`;

      wholeEmailData = {
        header: `Your changes have been approved`,
        subject: `Creation of New Project`,
      };

      break;

    case ACTIONS.CREATE_SPILL_REJECTED:
      bodyToReturn = `The project you created has been rejected by the Project Manager. 
            The following reason has been given by the Project Manager <br/> <br/>
            <i>${htmlSafe(info.notes)}</i>
            <br/>Click <a class="button" href=${info.origin}/dashboard/spills/${
        info.jobNo
      }>here</a> to view spill
            `;

      wholeEmailData = {
        header: `Your new spill request have been rejected by the Project Manager`,
        subject: `Creation of new Spill`,
      };

      break;

    case ACTIONS.EDIT_SPILL_APPROVAL:
      if (info.changes.length) {
        bodyToReturn = `Following changes were made by <strong>${
          info.name
        }</strong> : <br/> <br/>
        ${convertRowsToHtml(info.changes)} `;
      } else {
        bodyToReturn = `Changes were made to a spill with Job No: <strong>${info.jobNo}</strong> by ${info.name}.`;
      }

      bodyToReturn += `<br/><p>Click <a class="button" href=${info.origin}/dashboard/spills/${info.jobNo}>here</a> to view spill or you can see <a class="button" href=${info.origin}/dashboard/actions>pending projects</a>.</p>
     `;

      wholeEmailData = {
        header: `Spill Edited Approval`,
        subject: `Spill Edited Approval`,
      };

      break;

    case ACTIONS.EDIT_SPILL:
      bodyToReturn = `The project you updated has been accepted by the Project Manager.
       Click <a class="button" href=${info.origin}/dashboard/spills/${info.newJobNo}>here</a> to view spill`;

      wholeEmailData = {
        header: `Your changes have been approved`,
        subject: `Updatation of Spill`,
      };

      break;

    case ACTIONS.EDIT_SPILL_REJECTED:
      bodyToReturn = `The changes you requested has been rejected by the Project Manager. 
          The following reason has been given by the Project Manager <br/> <br/>
          <i>${htmlSafe(info.notes)}</i>
          <br/>Click <a class="button" href=${info.origin}/dashboard/spills/${
        info.jobNo
      }>here</a> to view spill
          `;

      wholeEmailData = {
        header: `Your requested changes have been rejected by the Project Manager`,
        subject: `Updating Spill Rejected`,
      };

      break;
    case ACTIONS.ADD_NOTE:
      const { spillObj } = info;
      const refNumber = getRefNumber(spillObj);
      spillLink = getSpillLink(URL_FOR_EMAIL, spillObj.job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Location",
          value: `${(spillObj.address || "N/A") +
            ", " +
            (spillObj.city || "N/A") +
            ", " +
            (spillObj.state || "N/A") +
            ", " +
            (spillObj.country || "N/A")}`,
        },
      ];
      spillObj.conditions &&
        backgroundInfo.push({
          key: "Site Conditions",
          value: spillObj.conditions,
        });
      bodyToReturn = `
      <div class='note-header'>Incident #${spillObj.job_no} ${
        refNumber !== "" ? "(" + refNumber + ")" : ""
      } </div> <br />
      <p class='sub-header'>
      This is a journal note regarding <a href="${spillLink}">spill incident #${
        spillObj.job_no
      } </a> managed by PES on behalf of <strong>${
        spillObj.client_organization.name
      }</strong>
       </p> 
       <br />
       <br />
      <h3><strong> ${info.note.serviceType} </strong></h3> <br />
      <p>A note was added by<strong> <span class="black"> ${
        info.userName
      } </span></strong> to a <a href="${spillLink}">spill </a>. 
       Following are the fields added : </p><br> 
             <div class="changesContainer" style="flex-direction: column;"> ${getAddedHtml(
               info.changes
             )} </div><br/> <p>${
        spillObj.send_attachment
          ? "Note attachments are added as attachments to this email if any"
          : 'Sending attachments is disabled for this spill, to get attachments with emails, allow "Send Attachments" from spill settings'
      }.</p><br/>
        ${generateBackgroundInfoBlock(backgroundInfo)}
      `;

      wholeEmailData = {
        header: ``,
        subject:
          info.note.serviceType ===
          CONSTANTS.CLOSURE_PACKET_FOR_PAYMENT_SERVICE_NAME
            ? `INVOICE for PES ${spillObj.job_no} ${refNumber} Journal`
            : `Incident # ${spillObj.job_no}/${refNumber} Journal`,
      };
      break;
    case ACTIONS.DELETE_ATTACHMENT:
      const { spillObj: spill } = info;
      backgroundInfo = [
        { key: "Note Id", value: info.noteId },
        {
          key: "Link to Spill",
          value: `<a href="${getSpillLink(
            URL_FOR_EMAIL,
            spill.job_no
          )}"> Click here ! </a>`,
        },
      ];
      bodyToReturn = `
       <div class='note-header'>Incident #${spill.job_no} ${
        getRefNumber(spill) !== "" ? "(" + getRefNumber(spill) + ")" : ""
      } </div> <br />

       <p class='sub-header'>
      This is an attachment deleted notification regarding <a href="${getSpillLink(
        URL_FOR_EMAIL,
        spill.job_no
      )}">spill incident #${
        spill.job_no
      } </a> managed by PES on behalf of <strong>${
        spill.client_organization.name
      }</strong>
       </p> 
       <br />
       <br />
       <p>The attachments <strong class="black"> ${info.deletedAttachments
         .map((attach) => attach.name)
         .join(", ")} </strong> were deleted by <strong class="black">${
        info.userName
      } @ ${info.ipAddress}<strong> </p> 
      <br />
      ${generateBackgroundInfoBlock(backgroundInfo)}
      `;
      wholeEmailData = {
        header: ``,
        subject: `Incident # ${spill.job_no}/Note # ${info.noteId} attachment deleted`,
      };

      break;

    case ACTIONS.REJECT_DOCUMENTS:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.spill.job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Client Organization",
          value: info.spill.client_organization.name,
        },
        { key: "Rejected by", value: info.user.full_name },
      ];
      const docsReasonTable = convertToTableData(
        [
          { heading: "Name", key: "name" },
          { heading: "Reason", key: "admin_note" },
        ],
        info.rejectedDocs
      );

      bodyToReturn = `Hi <b>${
        info.recievingUser.full_name
      }</b>, the following documents were rejected by <b>${
        info.user.full_name
      } </b> from the <a href="${spillLink}">incident# ${
        info.spill.job_no
      }</a> :
      <br />
      <br />
          ${getTableViewForEmail(docsReasonTable)}

          <br />
          <br />
      ${generateBackgroundInfoBlock(backgroundInfo)}
          `;
      wholeEmailData = {
        header: `Incident # ${info.spill.job_no}`,
        subject: `Incident # ${info.spill.job_no} Documents Rejected`,
      };

      break;

    case ACTIONS.STATUS_CHANGE:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.spill.job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Client Organization",
          value: info.spill.client_organization.name,
        },
        { key: "Changed by", value: info.changeUser },
      ];

      bodyToReturn = `Hi, the status of  <a href="${spillLink}">incident# ${
        info.spill.job_no
      }</a> was changed by <b>${info.changeUser} </b> from <b>${
        info.spill.status
      }</b> to <b>${info.newStatus}</b>
     
          <br />
          <br />
      ${generateBackgroundInfoBlock(backgroundInfo)}
          `;
      wholeEmailData = {
        header: `Incident # ${info.spill.job_no}`,
        subject: `Incident # ${info.spill.job_no} Status Changed`,
      };

      break;

    case ACTIONS.DOCUMENTS_SUBMITTED:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.spill.job_no);

      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Contractor",
          value: info.contractor?.name || "N/A",
        },
        { key: "Submitted by", value: info.userName },
      ];

      bodyToReturn = `Hi, the <b>${
        info.userName
      }</b> has uploaded the following documents for review:
     
      ${generateList(info.admin.spill_attachments)}
          <br />
          <br />
      ${generateBackgroundInfoBlock(backgroundInfo)}
          `;
      wholeEmailData = {
        header: `Incident # ${info.spill.job_no}, Ready for Review`,
        subject: `Packet for ${info.spill.job_no}, Ready for Review`,
      };

      break;

    case ACTIONS.EDIT_NOTE:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.spill.job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Note ID",
          value: info.note_id,
        },
        {
          key: "Client Organization",
          value: info.spill.client_organization.name,
        },
        { key: "Changed by", value: info.change_by },
      ];
      const changeTable = convertToTableData(
        [
          { heading: "Edited Field", key: "edited_field" },
          { heading: "Prev Value", key: "prev_val" },
          { heading: "New Value", key: "new_val" },
        ],
        info.changes
      );

      bodyToReturn = `Hi, the following changes were made by <b>${
        info.change_by
      } </b> to note <b>(ID:${
        info.note_id
      })</b> of <a href="${spillLink}">incident# ${info.spill.job_no}</a> :
      <br />
      <br />
          ${getTableViewForEmail(changeTable)}

          <br />
          <br />
      ${generateBackgroundInfoBlock(backgroundInfo)}
          `;
      wholeEmailData = {
        header: `Note # ${info.note_id} Edited Notification`,
        subject: `Incident # ${info.spill.job_no}, Note # ${info.note_id} Edited`,
      };
      break;

    case ACTIONS.EDIT_SPILL_CLIENT_ORGANIZATION:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.updatedJobNumber);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Previous Client Organization",
          value: info.updatedClientOrganization,
        },
        {
          key: "New Client Organization",
          value: info.clientOrganizationToUpdate,
        },
        { key: "Changed by", value: info.changeUser },
      ];
      bodyToReturn = `Hi, the Client Organization of incident# ${
        info.jobNumberToUpdate
      }</a> was changed by <b>${info.changeUser}
      </b> from <b>${info.updatedClientOrganization}</b>
      </b> to <b>${info.clientOrganizationToUpdate}</b>.
      <br />
      
      So your new incident# is ${info.updatedJobNumber} 
      ${generateBackgroundInfoBlock(backgroundInfo)}
      `;
      wholeEmailData = {
        header: `Incident # ${info.jobNumberToUpdate}`,
        subject: `Incident # ${info.jobNumberToUpdate} Client Organization and Incident No. Updated`,
      };
      break;

    case ACTIONS.PACKET_REVIEWER_ASSIGNMENT:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.spill.job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Packet Reviewer Assigned",
          value: info.assignedPacketReviewer,
        },
        { key: "Assigned by", value: info.assignerUser },
      ];
      bodyToReturn = `Hi, the Packet Reviewer Assigned to incident# ${
        info.spill.job_no
      }</a> was assigned by <b>${info.assignerUser}
        <br />
        ${generateBackgroundInfoBlock(backgroundInfo)}
        `;
      wholeEmailData = {
        header: `Packet Reveiwer Assignment`,
        subject: `Packet Reviewer Assigned To Incident # ${info.spill.job_no} `,
      };
      break;

    case ACTIONS.REQUEST_DOCUMENTATION:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.spill_job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Requested Documentation Types",
          value: `${getRequestedDocTypes(info.requested_doc_types)}`,
        },
        { key: "Requested by", value: info.requested_by },
      ];
      bodyToReturn = `Hi, the Requested Documentation for the incident# ${
        info.spill_job_no
      }</a> were requested by: <b>${info.requested_by}
      <br />
       ${info.requested_to ? `against contractor: ${info.requested_to}` : " "}
      ${generateBackgroundInfoBlock(backgroundInfo)}
      `;
      wholeEmailData = {
        header: `Requested Documentation`,
        subject: `Requested Documentation For Incident # ${info.spill_job_no} `,
      };
      break;

    case ACTIONS.REQUEST_DOCUMENTATION_SUBMISSION:
      spillLink = getSpillLink(URL_FOR_EMAIL, info.spill_job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Requested Documentation Types",
          value: `${getRequestedDocTypes(info.requested_doc_types)}`,
        },
      ];
      bodyToReturn = `Hi, the Requested Documents ${getRequestedDocTypes(
        info.requested_doc_types
      )} for the incident# ${info.spill_job_no}</a> were submitted
        <br />
        ${generateBackgroundInfoBlock(backgroundInfo)}
        `;
      wholeEmailData = {
        header: `Requested Documents Submission`,
        subject: `Requested Documents Submission For Incident # ${info.spill_job_no} `,
      };
      break;

    case ACTIONS.REPLACE_REJECTED_FILES:
      spillLink = getSpillLink(URL_FOR_EMAIL, info?.spill_job_no);
      backgroundInfo = [
        {
          key: "Link to Spill",
          value: `<a href="${spillLink}"> Click here ! </a>`,
        },
        {
          key: "Attachments Resubmitted For Contractor",
          value: `${info?.contractorName}`,
        },
      ];
      bodyToReturn = `Hi, the Rejected Documents for the incident# ${
        info?.spill_job_no
      }</a> were re-submitted by
      ${info?.contractorName}
        <br />
        ${generateBackgroundInfoBlock(backgroundInfo)}
        `;
      wholeEmailData = {
        header: `Documents Re-Submission`,
        subject: `Documents Re-Submission For Incident # ${info?.spill_job_no} `,
      };
      break;

    default:
      null;
  }

  return { ...wholeEmailData, body: bodyToReturn };
};

export const getContractors = async (id) => {
  const contractors = await models.SpillContractors.findAll({
    include: [
      {
        model: models.Addresses,
        required: false,
      },
      {
        model: models.Contractors,
        required: false,
      },
    ],
    where: {
      connection_id: id,
      deleted_at: null,
    },
  });
  return contractors;
};

export const handleRejectedContractors = async (
  rejectedContractors,
  spill_id,
  { id: change_owner_id, full_name: change_owner }
) => {
  try {
    const contractor_history = [];
    for (let contractor of rejectedContractors) {
      //checking if rejected is the contractor is main or sub-address
      let history_instance = {
        change_owner,
        change_owner_id,
        spill_id,
        description: contractor?.reject_reason,
        response_by: contractor?.rejected_by,
        contractor_label: contractor?.label,
      };
      if (contractor.addressId) {
        await models.Addresses.update(
          { reject_count: models.sequelize.literal("reject_count + 1") },
          { where: { id: contractor.addressId } }
        );
        history_instance = {
          ...history_instance,
          address_id: contractor.addressId,
        };
      } else {
        await models.Contractors.update(
          { reject_count: models.sequelize.literal("reject_count + 1") },
          { where: { id: contractor.contractor_id } }
        );
        history_instance = {
          ...history_instance,
          contractor_id: contractor.contractor_id,
        };
      }
      contractor_history.push(history_instance);
    }
    contractor_history.length &&
      (await models.ContractorHistory.bulkCreate(contractor_history));
  } catch (error) {}
};

export const incrementResponseCount = async (acceptedContractors) => {
  acceptedContractors.map((contractor) => {
    if (contractor.accepted) {
      if (contractor.addressId || contractor.address_id) {
        models.Addresses.update(
          {
            respond_count: models.sequelize.literal("respond_count + 1"),
          },
          { where: { id: contractor.addressId || contractor.address_id } }
        );
      } else {
        models.Contractors.update(
          {
            respond_count: models.sequelize.literal("respond_count + 1"),
          },
          {
            where: { id: contractor.contractor_id },
          }
        );
      }
    }
  });
};

export const adjustSpillTotal = async (id, prevNote, amount) => {
  try {
    if (prevNote?.dataValues?.amount === amount) return;

    const spill = await models.Spills.findOne({
      where: { id },
      attributes: ["total_notes_sum"],
    });

    const newTotal =
      +spill.dataValues.total_notes_sum -
      (+prevNote?.dataValues?.amount || 0) +
      +amount;
    await models.Spills.update(
      { total_notes_sum: newTotal.toFixed(2) },
      { where: { id } }
    );
  } catch (err) {
    console.error(err);
  }
};

export const uniqueIdGenerator = (() => (str = "") =>
  `${str}${Math.random()
    .toString(16)
    .slice(2)}`)(0);

export const filterPacketReviewers = (arr1, arr2) => {
  const filtered = arr1?.filter(
    (elem) =>
      !arr2?.find(
        ({ packet_reviewer_user_id, assigned_spill_id }) =>
          elem?.packet_reviewer_user_id === packet_reviewer_user_id &&
          elem?.assigned_spill_id === assigned_spill_id
      )
  );
  return filtered;
};

export const filterSpillsToInsert = (arr1, arr2) => {
  const result = arr1?.filter((obj1) =>
    arr2?.every((obj2) => obj1?.assigned_spill_id !== obj2?.assigned_spill_id)
  );
  return result;
};

export const filterSpillsToUpdate = (arr1, arr2) => {
  const result = arr1?.filter((obj1) =>
    arr2?.some((obj2) => obj1?.assigned_spill_id === obj2?.assigned_spill_id)
  );
  return result;
};

export const uniqueStringsInArray = (value, index, self) => {
  return self.indexOf(value) === index;
};

export const getUser = async (email, id) => {
  try {
    const where = email ? { email } : { id };
    const user = await models.User.findOne({ where });

    return getDataValues(user);
  } catch (err) {
    console.error(err);
  }
};

// API don't require external data in req.user object
export const userWithoutExternalData = (reqUrl) => {
  if (reqUrl && userWithOutExternalDataUrls.includes(reqUrl)) {
    return true
  }
  return false
};

// API require external data
export const includeExternalData = (reqUrl) => {
  if (reqUrl && roleExternalDataUrls.includes(reqUrl)) {
    return false
  }
  return true
};

/* Check if users eula is accepted for the current year, 
if not then logout the user setting eula false */
export const checkUserEula = async (user) => {
  const currentYear = new Date().getFullYear();
  const userIsContractorOrCorporate = [5, 6, 7, 8, 9, 10].includes(
    user?.role_id
  );
  const user_id = user?.id;
  if (currentYear !== user?.eula_accepted_year &&
    user?.eula_accepted === true &&
    userIsContractorOrCorporate) {
    await models.User.update(
      {
        eula_accepted: false,
      },
      { where: { id: user_id }, returning: true }
    );
    return true;
  }
  return false;
};

export const getReportingRequirementHistory = async (country, state, openedOn) => {
  let countryData = country;
  if (country === null) {
    countryData = 'United States of America';
  }
  const query = `SELECT a.jurisdiction, a.name, rrh.*
  FROM agencies a
  LEFT JOIN reporting_requirements_history rrh ON a.id = rrh.agency_id AND rrh.deleted_at IS NULL
  INNER JOIN (
      SELECT agency_id, MAX(revision_date) AS latest_revision_date
      FROM reporting_requirements_history
      WHERE revision_date <= '${openedOn}' AND deleted_at IS NULL
      GROUP BY agency_id
  ) latest_rrh ON rrh.agency_id = latest_rrh.agency_id AND rrh.revision_date = latest_rrh.latest_revision_date
  WHERE (
      (a.country = '${countryData}' AND a.jurisdiction = '${JURISDICTION.NATIONAL}') 
      OR 
      (a.country = '${countryData}' AND a.state = '${state}' AND a.jurisdiction = '${JURISDICTION.STATE}')
    )
    AND a.deleted_at IS NULL;`;
  const getReportingRequirement = await sequelize.query(query);
  return getReportingRequirement[0];
};


export const updateReportingRequirementHistory = async (req, transaction) => {
  try {
    const {
      id,
      petroleum_release_amount,
      petroleum_release,
      hazardous_material_amount,
      hazardous_material,
      water_impact_amount,
      water_impact,
      soil_impact_amount,
      soil_impact,
      revision_date,
    } = req.body;

    const reportingHistory = {
      petroleum_release_amount: petroleum_release_amount || null,
      petroleum_release: petroleum_release || null,
      hazardous_material_amount: hazardous_material_amount || null,
      hazardous_material: hazardous_material || null,
      water_impact_amount: water_impact_amount || null,
      water_impact: water_impact || null,
      soil_impact_amount: soil_impact_amount || null,
      soil_impact: soil_impact || null,
    };
    if (!Object.values(reportingHistory).every((v) => v === null)) {
      const where = {
        where: { 
          agency_id: id,
          revision_date: {
            [Op.eq]: revision_date ? revision_date : null
          }
        },
        transaction
      }
      const result = await models.ReportingRequirementsHistory.count(where);
      if (result > 0) {
        await models.ReportingRequirementsHistory.destroy(where);
      }
      await models.ReportingRequirementsHistory.create(
        { 
          agency_id: id,
          ...reportingHistory,
          revision_date: revision_date || null
        },
        { transaction }
      );
    }
  } catch (error) {
    console.log(error);
  }
};

export const findClientWasteHandlings = async (org_id, openedOn) => {
  try {
    const find = await models.ClientOrganizationWasteHandlings.findOne({
      where: { 
        org_id, 
        revision_date: {
          [Op.lte] : openedOn
        }
      },
      order: [["created_at","DESC"]],
      limit: 1, 
    });
    return find;
  } catch (error) {
    console.log(error)
  }
};

export const createReportingRequirementsHistory = async (transaction, agencyId, historyObj) => {
  try {
    let reportingHistory = {
      petroleum_release_amount: historyObj.petroleum_release_amount || null,
      petroleum_release: historyObj.petroleum_release || null,
      hazardous_material_amount: historyObj.hazardous_material_amount || null,
      hazardous_material: historyObj.hazardous_material || null,
      water_impact_amount: historyObj.water_impact_amount || null,
      water_impact: historyObj.water_impact || null,
      soil_impact_amount: historyObj.soil_impact_amount || null,
      soil_impact: historyObj.soil_impact || null,
    };
    if (!Object.values(reportingHistory).every((v) => v === null)) {
      reportingHistory = {
        ...reportingHistory,
        agency_id: agencyId,
        revision_date: historyObj.revision_date,
      };
      const historyRecord = await models.ReportingRequirementsHistory.create(reportingHistory, { transaction });
      reportingHistory = historyRecord?.dataValues
    }
    return reportingHistory;
  } catch (error) {
    console.log(error)
  }
};