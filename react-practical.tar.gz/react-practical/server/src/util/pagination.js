const limit = 10;

export default function(p = 0, options = {}) {
  return {
    current: Number(p) || 0,
    limit: options.limit || limit,
    offset: Number(p) > 0 ? (Number(p) - 0) * (options.limit || limit) : 0,
  };
}
