import models from "../models";
import { genericSender } from "../services/email/emailProvider";
import { createJobNumber } from "../util/misc";
import { ACTIONS } from "../util/constants";
import { generateHtml } from "../util/helper";

const { URL_FOR_EMAIL } = process.env;

export const newAction = async ({
  type,
  data,
  status,
  manager_id,
  user_id,
  info,
  models,
}) => {
  const manager = await models.User.findOne({ where: { id: manager_id } });
  const result = await models.PmActions.create({
    type,
    data,
    status,
    manager_id,
    user_id,
  });
  const user = await models.User.findOne({
    where: { id: user_id },
    include: [
      {
        model: models.ClientOrganizations,
        required: false,
      },
    ],
  });

  let dataForEmail = null;

  switch (type) {
    case ACTIONS.CREATE_SPILL:
      dataForEmail = {
        sendEmailTo: manager?.dataValues?.email,
        sendEmailFrom: user?.dataValues?.email,
        ...generateHtml(
          {
            origin: URL_FOR_EMAIL,
            jobNo: data?.jobNo,
            userName: user?.dataValues?.full_name,
            orgName: user?.dataValues?.client_organization?.dataValues?.name,
          },
          ACTIONS.CREATE_SPILL_APPROVAL
        ),
      };
      genericSender(dataForEmail);
      return { ...result.toJSON(), user: manager };
      break;
    case ACTIONS.EDIT_SPILL:
      dataForEmail = {
        sendEmailTo: manager?.dataValues?.email,
        sendEmailFrom: user?.dataValues?.email,
        ...generateHtml(
          {
            origin: URL_FOR_EMAIL,
            jobNo: data.job_no,
            name: info.userFullName,
            changes: info.changes,
          },
          ACTIONS.EDIT_SPILL_APPROVAL
        ),
      };
      genericSender(dataForEmail);
      break;
    default:
      null;
  }
};

export const executeAction = async (action) => {
  let dataForEmail = null;
  const manager = await models.User.findOne({
    where: { id: action.manager_id },
  });

  switch (action.type) {
    case ACTIONS.CREATE_SPILL:
      const newSpill = await models.Spills.findOne({
        where: { id: action.data.id },
        include: [
          {
            model: models.ClientOrganizations,
          },
        ],
      });
      console.log(newSpill);
      const newJobNo = await createJobNumber(
        newSpill.client_organization.code,
        false
      );
      await models.Spills.update(
        {
          job_no: newJobNo,
          is_approved: true,
        },
        { where: { id: action.data.id } }
      );

      dataForEmail = {
        sendEmailTo: action.user.email,
        ...generateHtml(
          { origin: URL_FOR_EMAIL, newJobNo },
          ACTIONS.CREATE_SPILL
        ),
      };

      break;
    case ACTIONS.EDIT_SPILL:
      dataForEmail = {
        sendEmailTo: action.user.email,

        ...generateHtml(
          { origin: URL_FOR_EMAIL, newJobNo },
          ACTIONS.EDIT_SPILL
        ),
      };

      break;
    default:
      break;
  }

  dataForEmail &&
    genericSender({
      ...dataForEmail,
      sendEmailFrom: manager?.dataValues?.email,
    });
};

export default newAction;
