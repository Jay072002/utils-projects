import archiver from "archiver";
import fs from "fs";

export const createZipFile = async (pathArray, onEnd, path) => {
  const filePathArray = pathArray.map((filePath) => {
    const splitted = filePath.split("/");
    splitted[splitted.length - 1] = encodeURIComponent(
      splitted[splitted.length - 1]
    )
      .replaceAll("(", "%28")
      .replaceAll(")", "%29");
    return splitted.join("/");
  });
  !fs.existsSync(path.split("/")[0]) && fs.mkdirSync(path.split("/")[0]);

  let output = fs.createWriteStream(path);
  let archive = archiver("zip", {
    gzip: true,
    zlib: { level: 9 },
  });

  archive.on("error", function(err) {
    throw err;
  });

  output.on("finish", onEnd);

  archive.pipe(output);

  for (const filePath of filePathArray) {
    console.log("filePath :", filePath);
    console.log(
      'filePath.split("/").pop() ?? filePath.split("\\").pop() :',
      filePath.split("/").pop() ?? filePath.split("\\").pop()
    );
    archive.file(filePath, {
      name: filePath.split("/").pop() ?? filePath.split("\\").pop(),
    });
  }
  archive.finalize();
};

export const createAllZipFile = (adminArray, noteArray, onEnd, path) => {
  let output = fs.createWriteStream(path);
  let archive = archiver("zip", {
    gzip: true,
    zlib: { level: 9 },
  });

  archive.on("error", function(err) {
    throw err;
  });

  output.on("finish", onEnd);

  archive.pipe(output);

  for (const path of adminArray) {
    archive.file(path, {
      name: `admin/${
        path
          .split("/")
          .pop()
          .split("#")[1]
      }`,
    });
  }

  for (const path of noteArray) {
    archive.file(path, {
      name: `note/${
        path
          .split("/")
          .pop()
          .split("#")[1]
      }`,
    });
  }

  archive.finalize();
};
