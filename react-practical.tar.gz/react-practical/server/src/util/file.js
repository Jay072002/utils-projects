import fs from 'fs';
import http from 'http';
import https from 'https';
import path from 'path';

const File = {
  delete: filePath =>
    new Promise((resolve, reject) => {
      fs.unlink(filePath, err => {
        if (err) {
          reject(err);
        }

        resolve();
      });
    }),

  download: (url, dest) =>
    new Promise((resolve, reject) => {
      const filePath = dest || getRandomString();
      const file = fs.createWriteStream(path.resolve(filePath));
      const urlObj = getURLObj(url);
      const protocol = urlObj.protocol === 'https' ? https : http;

      protocol
        .get(url, response => {
          response.pipe(file);

          file.on('finish', () => {
            file.close();
            resolve(path.resolve(filePath));
          });
        })
        .on('error', err => {
          fs.unlink(filePath);
          reject(err);
        });
    }),
};

const getRandomString = (prefix = '', suffix = '') =>
  `${prefix}${Math.random()
    .toString(36)
    .substring(2)}${suffix}`;

const getURLObj = url => {
  const URL = String(url)
    .toLowerCase()
    .split(' ')
    .join('');
  const protocol = URL.split(':')[0] === 'https' ? 'https' : 'http';

  const obj = {
    protocol,
  };

  return obj;
};

export default File;
