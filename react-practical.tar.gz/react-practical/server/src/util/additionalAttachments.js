import models, { sequelize } from "../models";
import { certificateTypes } from "./constants";

export const fetchDataFromAttachmentTable = async (id) => {
  const fetchAdditionalAttachmentTypes = `
    SELECT 
    id AS attachment_id, label, value
    FROM
    contractor_attachment_types
    WHERE
    value IN ('contractorLiability' , 'contractorWorkers',
        'contractorW9',
        'hasWasteHauler',
        'rateSheet')`;

  let additionalAttachmentTypes = await sequelize.query(
    fetchAdditionalAttachmentTypes
  );

  if (additionalAttachmentTypes.length > 0) {
    additionalAttachmentTypes = additionalAttachmentTypes[0];
  } else {
    additionalAttachmentTypes = certificateTypes;
  }

  let fetchGenericAttachedDocuments = await models.GenericAttachedDocuments.findAll(
    {
      where: {
        contractor_id: id,
      },
    }
  );
  let ContractorAttachmentExpiries = await models.ContractorAttachmentsExpiry.findAll(
    {
      attributes: ["expiry_date", "disabled", "attachment_id", "contractor_id"],
      where: {
        contractor_id: id,
      },
    }
  );

  if (fetchGenericAttachedDocuments?.length > 0) {
    additionalAttachmentTypes = additionalAttachmentTypes.map((item1) => {
      let item2 = fetchGenericAttachedDocuments.find(
        (doc) => doc.attachment_type === item1.value
      );
      return {
        ...(item2 && item2?.dataValues),
        value: item1?.value,
        label: item1?.label,
        attachment_id: item1?.attachment_id,
      };
    });
  }

  if (ContractorAttachmentExpiries.length > 0) {
    const expiryDates = new Map();
    for (const item of ContractorAttachmentExpiries) {
      expiryDates.set(
        `${item.contractor_id}-${item.attachment_id}`,
        item.expiry_date
      );
    }
    for (const item of additionalAttachmentTypes) {
      const key = `${item.contractor_id}-${item.attachment_id}`;
      if (expiryDates.has(key)) {
        item.expiry_date = expiryDates.get(key);
      }
    }
  }

  return additionalAttachmentTypes;
};
