const request = require('request');

module.exports = {
  get: options =>
    new Promise((resolve, reject) => {
      request.get(options, (error, response, data) => {
        if (error) {
          reject(error);
          return;
        }

        if (response.statusCode !== 200) {
          reject(new Error(`Invalid status code${response.statusCode}>`));
          return;
        }

        resolve({
          data,
        });
      });
    }),

  put: (uri, options) =>
    new Promise((resolve, reject) => {
      request.put(uri, options, (error, response, body) => {
        if (error) {
          reject(error);
          return;
        }

        if (response.statusCode >= 200 && response.statusCode < 300) {
          resolve(body);
        }

        reject(new Error(`Invalid status code${response.statusCode}>`));
      });
    }),

  post: options =>
    new Promise((resolve, reject) => {
      request.post(options, (error, response, data) => {
        if (error) {
          reject(error);
          return;
        }

        if (response.statusCode !== 200) {
          reject(new Error(`Invalid status code${response.statusCode}>`));
          return;
        }

        resolve({
          data,
        });
      });
    }),
};
