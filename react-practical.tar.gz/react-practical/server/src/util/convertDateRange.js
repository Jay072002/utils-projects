/*
  input= date: dateTimeString
  output= a range of date with sequelize gte and lte operation
  `convertDateToDateRange can be only used for date`
 */
const Moment = require('moment');
const Sequelize = require('sequelize');

const { Op } = Sequelize;

const convertDateToDateRange = (dateFrom, dateTo, key) => {
  console.log('key :', key);
  console.log('dateTo :', dateTo);
  console.log('dateFrom :', dateFrom);
  let dateFilter = {};
  if (dateFrom) {
    dateFilter = {
      [Op.gte]: dateFrom,
    };
  }
  if (dateTo) {
    dateFilter = {
      ...dateFilter,
      [Op.lte]: dateTo,
    };
  }

  const toReturn = dateFrom || dateTo ? { [key]: dateFilter } : {};
  return toReturn;
};
const getFirstDay = (date, next) => {
  let converted = forceToCST(date);
  const year = converted.slice(0, 4);
  let month = converted.slice(5, 7);
  const day = converted.slice(8, 10);
  if (next) {
    month = (+month + 1).toLocaleString('en-US', {
      minimumIntegerDigits: 2,
      useGrouping: false,
    });
  }
  return `${year}-${month}-01T00:00:00.000Z`;
};

const getLastDay = (date, next) => {
  let converted = forceToCST(date);
  const year = converted.slice(0, 4);
  let month = converted.slice(5, 7);
  let day = converted.slice(8, 10);
  day = +day;
  day = day?.toString()?.length === 1 ? `0${day}` : `${day}`;
  if (next) {
    month = (+month + 1).toLocaleString('en-US', {
      minimumIntegerDigits: 2,
      useGrouping: false,
    });
  }
  return `${year}-${month}-${day}T23:59:59.999Z`;
};

const forceToCST = (date) => {
  const startIndex = date.indexOf('2');
  const endIndex = date.indexOf('Z');
  return date.slice(startIndex, endIndex + 1);
};

const forceToCSTForRawQuery = (date) => {
  let updatedDate = date.replace('T', ' ');
  updatedDate = updatedDate.replace('Z', '');
  updatedDate = updatedDate.split('.')[0];
  if (updatedDate.indexOf('"') > -1) {
    updatedDate = updatedDate.split('"')[1];
  }
  return updatedDate;
};

const convertDateDiffIntoHours = (date1, date2) => {
  let now = null;
  if (date2 === null) {
    now = Moment(new Date()); //todays date
  } else {
    now = Moment(date2); // second date
  }
  const end = Moment(date1); // first date
  const duration = Moment.duration(now.diff(end));
  const hours = duration.asHours();
  let minutes = hours * 60;
  minutes = Math.ceil(minutes);
  return minutes;
};

export {
  convertDateToDateRange,
  forceToCST,
  forceToCSTForRawQuery,
  getFirstDay,
  getLastDay,
  convertDateDiffIntoHours,
};
