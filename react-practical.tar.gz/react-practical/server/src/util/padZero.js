export const padZero = (number, totalDigits = 4) => {
  return number.toString().padStart(totalDigits, "0");
};

export default padZero;
