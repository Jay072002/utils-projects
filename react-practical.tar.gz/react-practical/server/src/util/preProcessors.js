import {
  ROLES,
  CONSTANTS,
  getAdminAttachmentTypes,
  CorporateStatusVisibility,
  ContractorStatusVisibility,
} from "./constants";
import models from "../models";

export const isObject = (obj) => {
  if (typeof obj === "object" && obj !== null && !Array.isArray(obj)) {
    return true;
  }
  return false;
};

export const isString = (obj) => typeof obj === "string";

export const isBoolean = (obj) => {
  return typeof obj === "boolean";
};

export const boolToString = (obj) => {
  return obj ? "Yes" : "No";
};

export const isDateString = (str) => {
  const dateStringRegex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(.*)(\d{0,})Z/g;
  return dateStringRegex.test(str);
};

export const insertAt = (str, strToInsert, index) => {
  return str.slice(0, index) + strToInsert + str.slice(index);
};

export function keyToName(key) {
  let keyToConvert = key;
  keyToConvert = keyToConvert.replaceAt(0, keyToConvert[0].toUpperCase());
  let i = 0;
  while (i < keyToConvert.length) {
    if (keyToConvert[i] === "_") {
      keyToConvert = keyToConvert.replaceAt(
        i + 1,
        keyToConvert[i + 1].toUpperCase()
      );
      keyToConvert = keyToConvert.replaceAt(i, " ");
      i++;
    } else if (keyToConvert[i] === keyToConvert[i].toUpperCase()) {
      keyToConvert = insertAt(keyToConvert, " ", i);
      i++;
    }
    i++;
  }

  return keyToConvert;
}

export const getFileNames = (fileList) => {
  const fileNames = [];
  fileList.map((file) =>
    fileNames.push(
      file?.originalname?.slice(file.originalname.indexOf("#") + 1)
    )
  );
  return fileNames;
};

export const convertRowsToHtml = (rows) => {
  const toReturn = rows.map(
    (change) =>
      `<div class="flex">
            <span class="fieldBasic fieldHeading">
                 ${change.name} :
            </span>
            ${
              change.old_val === "dontShow"
                ? ""
                : `<span class="fieldBasic fieldValueFrom">
                ${change.old_val}  
            </span>
            <span class="fieldTo">
              to
            </span>`
            }
           
            <span class="fieldBasic fieldValueTo">
                ${change.new_val}  
            </span>

        </div>`
  );
  return toReturn.join("");
};

export const getAddedHtml = (addedArr) => {
  return addedArr
    .map((change) =>
      Array.isArray(change)
        ? change.length
          ? `<div class="container">${getAddedHtml(change)}</div>`
          : ""
        : (isBoolean(change.value) || change.value || change.value === 0) &&
          (!Array.isArray(change.value) || change.value.length) &&
          change.value !== ""
        ? `<div class="flex">
            <span class="fieldBasic fieldHeading">
                 ${change.key} ${Array.isArray(change.value) ? "" : ":"}
            </span>
            <span class="fieldBasic fieldValueTo">
                ${
                  isBoolean(change.value)
                    ? boolToString(change.value)
                    : Array.isArray(change.value)
                    ? `<div class="spacer">  ${getAddedHtml(
                        change.value
                      )}  </div>`
                    : isDateString(change.value)
                    ? new Date(change.value)
                    : change.value
                }  
            </span>

        </div>
        `
        : ""
    )
    .join("");
};

export const camelToSnakeCase = (key) => {
  let i = 0;
  while (i < key.length) {
    if (key[i] === key[i].toUpperCase()) {
      key = insertAt(key, "_", i);
      key = key.replaceAt(i + 1, key[i + 1].toLowerCase());
      i++;
    }
    i++;
  }
  return key;
};

export const convertKeys = (obj) => {
  let objToReturn = {};
  Object.keys(obj).map(
    (key) => (objToReturn[camelToSnakeCase(key)] = obj[key])
  );

  return objToReturn;
};

export const generateAutoServiceNote = (
  service,
  service_id,
  userId,
  serviceName,
  additionalInfo
) => {
  const isAssignmentService = CONSTANTS.ASSIGNMENT_SERVICE_NAME === serviceName;

  return {
    userId: userId,
    serviceType: serviceName,
    serviceId: service_id,
    rate: service.rate,
    hour: !isAssignmentService ? 0 : 0.5,
    amount: !isAssignmentService ? 0 : service.rate * 0.5,
    type:
      additionalInfo.serviceType || !isAssignmentService ? "fixed" : "hourly",
    description: !isAssignmentService
      ? CONSTANTS.DOWNLOAD_ATTACHMENT_SERVICE_NAME === serviceName
        ? `Following attachments were downloaded by ${additionalInfo.name}@ ${
            additionalInfo.ipAddress
          } : 
      ${additionalInfo.filesDownloaded.join(" , ")}`
        : `From note with note id ${
            additionalInfo?.noteId
          } the attachments ${additionalInfo?.deletedAttachments
            ?.map((attach) => attach.name)
            .join(", ")} were deleted by ${additionalInfo?.name} @ ${
            additionalInfo?.ipAddress
          }`
      : "Initial information-gathering conversation with client was performed.",
  };
};

export const generateBackgroundInfoBlock = (info) => {
  return `
  <div class='background-info-container'>
  <div class='background-info-header'> Background information on this spill: </div>
      ${info
        .map(
          (item) => `<div class='background-info-item'> 
      <div class='background-info-item-heading'>
      ${item.key}: 
      </div>
      <div class='background-info-item-value'>
      ${item.value}
      
      </div>
      </div>`
        )
        .join("")}
  </div>
  `;
};

export const generateList = (list, key) => {
  return `${list
    .map((x) => `<h4 class="list-item">${x[key || "name"]} </h4>`)
    .join("")}`;
};

export const getRefNumber = (spillObj) => {
  return spillObj.claim_no
    ? `Claim # ${spillObj.claim_no}`
    : spillObj.pro
    ? `Pro # ${spillObj.pro}`
    : spillObj.tractor
    ? `Tractor # ${spillObj.tractor}`
    : spillObj.trailer
    ? `Trailer # ${spillObj.trailer}`
    : ``;
};

export const getSpillLink = (origin, jobNo) => {
  return `${origin}/dashboard/spills/view/${jobNo}`;
};

export const getRequestedDocTypes = (requestedTypes) => {
  const adminAttachmentTypeList = getAdminAttachmentTypes();

  const labels = adminAttachmentTypeList
    .filter((item) => requestedTypes.includes(item.value))
    .map((item) => item.label);

  const commaSeparatedLabels = labels.join(", ");

  return commaSeparatedLabels;
};

export const extractNameFromPathString = (str) =>
  str.slice(str.lastIndexOf("/") + 1);

export const extractNamesFromPathArray = (arr) =>
  arr.map((file) => extractNameFromPathString(file));

export const findAssociatedServices = async (org_id, service_name) => {
  return await models.ClientOrganizationServices.findAll({
    where: {
      org_id,
    },
    include: [
      {
        model: models.Services,
        where: {
          name: service_name,
        },
        attributes: ["id", "email_notifications"],
      },
    ],
  });
};

export const isNonEmptyAddress = (address) => {
  return (
    address.city &&
    address.state &&
    (address.address ||
      address.zipCode ||
      address.country ||
      address.phone ||
      address.fax ||
      address.contact ||
      !!address.tier_level)
  );
};

export const mapContractors = (contractors) => {
  const toReturn = [];
  contractors.map((contractor) => {
    if (!contractor.contractor) return;
    if (contractor.address_id) {
      const completeContractor = {
        id: contractor.id,
        addressId: contractor.address_id,
        contractor_id: contractor.contractor_id,
        label: `${contractor.contractor["name"]} ${
          contractor.address["tier_level"]
            ? ` - ${contractor.address["tier_level"]}`
            : ""
        }`,
        address: contractor.address.address,
        city: contractor.address.city,
        state: contractor.address.state,
        country: contractor.address.country,
        email: contractor.contractor.email,
        phone: contractor.address.phone,
        fax: contractor.address.fax,
        value: `${contractor.contractor_id} ${contractor.address_id}`,
        is_inactive: contractor.is_inactive,
        accepted: contractor.accepted,
        contractor_role: contractor.contractor_role,
      };
      toReturn.push(completeContractor);
      return;
    } else {
      const completeContractor = {
        id: contractor.id,
        contractor_id: contractor.contractor_id,
        label: `${contractor.contractor["name"]} ${
          contractor.contractor["tier_level"]
            ? ` - ${contractor.contractor["tier_level"]}`
            : ""
        }`,
        address: contractor.contractor.address,
        city: contractor.contractor.city,
        state: contractor.contractor.state,
        country: contractor.contractor.country,
        email: contractor.contractor.email,
        phone: contractor.contractor.phone,
        fax: contractor.contractor.fax,
        value: `${contractor.contractor_id} `,
        is_inactive: contractor.is_inactive,
        accepted: contractor.accepted,
        contractor_role: contractor.contractor_role,
      };
      toReturn.push(completeContractor);
      return;
    }
  });

  return toReturn;
};

export const calculateRecievingInfo = (receivers, subject, org_id) => {
  const isBlocked = process.env.BLOCK_EMAILS;
  const blockedRecievers = process.env.BLOCK_FALLBACK_EMAIL_ADDRESS;

  if (isBlocked === "yes") {
    console.log(
      "Emails Blocked, Sending instead to :",
      blockedRecievers.split(", ")
    );
    return {
      to: blockedRecievers.split(", "),
      subject: subject + " [Blocked]",
    };
  }
  return { to: receivers, subject };
};

export const uniqueArrayOfStrings = (arr) => {
  let uniqueObj = {};
  for (let i = 0; i < arr?.length; i++) {
    if (!uniqueObj[arr[i]]) {
      uniqueObj[arr[i]] = true;
    }
  }
  let uniqueArr = [];
  for (let prop in uniqueObj) {
    uniqueArr?.push(prop);
  }
  return uniqueArr;
};

export const getSpillObjectForCSV = (spill) => {
  const getContractor = (contractors) => {
    if (contractors & (contractors.length > 0)) {
      contractor = contractors[0];

      contractorLocation.push(contractor.address);
      contractorLocation.push(contractor.city);
      contractorLocation.push(contractor.state);
      contractorLocation.push(contractor.country);

      return {
        name: contractors[0].name,
        location: contractorLocation.map((x) => x || "N/A").join(", "),
      };
    }
  };
  return [
    spill.opened_on,
    spill.closed_on,
    spill.claim_no,
    spill.user.full_name,
    spill.client_organization.name,
    spill.onsite_poc_name,
    spill.address,
    spill.longitude,
    spill.latitude,
    spill.contr,
  ];
};
export const isContractorUser = (role) =>
  [ROLES.CONTRACTOR_ADMIN, ROLES.CONTRACTOR_USER].includes(role);

export const isCorporateUser = (role) =>
  [
    ROLES.CORPORATE_ACCOUNTING,
    ROLES.CORPORATE_ADMIN,
    ROLES.CORPORATE_LOGGER,
    ROLES.CORPORATE_USER,
  ].includes(role);

export const isPESUser = (role) =>
  [
    ROLES.PES_ADMIN,
    ROLES.PES_USER,
    ROLES.PES_ACCOUNTING_ADMIN,
    ROLES.SUPER_USER,
  ].includes(role);

export const isPESUser_2 = (role) =>
  [
    ROLES.PES_ADMIN,
    ROLES.PROB_PM,
    ROLES.PES_ACCOUNTING_ADMIN,
    ROLES.SUPER_USER,
  ].includes(role);

export const getTimeDifference = (date1, date2) => {
  date1 = new Date(date1);
  date2 = new Date(date2);
  let seconds = Math.floor((date2 - date1) / 1000);
  let minutes = Math.floor(seconds / 60);
  let hours = Math.floor(minutes / 60);
  let days = Math.floor(hours / 24);

  hours = hours - days * 24;
  minutes = minutes - days * 24 * 60 - hours * 60;
  seconds = seconds - days * 24 * 60 * 60 - hours * 60 * 60 - minutes * 60;
  return { days, hours, minutes, seconds };
};

export const filterSpills = (role, spills) => {
  let toReturn = [];
  if (isContractorUser(role)) {
    toReturn = spills.filter((spill) => {
      if (spill.status !== CONSTANTS.CLOSED_STATUS) {
        return true;
      }
      const nowDate = new Date();

      const timeDiff = getTimeDifference(
        spill.closed_on,
        nowDate.toUTCString()
      );

      if (timeDiff.days > 10) {
        return false;
      }
      return true;
    });
  } else {
    toReturn = spills;
  }

  return toReturn;
};

export const statusVisibility = (spillStatus, role) => {
  if (isPESUser(role)) {
    return spillStatus;
  } else if (isContractorUser(role)) {
    return ContractorStatusVisibility[spillStatus] || spillStatus;
  } else {
    return CorporateStatusVisibility[spillStatus] || spillStatus;
  }
};

export const convertStatuses = (statuses, role) => {
  return statuses.map((status) => statusVisibility(status, role)).flat();
};

export const isEmptyObject = (obj) => {
  return Object.keys(obj).every((element) => {
    return obj[element] === "" || obj[element] === null;
  });
};

export const isNullish = (obj) => {
  const isNull = Object.values(obj).every((value) => {
    if (value === null) {
      return true;
    } else {
      return false;
    }
  });
  return isNull;
};
