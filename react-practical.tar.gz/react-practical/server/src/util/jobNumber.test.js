const moment = require('moment');
const padZero = require('./padZero');

import createJobNumber from './createJobNumber';

jest.mock('../models', () => {
  return {
    Spills: {
      count: jest.fn().mockResolvedValue(0),
      findOne: jest.fn(),
    },
  };
});

const models = require('../models');

const orgCode = 'org1';
const isTemp = false;
const isTestSpill = false;

const testIDGeneration = async ({ start, end, increment, incrementPeriod }) => {
  let monthlySpillCount = 0;

  for (
    var today = moment(start);
    today.diff(end, 'days') <= 0;
    today.add(increment, incrementPeriod)
  ) {
    models.Spills.count.mockResolvedValue(monthlySpillCount);

    const currentTime = `"${today.format('YYYY-MM-DD')}"`;

    const jobNumber = await createJobNumber(
      orgCode,
      isTemp,
      currentTime,
      isTestSpill
    );

    monthlySpillCount = monthlySpillCount + 1;

    const paddedCount = padZero(monthlySpillCount, 4);
    const testJobNumber = `${today.format(`YY-${orgCode}-MM${paddedCount}`)}`;

    const endOfMonth = moment(today).endOf('month');
    if (today.format('YYYY-MM-DD') === endOfMonth.format('YYYY-MM-DD')) {
      monthlySpillCount = 0;
    }

    expect(jobNumber).toBe(testJobNumber);
  }
};

describe('Job number creation test', () => {
  it.skip('should create job for same month', async () => {
    models.Spills.findOne.mockResolvedValue({ job_no: '23-123-01011' });

    const jobNo = await createJobNumber(123);
    expect(jobNo).toBe('23-123-01012');
  });

  it.skip('should create job for different month', async () => {
    models.Spills.findOne.mockResolvedValue({ job_no: '23-123-02011' });

    const jobNo = await createJobNumber(123);
    expect(jobNo).toBe('23-123-01001');
  });

  it.skip('should create job for 3 years after every 1 day', async () => {
    models.Spills.count.mockResolvedValue(0);
    var start = moment('2023-01-01');
    var end = moment('2026-01-01');

    await testIDGeneration({
      start,
      end,
      increment: 1,
      incrementPeriod: 'day',
    });
  });

  it.skip('should create job for 3 years after every 15 days', async () => {
    models.Spills.count.mockResolvedValue(0);
    var start = moment('2023-01-01');
    var end = moment('2026-01-01');

    await testIDGeneration({
      start,
      end,
      increment: 15,
      incrementPeriod: 'days',
    });
  });

  it.skip('should create job for 2 months after every 2 hours', async () => {
    models.Spills.count.mockResolvedValue(0);
    var start = moment('2023-01-01');
    var end = moment('2023-03-01');

    await testIDGeneration({
      start,
      end,
      increment: 2,
      incrementPeriod: 'hours',
    });
  });

  it.skip('should create a test job for same month', async () => {
    models.Spills.findOne.mockResolvedValue({ job_no: '23-123-01TEST011' });

    const isProbPM = false;
    const isTestSpill = true;

    const jobNo = await createJobNumber(123, isTestSpill, isProbPM);
    expect(jobNo).toBe('23-123-01TEST012');
  });

  it.skip('should create a test job for different month', async () => {
    models.Spills.findOne.mockResolvedValue({ job_no: '23-123-02TEST011' });

    const isProbPM = false;
    const isTestSpill = true;

    const jobNo = await createJobNumber(123, isTestSpill, isProbPM);
    console.log('jobNo: ' + jobNo);
    expect(jobNo).toBe('23-123-01TEST001');
  });

  it.skip('should create a temp job for same month', async () => {
    models.Spills.findOne.mockResolvedValue({ job_no: 'TEMP-23-123-01011' });

    const isProbPM = true;
    const isTestSpill = false;

    const jobNo = await createJobNumber(123, isTestSpill, isProbPM);

    expect(jobNo).toBe('TEMP-23-123-01012');
  });

  it.skip('should create a temp job for different month', async () => {
    models.Spills.findOne.mockResolvedValue({ job_no: 'TEMP-23-123-02011' });

    const isProbPM = true;
    const isTestSpill = false;

    const jobNo = await createJobNumber(123, isTestSpill, isProbPM);
    expect(jobNo).toBe('TEMP-23-123-01001');
  });
});
