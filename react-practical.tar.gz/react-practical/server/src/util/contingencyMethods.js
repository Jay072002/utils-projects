import Moment from 'moment';
import mysql from 'mysql2/promise';
import { isDateString, isString } from '.';
import { getCompleteSpillByJobNo } from '../api/spills/spill.controller';
import models from '../models';
const {
  DATABASE_HOST,
  DATABASE_USERNAME,
  DATABASE_PASSWORD,
  MIGRATION_DATABASE_NAME,
  ENABLE_CONTIGENCY,
} = process.env;

export const getUserByEmail = async (email) => {
  const user = await models.User.findOne({ where: { email } });
  return user;
};

export const buildInsertQuery = (obj, table_name) => {
  let querryToReturn = `INSERT INTO ` + `${table_name}` + `(`;
  const columns = [];
  const values = [];
  Object.keys(obj).map((key) => {
    if (obj[key]) {
      if (['closed', 'opened'].includes(key)) {
        if (`${new Date(obj[key])}` !== 'Invalid Date') {
          console.log('new Date(obj[key]) :', new Date(obj[key]));
          columns.push(key);
          values.push(
            `"` +
              `${Moment(new Date(obj[key])).format('MM-DD-YYYY hh:mm:ss')}` +
              `"`
          );
        }
      } else {
        columns.push(key);
        values.push(isString(obj[key]) ? `"${obj[key]}"` : obj[key]);
      }
    }
  });
  querryToReturn +=
    columns.join(`, `) + `) VALUES (` + values.join(`, `) + `);`;
  console.log('Insert Querry ::', querryToReturn);
  return querryToReturn;
};

export const buildUpdateQuery = (obj, table_name, idKey, id) => {
  let querryToReturn = `UPDATE ` + `${table_name}` + ` SET `;
  const setters = [];
  Object.keys(obj).map((key) => {
    if (obj[key]) {
      if (['closed', 'opened'].includes(key)) {
        if (`${new Date(obj[key])}` !== 'Invalid Date') {
          setters.push(
            `${key} = "${Moment(new Date(obj[key])).format(
              'MM-DD-YYYY hh:mm:ss'
            )}"`
          );
        }
      } else {
        setters.push(
          `${key} = ${isString(obj[key]) ? `"${obj[key]}"` : `${obj[key]}`}`
        );
      }
    }
  });
  querryToReturn += setters.join(`,`);
  querryToReturn += ` WHERE ${idKey} = "${id}"`;

  return querryToReturn;
};

export const replicateSpill = async (
  obj,
  isObjJobNo = false,
  create = false,
  oldJobNo
) => {
  if (ENABLE_CONTIGENCY !== 'yes') {
    return;
  }
  let spillToReplicate;
  if (isObjJobNo) {
    spillToReplicate = await getCompleteSpillByJobNo(obj);
  } else {
    spillToReplicate = obj;
  }
  const { spill, connection, spillContractors } = spillToReplicate;
  const {
    spill_notes,
    reserves,
    recipients,
    client_organization,
    user,
    spill_admins,
    ...spill_info
  } = spill;

  const wholeUser = await getUserByEmail(user.dataValues.email);

  let customSpillObject = {
    pm: wholeUser.dataValues.id,
    org: client_organization.dataValues.id,
    address: spill.address,
    city: spill.city,
    st: spill.state,
    rate: spill.rate,
    zip: spill.zip_code,
    ctry: spill.country === 'Canada' ? 'CAN' : 'USA',
    who_on_scene: spill.contact,
    send_attachments: spill.send_attachment,
    site_conditions: spill.conditions,
    type: spill.type,
    responsible_party: spill.responsible,
    need_5800: spill.need_5800,
    is_waste: spill.is_waste,
    is_hazmat: spill.is_hazmat,
    has_msds: spill.has_msds,
    response_sent: spill.response_sent,
    subrogation: spill.subrogation,
    claim_no: spill.claim_no,
    opened: spill.opened_on,
    closed: spill.closed_on,
    status: spill.status_id,
    assignment_no: spill.assignment_no,
    freight_bill: spill.freight_bill,
    money_saved_mgt: spill.money_saved_mgt,
    money_saved_waste: spill.money_saved_waste,
    rate: spill.rate,
    material: spill.material_id,
    // id: spill.legacy_id || spill.id,
    num: spill.job_no,
  };

  const dbConnection = await mysql.createConnection({
    host: DATABASE_HOST,
    user: DATABASE_USERNAME,
    password: DATABASE_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  let querry = '';
  if (!create) {
    querry = buildUpdateQuery(customSpillObject, 'incident', 'num', oldJobNo);
  } else {
    querry = buildInsertQuery(customSpillObject, 'incident');
  }

  await dbConnection.execute(querry);

  dbConnection.end(function(err) {
    if (err) {
      return console.log('error:' + err.message);
    }
    console.log('Closed the database connection.');
  });
};
