"use strict";
var winston = require("winston");
var format = require("winston").format;
const os = require("os");

var levels = {
  debug: 0,
  error: 1,
  info: 2,
  http: 3,
};
var options = {
  file: {
    level: "http",
    filename: `logs/instance_${os.hostname()}_app.log`,
    handleExceptions: true,
    json: true,
    maxsize: 10485760,
    // 10MB
    // maxFiles: 5,
    colorize: true,
  },
  console: {
    level: "http",
    handleExceptions: true,
    json: false,
    colorize: true,
  },
};
const Logger = winston.createLogger({
  // levels: winston.config.npm.levels,
  format: format.combine(format.timestamp(), format.json()),
  levels: levels,
  transports: [
    new winston.transports.File(options.file),
    new winston.transports.Console(options.console),
    new winston.transports.File({
      filename: `logs/instance_${os.hostname()}error.log`,
      level: "error",
    }),
  ],
  exitOnError: false,
});
export default Logger;
