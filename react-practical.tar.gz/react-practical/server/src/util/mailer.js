import nodemailer from "nodemailer";
import fs from "fs";
import path from "path";
import moment from "moment";

const FOOTER = fs
  .readFileSync(path.resolve(__dirname, "email-templates", "footer.html"))
  .toString();
const WELCOME = fs
  .readFileSync(path.resolve(__dirname, "email-templates", "welcome.html"))
  .toString()
  .replace("*|FOOTER|*", FOOTER);

const EMAIL = {
  notification: {
    subject: (type) => `Quant-BOE - Your ${type} reports are here!`,
    html: (user) =>
      WELCOME.replace("*|DATE|*", moment().format("DD MMMM YYYY"))
        .replace("*|REASON|*", "Welcome to Quant BOE")
        .replace("*|FULL_NAME|*", user.full_name)
        .replace("*|DAILY_WEEKLY|*", user.reportViewPref)
        .replace("*|EMAIL|*", user.email)
        .replace("*|DAILY_WEEKLY|*", user.reportViewPref)
        .replace("*|DOCS|*", user.docs),
  },
};

const host = "smtp.gmail.com";
const port = 587;
const secure = false;
const user = "niftyhubinfo@gmail.com";
const pass = "nifty@gmail";
const from = '"Quant BOE" <niftyhubinfo@gmail.com>';

const transporter = nodemailer.createTransport({
  service: "Gmail",
  host,
  port,
  secure, // true for 465, false for other ports
  auth: {
    user, // generated ethereal user
    pass, // generated ethereal password
  },
  tls: {
    rejectUnauthorized: false,
  },
});

var smtpTransport = nodemailer.createTransport({
  host,
  port,
  secure,
  secureConnection: false,
  auth: {
    user,
    pass,
  },
});

export default function(type, userObj, obj) {
  // setup email data with unicode symbols
  const mailOptions = {
    from,
    to: userObj.email, // list of receivers
    subject: EMAIL[type].subject(userObj.reportViewPref), // Subject line
    html: EMAIL[type].html(userObj, obj), // html body
  };

  // send mail with defined transport object
  try {
    smtpTransport.sendMail(mailOptions);
    console.log("Sending email ::", type, " :: ", userObj.email);
  } catch (err) {
    console.error("Error sending email", err);
  }
}
