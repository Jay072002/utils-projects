import jwt from "jsonwebtoken";
import config from "../config/index.json";

const { JWT_SECRET } = process.env;

export const generateToken = (payload, options) =>
  jwt.sign(payload, JWT_SECRET, options);

export const decodeToken = (token, options) =>
  jwt.verify(token, JWT_SECRET, options);
