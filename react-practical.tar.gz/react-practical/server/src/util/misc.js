import { genericSender } from "../services/email/emailProvider";
import { getFirstDay, getLastDay } from "./convertDateRange";
import { generateHtml } from "./helper";
import { ROLES, ACTIONS, CONSTANTS } from "./constants";
import { convertToTableData } from "./htmlHelpers";
import models from "../models";

const padZero = (n, width, z = "0") => {
  z = z || "0";
  n = n + "";
  return n?.length >= width ? n : new Array(width - n?.length + 1).join(z) + n;
};

export const createDescription = (contractor, date, userName, address) => {
  let contractorLabel = contractor.dataValues.name;

  if (address) {
    contractorLabel += ` - ${contractor.dataValues.tier_level} - (${address
      .dataValues.city && address.dataValues.city + ","} ${
      address.dataValues.state
    })`;
  } else {
    contractorLabel += ` - ${contractor.dataValues.tier_level} - (${contractor
      .dataValues.city && contractor.dataValues.city + ","} ${
      contractor.dataValues.state
    })`;
  }
  return `${contractorLabel} was removed from assigned contractors by ${userName} at ${date}`;
};

export const searchUserByEmail = async (email) => {
  const result = await models.User.findOne({
    where: { email },
    include: [{ model: models.Roles }],
  });
  return result;
};

export const getAdminsOfUser = async (email) => {
  const user = await searchUserByEmail(email);
  if (user.role.role === ROLES.CONTRACTOR_USER) {
    const adminUsers = await models.User.findAll({
      include: [
        {
          model: models.Roles,
          required: true,
          where: { role: ROLES.CONTRACTOR_ADMIN },
        },
      ],
      where: {
        contractor_id: user.contractor_id,
      },
    });
    return adminUsers;
  } else {
    return null;
  }
};

export const sendAttachmentRejectionEmail = async (
  attachments,
  jobNo,
  user
) => {
  if (attachments?.length) {
    const spillData = await models.Spills.findOne({
      where: { job_no: jobNo },
      include: [{ model: models.ClientOrganizations }],
    });

    let userFiltered = {};
    let contractorFiltered = {};
    const send_email = spillData?.dataValues?.send_email;

    for (const attachment of attachments) {
      const relevantUser = attachment.attachment.user;

      //dividing attachments according to users which uploaded the attachment.
      if (userFiltered[relevantUser.email]) {
        userFiltered[relevantUser.email].attachments.push(
          attachment.attachment
        );
      } else {
        const contractorAdmins = await getAdminsOfUser(relevantUser.email);
        userFiltered[relevantUser.email] = {
          user: relevantUser,
          attachments: [attachment.attachment],
          contractorAdmins,
        };
      }

      //dividing attachments according to contractors which uploaded the attachment.
      if (contractorFiltered[attachment.id]) {
        contractorFiltered[attachment.id].push(attachment.attachment);
      } else {
        contractorFiltered[attachment.id] = [attachment.attachment];
      }
    }

    for (const [key, value] of Object.entries(userFiltered)) {
      // let emailText = `The following documents were rejected. Please submit the documents again. <br/> <br/>`;

      convertToTableData(
        [
          { heading: "Name", key: "name" },
          { heading: "Reason", key: "admin_note" },
        ],
        value.attachments
      );
      const sendEmailTo = [key];

      value.contractorAdmins?.length &&
        sendEmailTo.push(...value.contractorAdmins.map((x) => x.email));

      const dataForEmail = {
        sendEmailTo,
        sendEmailFrom: user.email,
        ...generateHtml(
          {
            user,
            spill: spillData.dataValues,
            rejectedDocs: value.attachments,
            recievingUser: value.user,
          },
          ACTIONS.REJECT_DOCUMENTS
        ),
      };
      // Check if the test spill has send_email true only then send emails
      if (send_email) {
        genericSender(dataForEmail);
      }
    }
  }
};

export const sendSubmissionEmail = async (
  spill,
  userName,
  userEmail,
  prevSpill
) => {
  for (const admin of spill.spill_admins.map((x) => x.dataValues)) {
    if (prevSpill?.spill_admins && Array.isArray(prevSpill?.spill_admins)) {
      const prevAdmin = prevSpill.spill_admins.find((x) => x.id === admin.id);
      if (admin && admin.is_complete && !prevAdmin.is_complete) {
        const contractor = await models.Contractors.findOne({
          where: { id: admin.contractor_id },
        });
        const dataForEmail = {
          sendEmailTo: [spill.user.email, CONSTANTS.PACKET_REVIEW_EMAIL],
          sendEmailFrom: userEmail,
          ...generateHtml(
            {
              userName: userName,
              spill: spill,
              admin,
              contractor: contractor.dataValues,
            },
            ACTIONS.DOCUMENTS_SUBMITTED
          ),
        };
        genericSender(dataForEmail);
      }
    }
  }
};

export const createJobNumber = async (
  orgCode,
  isTemp,
  current_time,
  is_test_spill
) => {
  console.log("current_time :", current_time);
  try {
    if (isTemp) {
      const result = await models.PmActions.count();
      const jobCode = `TEMP-${result}`;
      return jobCode;
    } else {
      const year = current_time.slice(3, 5);
      console.log("year :", year);
      const month = current_time.slice(6, 8);
      console.log("month :", month);

      var firstDay = getFirstDay(current_time);
      console.log("firstDay :", firstDay);
      var lastDay = getLastDay(current_time, true);
      lastDay = lastDay.replace("-13-", "-12-");
      console.log("lastDay :", lastDay);

      let where = {};

      if (is_test_spill) {
        where = {
          opened_on: {
            $between: [firstDay, lastDay],
          },
          job_no: {
            $like: "%TEST%",
          },
        };
      } else {
        where = {
          opened_on: {
            $between: [firstDay, lastDay],
          },
          job_no: {
            $and: [
              {
                $notLike: "TEMP%",
              },
              {
                $notLike: "%TEST%",
              },
            ],
          },
        };
      }

      const result = await models.Spills.count({
        where,
      });
      const strMonthCount = padZero(parseInt(result + 1), 4);
      const jobCode = `${year}-${orgCode}-${month}${
        is_test_spill ? `TEST${strMonthCount}` : strMonthCount
      }`;
      return jobCode;
    }
  } catch (err) {
    console.log(err);
    return "";
  }
};

export const getStatusCounts = (spillRows) => {
  let statusTotals = {};
  for (const row of spillRows) {
    const value = row.dataValues.status?.toLowerCase();
    if (statusTotals[value]) {
      statusTotals[value] += 1;
    } else {
      statusTotals[value] = 1;
    }
  }
  return statusTotals;
};
