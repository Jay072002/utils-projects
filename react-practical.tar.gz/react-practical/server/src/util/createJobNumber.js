const moment = require("moment");
const models = require("../models");
const { Op } = require("sequelize");
const { padZero } = require("./padZero");

const TEST_PREFIX = "TEST";
const TEMP_PREFIX = "TEMP";

const createJobNumberString = ({
  year,
  month,
  orgId,
  count,
  testingPrefix = "",
  isTestSpill,
  isProbPM,
}) => {
  if (isTestSpill) {
    return `${year}-${orgId}-${month}${TEST_PREFIX}${count}`;
  }
  if (isProbPM) {
    return `${TEMP_PREFIX}-${year}-${orgId}-${month}${count}`;
  }
  return `${year}-${orgId}-${month}${count}`;
};

const getCurrentYearMonth = () => {
  const today = moment(new Date()).tz("America/Chicago");
  const currentMonth = today.format("MM");
  const currentYear = today.format("YY");
  const currentYearFull = today.format("YYYY");

  console.log("CST Time : ", today);
  console.log({ currentMonth, currentYear, currentYearFull });

  return { currentMonth, currentYear, currentYearFull };
};

const breakDownJobNo = (jobNumber) => {
  // job number breakdown
  const jobNumberArray = jobNumber
    .replace(TEST_PREFIX, "")
    .replace(`${TEMP_PREFIX}-`, "")
    .split("-");

  const jobNoYear = jobNumberArray[0];
  const jobNoOrgId = jobNumberArray[1];
  const monthCounter = jobNumberArray[2];
  const jobNoMonth = monthCounter.slice(0, 2);
  const jobNoCount = parseInt(monthCounter.slice(2, monthCounter?.length));

  return {
    jobNoYear,
    jobNoOrgId,
    monthCounter,
    jobNoMonth,
    jobNoCount,
  };
};

const getTestIdsData = (isTestSpill, isProbPM) => {
  const { currentMonth, currentYearFull } = getCurrentYearMonth();
  let testingPrefix;

  if (isTestSpill) {
    testingPrefix = TEST_PREFIX;
  }

  if (isProbPM) {
    testingPrefix = TEMP_PREFIX;
  }

  const dateFilter = [
    models.sequelize.fn("month(created_at) = ", currentMonth),
    models.sequelize.fn("year(created_at) = ", currentYearFull),
  ];
  const whereClause =
    isTestSpill || isProbPM
      ? {
          where: {
            job_no: {
              [Op.like]: `%${testingPrefix}%`,
            },
            // [Op.and]: dateFilter,
          },
        }
      : {
          where: {
            job_no: {
              [Op.and]: [
                {
                  [Op.notLike]: `%${TEST_PREFIX}%`,
                },
                {
                  [Op.notLike]: `${TEMP_PREFIX}%`,
                },
              ],
            },
            // [Op.and]: dateFilter,
          },
        };

  return {
    whereClause,
    testingPrefix,
  };
};

// create Job Number
const createJobNumber = async (orgCode, isTestSpill, isProbPM) => {
  const { currentMonth, currentYear } = getCurrentYearMonth();
  const testData = getTestIdsData(isTestSpill, isProbPM);

  // find latest job
  const latestSpillJobNo = await models.Spills.findOne({
    ...testData.whereClause,
    attributes: ["job_no"],
    order: [["created_at", "DESC"]],
    limit: 1,
    logging: true,
  });

  if (!latestSpillJobNo || !latestSpillJobNo.job_no) {
    // create first spill, if nothing exists before
    const jobNumber = createJobNumberString({
      year: currentYear,
      month: currentMonth,
      orgId: orgCode,
      count: padZero(1, 4),
      testingPrefix: testData?.testingPrefix,
      isTestSpill,
      isProbPM,
    });
    return jobNumber;
  }

  const { jobNoYear, jobNoMonth, jobNoCount } = breakDownJobNo(
    latestSpillJobNo?.job_no
  );

  const isJobNoFromCurrentMonth =
    jobNoYear === currentYear && jobNoMonth === currentMonth;

  const incrementedJobCount = jobNoCount + 1;
  const count = isJobNoFromCurrentMonth ? incrementedJobCount : 1;

  const jobNumber = createJobNumberString({
    year: currentYear,
    month: currentMonth,
    orgId: orgCode,
    count: padZero(count, 4),
    testingPrefix: testData?.testingPrefix,
    isTestSpill,
    isProbPM,
  });
  return jobNumber;
};

export default createJobNumber;
