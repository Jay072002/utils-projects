require("dotenv").config();
// Initialize Secrets Manager:

// Required imports
require("@babel/register");
require("core-js/stable");
require("regenerator-runtime/runtime");

let app = null;

(async function initalizeSequenceLoading() {
  ({ app } = require("./app"));
})();

module.exports = app;
