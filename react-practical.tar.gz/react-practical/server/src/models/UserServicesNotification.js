module.exports = (sequelize, DataTypes) => {
    const UserServicesNotifications = sequelize.define(
      "user_services_notifications",
      {
        user_id: DataTypes.INTEGER,
        service_id: DataTypes.INTEGER,
        notification: DataTypes.BOOLEAN,
      },
      {
        underscored: true,
        paranoid: true,
        defaultScope: {
          attributes: [
            "id",
            "user_id",
            "service_id",
            "notification",
            "updated_at",
            "created_at",
            "deleted_at",
          ],
        },
      }
    );
  
    UserServicesNotifications.associate = function(models) {
      UserServicesNotifications.belongsTo(models.User);
      UserServicesNotifications.belongsTo(models.Services);
    };
  
    return UserServicesNotifications;
  };
  