module.exports = (sequelize, DataTypes) => {
  const ContractorAttachmentTypes = sequelize.define(
    'contractor_attachment_types',
    {
      label: DataTypes.STRING,
      value: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'label',
          'value',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );

  ContractorAttachmentTypes.associate = function(models) {
    ContractorAttachmentTypes.belongsTo(models.ContractorAttachmentsExpiry);
  };

  return ContractorAttachmentTypes;
};
