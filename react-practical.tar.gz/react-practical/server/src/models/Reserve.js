module.exports = (sequelize, DataTypes) => {
  const Reserves = sequelize.define(
    "reserves",
    {
      spill_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      amount: DataTypes.DECIMAL,
      legacy_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "spill_id",
          "user_id",
          "amount",
          "legacy_id",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  Reserves.associate = function(models) {
    Reserves.belongsTo(models.Spills);

    Reserves.belongsTo(models.User, {
      targetKey: "id",
      foreignKey: "user_id",
    });
  };

  return Reserves;
};
