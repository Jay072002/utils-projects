/** @format */

module.exports = (sequelize, DataTypes) => {
  const SpillAdmin = sequelize.define(
    "spill_admins",
    {
      spill_id: DataTypes.INTEGER,
      info: DataTypes.TEXT,
      pix: DataTypes.DATE,
      spill_summary: DataTypes.DATE,
      contractor_inv: DataTypes.DATE,
      waste_doc: DataTypes.DATE,
      contractor_invoice: DataTypes.STRING,
      inv_no: DataTypes.STRING,
      final_contractor_invoice: DataTypes.STRING,
      savings: DataTypes.STRING,
      pes_paid: DataTypes.DATE,
      contractor_paid: DataTypes.DATE,
      trans_to_ct: DataTypes.DATE,
      pay_by: DataTypes.DATE,
      response_time: DataTypes.STRING,
      contractor_id: DataTypes.INTEGER,
      contractor_address_id: DataTypes.INTEGER,
      is_removed: DataTypes.BOOLEAN,
      is_main: DataTypes.BOOLEAN,
      is_complete: DataTypes.BOOLEAN,
      is_not_required: DataTypes.BOOLEAN,
      status: DataTypes.STRING,
      reject_reason: DataTypes.STRING,
      pes_inv_no: DataTypes.INTEGER,
      pes_inv_amount: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "spill_id",
          "info",
          "pix",
          "spill_summary",
          "updated_at",
          "created_at",
          "deleted_at",
          "contractor_inv",
          "waste_doc",
          "contractor_invoice",
          "inv_no",
          "final_contractor_invoice",
          "savings",
          "pes_paid",
          "contractor_paid",
          "trans_to_ct",
          "pay_by",
          "response_time",
          "contractor_id",
          "contractor_address_id",
          "is_removed",
          "is_main",
          "is_complete",
          "is_not_required",
          "status",
          "reject_reason",
          "pes_inv_no",
          "pes_inv_amount",
        ],
      },
    }
  );
  SpillAdmin.associate = function(models) {
    SpillAdmin.belongsTo(models.Contractors, {
      targetKey: "id",
      foreignKey: "contractor_id",
    });
    SpillAdmin.belongsTo(models.Addresses, {
      targetKey: "id",
      foreignKey: "contractor_address_id",
    });
    SpillAdmin.hasMany(models.SpillAttachments, {
      targetKey: "spill_admin_id",
      foreignKey: "spill_admin_id",
    });
    SpillAdmin.belongsTo(models.ContractorRequestedDocumentations, {
      targetKey: "spill_admin_id",
      foreignKey: "id",
    });
  };
  return SpillAdmin;
};
