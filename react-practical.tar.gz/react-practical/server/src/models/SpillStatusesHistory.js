module.exports = (sequelize, DataTypes) => {
  const SpillStatusesHistory = sequelize.define(
    'spill_statuses_history',
    {
      spill_id: DataTypes.INTEGER,
      job_no: DataTypes.STRING,
      status: DataTypes.STRING,
      started_at: DataTypes.DATE,
      ended_at: DataTypes.DATE,
      user_id: DataTypes.INTEGER,
      user_name: DataTypes.STRING,
      user_role: DataTypes.STRING,
      is_status_automated: DataTypes.BOOLEAN,
    },
    {
      underscored: true,
      paranoid: true,
      tableName: 'spill_statuses_history',
      defaultScope: {
        attributes: [
          'spill_id',
          'job_no',
          'status',
          'started_at',
          'ended_at',
          'user_id',
          'user_name',
          'user_role',
          'created_at',
          'updated_at',
          'deleted_at',
          'is_status_automated',
        ],
      },
    }
  );

  SpillStatusesHistory.associate = function(models) {
    SpillStatusesHistory.belongsTo(models.Spills);
  };

  return SpillStatusesHistory;
};
