module.exports = (sequelize, DataTypes) => {
  const SalvageContainer = sequelize.define(
    "salvage_containers",
    {
      note_id: DataTypes.INTEGER,
      sc_no: DataTypes.STRING,
      type: DataTypes.STRING,
      content: DataTypes.STRING,
      is_hazmat: DataTypes.STRING,
      disposal_handled_by: DataTypes.STRING,
      container_disposition: DataTypes.STRING,
      un_no: DataTypes.STRING,
      drum_weight: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "note_id",
          "sc_no",
          "type",
          "content",
          "un_no",
          "drum_weight",
          "is_hazmat",
          "disposal_handled_by",
          "container_disposition",
          "created_at",
          "updated_at",
          "deleted_at",
        ],
      },
    }
  );
  return SalvageContainer;
};
