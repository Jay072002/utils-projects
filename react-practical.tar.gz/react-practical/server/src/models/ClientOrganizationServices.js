module.exports = (sequelize, DataTypes) => {
  const ClientOrganizationServices = sequelize.define(
    "client_organization_services",
    {
      org_id: DataTypes.INTEGER,
      service_id: DataTypes.INTEGER,
      type: DataTypes.STRING,
      rate: DataTypes.DECIMAL,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "org_id",
          "service_id",
          "type",
          "rate",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  ClientOrganizationServices.associate = function(models) {
    ClientOrganizationServices.belongsTo(models.ClientOrganizations);
    ClientOrganizationServices.belongsTo(models.Services);
  };

  return ClientOrganizationServices;
};
