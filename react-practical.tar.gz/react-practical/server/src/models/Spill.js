module.exports = (sequelize, DataTypes) => {
  const Spill = sequelize.define(
    "spills",
    {
      user_id: DataTypes.INTEGER,
      org_id: DataTypes.INTEGER,
      job_no: DataTypes.STRING,
      opened_on: DataTypes.DATE,
      send_attachment: DataTypes.BOOLEAN,
      status: DataTypes.STRING,
      conditions: DataTypes.STRING,
      address: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      zip_code: DataTypes.STRING,
      country: DataTypes.STRING,
      contact: DataTypes.STRING,
      type: DataTypes.STRING,
      responsible: DataTypes.STRING,
      need_5800: DataTypes.BOOLEAN,
      is_waste: DataTypes.BOOLEAN,
      has_msds: DataTypes.BOOLEAN,
      is_hazmat: DataTypes.BOOLEAN,
      response_sent: DataTypes.BOOLEAN,
      subrogation: DataTypes.BOOLEAN,
      claim_no: DataTypes.STRING,
      facility_id: DataTypes.UUID,
      is_demo: DataTypes.BOOLEAN,
      closed_on: DataTypes.DATE,
      material: DataTypes.STRING,
      status_id: DataTypes.INTEGER,
      assignment_no: DataTypes.STRING,
      freight_bill: DataTypes.STRING,
      money_saved_mgt: DataTypes.DECIMAL,
      money_saved_waste: DataTypes.DECIMAL,
      rate: DataTypes.DECIMAL,
      material_id: DataTypes.INTEGER,
      is_approved: DataTypes.BOOLEAN,
      send_email: DataTypes.BOOLEAN,
      is_legacy: DataTypes.BOOLEAN,
      latitude: DataTypes.DECIMAL,
      longitude: DataTypes.DECIMAL,
      tractor: DataTypes.STRING,
      trailer: DataTypes.STRING,
      onsite_poc_name: DataTypes.STRING,
      onsite_poc_phone: DataTypes.STRING,
      driver_name: DataTypes.STRING,
      driver_phone: DataTypes.STRING,
      pro: DataTypes.STRING,
      map_needed: DataTypes.BOOLEAN,
      amount_released: DataTypes.DOUBLE,
      quantity_type_released: DataTypes.STRING,
      damaged_container_type: DataTypes.STRING,
      un_no: DataTypes.STRING,
      damage_type: DataTypes.STRING,
      location_type: DataTypes.STRING,
      drain_impacted: DataTypes.BOOLEAN,
      waterway_impacted: DataTypes.BOOLEAN,
      legacy_id: DataTypes.INTEGER,
      last_status_changed: DataTypes.DATE,
      total_notes_sum: DataTypes.INTEGER,
      is_emergency: DataTypes.BOOLEAN,
      watched: DataTypes.BOOLEAN,
      assigned_packet_reviewer_id: DataTypes.INTEGER,
      job_no_year: DataTypes.STRING,
      job_no_month_count: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "user_id",
          "org_id",
          "job_no",
          "opened_on",
          "send_attachment",
          "status",
          "conditions",
          "address",
          "city",
          "state",
          "zip_code",
          "country",
          "contact",
          "type",
          "responsible",
          "need_5800",
          "is_waste",
          "has_msds",
          "is_hazmat",
          "response_sent",
          "subrogation",
          "claim_no",
          "facility_id",
          "is_demo",
          "closed_on",
          "material",
          "status_id",
          "assignment_no",
          "freight_bill",
          "money_saved_mgt",
          "money_saved_waste",
          "rate",
          "material_id",
          "is_approved",
          "send_email",
          "is_legacy",
          "un_no",
          "latitude",
          "longitude",
          "tractor",
          "trailer",
          "onsite_poc_name",
          "onsite_poc_phone",
          "driver_name",
          "driver_phone",
          "pro",
          "map_needed",
          "amount_released",
          "quantity_type_released",
          "damaged_container_type",
          "damage_type",
          "location_type",
          "drain_impacted",
          "waterway_impacted",
          "legacy_id",
          "last_status_changed",
          "total_notes_sum",
          "is_emergency",
          "watched",
          "assigned_packet_reviewer_id",
          "job_no_year",
          "job_no_month_count",
        ],
      },
    }
  );

  Spill.associate = function(models) {
    Spill.belongsTo(models.User, {
      targetKey: "id",
      foreignKey: "user_id",
    });
    Spill.belongsTo(models.ClientOrganizations, {
      targetKey: "id",
      foreignKey: "org_id",
    });
    Spill.belongsTo(models.SpillMaterial, {
      targetKey: "id",
      foreignKey: "material_id",
    });
    Spill.hasMany(models.Recipients);
    Spill.belongsTo(models.SpillStatuses, {
      targetKey: "id",
      foreignKey: "status_id",
    });
    Spill.hasMany(models.SpillManagers, {
      targetKey: "spill_id",
      foreignKey: "spill_id",
    });
    Spill.hasMany(models.Connections);
    Spill.hasMany(models.SpillContractors, {
      targetKey: "contractor_id",
      foreignKey: "contractor_id",
    });
    Spill.hasMany(models.SpillNotes, {
      targetKey: "spill_id",
      foreignKey: "spill_id",
    });
    Spill.hasMany(models.Reserves, {
      targetKey: "spill_id",
      foreignKey: "spill_id",
    });
    Spill.hasMany(models.SpillAdmins, {
      targetKey: "spill_id",
      foreignKey: "spill_id",
    });
    Spill.hasMany(models.SpillStatusesHistory, {
      targetKey: "id",
      foreignKey: "spill_id",
    });
    Spill.hasMany(models.ContractorHistory);
    Spill.belongsTo(models.PacketReviewerAssignments, {
      targetKey: "assigned_spill_id",
      foreignKey: "id",
    });
    Spill.belongsTo(models.ContractorRequestedDocumentations, {
      targetKey: "spill_id",
      foreignKey: "id",
    });
  };

  return Spill;
};
