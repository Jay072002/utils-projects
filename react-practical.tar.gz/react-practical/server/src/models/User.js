/** @format */

import crypto from 'crypto';
import models from '../../models';

module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define(
    'user',
    {
      full_name: DataTypes.STRING,
      phone: DataTypes.STRING,
      email: {
        type: DataTypes.STRING,
        validate: {
          isEmail: true,
        },
      },
      secondary_email: {
        type: DataTypes.STRING,
        validate: {
          isEmail: true,
        },
      },
      password: {
        type: DataTypes.STRING,
        get() {
          return () => this.getDataValue('password');
        },
      },
      created_by: DataTypes.INTEGER,
      confirmed: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      role_id: DataTypes.INTEGER,
      email_notification: DataTypes.BOOLEAN,
      active: DataTypes.BOOLEAN,
      org_id: DataTypes.INTEGER,
      originalPassword: DataTypes.VIRTUAL,
      last_login: DataTypes.DATE,
      last_logout: DataTypes.DATE,
      eula_accepted: DataTypes.BOOLEAN,
      eula_accepted_year: DataTypes.INTEGER,
      is_packet_reviewer: DataTypes.BOOLEAN,
      is_demo: DataTypes.BOOLEAN,
      contractor_id: DataTypes.INTEGER,
      contractor_address_id: DataTypes.INTEGER,
      is_default: DataTypes.BOOLEAN,
      // haz_waste_hauler: DataTypes.BOOLEAN,
      // license_number: DataTypes.STRING,
      // license_number_expiry: DataTypes.DATE,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'full_name',
          'phone',
          'email',
          'secondary_email',
          'password',
          'created_by',
          'confirmed',
          'role_id',
          'email_notification',
          'active',
          'org_id',
          'eula_accepted',
          'eula_accepted_year',
          'is_packet_reviewer',
          'updated_at',
          'created_at',
          'deleted_at',
          'last_login',
          'last_logout',
          'is_demo',
          'contractor_id',
          'contractor_address_id',
          'is_default',
          // 'haz_waste_hauler',
          // 'license_number',
          // 'license_number_expiry',
        ],
      },
      hooks: {
        beforeCreate(user) {
          user.password = user.password
            ? crypto
                .createHash('sha256')
                .update(user.password())
                .digest('base64')
            : null;
        },
      },
    }
  );
  User.associate = function(models) {
    // associations can be defined here
  };
  User.findByEmailPassword = function(email, password) {
    return this.find({
      where: {
        email,
        password: crypto
          .createHash('sha256')
          .update(password)
          .digest('base64'),
      },
      paranoid: false,
    });
  };
  User.prototype.resetPassword = function() {
    let password = '';
    const charset =
      'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

    for (let i = 0; i < 8; i++) {
      password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    this.password = crypto
      .createHash('sha256')
      .update(password)
      .digest('base64');
    this.setDataValue('originalPassword', password);
    return this.save();
  };

  User.verifyPassword = function(id, pass) {
    return this.find({
      where: {
        id,
        password: crypto
          .createHash('sha256')
          .update(pass)
          .digest('base64'),
      },
    });
  };

  User.updatePassword = function(id, pass) {
    const password = crypto
      .createHash('sha256')
      .update(pass)
      .digest('base64');
    return this.update(
      {
        password,
      },
      {
        where: {
          id,
        },
      }
    );
  };

  User.associate = function(models) {
    User.belongsTo(models.ClientOrganizations, {
      targetKey: 'id',
      foreignKey: 'org_id',
    });

    User.hasMany(models.UserOrganizations, {
      targetKey: 'user_id',
      foreignKey: 'user_id',
    });

    User.hasMany(models.SpillManagers, {
      targetKey: 'user_id',
      foreignKey: 'user_id',
    });

    User.hasMany(models.UserServicesNotifications, {
      targetKey: 'user_id',
      foreignKey: 'user_id',
    });

    User.belongsTo(models.Roles, {
      targetKey: 'id',
      foreignKey: 'role_id',
    });
    User.belongsTo(models.Contractors, {
      targetKey: 'id',
      foreignKey: 'contractor_id',
    });
    User.belongsTo(models.Addresses, {
      targetKey: 'id',
      foreignKey: 'contractor_address_id',
    });
  };

  return User;
};
