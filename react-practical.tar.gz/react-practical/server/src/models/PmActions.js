module.exports = (sequelize, DataTypes) => {
  const PmAction = sequelize.define(
    "pm_actions",
    {
      type: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      manager_id: DataTypes.INTEGER,
      data: DataTypes.JSON,
      status: DataTypes.STRING,
      notes: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "type",
          "user_id",
          "manager_id",
          "data",
          "status",
          "notes",
          "created_at",
          "updated_at",
          "deleted_at",
        ],
      },
    }
  );

  PmAction.associate = function(models) {
    PmAction.belongsTo(models.User, {
      as: "manager",
      targetKey: "id",
      foreignKey: "manager_id",
    });
    PmAction.belongsTo(models.User, {
      as: "user",
      targetKey: "id",
      foreignKey: "user_id",
    });
  };

  return PmAction;
};
