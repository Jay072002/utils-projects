import { v4 as uuidv4 } from 'uuid';

module.exports = (sequelize, DataTypes) => {
  const RequestFacilities = sequelize.define(
    'request_facilities',
    {
      org_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      file_name: DataTypes.STRING,
      key: DataTypes.STRING,
      url_link: DataTypes.STRING,
      status: {
        type: DataTypes.ENUM,
        values: ['not_processed', 'in_progress', 'completed', 'failed']
      },
      process_start: DataTypes.DATE,
      process_end: DataTypes.DATE,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'org_id',
          'user_id',
          'file_name',
          'key',
          'url_link',
          'status',
          'process_start',
          'process_end',
          'created_at',
          'updated_at',
          'deleted_at'
        ],
      },
    }
  );

  RequestFacilities.beforeCreate(v => v.id = uuidv4());

  RequestFacilities.associate = function(models) {
    RequestFacilities.belongsTo(models.User, {
      targetKey: "id",
      foreignKey: "user_id",
    });
    RequestFacilities.belongsTo(models.ClientOrganizations, {
      targetKey: "id",
      foreignKey: "org_id",
    });
  };

  return RequestFacilities;
};
