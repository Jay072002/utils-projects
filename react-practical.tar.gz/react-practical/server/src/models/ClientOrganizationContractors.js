import { v4 as uuidv4 } from 'uuid';

export default (sequelize, DataTypes) => {
  const ClientOrganizationContractors = sequelize.define(
    "client_organization_contractors",
    {
      org_id: DataTypes.INTEGER,
      contractor_id: DataTypes.INTEGER,
      address_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "org_id",
          "contractor_id",
          "address_id",
          "created_at",
          "updated_at",
          "deleted_at",
        ],
      },
    }
  );

  ClientOrganizationContractors.beforeCreate(v => v.id = uuidv4());
  return ClientOrganizationContractors;
};
