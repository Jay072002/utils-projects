module.exports = (sequelize, DataTypes) => {
  const SpillMaterial = sequelize.define(
    "spill_material",
    {
      name: DataTypes.STRING,
      org_id: DataTypes.INTEGER,
      hits: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "name",
          "org_id",
          "hits",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  SpillMaterial.associate = function(models) {
    SpillMaterial.belongsTo(models.ClientOrganizations, {
      targetKey: "id",
      foreignKey: "org_id",
    });
  };

  return SpillMaterial;
};
