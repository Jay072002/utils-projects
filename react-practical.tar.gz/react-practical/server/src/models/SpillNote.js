module.exports = (sequelize, DataTypes) => {
  const SpillNote = sequelize.define(
    "spill_notes",
    {
      service_id: DataTypes.INTEGER,
      service_type: DataTypes.STRING,
      rate: DataTypes.DECIMAL,
      hour: DataTypes.DECIMAL,
      amount: DataTypes.DECIMAL,
      description: DataTypes.TEXT,
      report_no: DataTypes.STRING,
      ip_address_identifier: DataTypes.STRING,
      owner: DataTypes.STRING,
      no_of_salvage_container: DataTypes.INTEGER,
      no_of_samples: DataTypes.INTEGER,
      date: DataTypes.DATE,
      estimated_cost: DataTypes.INTEGER,
      established_lane_closure: DataTypes.BOOLEAN,
      excavation_begun: DataTypes.BOOLEAN,
      excavation_completed: DataTypes.BOOLEAN,
      excavation_time: DataTypes.STRING,
      time: DataTypes.TIME,
      task_associated_relevance: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      spill_id: DataTypes.INTEGER,
      legacy_id: DataTypes.INTEGER,
      type: DataTypes.STRING,
      projected_eta: DataTypes.INTEGER,
      actual_eta: DataTypes.INTEGER,
      incident_no: DataTypes.STRING,
      state_incident_no: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "service_id",
          "service_type",
          "rate",
          "hour",
          "amount",
          "description",
          "report_no",
          "ip_address_identifier",
          "owner",
          "no_of_salvage_container",
          "no_of_samples",
          "date",
          "estimated_cost",
          "established_lane_closure",
          "excavation_begun",
          "excavation_completed",
          "time",
          "excavation_time",
          "task_associated_relevance",
          "user_id",
          "spill_id",
          "legacy_id",
          "type",
          "projected_eta",
          "actual_eta",
          "incident_no",
          "state_incident_no",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
        hooks: {
          beforeCreate: (record, options) => {
            record.dataValues.createdAt = new Date()
              .toISOString()
              .replace(/T/, " ")
              .replace(/\..+/g, "");
            record.dataValues.updatedAt = new Date()
              .toISOString()
              .replace(/T/, " ")
              .replace(/\..+/g, "");
          },
          beforeUpdate: (record, options) => {
            record.dataValues.updatedAt = new Date()
              .toISOString()
              .replace(/T/, " ")
              .replace(/\..+/g, "");
          },
        },
      },
    }
  );

  SpillNote.associate = function(models) {
    SpillNote.hasMany(models.SalvageContainers, {
      targetKey: "note_id",
      foreignKey: "note_id",
    });
    SpillNote.belongsTo(models.Spills);
    SpillNote.belongsTo(models.User);
    // Added model
    SpillNote.hasMany(models.NoteAttachments);
  };

  return SpillNote;
};
