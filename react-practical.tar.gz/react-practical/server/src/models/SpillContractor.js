module.exports = (sequelize, DataTypes) => {
  const SpillContractors = sequelize.define(
    'spill_contractors',
    {
      connection_id: DataTypes.INTEGER,
      contractor_id: DataTypes.INTEGER,
      address_id: DataTypes.INTEGER,
      state_incident_no: DataTypes.STRING,
      is_inactive: DataTypes.BOOLEAN,
      accepted: DataTypes.BOOLEAN,
      contractor_role: DataTypes.STRING,
      activity_performed: DataTypes.BOOLEAN,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'connection_id',
          'contractor_id',
          'address_id',
          'is_inactive',
          'accepted',
          'contractor_role',
          'activity_performed',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );

  SpillContractors.associate = function(models) {
    SpillContractors.belongsTo(models.Addresses, {
      targetKey: 'id',
      foreignKey: 'address_id',
    });
    SpillContractors.belongsTo(models.Connections);
    SpillContractors.belongsTo(models.Contractors, {
      targetKey: 'id',
      foreignKey: 'contractor_id',
    });
  };

  return SpillContractors;
};
