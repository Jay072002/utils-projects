module.exports = (sequelize, DataTypes) => {
  const GenericAttachedDocument = sequelize.define(
    'generic_attached_documents',
    {
      contractor_id: DataTypes.INTEGER,
      is_contractors: DataTypes.BOOLEAN,
      is_pes_admin: DataTypes.BOOLEAN,
      name: DataTypes.STRING,
      url_link: DataTypes.STRING,
      key: DataTypes.STRING,
      attachment_type: DataTypes.STRING,
      attachment_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      tableName: 'generic_attached_documents',
      defaultScope: {
        attributes: [
          'id',
          'contractor_id',
          'is_contractors',
          'is_pes_admin',
          'name',
          'url_link',
          'key',
          'attachment_type',
          'attachment_id',
          'created_at',
          'updated_at',
          'deleted_at',
        ],
      },
    }
  );

  return GenericAttachedDocument;
};
