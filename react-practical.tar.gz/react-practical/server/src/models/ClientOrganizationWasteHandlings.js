import { v4 as uuidv4 } from 'uuid';

module.exports = (sequelize, DataTypes) => {
  const ClientOrganizationWasteHandlings = sequelize.define(
    'client_organization_waste_handlings',
    {
      org_id: DataTypes.INTEGER,
      hazardous_waste: DataTypes.STRING,
      non_hazardous_waste: DataTypes.STRING,
      revision_date: DataTypes.DATEONLY,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'org_id',
          'hazardous_waste',
          'non_hazardous_waste',
          'revision_date',
          'created_at',
          'updated_at',
          'deleted_at',
        ],
      },
    }
  );

  ClientOrganizationWasteHandlings.beforeCreate(v => v.id = uuidv4());

  ClientOrganizationWasteHandlings.associate = function(models) {
    ClientOrganizationWasteHandlings.belongsTo(models.ClientOrganizations);
  };

  return ClientOrganizationWasteHandlings;
};
