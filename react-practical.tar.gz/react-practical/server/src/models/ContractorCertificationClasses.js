module.exports = (sequelize, DataTypes) => {
  const ContractorCertificationClasses = sequelize.define(
    'contractor_certification_classes',
    {
      type: DataTypes.STRING,
      class: DataTypes.STRING,
      certificate_name: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'type',
          'class',
          'certificate_name',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );
  return ContractorCertificationClasses;
};
