module.exports = (sequelize, DataTypes) => {
  const Contractor = sequelize.define(
    'contractors',
    {
      name: DataTypes.STRING,
      address: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      zipCode: DataTypes.STRING,
      country: DataTypes.STRING,
      email: DataTypes.STRING,
      phone: DataTypes.STRING,
      fax: DataTypes.STRING,
      contact: DataTypes.STRING,
      tier_level: DataTypes.STRING,
      respond_count: DataTypes.INTEGER,
      reject_count: DataTypes.INTEGER,
      haz_waste_hauler: DataTypes.BOOLEAN,
      license_number: DataTypes.STRING,
      license_number_expiry: DataTypes.DATE,
      certification_classes: DataTypes.STRING,
      do_not_use: DataTypes.BOOLEAN
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'name',
          'address',
          'city',
          'state',
          'zipCode',
          'country',
          'email',
          'phone',
          'fax',
          'contact',
          'tier_level',
          'respond_count',
          'reject_count',
          'haz_waste_hauler',
          'license_number',
          'license_number_expiry',
          'certification_classes',
          'do_not_use',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );
  Contractor.associate = function(models) {
    Contractor.hasOne(models.SpillAdmins);
    Contractor.hasMany(models.SpillContractors);
    Contractor.hasMany(models.ContractorHistory);
    Contractor.hasMany(models.ContractorCertificationClasses);
    Contractor.hasMany(models.GenericAttachedDocuments);
    Contractor.hasMany(models.ContractorAttachmentsExpiry);
    Contractor.hasMany(models.ClientOrganizationContractors, {
      targetKey: 'contractor_id',
      foreignKey: 'contractor_id',
    });
  };
  return Contractor;
};
