module.exports = (sequelize, DataTypes) => {
    const ReportInvoicePackagingDownloadsHistory = sequelize.define('report_invoice_packaging_downloads_history', {
        user_id: DataTypes.INTEGER,
        spill_id: DataTypes.INTEGER,
        username: DataTypes.STRING,
        email: DataTypes.STRING,
        note_created_at: {
            type: DataTypes.DATE,
            allowNull: true
        },
        download_at: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    },
        {
            underscored: true,
            tableName: 'report_invoice_packaging_downloads_history',
            defaultScope: [
                'user_id',
                'spill_id',
                'created_at',
                "username",
                "email",
                'note_created_at',
                'download_at',
                'updated_at',
                'deleted_at',
            ]
        }
    )
    ReportInvoicePackagingDownloadsHistory.associate = function (models) {
        ReportInvoicePackagingDownloadsHistory.belongsTo(models.Spills, {
            targetKey: "id",
            foreignKey: "spill_id",
        });

        ReportInvoicePackagingDownloadsHistory.belongsTo(models.SpillStatusesHistory, {
            targetKey: "spill_id",
            foreignKey: "spill_id",
        });
    }

    return ReportInvoicePackagingDownloadsHistory;


}