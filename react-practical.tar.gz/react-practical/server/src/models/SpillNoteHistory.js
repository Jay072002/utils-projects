module.exports = (sequelize, DataTypes) => {
  const SpillNoteHistory = sequelize.define(
    "spill_notes_history",
    {
      change_owner: DataTypes.STRING,
      change_owner_id: DataTypes.INTEGER,
      spill_id: DataTypes.INTEGER,
      note_id: DataTypes.INTEGER,
      note_edit_id: DataTypes.INTEGER,
      edited_field: DataTypes.STRING,
      prev_val: DataTypes.STRING,
      new_val: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      tableName: "spill_notes_history",
      defaultScope: {
        attributes: [
          "id",
          "note_id",
          "spill_id",
          "note_edit_id",
          "edited_field",
          "prev_val",
          "new_val",
          "change_owner",
          "change_owner_id",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  return SpillNoteHistory;
};
