import { v4 as uuidv4 } from 'uuid';

module.exports = (sequelize, DataTypes) => {
  const ClientOrganizationFacilities = sequelize.define(
    "client_organization_facilities",
    {
      org_id: DataTypes.INTEGER,
      name: DataTypes.STRING,
      internal_id: DataTypes.STRING,
      generator_status: DataTypes.STRING,
      epa_id: DataTypes.STRING,
      address: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      country: DataTypes.STRING,
      zip_code: DataTypes.STRING,
      phone_number: DataTypes.STRING,
      region: DataTypes.DECIMAL,
      is_active: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "org_id",
          "name",
          "internal_id",
          "generator_status",
          "epa_id",
          "address",
          "city",
          "state",
          "country",
          "zip_code",
          "phone_number",
          "region",
          "is_active",
          "created_at",
          "updated_at",
          "deleted_at",
        ],
      },
    }
  );
  ClientOrganizationFacilities.beforeCreate(v => v.id = uuidv4());

  ClientOrganizationFacilities.associate = function(models) {
    ClientOrganizationFacilities.belongsTo(models.ClientOrganizations);
  };

  return ClientOrganizationFacilities;
};
