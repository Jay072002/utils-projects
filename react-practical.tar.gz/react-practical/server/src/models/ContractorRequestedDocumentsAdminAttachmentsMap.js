module.exports = (sequelize, DataTypes) => {
  const ContractorRequestedDocumentsAdminAttachmentsMap = sequelize.define(
    "contractor_requested_documents_admin_attachments_maps",
    {
      request_id: DataTypes.INTEGER,
      uploaded_admin_attachments_id: DataTypes.INTEGER,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE,
      deleted_at: DataTypes.DATE,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "request_id",
          "uploaded_admin_attachments_id",
          "created_at",
          "updated_at",
          "deleted_at",
        ],
      },
    }
  );

  return ContractorRequestedDocumentsAdminAttachmentsMap;
};
