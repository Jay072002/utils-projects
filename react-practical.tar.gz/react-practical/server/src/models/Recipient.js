module.exports = (sequelize, DataTypes) => {
  const Recipients = sequelize.define(
    "recipients",
    {
      spill_id: DataTypes.INTEGER,
      user_id: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: ["id", "spill_id", "user_id"],
      },
    }
  );

  Recipients.associate = function(models) {
    Recipients.belongsTo(models.Spills, {
      targetKey: "id",
      foreignKey: "spill_id",
    });
    Recipients.belongsTo(models.User, {
      targetKey: "id",
      foreignKey: "user_id",
    });
  };

  return Recipients;
};
