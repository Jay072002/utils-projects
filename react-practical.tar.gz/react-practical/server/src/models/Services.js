module.exports = (sequelize, DataTypes) => {
  const Services = sequelize.define(
    'services',
    {
      name: DataTypes.STRING,
      order: DataTypes.INTEGER,
      email_notifications: DataTypes.BOOLEAN,
      report_number: DataTypes.BOOLEAN,
      ip_address_identifier: DataTypes.BOOLEAN,
      owner: DataTypes.BOOLEAN,
      salvage_containers: DataTypes.BOOLEAN,
      samples: DataTypes.BOOLEAN,
      cost: DataTypes.BOOLEAN,
      establish_lane_closure: DataTypes.BOOLEAN,
      excavation_begun: DataTypes.BOOLEAN,
      excavation_completed: DataTypes.BOOLEAN,
      task_associated_relevance: DataTypes.BOOLEAN,
      time: DataTypes.BOOLEAN,
      date: DataTypes.BOOLEAN,
      upload_attachment: DataTypes.BOOLEAN,
      is_default: DataTypes.BOOLEAN,
      active: DataTypes.BOOLEAN,
      projected_eta: DataTypes.BOOLEAN,
      actual_eta: DataTypes.BOOLEAN,
      category_id: DataTypes.INTEGER,
      national_incident_no: DataTypes.BOOLEAN,
      state_incident_no: DataTypes.BOOLEAN,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'name',
          'order',
          'email_notifications',
          'report_number',
          'ip_address_identifier',
          'owner',
          'salvage_containers',
          'samples',
          'cost',
          'establish_lane_closure',
          'excavation_begun',
          'excavation_completed',
          'task_associated_relevance',
          'time',
          'date',
          'upload_attachment',
          'is_default',
          'active',
          'projected_eta',
          'actual_eta',
          'category_id',
          'national_incident_no',
          'state_incident_no',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );

  Services.associate = function(models) {
    Services.hasOne(models.ClientOrganizationServices, {
      targetKey: 'service_id',
      foreignKey: 'id',
    });
    Services.hasOne(models.UserServicesNotifications, {
      targetKey: 'service_id',
      foreignKey: 'id',
    });
    Services.belongsTo(models.Categories);
  };

  return Services;
};
