module.exports = (sequelize, DataTypes) => {
  const SpillManagers = sequelize.define(
    "spill_managers",
    {
      spill_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "spill_id",
          "user_id",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  SpillManagers.associate = function(models) {
    SpillManagers.belongsTo(models.Spills);
    SpillManagers.belongsTo(models.User, {
      targetKey: "id",
      foreignKey: "user_id",
    });
  };

  return SpillManagers;
};
