module.exports = (sequelize, DataTypes) => {
  const SpillAttachmentLogs = sequelize.define(
    "spill_attachment_logs",
    {
      spill_attachment_id: DataTypes.INTEGER,
      status: DataTypes.STRING,
      spill_admin_id: DataTypes.INTEGER,
      type: DataTypes.STRING,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE,
      deleted_at: DataTypes.DATE,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "spill_attachment_id",
          "status",
          "spill_admin_id",
          "type",
          "created_at",
          "updated_at",
          "deleted_at",
        ],
      },
    }
  );

  return SpillAttachmentLogs;
};
