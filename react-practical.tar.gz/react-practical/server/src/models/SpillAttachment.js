module.exports = (sequelize, DataTypes) => {
  const SpillAttachment = sequelize.define(
    'spill_attachments',
    {
      name: DataTypes.STRING,
      url_link: DataTypes.STRING,
      key: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      rejected_count: DataTypes.INTEGER,
      status: DataTypes.STRING,
      admin_note: DataTypes.STRING,
      type: DataTypes.STRING,
      size: DataTypes.STRING,
      inv_amount: DataTypes.DOUBLE,
      savings: DataTypes.DOUBLE,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'name',
          'url_link',
          'key',
          'spill_admin_id',
          'rejected_count',
          'user_id',
          'status',
          'admin_note',
          'type',
          'size',
          'inv_amount',
          'savings',
          // 'expiry_date',
          'created_at',
          'updated_at',
          'deleted_at',
        ],
      },
    }
  );

  SpillAttachment.associate = function(models) {
    SpillAttachment.belongsTo(models.User);
    SpillAttachment.hasMany(models.SpillAttachmentsHistory, {
      targetKey: 'spill_attachment_id',
      foreignKey: 'spill_attachment_id',
    });
  };

  return SpillAttachment;
};
