module.exports = (sequelize, DataTypes) => {
  const NoteAttachment = sequelize.define(
    'note_attachments',
    {
      type: DataTypes.STRING,
      url_link: DataTypes.STRING,
      key: DataTypes.STRING,
      spill_note_id: DataTypes.INTEGER,
      size: DataTypes.STRING,
      name: DataTypes.STRING,
      status: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'type',
          'url_link',
          'key',
          'spill_note_id',
          'size',
          'name',
          'status',
          'created_at',
          'updated_at',
          'deleted_at',
        ],
      },
    }
  );
  return NoteAttachment;
};
