module.exports = (sequelize, DataTypes) => {
  const AssociatedOrganizations = sequelize.define(
    'associated_organizations',
    {
      org_id: DataTypes.INTEGER,
      associated_org_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: ['id', 'org_id', 'associated_org_id'],
      },
    }
  );

  AssociatedOrganizations.associate = function(models) {
    AssociatedOrganizations.belongsTo(models.ClientOrganizations, {
      foreignKey: 'associated_org_id',
      targetKey: 'id',
    });
  };

  return AssociatedOrganizations;
};
