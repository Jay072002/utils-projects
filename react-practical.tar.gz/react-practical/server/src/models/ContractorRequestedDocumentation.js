module.exports = (sequelize, DataTypes) => {
  const ContractorRequestedDocumentation = sequelize.define(
    "contractor_requested_documentations",
    {
      contractor_id: DataTypes.INTEGER,
      contractor_address_id: DataTypes.INTEGER,
      spill_id: DataTypes.INTEGER,
      requested_type: DataTypes.STRING,
      requested_by: DataTypes.INTEGER,
      status: DataTypes.STRING,
      requested_at: DataTypes.DATE,
      uploaded_at: DataTypes.DATE,
      uploaded_by: DataTypes.INTEGER,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE,
      deleted_at: DataTypes.DATE,
      spill_admin_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "contractor_id",
          "contractor_address_id",
          "spill_id",
          "requested_type",
          "requested_by",
          "status",
          "requested_at",
          "uploaded_at",
          "uploaded_by",
          "created_at",
          "updated_at",
          "deleted_at",
          "spill_admin_id",
        ],
      },
    }
  );

  ContractorRequestedDocumentation.associate = function(models) {
    ContractorRequestedDocumentation.belongsTo(models.Spills, {
      targetKey: "id",
      foreignKey: "spill_id",
    });
    ContractorRequestedDocumentation.belongsTo(models.SpillAdmins, {
      targetKey: "id",
      foreignKey: "spill_admin_id",
    });
  };

  return ContractorRequestedDocumentation;
};
