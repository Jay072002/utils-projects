module.exports = (sequelize, DataTypes) => {
  const UpdateUploadHistoryFailure = sequelize.define(
    "update_upload_history_failures",
    {
      note_id: DataTypes.INTEGER,
      spill_id: DataTypes.INTEGER,
      old_path: DataTypes.STRING,
      new_path: DataTypes.STRING,
      attachment_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "note_id",
          "spill_id",
          "old_path",
          "new_path",
          "attachment_id",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  return UpdateUploadHistoryFailure;
};
