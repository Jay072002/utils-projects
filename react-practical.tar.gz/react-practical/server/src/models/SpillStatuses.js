module.exports = (sequelize, DataTypes) => {
  const SpillStatuses = sequelize.define(
    "spill_statuses",
    {
      name: DataTypes.STRING,
      status: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "name",
          "status",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  return SpillStatuses;
};
