module.exports = (sequelize, DataTypes) => {
  const Address = sequelize.define(
    "addresses",
    {
      entity_id: DataTypes.INTEGER,
      entity_type: DataTypes.STRING,
      address: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      zipCode: DataTypes.STRING,
      country: DataTypes.STRING,
      phone: DataTypes.STRING,
      fax: DataTypes.STRING,
      contact: DataTypes.STRING,
      tier_level: DataTypes.STRING,
      respond_count: DataTypes.INTEGER,
      reject_count: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "entity_id",
          "entity_type",
          "address",
          "city",
          "state",
          "zipCode",
          "country",
          "phone",
          "fax",
          "contact",
          "tier_level",
          "respond_count",
          "reject_count",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  Address.associate = function(models) {
    Address.hasOne(models.Agencies);
    Address.hasOne(models.SpillAdmins);
    Address.hasMany(models.ContractorHistory);
    Address.hasMany(models.ContractorAttachmentsExpiry, {
      foreignKey: 'contractor_id',
      sourceKey: 'entity_id',
    });
    Address.hasMany(models.ClientOrganizationContractors, {
      targetKey: 'address_id',
      foreignKey: 'address_id',
    });
  };

  return Address;
};
