module.exports = (sequelize, DataTypes) => {
  const UserOrganizations = sequelize.define(
    "user_organizations",
    {
      user_id: DataTypes.INTEGER,
      org_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "user_id",
          "org_id",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  UserOrganizations.associate = function(models) {
    UserOrganizations.belongsTo(models.User);
    UserOrganizations.belongsTo(models.ClientOrganizations);
  };

  return UserOrganizations;
};
