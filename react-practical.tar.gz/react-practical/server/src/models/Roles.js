module.exports = (sequelize, DataTypes) => {
  const Roles = sequelize.define(
    "roles",
    {
      role: DataTypes.INTEGER,
      permission_id: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "role",
          "permission_id",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  Roles.associate = function(models) {
    Roles.belongsTo(models.Permissions, {
      targetKey: "id",
      foreignKey: "permission_id",
    });
  };

  return Roles;
};
