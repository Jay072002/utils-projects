const { Op } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  const Agencies = sequelize.define(
    "agencies",
    {
      name: DataTypes.STRING,
      address: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      zipCode: DataTypes.STRING,
      country: DataTypes.STRING,
      phone: DataTypes.STRING,
      fax: DataTypes.STRING,
      contact: DataTypes.STRING,
      jurisdiction: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "name",
          "address",
          "city",
          "state",
          "zipCode",
          "country",
          "phone",
          "fax",
          "contact",
          "jurisdiction",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  Agencies.associate = function(models) {
    Agencies.hasMany(models.Addresses, {
      targetKey: "entity_id",
      foreignKey: "entity_id",
    });
    Agencies.hasMany(models.ReportingRequirementsHistory, {
      targetKey: "agency_id",
      foreignKey: "agency_id",
    });
  };

  return Agencies;
};
