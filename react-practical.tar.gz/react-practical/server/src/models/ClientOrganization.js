module.exports = (sequelize, DataTypes) => {
  const ClientOrganizations = sequelize.define(
    'client_organizations',
    {
      name: DataTypes.STRING,
      salesPerson: DataTypes.STRING,
      taxId: DataTypes.STRING,
      address: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      zipCode: DataTypes.STRING,
      country: DataTypes.STRING,
      phone: DataTypes.STRING,
      rate: DataTypes.DECIMAL,
      active: DataTypes.BOOLEAN,
      service_id: DataTypes.INTEGER,
      rate_type: DataTypes.STRING,
      is_demo: DataTypes.BOOLEAN,
      sales_person_id: DataTypes.INTEGER,
      is_god: DataTypes.BOOLEAN,
      code: DataTypes.STRING,
      payment_terms: DataTypes.INTEGER,
      timestamp_visibility: DataTypes.BOOLEAN,
      monetary_visibility: DataTypes.BOOLEAN,
      is_default_parent_users: DataTypes.BOOLEAN,
      hazardous_waste: DataTypes.STRING,
      non_hazardous_waste: DataTypes.STRING,
      revision_date: DataTypes.DATEONLY,
      reporting: DataTypes.BOOLEAN,
      reporting_instruction: DataTypes.STRING,
      report_5800: DataTypes.BOOLEAN,
      instruction_5800: DataTypes.STRING,
      miscellaneous: DataTypes.STRING,
      is_ics_client: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'name',
          'salesPerson',
          'taxId',
          'address',
          'city',
          'state',
          'zipCode',
          'country',
          'phone',
          'rate',
          'active',
          'service_id',
          'rate_type',
          'is_demo',
          'sales_person_id',
          'is_god',
          'code',
          'payment_terms',
          'timestamp_visibility',
          'monetary_visibility',
          'is_default_parent_users',
          'hazardous_waste',
          'non_hazardous_waste',
          'revision_date',
          'reporting',
          'reporting_instruction',
          'report_5800',
          'instruction_5800',
          'miscellaneous',
          'is_ics_client',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );

  ClientOrganizations.associate = function(models) {
    ClientOrganizations.hasMany(models.AssociatedOrganizations, {
      targetKey: 'org_id',
      foreignKey: 'org_id',
    });
    ClientOrganizations.hasMany(models.SpillMaterial, {
      targetKey: 'org_id',
      foreignKey: 'org_id',
    });
    ClientOrganizations.hasMany(models.UserOrganizations, {
      targetKey: 'org_id',
      foreignKey: 'org_id',
    });
    ClientOrganizations.hasMany(models.ClientOrganizationServices, {
      targetKey: 'org_id',
      foreignKey: 'org_id',
    });
    ClientOrganizations.hasMany(models.ClientOrganizationFacilities, {
      targetKey: 'org_id',
      foreignKey: 'org_id',
    });
    ClientOrganizations.hasMany(models.ClientOrganizationContractors, {
      targetKey: 'org_id',
      foreignKey: 'org_id',
    });
  };

  return ClientOrganizations;
};
