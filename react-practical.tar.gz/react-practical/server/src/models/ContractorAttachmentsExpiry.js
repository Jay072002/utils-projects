module.exports = (sequelize, DataTypes) => {
  const ContractorAttachmentsExpiry = sequelize.define(
    'contractor_attachments_expiry',
    {
      user_id: DataTypes.INTEGER,
      contractor_id: DataTypes.INTEGER,
      attachment_id: DataTypes.INTEGER,
      contractor_address_id: DataTypes.INTEGER,
      expiry_date: DataTypes.DATE,
      disabled: DataTypes.BOOLEAN,
    },
    {
      underscored: true,
      paranoid: true,
      tableName: 'contractor_attachments_expiries',
      defaultScope: {
        attributes: [
          'id',
          'user_id',
          'contractor_id',
          'attachment_id',
          'contractor_address_id',
          'expiry_date',
          'disabled',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );

  ContractorAttachmentsExpiry.associate = function(models) {
    ContractorAttachmentsExpiry.hasOne(models.ContractorAttachmentTypes, {
      targetKey: 'attachment_id',
      foreignKey: 'id',
    });
    ContractorAttachmentsExpiry.hasOne(models.User, {
      targetKey: 'user_id',
      foreignKey: 'id',
    });
  };

  return ContractorAttachmentsExpiry;
};
