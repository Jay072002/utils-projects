module.exports = (sequelize, DataTypes) => {
  const Connections = sequelize.define(
    "connections",
    {
      spill_id: DataTypes.INTEGER,
      agency_national: DataTypes.STRING,
      incident_no: DataTypes.STRING,
      agency_id: DataTypes.INTEGER,
      address_id: DataTypes.INTEGER,
      state_incident_no: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          "id",
          "spill_id",
          "agency_national",
          "incident_no",
          "agency_id",
          "address_id",
          "state_incident_no",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  Connections.associate = function(models) {
    Connections.belongsTo(models.Spills);
    Connections.belongsTo(models.Agencies, {
      targetKey: "id",
      foreignKey: "agency_id",
    });
    Connections.hasMany(models.SpillContractors, {
      targetKey: "connection_id",
      foreignKey: "connection_id",
    });
    Connections.belongsTo(models.Addresses, {
      targetKey: "id",
      foreignKey: "address_id",
    });
    Connections.belongsTo(models.Agencies);
  };

  return Connections;
};
