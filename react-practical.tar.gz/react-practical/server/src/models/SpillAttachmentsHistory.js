module.exports = (sequelize, DataTypes) => {
  const SpillAttachmentsHistory = sequelize.define(
    'spill_attachments_history',
    {
      note: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      url_link: DataTypes.STRING,
      spill_attachment_id: DataTypes.INTEGER,
      key: DataTypes.STRING,
      size: DataTypes.STRING,
      inv_amount: DataTypes.DOUBLE,
    },
    {
      underscored: true,
      paranoid: true,
      tableName: 'spill_attachments_history',
      defaultScope: {
        attributes: [
          'id',
          'note',
          'user_id',
          'size',
          'key',
          'url_link',
          'spill_attachment_id',
          'inv_amount',
          // 'expiry_date',
          'created_at',
          'updated_at',
          'deleted_at',
        ],
      },
    }
  );

  SpillAttachmentsHistory.associate = function(models) {
    SpillAttachmentsHistory.belongsTo(models.SpillAttachments);
  };

  return SpillAttachmentsHistory;
};
