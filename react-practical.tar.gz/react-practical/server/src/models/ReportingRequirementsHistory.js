import { v4 as uuidv4 } from 'uuid';

module.exports = (sequelize, DataTypes) => {
  const ReportingRequirementsHistory = sequelize.define(
    "reporting_requirements_history",
    {
      agency_id: DataTypes.INTEGER,
      petroleum_release_amount: DataTypes.DECIMAL,
      petroleum_release: DataTypes.STRING,
      hazardous_material_amount: DataTypes.DECIMAL,
      hazardous_material: DataTypes.STRING,
      water_impact_amount: DataTypes.DECIMAL,
      water_impact: DataTypes.STRING,
      soil_impact_amount: DataTypes.DECIMAL,
      soil_impact: DataTypes.STRING,
      revision_date: DataTypes.DATEONLY,
    },
    {
      underscored: true,
      paranoid: true,
      tableName: 'reporting_requirements_history',
      defaultScope: {
        attributes: [
          "id",
          "agency_id",
          "petroleum_release_amount",
          "petroleum_release",
          "hazardous_material_amount",
          "hazardous_material",
          "water_impact_amount",
          "water_impact",
          "soil_impact_amount",
          "soil_impact",
          "revision_date",
          "created_at",
          "updated_at",
          "deleted_at",
        ],
      },
    }
  );

  ReportingRequirementsHistory.beforeCreate(v => v.id = uuidv4());

  ReportingRequirementsHistory.associate = function(models) {
    ReportingRequirementsHistory.hasMany(models.Agencies, {
      targetKey: "id",
      foreignKey: "agency_id",
    });
  };

  return ReportingRequirementsHistory;
};
