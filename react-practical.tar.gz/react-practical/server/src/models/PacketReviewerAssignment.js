module.exports = (sequelize, DataTypes) => {
  const PacketReviewerAssignment = sequelize.define(
    'packet_reviewer_assignments',
    {
      packet_reviewer_user_id: DataTypes.INTEGER,
      packet_reviewer_user_full_name: DataTypes.STRING,
      assigned_spill_id: DataTypes.INTEGER,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: [
          'id',
          'packet_reviewer_user_id',
          'packet_reviewer_user_full_name',
          'assigned_spill_id',
          'updated_at',
          'created_at',
          'deleted_at',
        ],
      },
    }
  );

  PacketReviewerAssignment.associate = function(models) {
    PacketReviewerAssignment.belongsTo(models.Spills, {
      targetKey: 'id',
      foreignKey: 'assigned_spill_id',
    });
    PacketReviewerAssignment.belongsTo(models.User, {
      targetKey: 'id',
      foreignKey: 'packet_reviewer_user_id',
    });
  };

  return PacketReviewerAssignment;
};
