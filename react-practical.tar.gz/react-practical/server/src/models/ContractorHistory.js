module.exports = (sequelize, DataTypes) => {
  const ContractorHistory = sequelize.define(
    "contractor_history",
    {
      response_by: DataTypes.STRING,
      change_owner: DataTypes.STRING,
      change_owner_id: DataTypes.INTEGER,
      spill_id: DataTypes.INTEGER,
      contractor_id: DataTypes.INTEGER,
      address_id: DataTypes.INTEGER,
      description: DataTypes.STRING,
      contractor_label: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      tableName: "contractor_history",
      defaultScope: {
        attributes: [
          "id",
          "response_by",
          "change_owner",
          "change_owner_id",
          "spill_id",
          "contractor_id",
          "address_id",
          "description",
          "contractor_label",
          "updated_at",
          "created_at",
          "deleted_at",
        ],
      },
    }
  );

  ContractorHistory.associate = function(models) {
    ContractorHistory.belongsTo(models.Spills, {
      targetKey: "id",
      foreignKey: "spill_id",
    });
    ContractorHistory.belongsTo(models.Contractors, {
      targetKey: "id",
      foreignKey: "contractor_id",
    });
    ContractorHistory.belongsTo(models.Addresses, {
      targetKey: "id",
      foreignKey: "address_id",
    });
  };

  return ContractorHistory;
};
