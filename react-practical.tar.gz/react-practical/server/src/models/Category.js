module.exports = (sequelize, DataTypes) => {
  const Categories = sequelize.define(
    "categories",
    {
      name: DataTypes.STRING,
    },
    {
      underscored: true,
      paranoid: true,
      defaultScope: {
        attributes: ["id", "name", "updated_at", "created_at", "deleted_at"],
      },
    }
  );

  Categories.associate = function(models) {
    Categories.hasOne(models.Services, {
      targetKey: "category_id",
      foreignKey: "id",
    });
  };

  return Categories;
};
