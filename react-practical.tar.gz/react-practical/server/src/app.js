dotenv.config();
import config from "./config/index.json";
import app from "./config/express";
import http from "http";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import https from "https";
import Logger from "./util/logger";

require("newrelic");

process.env.NODE_ENV = config.NODE_ENV;

let server;

process.on("uncaughtException", (err) => {
  console.error(new Date(), " uncaughtException:", err.message);
});

if (process.env.NODE_ENV === "production") {
  try {
    const options = {
      key: fs.readFileSync(
        path.resolve(__dirname, "./Certificates/privkey.pem")
      ),
      cert: fs.readFileSync(
        path.resolve(__dirname, "./Certificates/fullchain.pem")
      ),
    };

    https
      .createServer(options, (req, res) => {
        res.writeHead(301, {
          Location: `https://${req.headers.host}${req.url}`,
        });
        res.end();
      })
      .listen(3001);

    http
      .createServer((req, res) => {
        res.writeHead(301, {
          Location: `https://${req.headers.host}${req.url}`,
        });
        res.end();
      })
      .listen(80);
  } catch (err) {
    app.listen(80);
    console.error(
      "HTTPS initialization failed",
      err.message,
      "Falling back to HTTP"
    );
  }
} else {
  server = app.listen(config.PORT).on("listening", async () => {
    Logger.log("info", `Server running at http://localhost:${config.PORT}/`);
  });
}

module.exports = { app, server };
