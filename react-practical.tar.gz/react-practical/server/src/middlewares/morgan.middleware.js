import morgan from "morgan";

import Logger from "../util/logger";

// Override the stream method by telling
// Morgan to use our custom logger instead of the console.log.
morgan.token("body", function(req, res) {
  if (req.body !== null) {
    if (req.url === "/user/login" || req.url === "/user/add") {
      //Passwords should not be logged during the logging.
      return JSON.stringify(`email: ${req.body.email}, password:*********`);
    } else {
      return JSON.stringify(req.body);
    }
  } else return "";
});

const stream = {
  write: (message) => {
    Logger.http(message);
  },
};

//Used to skip if the app is not in the dev mode.
const skip = () => {
  //** Should be like but right now no way of knowing whether its dev or prod */
  // const env = process.env.NODE_ENV || "development";
  // return env !== "development";
  return false;
};

// Build the morgan middleware
const morganMiddleware = morgan(
  ":method :url :status :res[content-length] :body  - :response-time ms",
  { stream, skip }
);

export default morganMiddleware;
