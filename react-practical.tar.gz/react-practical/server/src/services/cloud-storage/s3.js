import fs from 'fs';
import AWS from 'aws-sdk';
import { orderBy } from 'lodash';

const accessKey = process.env.AWS_S3_ACCESS_KEY_ID;
const secretKey = process.env.AWS_S3_SECRET_ACCESS_KEY;
const bucketName = process.env.AWS_S3_BUCKET;

const s3 = new AWS.S3({
  accessKeyId: accessKey,
  secretAccessKey: secretKey,
});

const uploadFileToS3Bucket = async (file, fileName) => {
  const fileContent = fs.readFileSync(file);
  const params = {
    Bucket: bucketName,
    Key: fileName,
    Body: fileContent,
  };

  try {
    const stored = await s3.upload(params).promise();
    return stored;
  } catch (err) {
    return err;
  }
};

const downloadFileFromS3Bucket = async (key) => {
  try {
    const fileStream = await s3
      .getObject({ Bucket: process.env.AWS_S3_BUCKET, Key: key })
      .createReadStream();
    return fileStream;
  } catch (err) {
    return err;
  }
};

const getSignedUrl = async (
  Key,
  UploadId,
  parts,
  Bucket = process.env.AWS_S3_BUCKET
) => {
  try {
    const partsMap = Array.from(Array(parts).keys());
    const multipartParams = {
      Bucket,
      Key,
      UploadId,
    };
    const promises = partsMap.map((p, i) => {
      return s3.getSignedUrlPromise('uploadPart', {
        ...multipartParams,
        PartNumber: i + 1,
      });
    });
    const signedUrls = await Promise.all(promises);
    const partSignedUrlList = signedUrls.map((signedUrl, i) => {
      return {
        signedUrl,
        PartNumber: i + 1,
      };
    });
    return partSignedUrlList;
  } catch (e) {
    return e;
  }
};
const initiateMultiPartUpload = async (
  fileName,
  Bucket = process.env.AWS_S3_BUCKET
) => {
  const multipartParams = {
    Bucket,
    Key: `${fileName}`,
  };
  const multipartUpload = await s3
    .createMultipartUpload(multipartParams)
    .promise();
  return { fileId: multipartUpload?.UploadId, fileKey: multipartUpload?.Key };
};

const finalizeMultiPartUpload = async (
  Key,
  UploadId,
  parts,
  Bucket = process.env.AWS_S3_BUCKET
) => {
  const multipartParams = {
    Bucket,
    Key,
    UploadId,
    MultipartUpload: {
      Parts: orderBy(parts, ['PartNumber'], ['asc']),
    },
  };
  const output = await s3.completeMultipartUpload(multipartParams).promise();
  return output?.Location;
};

module.exports = {
  uploadFileToS3Bucket,
  downloadFileFromS3Bucket,
  initiateMultiPartUpload,
  getSignedUrl,
  finalizeMultiPartUpload,
};
