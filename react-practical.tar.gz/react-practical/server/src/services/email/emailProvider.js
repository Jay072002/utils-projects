import { getUser } from "../../util/helper";
import { CONSTANTS } from "../../util/constants";

const nodemailer = require("nodemailer");
const Email = require("email-templates");
import { calculateRecievingInfo } from "../../util/preProcessors";
import Logger from "../../util/logger";

const { URL_FOR_EMAIL } = process.env;

const options = {
  pool: true,
  host: process.env.AWS_SMTP_SERVER,
  port: 465,
  secure: true,
  auth: {
    user: process.env.AWS_SMTP_USERNAME,
    pass: process.env.AWS_SMTP_PASSWORD,
  },
};

const transporter = nodemailer.createTransport(options);

transporter.verify((error, success) => {
  if (error) {
    Logger.log("error", "error with email connection");
    Logger.log("error", `Error : ${error}`);
  } else if (success) {
    Logger.log("info", "SMTP server connected successfully");
  }
});

export const emailSender = async ({
  sendEmailTo,
  sendEmailFrom,
  header,
  subject,
  body,
  password,
}) => {
  const email = new Email({
    views: { root: __dirname },
    preview: false,
    message: await getEmailAddressConfig(sendEmailFrom),
    send: true,
    transport: transporter,
  });

  email
    .send({
      template: "emailView",
      message: calculateRecievingInfo(sendEmailTo, subject),
      locals: {
        productName: "PES-Spills",
        header,
        body,
        password,
        sendEmailTo,
      },
    })
    .then(() => {
      console.log(
        "Email sent from : ",
        sendEmailFrom,
        "Email sent to : ",
        sendEmailTo,
        "    ( ",
        new Date().toLocaleString(),
        " )"
      );
    })
    .catch((error) => {
      console.error(error);
    });
};

export const getEmailAddressConfig = async (senderAddress) => {
  const user = await getUser(senderAddress);
  if (senderAddress?.endsWith(CONSTANTS.OFFICIAL_EMAIL_DOMAIN)) {
    return {
      from: `${user?.full_name ? user?.full_name : ""} <${senderAddress}>`,
    };
  }
  return {
    from: `${user?.full_name ? user?.full_name : ""} <${
      CONSTANTS.DEFAULT_EMAIL
    }>`,
    replyTo: senderAddress,
  };
};

export const genericSender = async ({
  sendEmailTo,
  sendEmailFrom,
  header,
  subject,
  body,
  link,
  changes,
  emailType,
  attachments,
}) => {
  const email = new Email({
    views: { root: __dirname },
    preview: false,
    message: await getEmailAddressConfig(sendEmailFrom),
    send: true,
    transport: transporter,
  });
  return (
    sendEmailTo?.length &&
    email
      .send({
        template: emailType ?? "genericView",
        message: {
          ...calculateRecievingInfo(sendEmailTo, subject),
          attachments,
        },
        locals: {
          productName: "PES-Spills",
          header,
          body,
          changes: changes,
          origin: URL_FOR_EMAIL,
        },
      })
      .then(() => {
        console.log(
          "Email sent to : ",
          sendEmailTo,
          "    ( ",
          new Date().toLocaleString(),
          " )"
        );
      })
      .catch((error) => {
        if (error.responseCode === 552) {
          genericSender({
            sendEmailTo,
            sendEmailFrom,
            header,
            subject,
            body:
              body +
              "<br/> ** Attachment size limit exceeded. Should be seen from portal.",
            changes,
            emailType,
            attachments: [],
          });
        } else {
          console.error(error);
        }
      })
  );
};
