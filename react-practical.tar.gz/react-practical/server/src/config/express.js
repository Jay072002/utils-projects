import * as Sentry from "@sentry/node";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
import express from "express";
import frameguard from "frameguard";
import fs from "fs";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "path";
import responseTime from "response-time";
import models from "../models";
import actionRoutes from "../api/actions/actions.route";
import agencyRoutes from "../api/agencies/agency.route";
import clientOrganizationRoutes from "../api/client-organizations/client-organizations.route";
import contractorRoutes from "../api/contractors/contractor.route";
import downloadRoutes from "../api/download/download.route";
import migrationRoutes from "../api/migrations/migrations.route";
import searchRoutes from "../api/search/search.route";
import servicesRoutes from "../api/services/services.route";
import spillRoutes from "../api/spills/spill.route";
import userRoutes from "../api/users/user.route";
import morganMiddleware from "../middlewares/morgan.middleware";
const { JWT_SECRET, ORIGIN, SENTRY_DSN } = process.env;
import { checkUserEula, includeExternalData, userWithoutExternalData } from "../util/helper";
const app = express();

const router = express.Router();
const acceptedTypes = [
  "image/png",
  "image/jpg",
  "image/jpeg",
  "image/tiff",
  "video/mp4",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/pdf",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
  "text/csv",
];

// enable parsers

app.use(bodyParser.json());

app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);

app.use(cookieParser());
// Injects X-Response-Time response header
app.use(responseTime());
// Tester for X-Response-Time: Returned max time 2.9 millisecond so won't impact the existing apis
// app.get('/test/rs', (req, res) => res.send({ hit: '/test/rs' }));
// restricts who can put your site in a frame
app.use(frameguard());
// enable cross-origin requests
// app.use(cors());

app.use(
  cors({
    origin: true,
    credentials: true,
  })
);
// sentry io
Sentry.init({
  dsn: SENTRY_DSN,
  tracesSampleRate: 0.5,
});
app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.tracingHandler());
app.use(Sentry.Handlers.errorHandler());
// sentry io end

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    // const uploadDir = __dirname + `../../uploads/admin`;
    if (file.originalname.split("#")[0].includes("admin")) {
      !fs.existsSync("uploads/admin") &&
        fs.mkdirSync("uploads/admin", { recursive: true });
      cb(null, "uploads/admin");
    } else if (file.originalname.split("#")[0].includes("certificate")) {
      !fs.existsSync("uploads/certificate") &&
        fs.mkdirSync("uploads/certificate", { recursive: true });
      cb(null, "uploads/certificate");
    } else if (file.originalname.split("#")[0].includes("client_facility")) {
      !fs.existsSync("uploads/client_facility") &&
        fs.mkdirSync("uploads/client_facility", { recursive: true });
      cb(null, "uploads/client_facility");
    } else {
      !fs.existsSync("uploads/notes") &&
        fs.mkdirSync("uploads/notes", { recursive: true });
      cb(null, "uploads/notes");
    }
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const filter = (req, file, cb) => {
  if (acceptedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

// enable system logging
// const accessLogStream = fs.createWriteStream("access.log", { flags: "a" });
// app.use(morgan("combined", { stream: accessLogStream }));

app.use(multer({ storage: fileStorage, fileFilter: filter }).any());
// route config
userRoutes(router);
agencyRoutes(router);
contractorRoutes(router);
clientOrganizationRoutes(router);
spillRoutes(router);
servicesRoutes(router);
searchRoutes(router);
downloadRoutes(router);
migrationRoutes(router);
actionRoutes(router);
const authorization = (req, res, next) => {
  try {
    const user = jwt.verify(req.cookies.session_id, JWT_SECRET);

    if (user) {
      req.user = user; // eslint-disable-line
      next();
    } else {
      res.status(403).send();
    }
  } catch (err) {
    res.status(403).send();
  }
};
//FIXME:Reason of Delay in response
app.use(
  /\/api\/\w+\/((?!signup|verify|assets|login|forgotPassword|editProfile|migration|contractors|agency|clientOrganization|user|salePersonID|spill|spillNotes|spillReserves|status|calculateSum|material|tiers)).+/,
  authorization,
  async (req, res, next) => {
    const { id, opsTrack } = req.user;

    if (userWithoutExternalData(req?.baseUrl)) {
      const userEula = {
        role_id: req?.user?.role_id,
        id: req?.user?.id,
        eula_accepted_year: req?.user?.eula_accepted_year,
        eula_accepted: req?.user?.eula_accepted,
      }
      const eulaStatus = await checkUserEula(userEula)
      if (eulaStatus) {
        res.clearCookie("session_id");
        return res.status(200).json({
          message: "Logged Out",
        });
      } else {
        next();
        return false;
      }
    }

    const include = [
      {
        model: models.Roles,
        attributes: ["role"],
        include: [
          {
            model: models.Permissions,
            required: false,
          },
        ],
      }
    ];

    if (includeExternalData(req?.baseUrl)) {
      include.push(
        {
          model: models.UserServicesNotifications,
          required: false,
          include: [
            {
              model: models.Services,
              required: false,
            },
          ],
        },
        {
          model: models.Contractors,
          required: false,
        },
        {
          model: models.Addresses,
          required: false,
        },
        {
          model: models.ClientOrganizations,
          required: false,
          include: [
            {
              model: models.ClientOrganizationServices,
              include: [
                {
                  model: models.Services,
                  required: false,
                },
              ],
            },
          ],
        }
      )
    }

    models.User.findOne({
      where: {
        id,
      },
      include,
    })
      .then(async (user) => {
        if (user) {
          req.user = user;
          req.user.opsTrack = opsTrack;
          const userEula = {
            role_id: user?.dataValues?.role_id,
            id: user?.dataValues?.id,
            eula_accepted_year: user?.dataValues?.eula_accepted_year,
            eula_accepted: user?.dataValues?.eula_accepted,
          }

          const eulaStatus = await checkUserEula(userEula)
          if (eulaStatus) {
            res.clearCookie("session_id");
            return res.status(200).json({
              message: "Logged Out",
            });
          } else {
            next();
            return false;
          }
        } else {
          next(new Error("User not found"));
        }
      })
      .catch((err) => {
        next(err);
      });
  }
);
app.use(morganMiddleware);

app.use("/api", router);
app.use(express.static(path.resolve(__dirname, "../../../build")));
app.use(express.static(path.resolve(__dirname, "../../../public")));
app.use(express.static(path.resolve(__dirname, "../../../uploads")));
app.use("/", (req, res) =>
  res.sendFile(path.resolve(__dirname, "../../../build/index.html"))
);

app.use((err, req, res) => {
  res.status(400).json({
    status: 400,
    message: err.message,
  });
});
export default app;