import _ from "lodash";
import { Op } from "sequelize";
import models from "../../models";
import { fetchDataFromAttachmentTable } from "../../util/additionalAttachments";
import pagination from "../../util/pagination";
import { buildSearchQuery } from "../../util/searchMethods";
import { ROLES } from '../../util';

export const search = async (req, res) => {
  const { searchText, role, type, page, searchFields, activeFilter } = req.body;
  const { contractor_id , client_organization, role: userRoles} = req.user;


  try {
    let responsedata;
    let responseType;
    let count;

    const { limit, offset, current } = pagination(page);

    switch (type) {
      case "User": {
        try {
          const query = await buildSearchQuery(
            searchText,
            type,
            role,
            searchFields,
            activeFilter,
            contractor_id,
            client_organization
          );

          let usersCount = await models.User.count({
            ...query,
            paranoid: false,
          });

          let users = await models.User.findAll({
            ...query,
            limit,
            offset,
            paranoid: false,
          });

          responsedata = users;
          responseType = type;
          count = usersCount;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      case "Agency": {
        let where = {
          $or: [
            {
              name: {
                $like: `%${searchText}%`,
              },
            },
          ],
        };

        try {
          const agenciesCount = await models.Agencies.count({
            where,
          });
          const agencies = await models.Agencies.findAll({
            include: [
              {
                model: models.Addresses,
                required: false,
              },
            ],
            limit,
            offset,
            where,
            paranoid: false,
          });
          const agencyData = [];
          if (userRoles?.role === ROLES.SUPER_USER) {
            for (let index = 0; index < agencies.length; index++) {
              const element = {...agencies[index]?.dataValues};
              const reportingRequirementsHistory = await models.ReportingRequirementsHistory.findOne({
                where: { 
                  agency_id: element.id,
                  deleted_at: {
                    [Op.eq]: null
                  }
                },
                order: [["created_at","DESC"]]
              });
              element.reportingRequirements = reportingRequirementsHistory || {};
              agencyData.push(element);
            }
          }
          responsedata = agencyData;
          responseType = type;
          count = agenciesCount;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      case "Contractor": {
        let where = {
          $or: [
            {
              name: {
                $like: `%${searchText}%`,
              },
            },
          ],
          deleted_at: null,
        };

        try {
          let completeContractors = [];
          const contractorsCount = await models.Contractors.count({
            where,
          });
          const contractors = await models.Contractors.findAll({
            where,
            limit,
            offset,
            paranoid: false,
          });

          for (const contractor of contractors) {
            let additionalAttachmentTypes = await fetchDataFromAttachmentTable(
              contractor?.dataValues?.id
            );

            const addresses = await models.Addresses.findAll({
              where: {
                entity_type: "contractor",
                entity_id: contractor?.dataValues?.id,
                deleted_at: null,
              },
            });

            completeContractors.push({
              ...contractor.toJSON(),
              GenericAttachedDocuments: additionalAttachmentTypes,
              addresses,
            });
          }

          responsedata = completeContractors;
          responseType = type;
          count = contractorsCount;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      case "Client": {
        let where = {
          $or: [
            {
              name: {
                $like: `%${searchText}%`,
              },
            },
            {
              code: {
                $like: `%${searchText}%`,
              },
            },
          ],
        };

        try {
          const clientOrganizationsCount = await models.ClientOrganizations.count(
            {
              where,
            }
          );
          let clientOrganizations = await models.ClientOrganizations.findAll({
            include: [
              {
                model: models.AssociatedOrganizations,
                required: false,
              },
            ],
            where,
            limit,
            offset,
            paranoid: false,
          });

          responsedata = clientOrganizations;
          responseType = type;
          count = clientOrganizationsCount;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      default:
        null;
    }

    const total = Math.ceil(count / limit) || 0;
    res.status(200).json({
      success: true,
      data: responsedata.map((x) => x?.dataValues ?? x),
      type: responseType,
      pagination: {
        page,
        count,
        totalPages: total,
        currentPage: current > total ? total : current,
      },
    });
  } catch (error) {
    res.status(500).json({
      message:
        "There was an error on the server and the request could not be completed.",
    });
    console.log(error);
  }
};
