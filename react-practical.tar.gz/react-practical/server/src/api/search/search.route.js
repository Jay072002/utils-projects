import * as searchController from "./search.controller";

export default (route) => {
  route.post("/search/data", searchController.search);
};
