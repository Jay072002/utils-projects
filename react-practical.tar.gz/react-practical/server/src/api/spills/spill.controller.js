import Moment from "moment";
import moment from "moment-timezone";
import fs from "fs";
import { Parser } from "json2csv";
import models, { sequelize } from "../../models";
import {
  generateHtml,
  getChanges,
  getComparedNotes,
  getDataValues,
  getAddedObj,
  getContractors,
  handleRejectedContractors,
  incrementResponseCount,
  adjustSpillTotal,
  uniqueIdGenerator,
  filterPacketReviewers,
  filterSpillsToUpdate,
  filterSpillsToInsert,
  uniqueStringsInArray,
  findClientWasteHandlings,
} from "../../util/helper";
import pagination from "../../util/pagination";
import { uploadFileToS3Bucket } from "../../util/s3";
import {
  convertDateToDateRange,
  forceToCSTForRawQuery,
  convertDateDiffIntoHours,
} from "../../util/convertDateRange";
import {
  createDescription,
  sendAttachmentRejectionEmail,
  sendSubmissionEmail,
  // createJobNumber,
  getStatusCounts,
  convertKeys,
  findAssociatedServices,
  generateAutoServiceNote,
  getFileNames,
  mapContractors,
  filterSpills,
  isContractorUser,
  buildIncludeQueryForConnections,
  convertStatuses,
  getRejectedSpillIds,
  isEmptyObject,
  isNullish,
  getSpillCountForContractorUsers,
  getSpillCountForGeneralUsers,
  wasteGeneratedCondition,
  getDocumentationInReviewSpillsCount,
  uniqueArrayOfStrings,
  getReportingRequirementHistory,
} from "../../util";
import {
  USER_TYPE,
  ROLES,
  ACTIONS,
  CONSTANTS,
  SPILL_CONTRACTOR_ROLES,
} from "../../util/constants";
import { genericSender } from "../../services/email/emailProvider";
import { searchSpillsForCSV } from "../download/download.service";
import {
  initiateMultiPartUpload,
  getSignedUrl,
  finalizeMultiPartUpload,
} from "../../services/cloud-storage/s3";
import createJobNumber from "../../util/createJobNumber";
import newAction from "../../util/actions";

const { OVERWATCH_EMAIL, MAP_REQ_EMAIL, EMAIL_SENDER } = process.env;
const { Op } = require("sequelize");

export const createNewSpill = async (req, res, next) => {
  try {
    const {
      user_id,
      org_id,
      opened_on,
      send_attachment,
      users,
      status,
      manager_id,
      current_time,
      is_test_spill,
      send_email,
      is_emergency,
      facility_id
    } = req.body;
    console.log("current_time :", current_time);

    let spillStatus = {};
    let is_demo = false;

    const { role } = req.user?.role;
    const user_name = req?.user?.full_name;

    if (role === ROLES.DEMO) {
      is_demo = true;
    }

    if (status) {
      const spillStatusSplitter = status.split(":");

      const status_type = spillStatusSplitter[0].trim();
      const status_name = spillStatusSplitter[1].trim();

      const statusFound = await models.SpillStatuses.findOne({
        where: {
          status: status_type,
          name: status_name,
        },
      });

      spillStatus = statusFound;
    }

    const org = await models.ClientOrganizations.findById(org_id);

    const isProbPM = role === ROLES.PROB_PM;

    const job_no = await createJobNumber(org.code, is_test_spill, isProbPM);
    const splittedJobNumber = job_no.split("-");
    const job_no_year = splittedJobNumber[0];
    const job_no_month_count = splittedJobNumber[splittedJobNumber.length - 1];
    // const job_no = await createJobNumber(
    //   org.code,
    //   role === ROLES.PROB_PM,
    //   current_time,
    //   is_test_spill
    // );

    const spillObj = {
      user_id,
      org_id,
      job_no,
      opened_on,
      send_attachment,
      status,
      status_id: spillStatus.id,
      is_demo,
      is_approved: role !== ROLES.PROB_PM,
      send_email,
      is_emergency,
      job_no_year,
      job_no_month_count,
      facility_id
    };

    const spill = await models.Spills.create(spillObj);
    spill.dataValues = {
      ...spill.dataValues,
      opened_on: spill.opened_on,
      closed_on: spill.closed_on
        ? Moment(spill.closed_on).format("MMMM DD YYYY hh:mm a")
        : "Still Open",
      clientOrgName: org.name,
    };

    let selectedUsersEmail = [];

    const usersForEmail = (users || [])?.map((user) => {
      selectedUsersEmail.push(user?.email);
      return { spill_id: spill.dataValues.id, user_id: user.value };
    });

    const manager = await models.User.findOne({ where: { id: user_id } });
    const recipients = await models.Recipients.bulkCreate(usersForEmail ?? []);

    await createAssignmentNote(
      { ...spill.dataValues, client_organization: org },
      org_id,
      [...(users || []), manager?.dataValues],
      req.user
    );

    if (role === ROLES.PROB_PM) {
      await newAction({
        type: ACTIONS.CREATE_SPILL,
        data: {
          id: spill.dataValues.id,
          jobNo: job_no,
          org_id: spill?.dataValues?.org_id,
        },
        status: "Pending",
        manager_id,
        user_id: req.user.id,
        models,
      });
    }

    // Add a status of spill being created to the status history table
    const currentCSTDate = Moment.utc(new Date())?.tz("America/Rankin_Inlet");
    const started_at = currentCSTDate?.format("YYYY-MM-DD HH:mm:ss");

    const create_new_spill_status_history = `
      INSERT INTO spill_statuses_history
        (
        spill_id,
        job_no,
        status,
        started_at,
        user_id,
        user_name,
        user_role,
        created_at,
        updated_at,
        is_status_automated
        )
        VALUES
        (
         ${spill?.dataValues?.id},
         '${job_no}',
         '${status}',
         '${started_at}',
         ${user_id},
         '${user_name}',
         '${role}',
         '${started_at}',
         '${started_at}',
         '1'
        )
      `;

    await sequelize.query(create_new_spill_status_history);

    res.status(200).json({
      data: { spill, admin: [] },
    });
  } catch (err) {
    console.log(err);
    let message;
    switch (err.message) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};

export const createAssignmentNote = async (
  spill_obj,
  org_id,
  recipients,
  sendEmailFrom
) => {
  const associatedService = await findAssociatedServices(
    org_id,
    CONSTANTS.ASSIGNMENT_SERVICE_NAME
  );

  const serviceType = associatedService[0]?.dataValues?.type || null;

  if (!associatedService?.length) return;
  const note = generateAutoServiceNote(
    associatedService[0].dataValues,
    associatedService[0].service.dataValues.id,
    sendEmailFrom.dataValues.id,
    CONSTANTS.ASSIGNMENT_SERVICE_NAME,
    { serviceType }
  );
  const changes = getAddedObj(note);

  createNote([note], spill_obj.id, [], [], []);

  if (!recipients.length) return;
  const dataForEmail = {
    sendEmailTo: recipients.map((recipient) => recipient?.email),
    sendEmailFrom: sendEmailFrom.dataValues.email,
    ...generateHtml(
      {
        changes,
        spillObj: spill_obj,
        userName: sendEmailFrom.dataValues.full_name,
        note,
      },
      ACTIONS.ADD_NOTE
    ),
  };
  // Check if the test spill has send_email true only then send emails
  if (spill_obj?.send_email) {
    genericSender(dataForEmail);
  }
};

export const getSpills = async (req, res) => {
  const {
    id,
    permission,
    role,
    page,
    limit: rowsPerPage,
    userType,
  } = req.query;

  const { limit, offset, current } = pagination(page, { limit: +rowsPerPage });

  let total = 0;

  let order = [["created_at", "DESC"]];

  let include = [
    {
      model: models.ClientOrganizations,
      required: false,
      attributes: ["name"],
    },
  ];

  const spillPermission =
    permission.toString().toLowerCase() === "true" ? true : false;

  let where = { is_approved: true };

  try {
    let spillsData;

    switch (role) {
      case ROLES.CONTRACTOR_USER: {
        let user = await models.User.findOne({
          where: { id },
        });
        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = {
            ...where,
            "$connections.spill_contractors.address_id$":
              user.contractor_address_id,
          };
          /* 
        In where condistion OR clause is added because 
        when contractor is inactive and it have not performed 
        any activity then it will not show in the contractor listing
        Further groupby is added to avoid duplicate listings
        */
          where = {
            ...where,
            "$connections.spill_contractors.contractor.id$": user.contractor_id,

            $and: [
              {
                $or: [
                  {
                    "$connections.spill_contractors.is_inactive$": false,
                  },
                  {
                    "$connections.spill_contractors.is_inactive$": null,
                  },
                  {
                    "$connections.spill_contractors.activity_performed$": true,
                  },
                ],
              },
              {
                $or: [
                  {
                    "$connections.spill_contractors.accepted$": true,
                  },
                ],
              },
            ],
          };
        }

        if (userType === USER_TYPE.GENERAL) {
          where = {
            ...where,
            job_no: {
              $and: [
                {
                  $notLike: "TEMP%",
                },
                {
                  $notLike: "%TEST%",
                },
              ],
            },
          };
        }

        let spills = await models.Spills.findAndCountAll({
          subQuery: false,
          include: [
            ...include,
            {
              model: models.Connections,
              required: false,
              as: "connections",
              include: [
                {
                  model: models.SpillContractors,
                  required: false,
                  as: "spill_contractors",
                  where: {
                    contractor_id: user.contractor_id,
                    address_id: user.contractor_address_id,
                  },
                  include: [
                    {
                      model: models.Contractors,
                      as: "contractor",
                      required: false,
                      where: { id: user.contractor_id },
                    },
                  ],
                },
              ],
            },
          ],
          where,
          order,
          limit,
          offset,
          group: [
            `spills.id`,
            `connections.id`,
            `connections->spill_contractors.id`,
          ],
          paranoid: false,
          distinct: true,
        });
        total = spills.count.length;
        spillsData = spills.rows;
        /* filter spills for contractor if thier activity_performed is false 
        and spill contractor is inactive */
        let isAdminToBeRemoved = false;
        for (const [index, spill] of spillsData.entries()) {
          spill.connections[0].spill_contractors.map((item) => {
            if (
              item.activity_performed === false &&
              item.is_inactive === true
            ) {
              isAdminToBeRemoved = true;
            } else {
              isAdminToBeRemoved = false;
            }
          });
          if (isAdminToBeRemoved) {
            spillsData.splice(index, 1);
          }
        }
        break;
      }
      case ROLES.CONTRACTOR_ADMIN: {
        let user = await models.User.findOne({
          where: { id },
        });
        /* 
        In where condistion OR clause is added because 
        when contractor is inactive and it have not performed 
        any activity then it will not show in the contractor listing
        Further groupby is added to avoid duplicate listings
        */
        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = {
            ...where,
            "$connections.spill_contractors.contractor.id$": user.contractor_id,

            $and: [
              {
                $or: [
                  {
                    "$connections.spill_contractors.is_inactive$": false,
                  },
                  {
                    "$connections.spill_contractors.is_inactive$": null,
                  },
                  {
                    "$connections.spill_contractors.activity_performed$": true,
                  },
                ],
              },
              {
                $or: [
                  {
                    "$connections.spill_contractors.accepted$": true,
                  },
                ],
              },
            ],
          };
        }

        if (userType === USER_TYPE.GENERAL) {
          where = {
            ...where,
            job_no: {
              $and: [
                {
                  $notLike: "TEMP%",
                },
                {
                  $notLike: "%TEST%",
                },
              ],
            },
          };
        }

        let spills = await models.Spills.findAndCountAll({
          subQuery: false,
          include: [
            ...include,
            {
              model: models.Connections,
              required: false,
              as: "connections",
              include: [
                {
                  model: models.SpillContractors,
                  required: false,
                  as: "spill_contractors",
                  where: { contractor_id: user.contractor_id },
                  include: [
                    {
                      model: models.Contractors,
                      as: "contractor",
                      required: false,
                      where: { id: user.contractor_id },
                    },
                  ],
                },
              ],
            },
          ],
          where,
          group: [
            `spills.id`,
            `connections.id`,
            `connections->spill_contractors.id`,
          ],
          order,
          limit,
          offset,
          paranoid: false,
          distinct: true,
        });
        total = spills.count.length;
        spillsData = spills.rows;
        /* filter spills for contractor if thier activity_performed is false 
        and spill contractor is inactive */
        let isAdminToBeRemoved = false;
        for (const [index, spill] of spillsData.entries()) {
          spill.connections[0].spill_contractors.map((item) => {
            if (
              item.activity_performed === false &&
              item.is_inactive === true
            ) {
              isAdminToBeRemoved = true;
            } else {
              isAdminToBeRemoved = false;
            }
          });
          if (isAdminToBeRemoved) {
            spillsData.splice(index, 1);
          }
        }
        break;
      }

      case ROLES.CORPORATE_USER || ROLES.CONTRACTOR_ADMIN: {
        let user = await models.User.findOne({
          where: { id },
        });

        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = { ...where, org_id: user.org_id };
        }

        if (userType === USER_TYPE.GENERAL) {
          where = {
            ...where,
            job_no: {
              $and: [
                {
                  $notLike: "TEMP%",
                },
                {
                  $notLike: "%TEST%",
                },
              ],
            },
          };
        }

        let spills = await models.Spills.findAndCountAll({
          include,
          where,
          order,
          limit,
          offset,
          paranoid: false,
          distinct: true,
        });

        total = spills.count;
        spillsData = spills.rows;

        break;
      }
      default:
        if (spillPermission) {
          let user = await models.User.findOne({
            where: { id },
          });

          let associatedOrgs = await models.AssociatedOrganizations.findAll({
            where: {
              org_id: user?.org_id,
            },
          });

          let associated_orgs = [user.org_id];

          associatedOrgs.map((associatedOrgs) => {
            associated_orgs.push(associatedOrgs.associated_org_id);
          });

          if (role === ROLES.DEMO) {
            where = { ...where, is_demo: true };
          } else {
            where = { ...where, is_demo: false };
            where = { ...where, org_id: { $in: associated_orgs } };
          }

          if (userType === USER_TYPE.GENERAL) {
            where = {
              ...where,
              job_no: {
                $and: [
                  {
                    $notLike: "TEMP%",
                  },
                  {
                    $notLike: "%TEST%",
                  },
                ],
              },
            };
          }

          let spills = await models.Spills.findAndCountAll({
            include,
            where,
            order,
            limit,
            offset,
            paranoid: false,
          });

          total = spills.count;
          spillsData = spills.rows;
        } else {
          if (role === ROLES.DEMO) {
            where = { ...where, is_demo: true };
          } else {
            where = { ...where, is_demo: false };
          }

          if (userType === USER_TYPE.GENERAL) {
            where = {
              ...where,
              job_no: {
                $and: [
                  {
                    $notLike: "TEMP%",
                  },
                  {
                    $notLike: "%TEST%",
                  },
                ],
              },
            };
          }

          let spills = await models.Spills.findAndCountAll({
            include,
            where,
            order,
            limit,
            offset,
            paranoid: false,
          });

          total = spills.count;
          spillsData = spills.rows;
        }
    }

    // const total = Math.ceil(spillsData.count / limit) || 0;

    spillsData = spillsData.map((spill) => {
      let closedOn;

      const searchStatusString = spill?.status?.search("Open");

      if (spill.closed_on && searchStatusString != -1) {
        closedOn = "Re-Opened";
      } else {
        closedOn = spill.closed_on || "Still Open";
      }

      spill.dataValues = {
        ...spill.dataValues,
        opened_on: spill.opened_on,
        closed_on: closedOn,
      };
      return spill;
    });

    res.status(200).json({
      data: spillsData,
      pagination: {
        current: current > total ? total : current,
        total,
      },
    });
  } catch (err) {
    console.log(err);
  }
};

export const getMySpills = async (req, res) => {
  const { page, id, permission, role, userType } = req.query;

  const { limit, offset, current } = pagination(page);

  let where = {};

  where = {
    "$recipients.user_id$": id,
  };

  if (userType === USER_TYPE.GENERAL) {
    where = {
      ...where,
      job_no: {
        $and: [
          {
            $notLike: "TEMP%",
          },
          {
            $notLike: "%TEST%",
          },
        ],
      },
    };
  }

  try {
    let spills = await models.Spills.findAll({
      include: [
        {
          model: models.Recipients,
          required: false,
          include: [
            {
              model: models.User,
              required: false,
            },
          ],
        },
        {
          model: models.Reserves,
          required: false,
          include: [
            {
              model: models.User,
              required: false,
            },
          ],
        },
        {
          model: models.User,
          required: false,
        },
        {
          model: models.ClientOrganizations,
          required: false,
        },
        {
          model: models.SpillNotes,
          required: false,
        },
        {
          model: models.SpillMaterial,
          required: false,
          attributes: ["name"],
        },
      ],
      where,
      paranoid: false,
    });

    spills = spills.map((spill) => {
      let closedOn;

      const searchStatusString = spill?.status?.search("Open");

      if (spill.closed_on && searchStatusString != -1) {
        closedOn = "Re-Opened";
      } else {
        closedOn = spill.closed_on
          ? Moment(spill.closed_on).format("MMMM DD YYYY hh:mm a")
          : "Still Open";
      }

      spill.dataValues = {
        ...spill.dataValues,
        opened_on: spill.opened_on,
        closed_on: closedOn,
        clientOrgName: spill.dataValues.client_organization.dataValues.name,
        managerName: spill.dataValues.user.dataValues.full_name,
      };
      delete spill.dataValues.client_organization;
      delete spill.dataValues.user;
      return spill;
    });

    res.status(200).json({
      data: spills,
    });
  } catch (err) {
    console.log(err);
  }
};

const createSpillContractors = async (id, obj) => {
  let spillContractorToCreate = [];
  let spillContractorRole = "";
  obj.map((contractor) => {
    if (contractor.addressId) {
      spillContractorRole = "Sub Contractor";
    } else {
      spillContractorRole = "Head Contractor";
    }

    contractor.accepted !== false &&
      spillContractorToCreate.push({
        connection_id: id,
        contractor_id: contractor.contractor_id,
        address_id: contractor.addressId || null,
        is_inactive: contractor.is_inactive,
        accepted: contractor.accepted,
        contractor_role: spillContractorRole,
      });
  });
  incrementResponseCount(spillContractorToCreate);
  await models.SpillContractors.bulkCreate(spillContractorToCreate);
};

const editSpillContractors = async (
  id,
  spillContractors,
  userId,
  spillId,
  userFullName
) => {
  // 1. Populate the new Spill Contractors array
  // 2. Check which contractors were there previously, but have been marked inactive now.
  // 3. Remove the old Spill Contractors. This is our solution to replace.
  // 4. Create a removal note for the contractors
  let toCreate = [];
  let newInactive = [];
  let accepted = [];
  let spillContractorRole = "";

  const previousContractors = await models.SpillContractors.findAll({
    where: {
      connection_id: id,
    },
  });

  for (const contractor of spillContractors) {
    let index = previousContractors.findIndex(
      (o) =>
        o.dataValues.contractor_id === contractor.contractor_id &&
        ((!contractor.addressId && !o.dataValues.address_id) ||
          o.dataValues.address_id === contractor.addressId)
    );
    if (index !== -1) {
      if (!previousContractors[index].is_inactive && contractor.is_inactive) {
        newInactive = [...newInactive, contractor];
      }
      if (
        contractor.accepted === true &&
        previousContractors[index].accepted === null
      ) {
        accepted.push(contractor);
      }
    } else {
      if (contractor.accepted) {
        accepted.push(contractor);
      }
    }

    if (contractor.addressId) {
      spillContractorRole = "Sub Contractor";
    } else {
      spillContractorRole = "Head Contractor";
    }

    contractor.accepted !== false &&
      toCreate.push({
        ...contractor,
        connection_id: id,
        accepted: contractor.accepted,
        contractor_id: contractor.contractor_id,
        address_id: contractor.addressId || null,
        is_inactive: contractor.is_inactive,
        contractor_role: spillContractorRole,
      });
  }

  await models.SpillContractors.destroy({
    where: {
      connection_id: id,
    },
    paranoid: false,
    force: true,
  });
  incrementResponseCount(accepted);
  await models.SpillContractors.bulkCreate(toCreate);

  createRemovalNotes(newInactive, userId, spillId, userFullName);
};

const createConnection = async (spillId, obj, spillContractors) => {
  const agencyId = obj.agencyId;

  const connectionToCreate = {
    spill_id: spillId,
    agency_national: obj?.agencyNational?.id || obj?.agencyNational,
    incident_no: obj.nationalIncidentNo,
    agency_id: agencyId,
    state_incident_no: obj.stateIncidentNo,
  };
  Object.keys(connectionToCreate).forEach(
    (k) => !(connectionToCreate[k] !== "") && delete connectionToCreate[k]
  );
  try {
    const connection = await models.Connections.create(connectionToCreate);
    if (spillContractors) {
      await createSpillContractors(connection?.id, spillContractors);
    }
    return connection;
  } catch (error) {
    console.log(error);
  }
};

const editConnection = async (
  spillId,
  connection,
  spillContractors,
  userId,
  userFullName
) => {
  const agencyId = connection?.agencyId;

  const connectionToEdit = {
    spill_id: spillId,
    agency_national:
      connection?.agencyNational?.id || connection?.agencyNational,
    incident_no: connection?.incidentNo || null,
    agency_id: agencyId,
    state_incident_no: connection?.stateIncidentNo || null,
  };

  Object.keys(connectionToEdit).forEach(
    (k) => !(connectionToEdit[k] !== "") && delete connectionToEdit[k]
  );

  try {
    const newConnection = await models.Connections.update(connectionToEdit, {
      where: {
        id: connection?.connectionId,
      },
    });

    if (Array.isArray(spillContractors)) {
      await editSpillContractors(
        connection?.connectionId,
        spillContractors,
        userId,
        spillId,
        userFullName
      );
    }

    return newConnection;
  } catch (error) {
    console.log(error);
  }
};

// Update Admins Data
const editAdmins = async (spillId, admins, jobNo, user, isNewFileReplaced) => {
  let newAdmins = [];
  let attachments = [];
  let attachmentContractors = [];
  let attachmentToDelete = [];
  let newComplete = [];
  let allComplete = true;
  let rejectCount = 0;
  let isAllApproved = true;
  let isAllComplete = [];

  for (const index in admins) {
    let finalInvoiceAmount = null;

    if (admins[index]?.attachments?.length) {
      for (const attachment of admins[index]?.attachments) {
        if (
          attachment.status === CONSTANTS.APPROVED &&
          attachment.type === CONSTANTS.CONTRACTOR_INV_TYPE_NAME
        ) {
          finalInvoiceAmount += attachment.inv_amount;
        }
      }
    }

    newAdmins.push({
      spill_id: spillId,
      info: admins[index].info,
      pix: admins[index].pix,
      spill_summary: admins[index].spillSummary,
      contractor_inv: admins[index].contractorInv,
      waste_doc: admins[index].wasteDoc,
      contractor_invoice: admins[index].contractorInvoice,
      inv_no: admins[index].invNo,
      final_contractor_invoice: finalInvoiceAmount,
      pes_inv_no: admins[index].pesInvNo,
      pes_inv_amount: admins[index].pesInvAmount,
      savings: admins[index].savings,
      pes_paid: admins[index].pesPaid || null,
      contractor_paid: admins[index].contractorPaid || null,
      trans_to_ct: admins[index].transToCt || null,
      pay_by: admins[index].payBy || null,
      response_time: admins[index].responseTime,
      contractor_id: admins[index].contractorId,
      contractor_address_id: admins[index].contractorAddressId || null,
      is_removed: admins[index].isRemoved,
      is_main: admins[index].isMain,
      is_complete: admins[index].isComplete,
      status: admins[index].status,
      reject_reason: admins[index].rejectReason,
      is_not_required: admins[index]?.isNotRequiredCheck,
    });

    if (!admins[index].isRemoved && !admins[index].isComplete) {
      isAllComplete.push(false);
    }

    if (admins[index].isRemoved && !admins[index].isComplete) {
      isAllComplete.push(false);
    }

    if (!admins[index].isRemoved && admins[index].isComplete) {
      isAllComplete.push(true);
    }

    if (admins[index].adminId) {
      newAdmins[index]["id"] = admins[index].adminId;
      if (admins[index].isComplete) {
        const prevAdmin = await models.SpillAdmins.findOne({
          where: { id: admins[index].adminId },
        });
        if (!prevAdmin?.dataValues?.is_complete) {
          newComplete.push(admins[index]);
        }
      }
    }
    if (admins[index].attachments) {
      for (const attachment of admins[index].attachments) {
        if (attachment?.status !== "approve") {
          isAllApproved = false;
        }
        if (attachment.isDelete) {
          attachmentToDelete = [...attachmentToDelete, attachment.id];
        } else {
          attachments = [...attachments, attachment];
          attachmentContractors = [
            ...attachmentContractors,
            admins[index].contractorId,
          ];
        }
      }
    }
  }

  allComplete = isAllComplete?.every((item) => item === true);

  try {
    const rejectedDocs = [];
    for (let i = 0, length = attachments.length; i < length; i++) {
      if (attachments[i].id && attachments[i].status === "reject") {
        rejectCount++;
        const prevAttachment = await models.SpillAttachments.findOne({
          where: { id: attachments[i].id },
        });

        const spillAdmin = await models.SpillAdmins.findOne({
          where: { id: prevAttachment?.dataValues?.spill_admin_id },
        });

        // Check if the admin is removed then don't count that's admins activity
        if (spillAdmin?.dataValues?.is_removed !== true) {
          // Check if rejected count is greater for a file the update rejected docs array
          if (
            prevAttachment.dataValues.status === "reject" ||
            rejectCount > 0
          ) {
            if (attachments[i].first_time_rejection) {
              rejectedDocs.push({
                attachment: attachments[i],
                id: attachmentContractors[i],
              });
            }
          }
        }
      }
    }

    if (rejectedDocs?.length === 0) {
      rejectCount = 0;
    }

    if (isNewFileReplaced === false) {
      sendAttachmentRejectionEmail(rejectedDocs, jobNo, user);
    }

    const spillAttachmentLogsToUpdate = [];
    if (attachments?.length) {
      await models.SpillAttachments.bulkCreate(attachments, {
        updateOnDuplicate: ["status", "admin_note", "name", "updated_at"],
      });

      for (let i = 0; i < attachments?.length; i++) {
        const foundAttachmentLog = await models.SpillAttachmentLogs.findAll({
          attributes: ["status"],
          where: {
            spill_attachment_id: attachments[i]?.id,
          },
          order: [["created_at", "DESC"]],
          limit: 1,
        });

        if (foundAttachmentLog[0]?.status !== attachments[i]?.status) {
          spillAttachmentLogsToUpdate.push({
            spill_attachment_id: attachments[i]?.id,
            status: attachments[i]?.status,
            spill_admin_id: attachments[i]?.spill_admin_id,
            type: attachments[i]?.type,
          });
        }
      }
    }

    if (spillAttachmentLogsToUpdate?.length) {
      await models.SpillAttachmentLogs.bulkCreate(spillAttachmentLogsToUpdate);
    }

    for (const index in admins) {
      if (admins[index]?.adminId) {
        /* fetch all spill admins attachments based on admin id*/
        const fetchAdminAttachmentsWithSavings = `
        SELECT * FROM spill_attachments 
        WHERE spill_admin_id=${admins[index]?.adminId} and name like 'Final Contractor Invoice'
        order by updated_at asc;
      `;

        const fetchedAdminAttachmentsWithSavings = await sequelize.query(
          fetchAdminAttachmentsWithSavings
        );

        const adminSavingsToBeUpdated =
          fetchedAdminAttachmentsWithSavings[0][0]?.savings;

        /* check if any of the attachment name is Final Contractor Invoice */
        const adminAttachmentsHaveFinalContractorInvoice = fetchedAdminAttachmentsWithSavings[0]?.some(
          (attachment) => attachment?.name === "Final Contractor Invoice"
        );

        const fetchAdmin = `
        SELECT * FROM spill_admins
        WHERE id=${admins[index]?.adminId} AND spill_id=${spillId};
      `;

        const fetchedAdmin = await sequelize.query(fetchAdmin);

        /* check if admin savings to be added is present and 
        FCI attachment does exist */

        if (
          adminSavingsToBeUpdated &&
          adminAttachmentsHaveFinalContractorInvoice
        ) {
          /* check if admin savings exist */
          if (
            !fetchedAdmin[0][0]?.savings ||
            fetchedAdmin[0][0]?.savings?.length === 0
          ) {
            /* check if admin being modified is same for updating savings*/
            if (newAdmins[index]["id"] === admins[index]?.adminId) {
              newAdmins[index]["savings"] = `${adminSavingsToBeUpdated}`;
              let updateSpillAdminAttachmentSavings = `
                UPDATE spill_admins
                SET savings='${adminSavingsToBeUpdated}'
                WHERE id=${admins[index]?.adminId} AND spill_id=${spillId};
              `;
              await sequelize.query(updateSpillAdminAttachmentSavings);
            }
          }
        }
      }
    }

    await models.SpillAttachments.destroy({
      where: {
        id: attachmentToDelete,
      },
      paranoid: true,
    });

    for (const admin of newAdmins) {
      const where = {
        contractor_id: admin.contractor_id,
        contractor_address_id: admin.contractor_address_id,
        spill_id: admin.spill_id,
      };

      let result = await models.SpillAdmins.findOne({ where: where });

      if (result) {
        await models.SpillAdmins.update(admin, {
          where: where,
        });
      } else {
        await models.SpillAdmins.create(admin);
      }
    }

    const returnedAdmins = await models.SpillAdmins.findAll({
      include: [
        {
          model: models.SpillAttachments,
          attributes: ["id"],
        },
      ],
      where: { spill_id: spillId },
    });

    return [
      returnedAdmins,
      newComplete,
      allComplete,
      rejectedDocs.length > 0 ? true : false,
      rejectCount,
      isAllApproved && !!attachmentContractors?.length,
    ];
  } catch (error) {
    console.log(error);
  }
};

const editRecipients = async (obj, id) => {
  const users = await models.Recipients.destroy({
    where: {
      spill_id: id,
    },
    paranoid: true,
  });
  const usersToCreate = obj.map((user) => {
    return { user_id: user.value, spill_id: id };
  });
  await models.Recipients.bulkCreate(usersToCreate);
};

export const createNote = async (obj, id, files, noteFileData, videoFiles) => {
  const customNotes = [];

  let connectionsToBeFetched = false;
  /* Update spill connections national and 
  state incident number of not already existing
  based on services added */
  const fetchStateAndNationalIncidentNo = `
  SELECT incident_no, state_incident_no FROM connections
  WHERE spill_id=${id} AND deleted_at IS NULL;
  `;

  const fetchedStateAndNationalIncidentNo = await sequelize.query(
    fetchStateAndNationalIncidentNo
  );

  const nationalIncidentNo =
    fetchedStateAndNationalIncidentNo[0][0]?.incident_no;
  const stateIncidentNo =
    fetchedStateAndNationalIncidentNo[0][0]?.state_incident_no;

  if (
    (!stateIncidentNo || stateIncidentNo?.length === 0) &&
    obj[0]?.state_incident_no
  ) {
    const updateStateIncidentNo = `
    UPDATE connections SET state_incident_no = '${obj[0]?.state_incident_no}'
    WHERE spill_id=${id};
    `;
    await sequelize.query(updateStateIncidentNo);
    connectionsToBeFetched = true;
  }

  if (
    (!nationalIncidentNo || nationalIncidentNo?.length === 0) &&
    obj[0]?.incident_no
  ) {
    const updateNationalIncidentNo = `
    UPDATE connections SET incident_no = '${obj[0]?.incident_no}'
    WHERE spill_id=${id};
    `;
    await sequelize.query(updateNationalIncidentNo);
    connectionsToBeFetched = true;
  }

  // Create Note Object
  const noteRecieved = obj.map((note) => {
    if (note.type === "Custom Note") {
      customNotes.push(note);
    }
    let scheduleDate = note?.date ? Moment(note?.date).add(5, "hours") : null;

    return {
      spill_id: id,
      user_id: note.userId,
      amount: note.amount,
      containers: note.containers || [],
      estimated_cost: note.cost,
      date: scheduleDate,
      description: note.description,
      established_lane_closure: note.establishLaneClosure,
      excavation_begun: note.excavationBegun,
      excavation_completed: note.excavationCompleted,
      hour: note.hour,
      ip_address_identifier: note.ipAddressIdentifier,
      owner: note.owner,
      rate: note.rate,
      report_no: note.reportNo,
      no_of_samples: note.samples,
      service_id: note.serviceId,
      service_type: note.serviceType,
      task_associated_relevance: note.taskAssociatedRelevance,
      time: note.time,
      type: note.type,
      projected_eta: note.projected_eta,
      actual_eta: note.actual_eta,
      excavation_time: note.excavation_time,
      incident_no: note.incident_no,
      state_incident_no: note.state_incident_no,
    };
  });

  try {
    let noteData = [];

    let index = 0;
    let containerIndex = [];

    const noteToCreate = noteRecieved.map((note) => {
      Object.keys(note).forEach(
        (k) => !(note[k] !== "" && note[k] !== null) && delete note[k]
      );
      if (note.containers.length === 0) {
        delete note.containers;
      } else {
        containerIndex.push(index);
      }
      index++;
      return note;
    });
    const noteWithContainers = [];
    if (containerIndex.length > 0) {
      for (let i = 0; i < containerIndex.length; i++) {
        noteWithContainers.push(noteToCreate[containerIndex[i]]);
      }
      noteWithContainers.forEach((p) =>
        noteToCreate.splice(noteToCreate.indexOf(p), 1)
      );
    }

    let actualCalculatedETA = 0;

    if (noteToCreate.length > 0) {
      const spillId = id;
      const serviceId = noteToCreate[0]?.service_id;
      const fetchDispatchedContractorServiceNotes = `
        SELECT * FROM spill_notes WHERE
        spill_id=${spillId} 
        AND service_id=${17}
        AND deleted_at IS NULL
        ORDER BY created_at ASC;
      `;
      const fetchArrivedOnSiteServiceNote = `
        SELECT * FROM spill_notes 
        WHERE spill_id=${spillId}
        AND service_id=${30} 
        AND deleted_at IS NULL 
        ORDER BY created_at ASC LIMIT 1;
      `;

      // Arrived on Site Service:
      if (serviceId === 30) {
        // Case 1: Contractor Arrived on Site Service Added Initially:
        const [
          fetchedDispatchedContractorServiceNote,
          fetchedArrivedOnSiteServiceNote,
        ] = await Promise.all([
          sequelize.query(fetchDispatchedContractorServiceNotes),
          sequelize.query(fetchArrivedOnSiteServiceNote),
        ]);

        const noPreviousArrivedServiceExist =
          fetchedArrivedOnSiteServiceNote[0]?.length === 0;
        const arrivedServiceAlreadyExist =
          fetchedArrivedOnSiteServiceNote[0]?.length >= 1;
        const arrivedServices = fetchedArrivedOnSiteServiceNote[0];

        /* Case 2: Check if no previous Contractor Arrived on Site Service Added 
        then differ from initial dispatch service and run this case initally:
        */
        if (noPreviousArrivedServiceExist) {
          const initialDispatchedServiceCreatedAtTime =
            fetchedDispatchedContractorServiceNote[0][0]?.created_at;
          // Check if inital dispatch service time exists then calculate incoming note actual eta
          if (initialDispatchedServiceCreatedAtTime) {
            actualCalculatedETA = convertDateDiffIntoHours(
              initialDispatchedServiceCreatedAtTime,
              null
            );
          } else {
            actualCalculatedETA = null;
          }
        }

        /* Case 3: Check if Contractor Arrived on Site Service already 
        exists then do not calculate incoming note actual eta
         */
        if (arrivedServiceAlreadyExist) {
          const actualETAExists = arrivedServices?.some(
            (service) => service?.actual_eta !== null
          );
          // Check if actual eta is already calculated for any service added previously
          if (actualETAExists) {
            actualCalculatedETA = null;
          } else {
            const initialDispatchedServiceCreatedAtTime =
              fetchedDispatchedContractorServiceNote[0][0]?.created_at;

            actualCalculatedETA = convertDateDiffIntoHours(
              initialDispatchedServiceCreatedAtTime,
              null
            );
          }
        }
      }

      await Promise.all(
        noteToCreate.map(async (note, index) => {
          let updatedNoteObj = {};
          // Check if actual calculated eta is not null so add it inside the object
          if (actualCalculatedETA !== 0) {
            updatedNoteObj = { ...note, actual_eta: actualCalculatedETA };
          } else {
            updatedNoteObj = { ...note };
          }

          const noteCreated = await models.SpillNotes.create(updatedNoteObj);
          adjustSpillTotal(id, null, note.amount);
          noteData.push(noteCreated.dataValues);

          let relatedFiles = [];
          for (const fileIndex in files) {
            let noteIndex = noteFileData[fileIndex].noteIndex;
            if (noteIndex === index) {
              relatedFiles.push(files[fileIndex]);
            }
          }
          if (relatedFiles.length > 0) {
            await createAttachment(
              relatedFiles,
              noteCreated.id,
              id,
              videoFiles
            );
          }

          return;
        })
      );
    }
    if (noteWithContainers.length > 0) {
      for (const [index, note] of noteWithContainers.entries()) {
        let noteContainers = note.containers;
        delete note.containers;
        let updatedNoteObj = {};
        // Check if actual calculated eta is not null so add it inside the object
        if (actualCalculatedETA !== 0) {
          updatedNoteObj = { ...note, actual_eta: actualCalculatedETA };
        } else {
          updatedNoteObj = { ...note };
        }

        const noteCreated = await models.SpillNotes.create(updatedNoteObj);
        noteData.push(noteCreated.dataValues);
        noteContainers = noteContainers.map((container) => {
          return {
            ...container,
            note_id: noteCreated.id,
          };
        });
        await models.SalvageContainers.bulkCreate(noteContainers);
        let relatedFiles = [];
        for (const fileIndex in files) {
          let noteIndex = noteFileData[fileIndex].noteIndex;

          if (noteIndex === index) {
            relatedFiles.push(files[fileIndex]);
          }
        }
        if (relatedFiles.length > 0) {
          await createAttachment(relatedFiles, noteCreated.id, id, videoFiles);
        }
      }
    }
    return [noteData, customNotes, connectionsToBeFetched];
  } catch (error) {
    console.log(error);
  }
};

//Function to upload the files of Notes in Spills
const createAttachment = async (files, note_id, spillId, videoFiles) => {
  try {
    let attachments = [];
    let attachmentsToBeRemovedPathList = [];
    for (let file of files) {
      const data = await uploadFileToS3Bucket(
        file.path,
        `${spillId}/notes/${note_id}/${file.originalname.split("#")[1]}`
      );
      console.log("General File path=", file.path);
      attachments.push({
        name: file.originalname.split("#")[1],
        url_link: data.Location,
        key: data.key || data.Key,
        spill_note_id: note_id,
        size: file.size,
        status: data.Location ? "uploaded" : "queued",
      });
      attachmentsToBeRemovedPathList.push(file?.path);
    }

    if (videoFiles?.length > 0) {
      for (let videoFile of videoFiles) {
        attachments.push({
          name: videoFile.originalname.split("#")[1],
          url_link: null,
          key: null,
          spill_note_id: note_id,
          size: videoFile.size,
          status: "queued",
        });
        attachmentsToBeRemovedPathList.push(videoFile?.path);
      }
    }

    for (let attachmentPath of attachmentsToBeRemovedPathList) {
      fs.unlinkSync(attachmentPath);
    }

    await models.NoteAttachments.bulkCreate(attachments);
  } catch (err) {
    console.log("Error: ", err);
  }
};

export const getNoteHistory = async (req, res) => {
  const { spillId } = req.query;

  try {
    const history = await models.SpillNotesHistory.findAll({
      where: { spill_id: spillId, deleted_at: null },
    });
    res.status(200).json({
      data: history,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getContractorHistory = async (req, res) => {
  const { spillId } = req.query;

  try {
    const history = await models.ContractorHistory.findAll({
      where: { spill_id: spillId, deleted_at: null },
    });
    res.status(200).json({
      data: history,
    });
  } catch (err) {
    console.log(err);
  }
};

export const createSingleNote = async (req, res) => {
  try {
    const files = req.files;
    const noteGeneralAttachmentFiles = files.filter(
      (file) => !file?.mimetype.includes("video")
    );
    const noteVideoAttachmentFiles = files?.filter((file) =>
      file?.mimetype.includes("video")
    );
    const noteFiles = noteGeneralAttachmentFiles?.filter((file) =>
      file.originalname.includes("note")
    );

    const isAppendNoteLast = JSON.parse(req.body.isAppendNoteLast);
    const noteToCreate = JSON.parse(req.body.noteToCreate);
    const noteFileData = JSON.parse(req.body.noteFileData);
    const sendEmail = JSON.parse(req.body.sendEmail);
    const serviceId = noteToCreate.serviceId;
    const spillId = req.body.spillId;

    const spillObj = getDataValues(
      await models.Spills.findOne({
        where: { id: spillId },
        include: [
          {
            model: models.Recipients,
            required: false,
            include: [
              {
                model: models.User,
                required: false,
                include: [
                  {
                    model: models.UserServicesNotifications,
                    required: false,
                  },
                  {
                    model: models.ClientOrganizations,
                    required: false,
                    include: [
                      {
                        model: models.ClientOrganizationServices,
                        required: false,
                        include: [
                          {
                            model: models.Services,
                            required: false,
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            model: models.ClientOrganizations,
            required: false,
          },
          {
            model: models.User,
            required: false,
          },
        ],
      })
    );

    const services = await models.Services.findOne({
      where: { id: serviceId },
      attributes: ["name", "email_notifications"],
    });

    let emailList = [];
    const send_email = spillObj?.send_email;
    const over_watch = spillObj?.watched;

    if (sendEmail) {
      const recipients = spillObj?.recipients;
      if (recipients?.length > 0) {
        for (const recipient of recipients) {
          const userServicesNotifications =
            recipient?.user?.user_services_notifications;
          const userClientOrganizationServices =
            recipient?.user?.client_organization?.client_organization_services;
          if (userServicesNotifications?.length > 0) {
            for (const serviceNotification of userServicesNotifications) {
              for (const clientOrganizationService of userClientOrganizationServices) {
                if (
                  serviceId === serviceNotification?.service_id &&
                  serviceId === clientOrganizationService?.service?.id
                ) {
                  if (serviceNotification?.notification) {
                    emailList.push(recipient?.user?.email);
                  }
                }
              }
            }
          } else {
            for (const clientOrganizationService of userClientOrganizationServices) {
              if (serviceId === clientOrganizationService?.service?.id) {
                if (clientOrganizationService?.service?.email_notifications) {
                  emailList.push(recipient?.user?.email);
                }
              }
            }
          }
        }
      }

      const changes = {
        changes: getAddedObj(noteToCreate),
        files: noteFiles.map((file) => file.originalname.replace("note#", "")),
      };

      // PM:
      if (services?.dataValues?.email_notifications) {
        emailList.push(spillObj?.user?.email);
      }

      let uniqueEmailList = [...new Set(emailList)];

      const attachmentsList = spillObj.send_attachment
        ? noteFiles.map((noteFile) => {
            return {
              filename: noteFile.originalname.replace("note#", ""),
              path: noteFile.path,
            };
          })
        : [];

      if (over_watch) {
        uniqueEmailList?.push(OVERWATCH_EMAIL);
      }

      const dataForEmail = {
        sendEmailTo: uniqueEmailList,
        sendEmailFrom: req.user.email,
        ...generateHtml(
          {
            ...changes,
            userName: req.user.full_name,
            spillObj,
            note: noteToCreate,
          },
          ACTIONS.ADD_NOTE
        ),

        attachments: attachmentsList,
      };
      // Check if the test spill has send_email true only then send emails
      if (send_email) {
        genericSender(dataForEmail);
      }
    } else {
      const changes = {
        changes: getAddedObj(noteToCreate),
        files: noteFiles.map((file) => file.originalname.replace("note#", "")),
      };

      // PM:
      if (services?.dataValues?.email_notifications) {
        emailList.push(spillObj?.user?.email);
      }

      let uniqueEmailList = [...new Set(emailList)];

      const attachmentsList = spillObj.send_attachment
        ? noteFiles.map((noteFile) => {
            return {
              filename: noteFile.originalname.replace("note#", ""),
              path: noteFile.path,
            };
          })
        : [];

      if (over_watch) {
        uniqueEmailList?.push(OVERWATCH_EMAIL);
      }

      const dataForEmail = {
        sendEmailTo: uniqueEmailList,
        sendEmailFrom: req.user.email,
        ...generateHtml(
          {
            ...changes,
            userName: req.user.full_name,
            spillObj,
            note: noteToCreate,
          },
          ACTIONS.ADD_NOTE
        ),

        attachments: attachmentsList,
      };
      // Check if the test spill has send_email true only then send emails
      if (send_email) {
        genericSender(dataForEmail);
      }
    }

    const resp = await createNote(
      [noteToCreate],
      spillId,
      noteFiles,
      noteFileData,
      noteVideoAttachmentFiles
    );

    const attachments = await models.NoteAttachments.findAll({
      where: { spill_note_id: resp[0][0].id },
    });

    const salvage_containers = await models.SalvageContainers.findAll({
      where: { note_id: resp[0][0].id },
    });

    const connectionsFetched = resp[2];

    // Update spill connections on note creation
    let connectionsToDisplay = {};
    if (connectionsFetched) {
      const fetchUpdatedConnections = `
      SELECT * FROM connections 
      WHERE spill_id=${spillId} AND deleted_at IS NULL;
      `;

      const fetchedUpdatedConnections = await sequelize.query(
        fetchUpdatedConnections
      );

      connectionsToDisplay = fetchedUpdatedConnections[0][0];
    }

    res.json({
      success: true,
      data: {
        connection: { ...connectionsToDisplay },
        note: {
          ...resp[0][0],
          note_attachments: attachments,
          salvage_containers: salvage_containers,
          append_last: isAppendNoteLast,
        },
      },
    });
  } catch (error) {
    console.log("Error ::", error);
    res.status(500).send();
  }
};

export const createAttachmentDeletedNote = async (
  spill_obj,
  org_id,
  recipients,
  sendEmailFrom,
  deletedAttachments,
  noteId,
  ipAddress
) => {
  const associatedService = await models.ClientOrganizationServices.findAll({
    where: {
      org_id,
    },
    include: [
      {
        model: models.Services,
        where: {
          name: CONSTANTS.DELETION_ATTACHMENT_SERVICE_NAME,
        },
        attributes: ["id", "email_notifications"],
      },
    ],
  });

  if (!associatedService?.length) return;

  const note = generateAutoServiceNote(
    associatedService[0].dataValues,
    associatedService[0].service.dataValues.id,
    sendEmailFrom.id,
    CONSTANTS.DELETION_ATTACHMENT_SERVICE_NAME,
    {
      deletedAttachments,
      ipAddress: ipAddress,
      name: sendEmailFrom.full_name,
      noteId,
    }
  );

  const send_email = spill_obj?.send_email;
  const over_watch = spill_obj?.watched;

  createNote([note], spill_obj.id, [], []);

  const emailList = recipients.map((x) => x?.dataValues?.user?.dataValues);

  const filteredEmailList = emailList?.filter(
    (email) => email?.email_notification === true
  );

  const usersToEmail = [];

  filteredEmailList?.map((recipient) => usersToEmail.push(recipient?.email));

  if (
    associatedService[0]?.service?.dataValues?.email_notifications === false
  ) {
    usersToEmail.length = 0;
  }

  if (over_watch) {
    usersToEmail.push(OVERWATCH_EMAIL);
  }

  if (usersToEmail?.length > 0) {
    const dataForEmail = {
      sendEmailTo: usersToEmail,
      sendEmailFrom: sendEmailFrom.email,
      ...generateHtml(
        {
          spillObj: spill_obj,
          userName: sendEmailFrom.full_name,
          noteId,
          deletedAttachments,
          ipAddress,
        },
        ACTIONS.DELETE_ATTACHMENT
      ),
    };
    // Check if the test spill has send_email true only then send emails
    if (send_email) {
      genericSender(dataForEmail);
    }
  }
};

export const editNote = async (req, res, next) => {
  const files = req.files;

  const noteFiles = files.filter((file) => file.originalname.includes("note"));

  let note = JSON.parse(req.body.note);
  const ipAddress = JSON.parse(req.body.ipAddress);

  const { id, spillId } = note;

  let scheduleDate = note?.date ? Moment(note?.date).add(5, "hours") : null;
  let spillNote;

  // Fetch note data for note being updated
  const fetchIntialSpillNoteId = `
  SELECT id, service_id, state_incident_no, incident_no 
  FROM spill_notes 
  WHERE 
  spill_id = ${spillId} AND service_id = ${note.serviceId} 
  AND deleted_at IS NULL 
  ORDER BY created_at ASC LIMIT 1;
  `;

  const fetchedInitalSpillNoteId = await sequelize.query(
    fetchIntialSpillNoteId
  );
  let connectionsToBeFetched = false;
  const fetchedNoteId = fetchedInitalSpillNoteId[0][0]?.id;
  const fetchedNoteServiceId = fetchedInitalSpillNoteId[0][0]?.service_id;
  const fetchedNoteStateIncidentNo =
    fetchedInitalSpillNoteId[0][0]?.state_incident_no;
  const fetchedNoteNationalIncidentNo =
    fetchedInitalSpillNoteId[0][0]?.incident_no;

  // Check if the note id matches with the found note id
  if (id === fetchedNoteId) {
    // Check if the new state incident no exists update in connections
    if (fetchedNoteServiceId === 38 && fetchedNoteStateIncidentNo) {
      if (fetchedNoteStateIncidentNo !== note?.state_incident_no) {
        const updateStateIncidentNo = `
          UPDATE connections SET state_incident_no = '${note?.state_incident_no}'
          WHERE spill_id = ${spillId};
        `;
        await sequelize.query(updateStateIncidentNo);
        connectionsToBeFetched = true;
      }
    }

    // Check if the new national incident no exists update in connections
    if (fetchedNoteServiceId === 21 && fetchedNoteNationalIncidentNo) {
      if (fetchedNoteNationalIncidentNo !== note?.incident_no) {
        const updateNationalIncidentNo = `
        UPDATE connections SET incident_no = '${note?.incident_no}'
        WHERE spill_id = ${spillId};
        `;
        await sequelize.query(updateNationalIncidentNo);
        connectionsToBeFetched = true;
      }
    }
  }

  const noteData = {
    ...note,
    amount: note.amount,
    containers: note.containers || [],
    estimated_cost: note.cost,
    date: scheduleDate,
    description: note.description,
    established_lane_closure: note.establishLaneClosure,
    excavation_begun: note.excavationBegun,
    excavation_completed: note.excavationCompleted,
    hour: note.hour,
    ip_address_identifier: note.ipAddressIdentifier,
    owner: note.owner,
    rate: note.rate,
    report_no: note.reportNo,
    no_of_samples: note.samples,
    service_id: note.serviceId,
    service_type: note.serviceType,
    task_associated_relevance: note.taskAssociatedRelevance,
    time: note.time,
    type: note.type,
    state_incident_no: note.state_incident_no,
    incident_no: note.incident_no,
    projected_eta: note.projected_eta || null,
    actual_eta: note.actual_eta || null,
  };

  const previousNote = await models.SpillNotes.findOne({
    where: { id: note.id },
  });
  adjustSpillTotal(spillId, previousNote, note.amount);
  const previousHistory = await models.SpillNotesHistory.findAll({
    where: { note_id: note.id },
  });
  const changeOwner = await models.User.findOne({
    where: { id: req.user.dataValues.id },
  });
  const noteHistoryObject = getComparedNotes(
    previousNote,
    noteData,
    previousHistory,
    changeOwner.full_name
  );

  const spillObj = await models.Spills.findOne({
    where: { id: spillId },
    include: [{ model: models.ClientOrganizations }],
  });

  const services = await models.Services.findOne({
    where: { id: noteData?.service_id },
    attributes: ["name", "email_notifications"],
  });

  const spill = getDataValues(spillObj);
  const over_watch = spill?.watched;

  if (noteHistoryObject?.length > 0 && note.sendEmail) {
    let changes = [];

    noteHistoryObject.forEach((change, key) => {
      changes.push({
        edited_field: change.edited_field,
        prev_val: change.prev_val,
        new_val: change.new_val,
      });
    });

    // PM:
    const usersToEmail = [];
    if (services?.email_notifications) {
      usersToEmail.push(note.sendEmail);
    }

    if (over_watch) {
      usersToEmail.push(OVERWATCH_EMAIL);
    }

    const dataForEmail = {
      sendEmailTo: usersToEmail,
      sendEmailFrom: req.user.email,
      ...generateHtml(
        {
          note_id: noteHistoryObject[0].note_id,
          change_by: req.user.full_name,
          changes: changes,
          spill,
        },
        ACTIONS.EDIT_NOTE
      ),
    };
    // Check if the test spill has send_email true only then send emails
    if (spill?.send_email) {
      genericSender(dataForEmail);
    }
  }

  try {
    // Update note if id found
    if (id) {
      await models.SpillNotes.update(noteData, {
        where: { id },
      });

      let attachmentToDelete = [];
      if (note.attachments && note.attachments.length > 0) {
        note.attachments.map((attachment) => {
          if (attachment.isDelete) {
            attachmentToDelete = [...attachmentToDelete, attachment];
          }
        });
      }

      if (attachmentToDelete?.length > 0) {
        await models.NoteAttachments.destroy({
          where: {
            id: attachmentToDelete.map((attach) => attach.id),
          },
          paranoid: true,
        });
        const recipients = await models.Recipients.findAll({
          where: { spill_id: spillId },
          include: [{ model: models.User }],
        });

        await createAttachmentDeletedNote(
          spillObj?.dataValues,
          spillObj?.dataValues?.org_id,
          recipients,
          changeOwner,
          attachmentToDelete,
          id,
          ipAddress
        );
      }

      const { count, rows } = await models.SalvageContainers.findAndCountAll({
        where: { note_id: id },
      });

      if (note?.containers?.length > 0) {
        let toRemove = [];

        if (count > 0) {
          for (const row of rows) {
            const foundContainers = note.containers.find(
              (o) => o.id === row.dataValues.id
            );

            if (!foundContainers) {
              toRemove = [...toRemove, row.dataValues.id];
            }
          }
          models.SalvageContainers.destroy({ where: { id: toRemove } });
        }

        let noteContainers = note.containers;

        noteContainers = noteContainers.map((container) => {
          return {
            ...container,
            note_id: id,
          };
        });

        await models.SalvageContainers.bulkCreate(noteContainers, {
          updateOnDuplicate: [
            "sc_no",
            "type",
            "content",
            "is_hazmat",
            "un_no",
            "drum_weight",
          ],
        });
      } else {
        await models.SalvageContainers.destroy({ where: { note_id: id } });
      }

      if (noteFiles.length > 0) {
        await createAttachment(noteFiles, id, spillId, []);
      }

      const updatedNote = await models.SpillNotes.findOne({
        include: [
          {
            model: models.NoteAttachments,
            required: false,
          },
          {
            model: models.SalvageContainers,
            required: false,
            where: { deleted_at: null },
          },
          {
            model: models.User,
            attributes: ["full_name"],
          },
        ],
        where: { id },
      });

      spillNote = updatedNote;
    } else {
      // Create note if id not found
      const resp = await createNote([{ ...note }], spillId, noteFiles, [], []);
      const noteCreated = resp[0];
      const noteId = noteCreated[0].id;

      const updatedNote = await models.SpillNotes.findOne({
        include: [
          {
            model: models.NoteAttachments,
            required: false,
          },
          {
            model: models.SalvageContainers,
            required: false,
            where: { delete_at: null },
          },
          {
            model: models.User,
            attributes: ["full_name"],
          },
        ],
        where: { id: noteId },
      });

      spillNote = updatedNote;
    }

    let totalSpillNotes = await models.SpillNotes.findAll({
      attributes: ["id"],
      where: { spill_id: spillId },
    });

    if (totalSpillNotes?.length > 0) {
      spillNote.dataValues.totalNotesCount = totalSpillNotes?.length;
    }

    if (connectionsToBeFetched) {
      // Update spill connections on edit notes
      const fetchUpdatedConnections = `
      SELECT * FROM connections 
      WHERE spill_id=${spillId} AND deleted_at IS NULL;
      `;

      const fetchedUpdatedConnections = await sequelize.query(
        fetchUpdatedConnections
      );

      spillNote.dataValues.spillConnections = fetchedUpdatedConnections[0][0];
    }

    res.status(200).json({
      data: spillNote,
      spill_notes_data: await getSpillNotesData(spillId),
    });

    noteHistoryObject.forEach(async (change) => {
      await models.SpillNotesHistory.create(change);
    });
  } catch (error) {
    console.log(error);
  }
};

export const batchStatusUpdate = async (
  selected,
  selectAll,
  searchQuery,
  status,
  user,
  currentTime
) => {
  const { id: userId, full_name: userFullName, email: userEmail } = user;
  const { role: userRole } = user?.role;

  let ids = [];
  let include = [];

  if (selectAll) {
    let spills = await searchSpillsForCSV(
      searchQuery,
      user,
      false,
      [...include],
      ["id", "opened_on", "closed_on", "status"]
    );

    spills.spillsData?.map(
      (spill) =>
        !selected.includes(spill.dataValues.id) && ids.push(spill.dataValues.id)
    );
  } else {
    ids = selected;
  }

  const spillStatusSplitter = status.split(":");
  const status_type = spillStatusSplitter[0].trim();
  const status_name = spillStatusSplitter[1].trim();

  if (
    status_type === CONSTANTS.CLOSED_STATUS_TYPE &&
    status_name === "Closed"
  ) {
    await closeSpillById(ids, currentTime);
  }

  const statusFound = await models.SpillStatuses.findOne({
    where: {
      status: status_type,
      name: status_name,
    },
  });

  /* Check if the incoming status is new as that in the spill
  statuses history table then update the history and add new 
  status to the history tab*/
  const currentCSTDate = Moment.utc(new Date())?.tz("America/Rankin_Inlet");
  const currentCSTEndedAtDate = currentCSTDate?.format("YYYY-MM-DD HH:mm:ss");

  for (const spill_id of ids) {
    /* Update spill status history table with the new status 
      on update if the current status is different from the previous status */
    const get_spill_statuses_history_query = `
      SELECT * FROM spill_statuses_history
      WHERE spill_id=${spill_id}
      ORDER BY id
      DESC LIMIT 1;
      `;

    const spill_history_status_obj = await sequelize.query(
      get_spill_statuses_history_query
    );

    // Check if the fetched history for the spill exists
    if (spill_history_status_obj[0][0]) {
      const { id, job_no, started_at } = spill_history_status_obj[0][0];

      const history_status = spill_history_status_obj[0][0]?.status;
      const history_spill_id = spill_history_status_obj[0][0]?.spill_id;

      if (status !== history_status) {
        const update_previous_spill_status_history = `
        UPDATE spill_statuses_history 
        SET ended_at='${currentCSTEndedAtDate}'
        WHERE spill_id=${history_spill_id} AND id=${id};
        `;

        const create_new_spill_status_history = `
        INSERT INTO spill_statuses_history 
          (
          spill_id, 
          job_no, 
          status, 
          started_at, 
          user_id, 
          user_name, 
          user_role, 
          created_at,
          updated_at
          )
          VALUES 
          (
           ${spill_id},
           '${job_no}',
           '${status}',
           '${currentCSTEndedAtDate}',
           ${userId},
           '${userFullName}',
           '${userRole}',
           '${currentCSTEndedAtDate}',
           '${currentCSTEndedAtDate}'
          )
        `;

        await Promise.all([
          sequelize.query(create_new_spill_status_history),
          sequelize.query(update_previous_spill_status_history),
        ]);
      }
    }

    /* Check if the fetched history for the spill does not exists
    then update history with the new status or if it already exists
    and is same as the new one then do not update */
    const get_spill_status = `
    SELECT job_no FROM spills
    WHERE id=${spill_id};
    `;

    let fetched_status;

    if (
      spill_history_status_obj[0][0] === null ||
      spill_history_status_obj[0][0] === undefined
    ) {
      fetched_status = await sequelize.query(get_spill_status);

      const { job_no } = fetched_status[0][0];

      if (status) {
        const create_new_spill_status_history = `
        INSERT INTO spill_statuses_history 
          (
          spill_id, 
          job_no, 
          status, 
          started_at, 
          user_id, 
          user_name, 
          user_role, 
          created_at,
          updated_at
          )
          VALUES 
          (
           ${spill_id},
           '${job_no}',
           '${status}',
           '${currentCSTEndedAtDate}',
           ${userId},
           '${userFullName}',
           '${userRole}',
           '${currentCSTEndedAtDate}',
           '${currentCSTEndedAtDate}'
          )
        `;
        await sequelize.query(create_new_spill_status_history);
      }
    }
  }

  await models.Spills.update(
    { status, status_id: statusFound.id },
    {
      where: {
        id: ids,
      },
    }
  );

  for (const spill_id of ids) {
    await unAssignPacketReviewerOnStatusChange(spill_id);
  }

  const searchedSpills = await searchSpillsByConditions(
    searchQuery,
    user,
    true
  );

  return { data: { batchUpdate: true, ...searchedSpills } };
};

// Update spill note actual and projected eta (do not use):
// export const updateSpillNotesActualEtaInDB = async (req, res, next) => {
//   try {
//     /* Fetch projected eta services for calculating actual eta later */

//     const fetchDistinctSpillIDsForSpillNotes = `
//       select * from eta_data
//       where dispatch_time < arrival_time
//       and dispatch_time is not null and arrival_time is not null
//     `;

//     const fetchedDistinctSpillIDsForSpillNotes = await sequelize.query(
//       fetchDistinctSpillIDsForSpillNotes
//     );

//     const distinctSpillIdArr = [
//       ...fetchedDistinctSpillIDsForSpillNotes[0],
//     ].filter((note) => note.real_id !== null);

//     let counter = 1;

//     for (const data of distinctSpillIdArr) {
//       console.log('counter', counter);
//       console.log('data?.id', data?.id);
//       const arrivedDate = Moment(data.arrival_time); // arrived date
//       const dispatchDate = Moment(data.dispatch_time); // dispatch date
//       const duration = Moment.duration(arrivedDate.diff(dispatchDate));
//       const hours = duration.asHours();
//       const minutes = hours * 60;

//       const updateSpillNotesActualETA = `
//         UPDATE spill_notes
//         SET actual_eta_temp=${minutes}
//         WHERE id=${data?.real_id};
//       `;

//       await sequelize.query(updateSpillNotesActualETA);
//       counter++;
//     }

//     res.status(200).json({
//       data: 'Updated Successfully',
//     });
//   } catch (error) {
//     console.log('error', error);
//   }
// };

export const unAssignPacketReviewerOnStatusChange = async (spillId) => {
  try {
    const newDate = new Date();
    const date = moment.tz(newDate, "YYYY-MM-DDTHH:mm:ssZ");
    const cstDate = date.tz("America/Chicago");
    const formattedCSTDate = cstDate.format("YYYY-MM-DD HH:mm:ss");

    const fetchAllPacketReviewerAssignment = `
    SELECT * FROM packet_reviewer_assignments WHERE assigned_spill_id = ${spillId};
    `;

    let fetchedAllPacketReviewerAssignment = await sequelize.query(
      fetchAllPacketReviewerAssignment
    );

    fetchedAllPacketReviewerAssignment = fetchedAllPacketReviewerAssignment[0];

    if (fetchedAllPacketReviewerAssignment?.length > 0) {
      // Update logic for packet reviewer assignment history in db
      const fetchedCurrentPacketReviewerUserId =
        fetchedAllPacketReviewerAssignment[0]?.packet_reviewer_user_id;
      const assigned_at = fetchedAllPacketReviewerAssignment[0]?.created_at;
      const assigned_at_date_new_date = new Date(assigned_at);
      const assigned_at_date = moment.tz(
        assigned_at_date_new_date,
        "YYYY-MM-DDTHH:mm:ssZ"
      );
      const assigned_at_date_cst_ate = assigned_at_date.tz("America/Chicago");
      const formatted_assigned_at_date_cst_date = assigned_at_date_cst_ate.format(
        "YYYY-MM-DD HH:mm:ss"
      );

      const updatePacketReviewerAssignmentHistory = `
          INSERT INTO packet_reviewer_assignments_history
          (
            spill_id,
            assigned_packet_reviewer_id,
            assigned_at,
            created_at,
            updated_at
            )
            VALUES
            (
            ${spillId},
            ${fetchedCurrentPacketReviewerUserId},
            '${formatted_assigned_at_date_cst_date}',
            '${formattedCSTDate}',
            '${formattedCSTDate}'
            );`;

      console.log(updatePacketReviewerAssignmentHistory);

      await sequelize.query(updatePacketReviewerAssignmentHistory);
    }

    const unassignPacketReviewer = `
    DELETE FROM packet_reviewer_assignments 
    WHERE assigned_spill_id=${spillId};
    `;

    await sequelize.query(unassignPacketReviewer);
  } catch (error) {
    console.log("Error while unassigning packet reviewer:", error);
  }
};

// Manual Status Updates
export const updateStatus = async (req, res, next) => {
  try {
    const {
      status,
      job_no,
      spill_id,
      selected,
      selectAll,
      searchQuery,
      batchUpdate,
      currentTime,
    } = req.body;
    const { id: userId, full_name: userFullName, email: userEmail } = req?.user;
    const { role: userRole } = req?.user?.role;

    if (batchUpdate) {
      const resp = await batchStatusUpdate(
        selected,
        selectAll,
        searchQuery,
        status,
        req.user,
        currentTime
      );
      res.status(200).json(resp);
      return;
    }

    let spillData = await models.Spills.findOne({
      where: { id: spill_id },
      include: [
        { model: models.User, required: false },
        { model: models.ClientOrganizations, required: false },
      ],
    });
    let isDateInClosedOn = spillData?.dataValues?.closed_on instanceof Date;
    const currentSpillStatus = spillData?.dataValues?.status
      ?.split(":")[0]
      ?.trim();
    const send_email = spillData?.dataValues?.send_email;
    const over_watch = spillData?.dataValues?.watched;
    let spillStatus;

    if (status) {
      const spillStatusSplitter = status.split(":");
      const status_type = spillStatusSplitter[0].trim();
      const status_name = spillStatusSplitter[1].trim();

      if (
        status_type === CONSTANTS.CLOSED_STATUS_TYPE &&
        status_name === "Closed" &&
        !isDateInClosedOn
      ) {
        spillData.dataValues.closed_on = currentTime;
        await closeSpillById(spill_id, currentTime);
      }

      const statusFound = await models.SpillStatuses.findOne({
        where: {
          status: status_type,
          name: status_name,
        },
      });

      spillStatus = statusFound;
      const statusName =
        spillStatus.dataValues.status + ": " + spillStatus.dataValues.name;
      if (
        statusName != spillData.dataValues.status &&
        (statusName === CONSTANTS.READY_TO_INVOICE_STATUS ||
          statusName === CONSTANTS.FINAL_REVIEW_STATUS ||
          statusName === CONSTANTS.READY_TO_CLOSE_STATUS ||
          statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS ||
          statusName === CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION ||
          statusName === CONSTANTS.WORK_IN_PROGRESS ||
          statusName === CONSTANTS.CLOSED_STATUS ||
          statusName === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
          statusName === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
          statusName === CONSTANTS.PENDING_EXCAVATION_STATUS ||
          statusName === CONSTANTS.PENDING_DISPOSAL_STATUS ||
          statusName === CONSTANTS.INVOICE_SUBMITTED_TO_CLIENT_STATUS ||
          statusName === CONSTANTS.PAYMENT_PENDING_STATUS)
      ) {
        let usersToEmail = [
          statusName === CONSTANTS.READY_TO_INVOICE_STATUS
            ? CONSTANTS.INVOICE_EMAIL
            : statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS
            ? CONSTANTS.PACKET_REVIEW_EMAIL
            : statusName === CONSTANTS.FINAL_REVIEW_STATUS
            ? CONSTANTS.FINAL_REVIEW_EMAIL
            : "",
          spillData.dataValues.user?.email,
        ];

        usersToEmail = usersToEmail.filter((email) => email.length > 0);

        if (over_watch) {
          usersToEmail?.push(OVERWATCH_EMAIL);
        }

        /* send email to packet reviewer containing csv with
        packet reviewer capacity when status changes to
        documentation in review */
        if (
          usersToEmail.includes(CONSTANTS.PACKET_REVIEW_EMAIL) &&
          statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS
        ) {
          // remove the packet reviewer user from users to email and send another email
          usersToEmail = usersToEmail.filter(
            (email) => email !== CONSTANTS.PACKET_REVIEW_EMAIL
          );

          // Find all users where packet reviewer is true
          const fetchPacketReviewerCapacity = `
          SELECT id, full_name, email, is_packet_reviewer 
          FROM users
          WHERE is_packet_reviewer = TRUE;
          `;

          let fetchedPacketReviewerCapacity = await sequelize.query(
            fetchPacketReviewerCapacity
          );

          fetchedPacketReviewerCapacity = fetchedPacketReviewerCapacity[0]?.map(
            (reviewer) =>
              (reviewer = {
                ...reviewer,
                is_packet_reviewer:
                  reviewer?.is_packet_reviewer === 1 ? "TRUE" : "FLASE",
              })
          );

          const updatedPacketReviewerCapacity = [];

          // Fetch and update count as capacity
          for (let packetReviewer of fetchedPacketReviewerCapacity) {
            const fetchPacketReviewerAssignmentCount = `
            SELECT assigned_spill_id
            FROM packet_reviewer_assignments
            WHERE packet_reviewer_user_id = ${packetReviewer?.id}
            `;

            let fetchedPacketReviewerAssignmentCount = await sequelize.query(
              fetchPacketReviewerAssignmentCount
            );

            fetchedPacketReviewerAssignmentCount =
              fetchedPacketReviewerAssignmentCount[0];

            packetReviewer = {
              ...packetReviewer,
              packet_reviewer_count:
                fetchedPacketReviewerAssignmentCount?.length,
            };
            updatedPacketReviewerCapacity.push(packetReviewer);
          }

          // Add a CSV with packet_reviewer_capacity and dispatch an email to packet reviewer and the user updating the status
          if (updatedPacketReviewerCapacity?.length > 0) {
            const csvData = [];

            updatedPacketReviewerCapacity?.map((data) =>
              csvData?.push({ ...data })
            );

            const fields = [
              "full_name",
              "email",
              "is_packet_reviewer",
              "packet_reviewer_count",
            ];

            const json2CSVParser = new Parser({ fields });
            const csv = json2CSVParser.parse(csvData);

            const attachmentId = uniqueIdGenerator();
            const attachmentPath = `./uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`;

            // Write CSV
            fs.writeFile(attachmentPath, csv, (err) => {
              if (err) {
                console.log("Error writing file", err);
              } else {
                console.log("Successfully wrote file");
              }
            });

            const attachmentsList = [
              {
                filename: attachmentPath.split("/").pop(),
                path: attachmentPath,
              },
            ];

            const dataForEmail = {
              sendEmailTo: [CONSTANTS.PACKET_REVIEW_EMAIL, userEmail],
              sendEmailFrom: userEmail,
              ...generateHtml(
                {
                  spill: getDataValues(spillData),
                  newStatus: statusName,
                  changeUser: userFullName,
                },
                ACTIONS.STATUS_CHANGE
              ),
              attachments: attachmentsList,
            };

            if (send_email) {
              // Remove CSV
              await genericSender(dataForEmail).then(() => {
                fs.unlink(
                  `uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`,
                  (err) => {
                    if (err) {
                      console.log("WARNING! Unable to delete csv file.");
                    } else {
                      console.log("File removed successfully");
                    }
                  }
                );
              });
            }
          }
          const dataForEmailGeneric = {
            sendEmailTo: usersToEmail,
            sendEmailFrom: userEmail,
            ...generateHtml(
              {
                spill: getDataValues(spillData),
                newStatus: statusName,
                changeUser: userFullName,
              },
              ACTIONS.STATUS_CHANGE
            ),
          };
          // Check if the test spill has send_email true only then send emails
          if (send_email) {
            genericSender(dataForEmailGeneric);
          }
        } else {
          const dataForEmail = {
            sendEmailTo: usersToEmail,
            sendEmailFrom: userEmail,
            ...generateHtml(
              {
                spill: getDataValues(spillData),
                newStatus: statusName,
                changeUser: userFullName,
              },
              ACTIONS.STATUS_CHANGE
            ),
          };
          // Check if the test spill has send_email true only then send emails
          if (send_email) {
            genericSender(dataForEmail);
          }
        }
      }
      await models.Spills.update(
        { status, status_id: spillStatus?.id },
        {
          where: {
            id: spill_id,
          },
        }
      );
      const newDateTime = new Date();

      let closed_on;
      if (
        status_type === CONSTANTS.CLOSED_STATUS_TYPE &&
        (!isDateInClosedOn || currentSpillStatus === CONSTANTS.OPEN_STATUS_TYPE)
      ) {
        await models.Spills.update(
          {
            status,
            status_id: spillStatus?.id,
            closed_on: currentTime || newDateTime,
          },
          {
            where: {
              id: spill_id,
            },
          }
        );
        spillData.dataValues.closed_on = currentTime || newDateTime;
      } else {
        await models.Spills.update(
          { status, status_id: spillStatus?.id },
          {
            where: {
              id: spill_id,
            },
          }
        );
      }

      const searchStatusString = statusName.search("Open");

      if (spillData?.dataValues?.closed_on && searchStatusString != -1) {
        closed_on = "Re-Opened";
      } else {
        closed_on = spillData?.dataValues?.closed_on || "Still Open";
      }

      /* Update spill status history table with the new status 
      on update if the current status is different from the previous status */
      const get_spill_statuses_history_query = `
      SELECT * FROM spill_statuses_history
      WHERE spill_id=${spill_id}
      ORDER BY id
      DESC LIMIT 1;
      `;

      const spill_status_obj = await sequelize.query(
        get_spill_statuses_history_query
      );
      if (spill_status_obj[0][0]) {
        const {
          id,
          job_no,
          started_at,
          ended_at,
          user_id,
          user_name,
          user_role,
          created_at,
          updated_at,
          deleted_at,
        } = spill_status_obj[0][0];

        const history_status = spill_status_obj[0][0]?.status;
        const history_spill_id = spill_status_obj[0][0]?.spill_id;

        if (status !== history_status) {
          const currentCSTDate = Moment.utc(new Date())?.tz(
            "America/Rankin_Inlet"
          );

          const currentCSTEndedAtDate = currentCSTDate?.format(
            "YYYY-MM-DD HH:mm:ss"
          );

          const update_previous_spill_status_history = `
        UPDATE spill_statuses_history 
        SET ended_at='${currentCSTEndedAtDate}'
        WHERE spill_id=${history_spill_id} AND id=${id};
        `;

          const create_new_spill_status_history = `
        INSERT INTO spill_statuses_history 
          (
          spill_id, 
          job_no, 
          status, 
          started_at, 
          user_id, 
          user_name, 
          user_role, 
          created_at,
          updated_at
          )
          VALUES 
          (
           ${spill_id},
           '${job_no}',
           '${status}',
           '${currentCSTEndedAtDate}',
           ${userId},
           "${userFullName}",
           '${userRole}',
           '${currentCSTEndedAtDate}',
           '${currentCSTEndedAtDate}'
          )
        `;

          await Promise.all([
            sequelize.query(create_new_spill_status_history),
            sequelize.query(update_previous_spill_status_history),
          ]);
        }
      }

      /* Un-assign a packet reviewer if spill status has changed from:
      Documentation In Review || Documnetation Sent Back To Contractor 
      For Revision to any other status*/
      if (
        (status === CONSTANTS.WORK_IN_PROGRESS ||
          status === CONSTANTS.READY_TO_INVOICE_STATUS ||
          status === CONSTANTS.FINAL_REVIEW_STATUS ||
          status === CONSTANTS.READY_TO_CLOSE_STATUS ||
          status === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
          status === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
          status === CONSTANTS.PENDING_EXCAVATION_STATUS ||
          status === CONSTANTS.PENDING_DISPOSAL_STATUS ||
          status === CONSTANTS.INVOICE_SUBMITTED_TO_CLIENT_STATUS ||
          status === CONSTANTS.PAYMENT_PENDING_STATUS ||
          status === CONSTANTS.CLOSURE_PACKET_FOR_PAYMENT_SERVICE_NAME ||
          status === CONSTANTS.CLOSED_STATUS) &&
        (spillData?.dataValues?.status ===
          CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS ||
          spillData?.dataValues?.status ===
            CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION)
      ) {
        await unAssignPacketReviewerOnStatusChange(spill_id);
      }

      res.status(200).json({
        data: { spill_id, status, closed_on },
      });
    }
  } catch (error) {
    console.log("error ::", error);
    res.status(500).send();
    return;
  }
};

// getSpillStatusHistory
export const getSpillStatusHistory = async (req, res) => {
  try {
    const { spillId } = req.query;

    let status_history_data = [];

    const get_spill_status_history = `
    SELECT * FROM spill_statuses_history 
    WHERE spill_id=${spillId} AND deleted_at IS NULL
    ORDER BY id
    ASC
    `;

    const fetched_spill_status_history = await sequelize.query(
      get_spill_status_history
    );

    const spill_status_history = fetched_spill_status_history[0];

    for (const item of spill_status_history) {
      const status_obj = {
        status: item?.status,
        started_at: item?.started_at,
        ended_at: item?.ended_at,
        updated_by: `${item?.user_name} (${item?.user_role})`,
        is_status_automated: item?.is_status_automated,
        user_id: item?.user_id,
      };
      status_history_data.push(status_obj);
    }

    const filtered_status_history = status_history_data?.slice(0, -1);

    res.status(200).json({
      data: filtered_status_history,
      latestStatus: status_history_data[status_history_data.length - 1],
    });
  } catch (error) {
    console.log("error ::", error);
    res.status(500).send();
    return;
  }
};

// getSpillStatusHistory
export const getSpillPacketAssignmentHistory = async (req, res) => {
  try {
    const { spillId } = req?.query;

    let packet_assignment_history_data = [];

    const get_packet_assignment_history_data = `
      SELECT 
        u.full_name, prah.assigned_at, prah.created_at
      FROM
        packet_reviewer_assignments_history prah
      LEFT JOIN
        users u on prah.assigned_packet_reviewer_id = u.id
      WHERE
        spill_id = ${spillId} AND prah.deleted_at IS NULL
      ORDER BY prah.id ASC;
    `;

    const fetched_packet_assignment_history = await sequelize.query(
      get_packet_assignment_history_data
    );

    const packet_assignment_history = fetched_packet_assignment_history[0];

    for (const item of packet_assignment_history) {
      const status_obj = {
        packet_reviewer_assigned: item?.full_name,
        assigned_at: item?.assigned_at,
        unassigned_at: item?.created_at,
      };
      packet_assignment_history_data.push(status_obj);
    }

    res.status(200).json({
      data: packet_assignment_history_data,
    });
  } catch (error) {
    console.log("error ::", error);
    res.status(500).send();
    return;
  }
};

// getNoteHistory: getAdminAttachmentHistory
export const getAdminAttachmentHistory = async (req, res) => {
  const { attachmentId } = req.query;

  try {
    const inculde = [
      {
        model: models.Roles,
        attribute: ["role"],
      },
    ];

    let history = await models.SpillAttachmentsHistory.findAll({
      where: { spill_attachment_id: attachmentId },
    });

    let updatedHistory = [];

    for (let history_item of history) {
      const user = await models.User.findOne({
        where: {
          id: history_item.user_id,
        },
        inculde,
      });
      history_item.dataValues = {
        ...history_item.dataValues,
        uploaded_by: user?.dataValues?.full_name,
      };
      updatedHistory.push(history_item);
    }

    res.status(200).json({
      data: updatedHistory,
    });
  } catch (err) {
    console.log(err);
  }
};

export const replaceRejectedFiles = async (
  user,
  spillId,
  jobNumber,
  filesToBeReplacedData,
  adminFilesToBeReplaced
) => {
  let admin_ids = [];
  let spillData = null;
  let users_to_email = [];
  let contractors_name = null;

  try {
    // 1. send the new file to s3 for getting url link to be replaced with previous file url link
    for (let fileIndex in filesToBeReplacedData?.newFiles) {
      const data = await uploadFileToS3Bucket(
        adminFilesToBeReplaced[fileIndex].path,
        `${spillId}/admin/${
          adminFilesToBeReplaced[fileIndex].originalname.split("#")[1]
        }`
      );

      const contractorInvFileName = adminFilesToBeReplaced[
        fileIndex
      ].originalname.split("#")[1];

      // incoming file data
      let attachmentTypeToReplacePreviousAttachment =
        filesToBeReplacedData?.newFiles[fileIndex]?.attachmentType;
      let attachmentTypeToReplacePreviousAttachmentInvAmount =
        filesToBeReplacedData?.newFiles[fileIndex]?.inv_amount;

      // 2. run migration to add revise count col in spills attachment table >> (done-can be viewed in migrations directory)

      // 3. create the copy of file to be replaced in the history table
      const include = [
        {
          model: models.User,
          attributes: ["full_name", "email"],
        },
      ];

      const foundSpillAttachment = await models.SpillAttachments.findOne({
        where: {
          id: filesToBeReplacedData.previousFiles[fileIndex].id,
        },
        include,
      });

      admin_ids.push(foundSpillAttachment?.spill_admin_id);

      const attachmentHistoryObj = {
        spill_attachment_id: foundSpillAttachment.id,
        url_link: foundSpillAttachment.url_link,
        note: foundSpillAttachment.admin_note,
        user_id: foundSpillAttachment.user_id,
        size: foundSpillAttachment.size,
        key: foundSpillAttachment.key,
        inv_amount: foundSpillAttachment.inv_amount,
        expiry_date: foundSpillAttachment.expiry_date,
      };
      await models.SpillAttachmentsHistory.create(attachmentHistoryObj);

      // 4. replace the previous file link with the new one and increment revise count
      const attachmentToUpdateObj = {
        ...foundSpillAttachment?.dataValues,
        name:
          attachmentTypeToReplacePreviousAttachment === "contractorInv"
            ? contractorInvFileName
            : foundSpillAttachment?.name,
        user_id: user.id,
        url_link: data.Location,
        key: data.key || data.Key,
        status: "resubmitted",
        rejected_count: foundSpillAttachment.rejected_count + 1,
        inv_amount: attachmentTypeToReplacePreviousAttachmentInvAmount,
      };

      await models.SpillAttachments.update(attachmentToUpdateObj, {
        where: { id: foundSpillAttachment.id },
      });

      const spillAttachmentLogsToUpdate = {
        spill_attachment_id: attachmentToUpdateObj?.id,
        status: attachmentToUpdateObj?.status,
        spill_admin_id: attachmentToUpdateObj?.spill_admin_id,
        type: attachmentToUpdateObj?.type,
      };

      if (spillAttachmentLogsToUpdate) {
        await models.SpillAttachmentLogs.create(spillAttachmentLogsToUpdate);
      }

      // 5. check if the attachment type is contractor invoice
      if (foundSpillAttachment?.type === "contractorInv") {
        // 6. fetch first uploaded attachment that was rejected from attachment history table
        const foundSpillAdminId = foundSpillAttachment?.spill_admin_id;

        let fetchRelativeAttachmentHistory = `
        SELECT * FROM spill_attachments_history
        WHERE spill_attachment_id = ${foundSpillAttachment?.id}
        ORDER BY created_at ASC LIMIT 1;
        `;
        const relativeAttachmentHistory = await sequelize.query(
          fetchRelativeAttachmentHistory
        );

        const firstAttachmentInvoiceAmount =
          relativeAttachmentHistory[0][0]?.inv_amount;
        const relativeAttachmentHistoryExists =
          relativeAttachmentHistory[0]?.length > 0;

        // 7. Calculate Saving
        const savings =
          attachmentTypeToReplacePreviousAttachmentInvAmount -
          firstAttachmentInvoiceAmount;

        // 8. Update savings only if they are in negative and attachment history exists
        if (savings < 0 && relativeAttachmentHistoryExists) {
          let updateSpillAdminAttachmentSavings = `
          UPDATE spill_attachments
          SET savings='${savings}'
          WHERE spill_admin_id=${foundSpillAdminId} AND id=${foundSpillAttachment.id};
          `;
          await sequelize.query(updateSpillAdminAttachmentSavings);
        }
      }
      fs.unlinkSync(adminFilesToBeReplaced[fileIndex].path);
    }

    // Dispatch email to packet reviewer and contractors on attachments revision
    spillData = await models.Spills.findOne({
      where: { id: spillId },
    });

    admin_ids = [...new Set(admin_ids)];

    const fetchedPRUserId = await models.PacketReviewerAssignments.findOne({
      attributes: ["packet_reviewer_user_id"],
      where: { assigned_spill_id: spillId },
    });

    const fetchedPRUserEmail = await models.User.findOne({
      attributes: ["email"],
      where: { id: fetchedPRUserId?.packet_reviewer_user_id },
    });

    users_to_email.push(fetchedPRUserEmail?.email);

    for (let i = 0; i < admin_ids?.length; i++) {
      const contractorId = await models.SpillAdmins.findOne({
        attributes: ["contractor_id"],
        where: { id: admin_ids[i] },
      });

      const contractorEmail = await models.Contractors.findOne({
        attributes: ["email", "name"],
        where: { id: contractorId?.contractor_id },
      });

      contractors_name = contractorEmail?.name;
      users_to_email.push(contractorEmail?.email);
    }

    if (users_to_email?.length) {
      const users_to_email = uniqueArrayOfStrings(users_to_email);
      // const contractors_name = uniqueArrayOfStrings(contractorList);

      const dataForEmail = {
        sendEmailTo: users_to_email,
        sendEmailFrom: CONSTANTS.NO_REPLY_EMAIL,
        ...generateHtml(
          {
            spill: getDataValues(spillData),
            contractorName: contractors_name,
          },
          ACTIONS.REPLACE_REJECTED_FILES
        ),
      };

      await genericSender(dataForEmail);
    }
  } catch (err) {
    console.log(err);
  }
};

export const changeStatus = async (newStatus, prevSpill, user) => {
  const spillStatusSplitter = newStatus.split(":");
  let spillStatus = "";

  const status_type = spillStatusSplitter[0].trim();
  const status_name = spillStatusSplitter[1].trim();
  const spillId = prevSpill?.dataValues?.id;
  const send_email = prevSpill?.dataValues?.send_email;
  const over_watch = prevSpill?.dataValues?.watched;

  if (
    status_type === CONSTANTS.CLOSED_STATUS_TYPE &&
    status_name === "Closed"
  ) {
    await closeSpillById(spillId);
  }

  const statusFound = await models.SpillStatuses.findOne({
    where: {
      status: status_type,
      name: status_name,
    },
  });

  spillStatus = statusFound;
  const statusName =
    spillStatus?.dataValues.status + ": " + spillStatus?.dataValues.name;

  if (
    statusName != prevSpill?.dataValues?.status &&
    (statusName === CONSTANTS.READY_TO_INVOICE_STATUS ||
      statusName === CONSTANTS.FINAL_REVIEW_STATUS ||
      statusName === CONSTANTS.READY_TO_CLOSE_STATUS ||
      statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS ||
      statusName === CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION ||
      statusName === CONSTANTS.WORK_IN_PROGRESS ||
      statusName === CONSTANTS.CLOSED_STATUS ||
      statusName === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
      statusName === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
      statusName === CONSTANTS.PENDING_EXCAVATION_STATUS ||
      statusName === CONSTANTS.PENDING_DISPOSAL_STATUS ||
      statusName === CONSTANTS.INVOICE_SUBMITTED_TO_CLIENT_STATUS ||
      statusName === CONSTANTS.PAYMENT_PENDING_STATUS)
  ) {
    let usersToEmail = [
      statusName === CONSTANTS.READY_TO_INVOICE_STATUS
        ? CONSTANTS.INVOICE_EMAIL
        : statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS
        ? CONSTANTS.PACKET_REVIEW_EMAIL
        : statusName === CONSTANTS.FINAL_REVIEW_STATUS
        ? CONSTANTS.FINAL_REVIEW_EMAIL
        : "",
      prevSpill?.dataValues.user.email,
    ];

    usersToEmail = usersToEmail.filter((email) => email.length > 0);

    if (over_watch === 1 ? true : false) {
      usersToEmail?.push(OVERWATCH_EMAIL);
    }

    /* send email to packet reviewer containing csv with
    packet reviewer capacity when status changes to
    documentation in review */
    if (
      usersToEmail.includes(CONSTANTS.PACKET_REVIEW_EMAIL) &&
      statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS
    ) {
      // remove the packet reviewer user from users to email and send another email
      usersToEmail = usersToEmail.filter(
        (email) => email !== CONSTANTS.PACKET_REVIEW_EMAIL
      );

      // Find all users where packet reviewer is true
      const fetchPacketReviewerCapacity = `
      SELECT id, full_name, email, is_packet_reviewer 
      FROM users
      WHERE is_packet_reviewer = TRUE;
      `;

      let fetchedPacketReviewerCapacity = await sequelize.query(
        fetchPacketReviewerCapacity
      );

      fetchedPacketReviewerCapacity = fetchedPacketReviewerCapacity[0]?.map(
        (reviewer) =>
          (reviewer = {
            ...reviewer,
            is_packet_reviewer:
              reviewer?.is_packet_reviewer === 1 ? "TRUE" : "FLASE",
          })
      );

      const updatedPacketReviewerCapacity = [];

      // Fetch and update count as capacity
      for (let packetReviewer of fetchedPacketReviewerCapacity) {
        const fetchPacketReviewerAssignmentCount = `
        SELECT assigned_spill_id
        FROM packet_reviewer_assignments
        WHERE packet_reviewer_user_id = ${packetReviewer?.id}
        `;

        let fetchedPacketReviewerAssignmentCount = await sequelize.query(
          fetchPacketReviewerAssignmentCount
        );

        fetchedPacketReviewerAssignmentCount =
          fetchedPacketReviewerAssignmentCount[0];

        packetReviewer = {
          ...packetReviewer,
          packet_reviewer_count: fetchedPacketReviewerAssignmentCount?.length,
        };
        updatedPacketReviewerCapacity.push(packetReviewer);
      }

      // Add a CSV with packet_reviewer_capacity and dispatch an email to packet reviewer and the user updating the status
      if (updatedPacketReviewerCapacity?.length > 0) {
        const csvData = [];

        updatedPacketReviewerCapacity?.map((data) =>
          csvData?.push({ ...data })
        );

        const fields = [
          "full_name",
          "email",
          "is_packet_reviewer",
          "packet_reviewer_count",
        ];

        const json2CSVParser = new Parser({ fields });
        const csv = json2CSVParser.parse(csvData);

        const attachmentId = uniqueIdGenerator();
        const attachmentPath = `./uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`;

        // Write CSV
        fs.writeFile(attachmentPath, csv, (err) => {
          if (err) {
            console.log("Error writing file", err);
          } else {
            console.log("Successfully wrote file");
          }
        });

        const attachmentsList = [
          {
            filename: attachmentPath.split("/").pop(),
            path: attachmentPath,
          },
        ];

        const dataForEmail = {
          sendEmailTo: [CONSTANTS.PACKET_REVIEW_EMAIL, user.userEmail],
          sendEmailFrom: user.userEmail,
          ...generateHtml(
            {
              spill: getDataValues(prevSpill),
              newStatus: statusName,
              changeUser: user.userFullName,
            },
            ACTIONS.STATUS_CHANGE
          ),
          attachments: attachmentsList,
        };

        if (send_email) {
          // Remove CSV
          await genericSender(dataForEmail).then(() => {
            fs.unlink(
              `uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`,
              (err) => {
                if (err) {
                  console.log("WARNING! Unable to delete csv file.");
                } else {
                  console.log("File removed successfully");
                }
              }
            );
          });
        }
        const dataForEmailGeneric = {
          sendEmailTo: usersToEmail,
          sendEmailFrom: user.userEmail,
          ...generateHtml(
            {
              spill: getDataValues(prevSpill),
              newStatus: statusName,
              changeUser: user.userFullName,
            },
            ACTIONS.STATUS_CHANGE
          ),
        };
        // Check if the test spill has send_email true only then send emails
        if (send_email) {
          genericSender(dataForEmailGeneric);
        }
      }
    } else {
      const dataForEmail = {
        sendEmailTo: usersToEmail,
        sendEmailFrom: user.userEmail,
        ...generateHtml(
          {
            spill: getDataValues(prevSpill),
            newStatus: statusName,
            changeUser: user.userFullName,
          },
          ACTIONS.STATUS_CHANGE
        ),
      };
      // Check if the test spill has send_email true only then send emails
      if (send_email) {
        genericSender(dataForEmail);
      }
    }
  }

  /* Un-assign a packet reviewer if spill status has changed from:
      Documentation In Review || Documnetation Sent Back To Contractor 
      For Revision to any other status*/
  if (
    (newStatus === CONSTANTS.WORK_IN_PROGRESS ||
      newStatus === CONSTANTS.READY_TO_INVOICE_STATUS ||
      newStatus === CONSTANTS.FINAL_REVIEW_STATUS ||
      newStatus === CONSTANTS.READY_TO_CLOSE_STATUS ||
      newStatus === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
      newStatus === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
      newStatus === CONSTANTS.PENDING_EXCAVATION_STATUS ||
      newStatus === CONSTANTS.PENDING_DISPOSAL_STATUS ||
      newStatus === CONSTANTS.INVOICE_SUBMITTED_TO_CLIENT_STATUS ||
      newStatus === CONSTANTS.PAYMENT_PENDING_STATUS ||
      newStatus === CONSTANTS.CLOSURE_PACKET_FOR_PAYMENT_SERVICE_NAME ||
      newStatus === CONSTANTS.CLOSED_STATUS) &&
    (prevSpill?.dataValues?.status ===
      CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS ||
      prevSpill?.dataValues?.status ===
        CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION)
  ) {
    await unAssignPacketReviewerOnStatusChange(spillId);
  }

  return { status: newStatus, spillStatus };
};

const generateEmailOnOrganizationChange = (
  spillContractors,
  wholeSpill,
  prevSpill,
  job_no,
  userFullName,
  userEmail
) => {
  try {
    let usersToEmail = [];

    if (spillContractors.length) {
      for (let contractor of spillContractors) {
        if (contractor.email !== null) {
          usersToEmail.push(contractor.email);
        }
      }
    }

    const spillUserEmail = wholeSpill?.spill?.user?.email;

    const sendEmails = wholeSpill?.spill?.send_email;
    const over_watch = wholeSpill?.spill?.watched;

    usersToEmail = [...usersToEmail, userEmail, spillUserEmail];

    usersToEmail = [...new Set(usersToEmail)];

    if (over_watch) {
      usersToEmail?.push(OVERWATCH_EMAIL);
    }

    const dataForEmail = {
      sendEmailTo: usersToEmail,
      sendEmailFrom: userEmail,
      ...generateHtml(
        {
          spill: getDataValues(wholeSpill?.spill),
          jobNumberToUpdate: prevSpill?.dataValues?.job_no,
          updatedJobNumber: job_no,
          clientOrganizationToUpdate:
            wholeSpill.spill.client_organization?.name,
          updatedClientOrganization:
            prevSpill?.client_organization?.dataValues?.name,
          changeUser: userFullName,
        },
        ACTIONS.EDIT_SPILL_CLIENT_ORGANIZATION
      ),
    };
    // Check if the test spill has send_email true only then send emails
    if (sendEmails) {
      genericSender(dataForEmail);
    }
  } catch (error) {
    console.log("Error while sending email on organization change", error);
  }
};

export const requestDocumentation = async (req, res, next) => {
  try {
    const { requestedDocumentsData, adminData } = req?.body;
    const { id: userId, full_name: userFullName, email: userEmail } = req?.user;
    let requestedDocs = [];
    let userToEmailIds = [];
    const requestedDocTypes = [];
    const alreadyRequestedDocs = [];

    for (let i = 0; i < requestedDocumentsData?.length; i++) {
      const requestDocumentDataObject = {
        contractor_id: adminData?.contractor_id,
        contractor_address_id: adminData?.contractor_address_id,
        spill_id: adminData?.spill_id,
        requested_type: requestedDocumentsData[i]?.value,
        requested_by: userId,
        status: "requested",
        requested_at: requestedDocumentsData[i]?.created_at,
        uploaded_at: null,
        uploaded_by: null,
        created_at: requestedDocumentsData[i]?.created_at,
        updated_at: requestedDocumentsData[i]?.created_at,
        deleted_at: null,
        spill_admin_id: adminData?.spill_admin_id,
      };

      requestedDocs.push(requestDocumentDataObject);
    }

    // Check if there's a requested docs list
    if (requestedDocs?.length) {
      for (let i = 0; i < requestedDocs?.length; i++) {
        requestedDocTypes.push(requestedDocs[i]?.requested_type);
      }
      await models.ContractorRequestedDocumentations.bulkCreate(requestedDocs);

      // Populate users to email list only if the request is submitted
      userToEmailIds = [adminData?.contractor_id];
    }

    // Check if user to email's id's exists
    if (userToEmailIds?.length) {
      const fetchedContractorEmailAddresses = await models.Contractors.findAll({
        attributes: ["email", "name"],
        where: {
          id: userToEmailIds,
        },
      });

      // Update email recipients list
      const dispatchEmailToList = [];
      let dispatchEmailToName;

      // Fetch PM email
      const fetchedPMEmail = await models.User.findOne({
        attributes: ["email"],
        where: {
          id: adminData?.spill_pm_user_id,
        },
      });

      dispatchEmailToList.push(fetchedPMEmail?.email);
      dispatchEmailToList.push(userEmail);

      for (let i = 0; i < fetchedContractorEmailAddresses?.length; i++) {
        if (fetchedContractorEmailAddresses[i]?.email) {
          dispatchEmailToList.push(fetchedContractorEmailAddresses[i]?.email);
        }
        if (fetchedContractorEmailAddresses[i]?.name) {
          dispatchEmailToName = fetchedContractorEmailAddresses[i]?.name;
        }
      }

      // Dispatch email on requesting docs
      const dataForEmail = {
        sendEmailTo: dispatchEmailToList,
        sendEmailFrom: userEmail,
        ...generateHtml(
          {
            spill_job_no: adminData?.spill_job_no,
            requested_doc_types: requestedDocTypes,
            requested_by: userEmail,
            requested_to: dispatchEmailToName,
          },
          ACTIONS.REQUEST_DOCUMENTATION
        ),
      };

      await genericSender(dataForEmail);
    }
    await models.Spills.update(
      { status: CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION, status_id: 16 },
      {
        where: { id: adminData?.spill_id },
      }
    );

    res.status(200).json({
      previouslyRequestedDocs: alreadyRequestedDocs,
    });
  } catch (error) {
    console.log("Error while requesting documentation:: ", error);
  }
};

export const getSpillAdminRequestDocumentation = async (req, res, next) => {
  try {
    const { spill_admin_id, spill_id } = req?.query;

    const spillAdminRequestedDocs = [];

    const fetchSpillAdminRequested = await models.ContractorRequestedDocumentations.findAll(
      {
        attributes: ["id", "status", "requested_type"],
        where: {
          spill_id,
          spill_admin_id,
          status: "requested",
          deleted_at: null,
        },
      }
    );

    for (let i = 0; i < fetchSpillAdminRequested?.length; i++) {
      spillAdminRequestedDocs.push(fetchSpillAdminRequested[i]);
    }
    res.status(200).json({
      data: spillAdminRequestedDocs,
    });
  } catch (error) {
    console.log("Error while fetching requesting documentation:: ", error);
  }
};

export const updateSpillForAddingArrivedOnService = async (req, res, next) => {
  try {
    let completeSpill = JSON.parse(req?.body?.completeSpill);
    let adminData = JSON.parse(req?.body?.adminData);

    const id = completeSpill?.spill?.id;
    const job_no = completeSpill?.spill?.job_no;
    const spillContractors = completeSpill?.spillContractors;
    const longitude = completeSpill?.spill?.longitude;
    const latitude = completeSpill?.spill?.latitude;

    /* loop on spill contractors from wholeSpill and completeSpill match 
    their id's in whole spill and update their accepted flag after which
    we can update spill contractors */
    for (const spillContractor of spillContractors) {
      const updateSpillContractorResponse = `
        UPDATE spill_contractors
        SET accepted=${spillContractor?.accepted}
        WHERE id=${spillContractor?.id} AND contractor_id=${spillContractor?.contractor_id}`;

      await sequelize.query(updateSpillContractorResponse);
    }

    if (adminData?.length > 0) {
      await editAdmins(id, adminData, job_no, req.user, true);
    }

    const updateLatLong = `
    UPDATE spills
    SET
    longitude=${longitude}, 
    latitude=${latitude}
    where id=${id}
    `;
    await sequelize.query(updateLatLong);

    let wholeSpill = await getCompleteSpillByJobNo(job_no);

    res.status(200).json(wholeSpill);
  } catch (err) {
    console.log("Error while updating contractor response", err);
  }
};

const assignPacketReviewerOnEdit = async (
  packetReviewerToUpdateData,
  spill_id,
  userEmail
) => {
  try {
    const { id, full_name, count } = packetReviewerToUpdateData;
    const newDate = new Date();
    const date = moment.tz(newDate, "YYYY-MM-DDTHH:mm:ssZ");
    const cstDate = date.tz("America/Chicago");
    const formattedCSTDate = cstDate.format("YYYY-MM-DD HH:mm:ss");

    let dataToInsert = {
      assigned_spill_id: spill_id,
      packet_reviewer_user_id: id,
      packet_reviewer_user_full_name: full_name,
    };

    let hasAssignmentDone = false;
    let hasAssignmentOnUpdateDone = false;
    let hasAssignmentOnInsertionDone = false;

    const fetchPacketReviewerData = `
    SELECT * 
    FROM
      packet_reviewer_assignments
    WHERE 
      packet_reviewer_user_id = ${id} 
      AND
      assigned_spill_id = ${spill_id}; 
    `;

    let fetchedPacketReviewerData = await sequelize.query(
      fetchPacketReviewerData
    );

    fetchedPacketReviewerData = fetchedPacketReviewerData[0];

    // Filter out data if assignment is already done to the same reviewer
    if (fetchedPacketReviewerData?.length > 0) {
      dataToInsert = {};
    }

    if (Object.keys(dataToInsert)?.length > 0) {
      // Filter out data if assignment is already done but to a different reviewer to update spill assignment
      const fetchAllPacketReviewerAssignment = `
      SELECT * FROM packet_reviewer_assignments WHERE assigned_spill_id = ${spill_id};
      `;
      let fetchedAllPacketReviewerAssignment = await sequelize.query(
        fetchAllPacketReviewerAssignment
      );

      fetchedAllPacketReviewerAssignment =
        fetchedAllPacketReviewerAssignment[0];

      if (fetchedAllPacketReviewerAssignment?.length > 0) {
        // Update logic for packet reviewer assignment history in db
        const fetchedCurrentPacketReviewerUserId =
          fetchedAllPacketReviewerAssignment[0]?.packet_reviewer_user_id;
        const assigned_at = fetchedAllPacketReviewerAssignment[0]?.created_at;

        const assigned_at_date_new_date = new Date(assigned_at);
        const assigned_at_date = moment.tz(
          assigned_at_date_new_date,
          "YYYY-MM-DDTHH:mm:ssZ"
        );
        const assigned_at_date_cst_ate = assigned_at_date.tz("America/Chicago");
        const formatted_assigned_at_date_cst_date = assigned_at_date_cst_ate.format(
          "YYYY-MM-DD HH:mm:ss"
        );

        const updatePacketReviewerAssignmentHistory = `
          INSERT INTO packet_reviewer_assignments_history
          (
            spill_id,
            assigned_packet_reviewer_id,
            assigned_at,
            created_at,
            updated_at
            )
            VALUES
            (
              ${spill_id},
              ${fetchedCurrentPacketReviewerUserId},
              '${formatted_assigned_at_date_cst_date}',
              '${formattedCSTDate}',
              '${formattedCSTDate}'
              );`;

        await sequelize.query(updatePacketReviewerAssignmentHistory);

        // Update logic for packet reviewer assignment in db
        const updateReviewer = `
          UPDATE packet_reviewer_assignments
          SET
          packet_reviewer_user_id = ${dataToInsert?.packet_reviewer_user_id},
          packet_reviewer_user_full_name = '${dataToInsert?.packet_reviewer_user_full_name}',
          updated_at = '${formattedCSTDate}',
          deleted_at = NULL
          WHERE assigned_spill_id = ${dataToInsert?.assigned_spill_id};
          `;

        await sequelize.query(updateReviewer);
        hasAssignmentDone = true;
        hasAssignmentOnUpdateDone = true;
      } else {
        // Insertion logic for packet reviewer assignment in db
        const asssignReviewer = `
          INSERT INTO packet_reviewer_assignments
          (
            packet_reviewer_user_id,
            assigned_spill_id,
            packet_reviewer_user_full_name,
            created_at,
            updated_at
            )
            VALUES
            (
          ${dataToInsert?.packet_reviewer_user_id},
          ${dataToInsert?.assigned_spill_id},
          '${dataToInsert?.packet_reviewer_user_full_name}',
          '${formattedCSTDate}',
          '${formattedCSTDate}'
          );`;

        await sequelize.query(asssignReviewer);
        hasAssignmentDone = true;
        hasAssignmentOnInsertionDone = true;
      }

      // Fetch updated packet assignment data and count for a packet reviewer
      const fetchUpdatedPacketAssignmentData = `
        SELECT 
        id,
        packet_reviewer_user_id, 
        assigned_spill_id, 
        packet_reviewer_user_full_name 
        FROM packet_reviewer_assignments WHERE assigned_spill_id=${spill_id};
        `;

      const fetchPacketReviewerAssignments = `
        SELECT 
        assigned_spill_id 
        FROM packet_reviewer_assignments 
        WHERE packet_reviewer_user_id=${dataToInsert?.packet_reviewer_user_id};
        `;

      let [
        fetchedUpdatedPacketAssignmentData,
        fetchedPacketReviewerAssignments,
      ] = await Promise.all([
        sequelize.query(fetchUpdatedPacketAssignmentData),
        sequelize.query(fetchPacketReviewerAssignments),
      ]);

      fetchedUpdatedPacketAssignmentData =
        fetchedUpdatedPacketAssignmentData[0][0];

      fetchedPacketReviewerAssignments = fetchedPacketReviewerAssignments[0];

      const dataToReturn = {
        updatedPacketReviewerData: fetchedUpdatedPacketAssignmentData,
        count: fetchedPacketReviewerAssignments?.length,
      };

      // Update packet reviewer id in spills table if assignment is done
      if (hasAssignmentOnInsertionDone) {
        const updatePacketReviewerIdInSpills = `
        UPDATE spills 
        SET assigned_packet_reviewer_id = ${fetchedUpdatedPacketAssignmentData?.id}
        WHERE id = ${spill_id}
        `;
        await sequelize.query(updatePacketReviewerIdInSpills);
      }

      // Dipsatch email to packet reviewer, assigned reviewer and user who assigns the packet reviewer
      if (hasAssignmentDone) {
        // Find all users where packet reviewer is true
        const fetchPacketReviewerCapacity = `
          SELECT id, full_name, email, is_packet_reviewer 
          FROM users
          WHERE is_packet_reviewer = TRUE;
       `;

        let fetchedPacketReviewerCapacity = await sequelize.query(
          fetchPacketReviewerCapacity
        );

        fetchedPacketReviewerCapacity = fetchedPacketReviewerCapacity[0]?.map(
          (reviewer) =>
            (reviewer = {
              ...reviewer,
              is_packet_reviewer:
                reviewer?.is_packet_reviewer === 1 ? "TRUE" : "FLASE",
            })
        );

        const updatedPacketReviewerCapacity = [];

        // Fetch and update count as capacity in a CSV
        for (let packetReviewer of fetchedPacketReviewerCapacity) {
          const fetchPacketReviewerAssignmentCount = `
            SELECT assigned_spill_id
            FROM packet_reviewer_assignments
            WHERE packet_reviewer_user_id = ${packetReviewer?.id}
         `;

          let fetchedPacketReviewerAssignmentCount = await sequelize.query(
            fetchPacketReviewerAssignmentCount
          );

          fetchedPacketReviewerAssignmentCount =
            fetchedPacketReviewerAssignmentCount[0];

          packetReviewer = {
            ...packetReviewer,
            packet_reviewer_count: fetchedPacketReviewerAssignmentCount?.length,
          };
          updatedPacketReviewerCapacity.push(packetReviewer);
        }

        if (updatedPacketReviewerCapacity?.length > 0) {
          const csvData = [];

          updatedPacketReviewerCapacity?.map((data) =>
            csvData?.push({ ...data })
          );

          const fields = [
            "full_name",
            "email",
            "is_packet_reviewer",
            "packet_reviewer_count",
          ];

          const json2CSVParser = new Parser({ fields });
          const csv = json2CSVParser.parse(csvData);

          const attachmentId = uniqueIdGenerator();
          const attachmentPath = `./uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`;

          // Write CSV
          fs.writeFile(attachmentPath, csv, (err) => {
            if (err) {
              console.log("Error writing file", err);
            } else {
              console.log("Successfully wrote file");
            }
          });

          const attachmentsList = [
            {
              filename: attachmentPath.split("/").pop(),
              path: attachmentPath,
            },
          ];

          // Build data for email
          const fetchAssignedUserEmail = `
            SELECT email FROM users WHERE id = ${id};
          `;

          let fetchedAssignedUserEmail = await sequelize.query(
            fetchAssignedUserEmail
          );

          fetchedAssignedUserEmail = fetchedAssignedUserEmail[0][0]?.email;

          // Filter out duplciate users to email
          let usersToEmailList = [
            CONSTANTS.PACKET_REVIEW_EMAIL,
            userEmail,
            fetchedAssignedUserEmail,
          ];

          usersToEmailList = usersToEmailList?.filter(uniqueStringsInArray);

          let spillData = await models.Spills.findOne({
            where: { id: spill_id },
            include: [
              { model: models.User, required: false },
              { model: models.ClientOrganizations, required: false },
            ],
          });

          const fetchAssignedUser = `
          SELECT packet_reviewer_user_full_name
          FROM packet_reviewer_assignments
          WHERE assigned_spill_id = ${spill_id};
          `;

          let fetchedAssignedUser = await sequelize.query(fetchAssignedUser);

          fetchedAssignedUser =
            fetchedAssignedUser[0][0]?.packet_reviewer_user_full_name;

          const dataForEmail = {
            sendEmailTo: usersToEmailList,
            sendEmailFrom: userEmail,
            ...generateHtml(
              {
                spill: getDataValues(spillData),
                assignedPacketReviewer: fetchedAssignedUser,
                assignerUser: userEmail,
              },
              ACTIONS.PACKET_REVIEWER_ASSIGNMENT
            ),
            attachments: attachmentsList,
          };

          await genericSender(dataForEmail);

          // Remove CSV
          fs.unlink(
            `uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`,
            (err) => {
              if (err) {
                console.log("WARNING! Unable to delete csv file.");
              } else {
                console.log("File removed successfully");
              }
            }
          );
        }
      }

      return dataToReturn;
    }
  } catch (error) {
    console.log("error", error);
  }
};

export const editSpill = async (req, res, next) => {
  try {
    let filesToBeReplacedData =
      req?.body?.updatedFilesState && JSON.parse(req?.body?.updatedFilesState);

    let packetReviewerToUpdate =
      req?.body?.packetReviewerToUpdate &&
      JSON.parse(req?.body?.packetReviewerToUpdate);

    let isNewFileToBeUploaded = false;

    if (filesToBeReplacedData?.isNewFilesUploaded) {
      isNewFileToBeUploaded = filesToBeReplacedData?.isNewFilesUploaded;
    }

    const allFiles = req.files;

    const adminFilesToBeReplaced =
      allFiles &&
      allFiles.filter((file) => file.originalname.includes("admin-replace"));

    const adminFiles =
      allFiles &&
      allFiles.filter(
        (file) =>
          file.originalname.includes("admin") &&
          !file.originalname.includes("admin-replace")
      );

    const file =
      allFiles && allFiles.filter((file) => file.originalname.includes("note"));

    let fileData = JSON.parse(req?.body?.fileData);

    let noteFileData = JSON.parse(req?.body?.noteFileData);

    const currentTime = JSON.parse(req?.body?.currentTime);

    let completeSpill = JSON.parse(req?.body?.completeSpill);

    handleRejectedContractors(
      JSON.parse(req.body.rejectedContractors),
      completeSpill.id,
      req.user
    );

    let include = [
      // {
      //   model: models.SpillNotes,
      //   required: false,
      //   include: [
      //     {
      //       model: models.NoteAttachments,
      //       required: false,
      //     },
      //     {
      //       model: models.SalvageContainers,
      //       required: false,
      //     },
      //   ],
      // },
      // {
      //   model: models.Recipients,
      //   required: false,
      //   include: [
      //     {
      //       model: models.User,
      //       required: false,
      //     },
      //   ],
      // },
      // {
      //   model: models.Reserves,
      //   required: false,
      //   include: [
      //     {
      //       model: models.User,
      //       required: false,
      //     },
      //   ],
      // },
      // {
      //   model: models.SpillMaterial,
      //   required: false,
      //   attributes: ["name"],
      // },
      {
        model: models.ClientOrganizations,
        required: false,
        attributes: ["name"],
      },
      {
        model: models.User,
        required: false,
        attributes: ["email", "full_name"],
      },
      // {
      //   model: models.SpillAdmins,
      //   required: false,
      //   attributes: ["is_complete", "contractor_id"],
      //   include: [{ model: models.SpillAttachments, required: false }],
      // },
    ];
    const prevSpill = await models.Spills.findOne({
      where: {
        id: completeSpill.id,
      },
      include,
    });
    const {
      id: userId,
      full_name: userFullName,
      role: role,
      email: userEmail,
    } = req?.user;
    const { role: userRole } = req?.user?.role;

    const {
      id,
      user_id,
      prev_user_id,
      org_id,
      facility_id,
      status,
      type,
      conditions,
      address,
      city,
      state,
      zip_code,
      country,
      contact,
      responsible,
      need_5800,
      is_waste,
      has_msds,
      is_hazmat,
      un_no,
      response_sent,
      subrogation,
      claim_no,
      material,
      job_no,
      spillContractors,
      connectionData,
      adminData,
      recipients,
      note,
      attachments,
      latitude,
      longitude,
      tractor,
      trailer,
      onsitePocName,
      onsitePocPhone,
      driverPhone,
      driverName,
      pro,
      mapNeeded,
      amountReleased,
      quantityTypeReleased,
      damagedContainerType,
      damageType,
      locationType,
      drainImpacted,
      waterwayImpacted,
      rate,
      send_attachment,
      is_emergency,
      watched,
    } = completeSpill;

    let spillMaterial = {};
    let spillStatus = {};
    let materialName = "";
    let customNotes = [];
    let updatedPacketAssignment;

    if (packetReviewerToUpdate) {
      updatedPacketAssignment = await assignPacketReviewerOnEdit(
        packetReviewerToUpdate,
        id,
        userEmail
      );
    }

    if (mapNeeded) {
      const send_email = prevSpill?.dataValues?.send_email;
      const dataForEmail = {
        sendEmailTo: MAP_REQ_EMAIL,
        sendEmailFrom: userEmail,
        ...generateHtml(
          {
            spill: getDataValues(prevSpill),
          },
          ACTIONS.EDIT_SPILL_MAP_NEEDED
        ),
      };

      // Check if the test spill has send_email true only then send emails
      if (send_email) {
        genericSender(dataForEmail);
      }
    }

    // Materials Handling
    if (
      material?.name &&
      material?.name !== "" &&
      material?.name?.length > 0 &&
      material?.name.trim()
    ) {
      materialName = Object.keys(material).length
        ? material?.name ?? null
        : null;

      const materialFound = await models.SpillMaterial.findOne({
        where: {
          name: material.name,
        },
      });

      if (materialFound) {
        spillMaterial = materialFound;
      } else {
        spillMaterial = await models.SpillMaterial.create({
          name: material.name,
        });
      }
    } else {
      spillMaterial = {
        id: null,
      };
      materialName = null;
    }

    // STATUS Handling
    if (status) {
      let isDateInClosedOn = prevSpill?.dataValues?.closed_on instanceof Date;
      const send_email = prevSpill?.dataValues?.send_email;
      const over_watch = prevSpill?.dataValues?.watched;
      const spillStatusSplitter = status.split(":");

      const status_type = spillStatusSplitter[0].trim();
      const status_name = spillStatusSplitter[1].trim();

      if (
        status_type === CONSTANTS.CLOSED_STATUS_TYPE &&
        status_name === "Closed" &&
        !isDateInClosedOn
      ) {
        await closeSpillById(id, currentTime);
      }

      const statusFound = await models.SpillStatuses.findOne({
        where: {
          status: status_type,
          name: status_name,
        },
      });

      spillStatus = statusFound;
      const statusName =
        spillStatus?.dataValues.status + ": " + spillStatus?.dataValues.name;
      if (
        statusName != prevSpill?.dataValues.status &&
        (statusName === CONSTANTS.READY_TO_INVOICE_STATUS ||
          statusName === CONSTANTS.FINAL_REVIEW_STATUS ||
          statusName === CONSTANTS.READY_TO_CLOSE_STATUS ||
          statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS)
      ) {
        const usersToEmail = [
          statusName === CONSTANTS.READY_TO_INVOICE_STATUS
            ? CONSTANTS.INVOICE_EMAIL
            : statusName === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS
            ? CONSTANTS.PACKET_REVIEW_EMAIL
            : CONSTANTS.FINAL_REVIEW_EMAIL,
          prevSpill?.dataValues.user.email,
        ];

        if (over_watch) {
          usersToEmail?.push(OVERWATCH_EMAIL);
        }
        const dataForEmail = {
          sendEmailTo: usersToEmail,
          sendEmailFrom: userEmail,
          ...generateHtml(
            {
              spill: getDataValues(prevSpill),
              newStatus: statusName,
              changeUser: userFullName,
            },
            ACTIONS.STATUS_CHANGE
          ),
        };
        // Check if the test spill has send_email true only then send emails
        if (send_email) {
          genericSender(dataForEmail);
        }
      }
    }

    // CONNECTION Handling
    let connection = {};
    connectionData.incidentNo = connectionData?.nationalIncidentNo;

    if (connectionData?.connectionId) {
      connection = await editConnection(
        id,
        connectionData,
        spillContractors,
        userId,
        userFullName
      );
    } else {
      connection = await createConnection(id, connectionData, spillContractors);
    }

    
    // ADMIN Handling
    let admins = [];
    let newComplete = [];
    let allComplete = false;
    let newStatus = null;
    let isRejected = false;
    let rejectCount = 0;
    let isAllApproved = false;
    let adminAttachmentsLength = 0;
    let updatedStatus = completeSpill?.status;

    if (adminData?.length) {
      const resp = await editAdmins(
        id,
        adminData,
        job_no,
        req.user,
        isNewFileToBeUploaded
      );
      if (resp) {
        admins = resp[0];
        newComplete = resp[1];
        allComplete = resp[2];
        isRejected = resp[3];
        rejectCount = resp[4];
        isAllApproved = resp[5];
      }
    }

    // Checks for updating spill status baed on admin activity
    if ((rejectCount === 0 && allComplete) || isRejected) {
      let isAllAdminInactive = admins?.every(
        (admin) => admin?.is_removed === true
      );

      if (isAllApproved) {
        updatedStatus = CONSTANTS.READY_TO_INVOICE_STATUS;
      } else if (
        isRejected &&
        updatedStatus === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
      } else if (
        isAllApproved &&
        !isRejected &&
        allComplete &&
        (updatedStatus === CONSTANTS.WORK_IN_PROGRESS ||
          updatedStatus === CONSTANTS.READY_TO_INVOICE_STATUS ||
          updatedStatus === CONSTANTS.FINAL_REVIEW_STATUS ||
          updatedStatus === CONSTANTS.READY_TO_CLOSE_STATUS ||
          updatedStatus === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
          updatedStatus === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
          updatedStatus === CONSTANTS.PENDING_EXCAVATION_STATUS ||
          updatedStatus === CONSTANTS.PENDING_DISPOSAL_STATUS ||
          updatedStatus === CONSTANTS.INVOICE_SUBMITTED_TO_CLIENT_STATUS ||
          updatedStatus === CONSTANTS.INVOICE_SENT_TO_CLIENT_STATUS ||
          updatedStatus === CONSTANTS.PAYMENT_PENDING_STATUS)
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
      } else if (
        !isAllApproved &&
        isRejected &&
        allComplete &&
        (updatedStatus === CONSTANTS.WORK_IN_PROGRESS ||
          updatedStatus === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
          updatedStatus === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
          updatedStatus === CONSTANTS.PENDING_EXCAVATION_STATUS ||
          updatedStatus === CONSTANTS.PENDING_DISPOSAL_STATUS)
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
      } else if (
        !isAllApproved &&
        !isRejected &&
        allComplete &&
        (updatedStatus === CONSTANTS.WORK_IN_PROGRESS ||
          updatedStatus === CONSTANTS.READY_TO_INVOICE_STATUS ||
          updatedStatus === CONSTANTS.FINAL_REVIEW_STATUS ||
          updatedStatus === CONSTANTS.READY_TO_CLOSE_STATUS ||
          updatedStatus === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
          updatedStatus === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
          updatedStatus === CONSTANTS.PENDING_EXCAVATION_STATUS ||
          updatedStatus === CONSTANTS.PENDING_DISPOSAL_STATUS ||
          updatedStatus === CONSTANTS.INVOICE_SUBMITTED_TO_CLIENT_STATUS ||
          updatedStatus === CONSTANTS.INVOICE_SENT_TO_CLIENT_STATUS ||
          updatedStatus === CONSTANTS.PAYMENT_PENDING_STATUS)
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
      } else if (isAllAdminInactive) {
        updatedStatus = CONSTANTS.WORK_IN_PROGRESS;
      } else if (
        !isRejected &&
        updatedStatus === CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
      } else if (
        isRejected &&
        updatedStatus !== CONSTANTS.WORK_IN_PROGRESS &&
        updatedStatus !== CONSTANTS.READY_TO_INVOICE_STATUS
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
      } else {
        updatedStatus = updatedStatus;
      }
    }

    if (rejectCount) {
      if (rejectCount === filesToBeReplacedData?.newFiles?.length) {
        updatedStatus = CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
      }
    }

    await replaceRejectedFiles(
      req.user,
      completeSpill.id,
      completeSpill.job_no,
      filesToBeReplacedData,
      adminFilesToBeReplaced
    );

    if (adminFiles?.length > 0) {
      await addSpillAttachments(admins, adminFiles, fileData, userId, id);
    }

    // Recipients (User for Email) Handling
    (Array.isArray(recipients) || recipients === null) &&
      (await editRecipients(recipients?.length > 0 ? recipients : [], id));

    // New Note Handling (Will be Removed as new note is being created from another point)
    if (note.length > 0) {
      const resp = await createNote(note, id, file, noteFileData, []);
      customNotes = resp[1];
    }

    let spillToUpdate = {
      user_id,
      org_id,
      facility_id: facility_id || null,
      status: newStatus?.status || status,
      type,
      rate,
      conditions,
      address,
      city,
      state,
      zip_code,
      country,
      contact,
      responsible,
      need_5800,
      is_waste,
      has_msds,
      is_hazmat,
      un_no,
      response_sent,
      subrogation,
      claim_no,
      job_no,
      material: materialName,
      material_id: Object.keys(material).length
        ? material.id
          ? material.id
          : spillMaterial.id
        : null,
      status_id: newStatus?.spillStatus?.id || spillStatus.id,
      latitude,
      longitude,
      tractor,
      trailer,
      onsite_poc_name: onsitePocName,
      onsite_poc_phone: onsitePocPhone,
      driver_phone: driverPhone,
      driver_name: driverName,
      pro,
      map_needed: mapNeeded,
      amount_released: amountReleased,
      quantity_type_released: quantityTypeReleased,
      damaged_container_type: damagedContainerType,
      damage_type: damageType,
      location_type: locationType,
      drain_impacted: drainImpacted,
      waterway_impacted: waterwayImpacted,
      send_attachment,
      is_emergency: is_emergency,
      watched: watched,
    };

    // Check for the spill having requested docs
    const fetchSpillsDocumentationInReview = await models.ContractorRequestedDocumentations.findAll(
      {
        attributes: ["status"],
        where: {
          spill_id: id,
          deleted_at: null,
        },
      }
    );

    const isFetchedSpillHavingRequestedDocuments = fetchSpillsDocumentationInReview?.some(
      (requestedDoc) => requestedDoc?.status === "requested"
    );

    // Update spill job number when client organization changes
    if (org_id !== prevSpill.org_id) {
      try {
        await models.Spills.update(
          { job_no, org_id },
          {
            where: {
              id,
            },
          }
        );
      } catch (error) {
        console.log("job number update error", error);
        res.status(500).send();
      }
    }

    // Updated Spill
    let wholeSpill = await getCompleteSpillByJobNo(job_no);

    // Change status of the spill based on user actions and current spill status
    const spillAdminsList = [...wholeSpill.admin];
    let spillContractorsList = [...wholeSpill.spillContractors];
    let foundAdmins = [];
    let isAllAdminsComplete = false;
    let existingAdmin = {};
    const wholeSpillForStatusChange = { dataValues: { ...wholeSpill?.spill } };
    let hasActivityPerformed = false;
    let allAdminsStatus = [];
    let inActiveAdmins = [];
    let activeAdmins = [];

    // Send emails to users when spill organization changes and job number is updated
    if (org_id !== prevSpill.org_id) {
      generateEmailOnOrganizationChange(
        spillContractors,
        wholeSpill,
        prevSpill,
        job_no,
        userFullName,
        userEmail
      );
    }

    /* Check if contractor has performed any activity in their admin tab and 
    is active only show that specific spill to the contractor */
    let adminActivityCheckList = [];
    for (const [index, admin] of spillAdminsList.entries()) {
      if (
        admin.info !== "" ||
        admin.contractor_invoice !== "" ||
        admin.inv_no !== "" ||
        admin.spill_attachments.length > 0
      ) {
        hasActivityPerformed = true;
      } else {
        hasActivityPerformed = false;
      }

      adminActivityCheckList.push({
        activity_performed: hasActivityPerformed,
        contractor_id: admin.spill_contractor_id,
      });
    }

    for (const item of adminActivityCheckList) {
      let contractor_id = item.contractor_id;
      let activity_performed = item.activity_performed;

      await models.SpillContractors.update(
        { activity_performed },
        {
          where: { id: contractor_id },
        }
      );
    }

    /* Case-1: Check if all add users are active only 
  then change status to doc in review on completion*/
    spillContractorsList.map((contractor, index) => {
      existingAdmin = spillAdminsList.find(
        (admin) => admin.spill_contractor_id === contractor?.id
      );

      if (
        existingAdmin &&
        (contractor.accepted === true || contractor.accepted === null)
      ) {
        foundAdmins.push({
          ...existingAdmin,
        });
      }
    });

    // Check if the admin is active or not
    spillContractorsList = spillContractorsList.filter(
      (item) => item.is_inactive === false
    );

    // Map admins found to the array
    foundAdmins.map((admin) => {
      let attachmentStatus = admin?.spill_attachments?.map(
        (attachment) => attachment?.status
      );
      let hasAttachments = admin?.spill_attachments?.length > 0;
      let adminStatus = admin?.is_removed ?? false;
      let adminComplete = admin?.is_complete;
      let adminIsNotRequired = admin?.is_not_required;
      allAdminsStatus.push({
        hasAttachmentsAccepted: attachmentStatus,
        hasAttachmentsAttached: hasAttachments,
        isInactive: adminStatus,
        isComplete: adminComplete,
        isNotRequired: adminIsNotRequired,
      });
    });

    // Check if all add users are active only
    foundAdmins = foundAdmins.filter(
      (item) => item.spill_contractor_is_inactive === false
    );
    // Separate active and inactive admins
    inActiveAdmins = allAdminsStatus?.filter(
      (adminStatus) => adminStatus?.isInactive === true
    );
    activeAdmins = allAdminsStatus?.filter(
      (adminStatus) =>
        adminStatus?.isInactive === false &&
        adminStatus?.isNotRequired === false
    );

    const isAllFoundActiveAdminComplete =
      activeAdmins?.length > 0 &&
      activeAdmins?.every((admin) => admin.isComplete === true);

    /* Check if any of the admins have their docs rejected by admin 
    if so then change status to Documentation Sent Back For Revision */
    let hasSomeActiveAdminsAttachmentsRejected = activeAdmins
      ?.map((admin) =>
        admin?.hasAttachmentsAccepted?.some(
          (attachment) => attachment === "reject"
        )
      )
      .some((item) => item === true);

    if (
      spillContractorsList.length === foundAdmins.length &&
      isAllFoundActiveAdminComplete
    ) {
      isAllAdminsComplete = true;
    }

    const isSpillStatusIncludeClosedStatus = wholeSpill?.spill?.status?.includes(
      "Closed"
    );

    const isSpillIncludeClosedOn =
      prevSpill?.dataValues?.closed_on instanceof Date;

    const isSpillStatusReadyToInvoice =
      wholeSpill?.spill?.status === CONSTANTS.READY_TO_INVOICE_STATUS;
    const isSpillStatusFinalReview =
      wholeSpill?.spill?.status === CONSTANTS.FINAL_REVIEW_STATUS;
    const isSpillStatusInvoiceSubmittedToClient =
      wholeSpill?.spill?.status ===
      CONSTANTS.INVOICE_SUBMITTED_TO_CLIENT_STATUS;
    const isSpillStatusPaymentPending =
      wholeSpill?.spill?.status === CONSTANTS.PAYMENT_PENDING_STATUS;
    const isSpillStatusClosed =
      wholeSpill?.spill?.status === CONSTANTS.CLOSED_STATUS;
    const isSpillStatusDocumentationSentBackForRevision =
      wholeSpill?.spill?.status ===
      CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
    const isSpillStatusReadyToClose =
      wholeSpill?.spill?.status === CONSTANTS.READY_TO_CLOSE_STATUS;

    if (
      wholeSpill?.spill?.status === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
      wholeSpill?.spill?.status === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
      wholeSpill?.spill?.status === CONSTANTS.PENDING_EXCAVATION_STATUS ||
      wholeSpill?.spill?.status === CONSTANTS.PENDING_DISPOSAL_STATUS
    ) {
      updatedStatus = wholeSpill?.spill?.status;
    }
    if (
      !isSpillStatusFinalReview &&
      !isSpillStatusInvoiceSubmittedToClient &&
      !isSpillStatusPaymentPending &&
      !isSpillStatusClosed
    ) {
      if (
        !isSpillStatusReadyToInvoice &&
        isAllAdminsComplete === true &&
        hasSomeActiveAdminsAttachmentsRejected === false
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
      }
    }
    /* Check if current status is documentation sent back for
     review and no files or active admins rejected then update
     status to documentation in review */
    if (
      hasSomeActiveAdminsAttachmentsRejected === false &&
      isSpillStatusDocumentationSentBackForRevision
    ) {
      updatedStatus = CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
    }

    /* Case-2: Check if all admins are accepted and 
    marked submission as complete only then change status
    to Documentation in Review or else let it remain in 
    work in progress */
    const hasSomeContractorsPending = spillContractorsList.some(
      (contractor) =>
        contractor?.accepted === null && contractor?.is_inactive === null
    );
    if (hasSomeContractorsPending) {
      if (
        wholeSpill?.spill?.status === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
        wholeSpill?.spill?.status === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
        wholeSpill?.spill?.status === CONSTANTS.PENDING_EXCAVATION_STATUS ||
        wholeSpill?.spill?.status === CONSTANTS.PENDING_DISPOSAL_STATUS
      ) {
        updatedStatus = wholeSpill?.spill?.status;
      } else {
        updatedStatus = CONSTANTS.WORK_IN_PROGRESS;
      }
    }

    /* Case-3: once status is in documentation in review */
    /* Edge Case 1: If any contractor is inactive after
   Documentation In Review change status to Ready To Invoice */
    try {
      const isSpillStatusDocumentationInReview =
        wholeSpill?.spill?.status === CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
      const isSpillStatusDocumentationSentBackForRevision =
        wholeSpill?.spill?.status ===
        CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
      const isReadyToInvoice =
        wholeSpill?.spill?.status === CONSTANTS.READY_TO_INVOICE_STATUS;
      if (
        isSpillStatusDocumentationInReview ||
        isSpillStatusDocumentationSentBackForRevision
      ) {
        if (hasSomeActiveAdminsAttachmentsRejected === true) {
          updatedStatus = CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
        }

        // Check if all active admins attachments approved then change status to Ready To Invoice
        const isActiveAdminsAttachmentsApproved = activeAdmins
          ?.map((activeAdmin) =>
            activeAdmin?.hasAttachmentsAccepted?.every(
              (attachment) => attachment === "approve"
            )
          )
          .every((item) => item === true);

        if (isActiveAdminsAttachmentsApproved === true) {
          updatedStatus = CONSTANTS.READY_TO_INVOICE_STATUS;
        }

        // Check if all admins are inActive then change status of the spill to Work In Progress
        let hasAllAdminsInactive = allAdminsStatus?.every(
          (adminAttachment) => adminAttachment?.isInactive === true
        );

        if (hasAllAdminsInactive === true) {
          if (
            wholeSpill?.spill?.status === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
            wholeSpill?.spill?.status ===
              CONSTANTS.EXTENDED_REMEDATION_STATUS ||
            wholeSpill?.spill?.status === CONSTANTS.PENDING_EXCAVATION_STATUS ||
            wholeSpill?.spill?.status === CONSTANTS.PENDING_DISPOSAL_STATUS
          ) {
            updatedStatus = wholeSpill?.spill?.status;
          } else {
            updatedStatus = CONSTANTS.WORK_IN_PROGRESS;
          }
        }

        // Check if new admin is added while status is DOC in review or sent back to revision then change status to work in progress
        const isAllActiveAdminsAttachmentsAttached = activeAdmins?.every(
          (activeAdmin) => activeAdmin?.hasAttachmentsAttached === true
        );

        if (isAllActiveAdminsAttachmentsAttached === false) {
          if (
            wholeSpill?.spill?.status === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
            wholeSpill?.spill?.status ===
              CONSTANTS.EXTENDED_REMEDATION_STATUS ||
            wholeSpill?.spill?.status === CONSTANTS.PENDING_EXCAVATION_STATUS ||
            wholeSpill?.spill?.status === CONSTANTS.PENDING_DISPOSAL_STATUS
          ) {
            updatedStatus = wholeSpill?.spill?.status;
          } else {
            updatedStatus = CONSTANTS.WORK_IN_PROGRESS;
          }
        }
      }
      // Check if spill is in Ready To Invoice and all Admins are inactive then change status to Ready to Invoice
      if (isReadyToInvoice) {
        if (inActiveAdmins?.length > 0 && activeAdmins.length === 0) {
          updatedStatus = CONSTANTS.WORK_IN_PROGRESS;
        }
      }

      // Check if the spill is in the following statuses at this point then dont update the status
      if (
        isSpillStatusFinalReview ||
        isSpillStatusInvoiceSubmittedToClient ||
        isSpillStatusPaymentPending ||
        isSpillStatusClosed ||
        isSpillStatusReadyToClose
      ) {
        // Check if the active admins are inactive then update status to work in progress
        if (activeAdmins?.length === 0) {
          if (
            wholeSpill?.spill?.status === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
            wholeSpill?.spill?.status ===
              CONSTANTS.EXTENDED_REMEDATION_STATUS ||
            wholeSpill?.spill?.status === CONSTANTS.PENDING_EXCAVATION_STATUS ||
            wholeSpill?.spill?.status === CONSTANTS.PENDING_DISPOSAL_STATUS
          ) {
            updatedStatus = wholeSpill?.spill?.status;
          } else {
            updatedStatus = CONSTANTS.WORK_IN_PROGRESS;
          }
        } else {
          updatedStatus = wholeSpill?.spill?.status;
        }
      }
      // Check if the mark submission has been unchecked:
      if (!isAllFoundActiveAdminComplete) {
        /* 1: Check if admin has undone mark submission as complete then 
        leave status to default if automation has started */
        if (
          wholeSpill?.spill?.status === CONSTANTS.SITEWORK_COMPLETE_STATUS ||
          wholeSpill?.spill?.status === CONSTANTS.EXTENDED_REMEDATION_STATUS ||
          wholeSpill?.spill?.status === CONSTANTS.PENDING_EXCAVATION_STATUS ||
          wholeSpill?.spill?.status === CONSTANTS.PENDING_DISPOSAL_STATUS
        ) {
          updatedStatus = wholeSpill?.spill?.status;
        } else {
          /* 2: Check if admin has undone mark submission as complete then 
        check if docs are rejected so move it to the documentation sent back
        for revision status else move it to documentation in review if the current
        status is not work in progress*/
          if (hasSomeActiveAdminsAttachmentsRejected === true) {
            updatedStatus = CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
          }

          const isAllActiveAdminsAttachmentsAttached = activeAdmins?.every(
            (activeAdmin) => activeAdmin?.hasAttachmentsAttached === true
          );
          if (
            isAllActiveAdminsAttachmentsAttached &&
            wholeSpill?.spill?.status !== CONSTANTS.WORK_IN_PROGRESS
          ) {
            updatedStatus = CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS;
          }
        }
      }

      if (isSpillStatusIncludeClosedStatus && isSpillIncludeClosedOn) {
        updatedStatus = prevSpill?.dataValues?.status;
      }

      if (
        isFetchedSpillHavingRequestedDocuments &&
        (wholeSpill?.spill?.status ===
          CONSTANTS.DOCUMENTATION_IN_REVIEW_STATUS ||
          wholeSpill?.spill?.status ===
            CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION)
      ) {
        updatedStatus = CONSTANTS.DOCUMENTATION_SENT_BACK_FOR_REVISION;
      }
    } catch (error) {
      console.log("Error While Changing Status::", error);
    }

    if (prevSpill.dataValues.status !== updatedStatus) {
      newStatus = await changeStatus(updatedStatus, wholeSpillForStatusChange, {
        userEmail,
        userFullName,
      });
    }

    if (newStatus?.status) {
      /* Update spill status history table with the new status 
      on update if the current status is different from the previous status */
      const get_spill_statuses_history_query = `
      SELECT * FROM spill_statuses_history
      WHERE spill_id=${completeSpill?.id}
      ORDER BY id
      DESC LIMIT 1;
      `;

      const spill_status_obj = await sequelize.query(
        get_spill_statuses_history_query
      );

      if (spill_status_obj[0][0]) {
        const { id, job_no, started_at } = spill_status_obj[0][0];

        const history_status = spill_status_obj[0][0]?.status;
        const history_spill_id = spill_status_obj[0][0]?.spill_id;

        if (newStatus?.status !== history_status) {
          const currentCSTDate = Moment.utc(new Date())?.tz(
            "America/Rankin_Inlet"
          );
          const currentCSTEndedAtDate = currentCSTDate?.format(
            "YYYY-MM-DD HH:mm:ss"
          );

          const update_previous_spill_status_history = `
          UPDATE spill_statuses_history 
          SET ended_at='${currentCSTEndedAtDate}'
          WHERE spill_id=${history_spill_id} AND id=${id};
          `;

          const create_new_spill_status_history = `
          INSERT INTO spill_statuses_history 
            (
            spill_id, 
            job_no, 
            status, 
            started_at, 
            user_id, 
            user_name, 
            user_role, 
            created_at,
            updated_at,
            is_status_automated
            )
            VALUES 
            (
             ${history_spill_id},
             '${job_no}',
             '${newStatus?.status}',
             '${currentCSTEndedAtDate}',
             ${userId},
             "${userFullName}",
             '${userRole}',
             '${currentCSTEndedAtDate}',
             '${currentCSTEndedAtDate}',
             '1'
            )
          `;

          await Promise.all([
            sequelize.query(create_new_spill_status_history),
            sequelize.query(update_previous_spill_status_history),
          ]);
        }
      }
    }

    spillToUpdate = { ...spillToUpdate, status: newStatus?.status || status };

    Object.keys(spillToUpdate).forEach(
      (k) => (spillToUpdate[k] = spillToUpdate[k] || null)
    );

    if ((wholeSpill.spill?.country !== spillToUpdate?.country) || (wholeSpill.spill?.state || spillToUpdate?.state)) {
      const reportingRequirement = await getReportingRequirementHistory(spillToUpdate?.country, spillToUpdate?.state, wholeSpill?.spill?.opened_on ? moment(wholeSpill?.spill?.opened_on).format("YYYY-MM-DD") : null);
      wholeSpill = {
        ...wholeSpill,
        spill: { ...wholeSpill.spill, reportingRequirement},
      };
    }

    const getFacility = await models.ClientOrganizationFacilities.findById(spillToUpdate?.facility_id);

    try {
      await models.Spills.update(spillToUpdate, {
        where: {
          id,
        },
      });

      let closedOn;

      wholeSpill = {
        ...wholeSpill,
        spill: { ...wholeSpill.spill, ...spillToUpdate, facility: getFacility},
      };

      const spillData = { ...wholeSpill.spill };

      const searchStatusString = spillData?.status?.search("Open");

      if (spillData.closed_on != "Still Open" && searchStatusString != -1) {
        closedOn = "Re-Opened";
      } else {
        closedOn = spillData.closed_on || "Still Open";
      }

      //Sending Submission email if any admin's submission is marked as complete
      if (newComplete.length) {
        sendSubmissionEmail(
          getDataValues(spillData),
          userFullName,
          userEmail,
          getDataValues(prevSpill)
        );
      }

      const currentSpillData = {
        ...spillData,
        closed_on: closedOn,
        assigned_packet_reviewer: updatedPacketAssignment,
      };

      if (role?.dataValues.role === ROLES.PROB_PM) {
        newAction({
          type: ACTIONS.EDIT_SPILL,
          data: {
            id: spillData?.id,
            jobNo: spillData.job_no,
          },
          status: "Pending",
          manager_id: spillData.user_id,
          user_id: userId,
          info: {
            userFullName: userFullName,
            changes: getChanges(
              getDataValues(prevSpill),
              getDataValues(spillData)
            ),
          },
        });
      }
      res.json({
        success: true,
        data: {
          ...wholeSpill,
          spill: currentSpillData,
        },
      });
    } catch (error) {
      console.log(error);
      res.status(500).send();
    }
  } catch (error) {
    console.log("Error while updating spill", error);
  }
};

export const getTotalNotesForPrintSpill = async (req, res) => {
  try {
    const { spillId } = req.query;
    // spill notes
    const query = `
    SELECT sn.hour, sn.amount, sn.rate, sn.created_at, sn.service_type, sn.description, sn.deleted_at
      FROM spill_notes sn
      LEFT OUTER JOIN salvage_containers sc ON sc.note_id = sn.id
      WHERE sn.spill_id = ${spillId} AND sn.deleted_at IS NULL
      GROUP BY sn.id, sc.note_id
      ORDER BY sn.created_at ASC;
    `;

    let result = await sequelize.query(query);

    let totalSpillNotes = [...result[0]];
    let updatedTotalSpillNotes = totalSpillNotes?.map((note) => {
      return (note = {
        ...note,
        created_at: note?.created_at,
      });
    });

    res.status(200).json({
      data: updatedTotalSpillNotes,
    });
    return updatedTotalSpillNotes;
  } catch (err) {
    console.log("err", err);
  }
};

export const getPaginatedNotes = async (req, res) => {
  try {
    const { spillId } = req.query;
    let spillNotes = [];
    if (!spillId) {
      res.status(403).json({ message: `Invalid query params` });
    }

    const query = `select
      sn2.*,
      JSON_OBJECT("active",u.active,"full_name",u.full_name) as "user",
      notes.note_attachments,
      salvage.salvage_containers
      
    
    from spill_notes sn2
    left join users u on sn2.user_id =u.id
    left join
    (
      select sn.id,IF(COUNT(na.id) = 0, JSON_ARRAY(),JSON_ARRAYAGG(
          JSON_OBJECT(
          "id", na.id,
          "type", na.type,
          "url_link", na.url_link,
          "key", na.key,
          "spill_note_id", na.spill_note_id,
          "size", na.size,
          "name", na.name,
          "created_at", na.created_at,
          "updated_at", na.updated_at,
          "deleted_at", na.deleted_at
          )
         )) AS note_attachments
          
      
         from spill_notes sn
      left join note_attachments na on sn.id =na.spill_note_id and na.deleted_at is null
      where sn.spill_id =${spillId} and sn.deleted_at is null
      group by 1
    ) notes on sn2.id=notes.id
    left join
    (
    select sn.id,
    IF(COUNT(sc.id) = 0, JSON_ARRAY(),
     JSON_ARRAYAGG(
        JSON_OBJECT(
        "id", sc.id,
        "note_id", sc.note_id,
        "sc_no", sc.sc_no,
        "type", sc.type,
        "content", sc.content,
        "un_no", sc.uN_no,
        "drum_weight", sc.drum_weight,
        "is_hazmat", sc.is_hazmat,
        "disposal_handled_by", sc.disposal_handled_by,
        "container_disposition", sc.container_disposition,
        "created_at", sc.created_at,
        "updated_at", sc.updated_at,
        "deleted_at", sc.deleted_at
        )
       )) AS salvage_containers
         from spill_notes sn
      left join salvage_containers sc on sn.id =sc.note_id and sc.deleted_at is null
      where sn.spill_id =${spillId} and sn.deleted_at is null
      group by 1
    
    ) salvage
    on sn2.id =salvage.id
    where sn2.spill_id=${spillId} and sn2.deleted_at is null;

    `;
    let result = await sequelize.query(query);
    // Last array index will alwasys have the misc counts
    let totalSpillNotes = [...result[0]];

    if (totalSpillNotes?.length) {
      let totalSpillNotesAmount = totalSpillNotes
        ?.filter((note) => note?.amount !== null)
        ?.map((item) => parseFloat(item?.amount))
        .reduce((p, c) => p + c, 0);

      totalSpillNotesAmount = totalSpillNotesAmount.toFixed(2);

      totalSpillNotesAmount =
        totalSpillNotesAmount?.split(".")?.length > 0
          ? totalSpillNotesAmount
          : parseFloat(totalSpillNotesAmount.toFixed(2));

      let count = 0;
      totalSpillNotes.map((item) => {
        count += item.note_attachments.length;
      });

      let totalSpillNotesHour = totalSpillNotes
        ?.filter((note) => note?.hour !== null)
        ?.map((item) => +item?.hour)
        .reduce((p, c) => p + c, 0);

      totalSpillNotesHour = totalSpillNotesHour.toFixed(2);

      let totalNotesHours = totalSpillNotesHour;
      let totalNotesAmount = totalSpillNotesAmount;
      let totalNotesCount = totalSpillNotes?.length;
      let totalNotesAttachments = count;

      spillNotes = [
        ...totalSpillNotes,
        {
          totalNotesHours: totalNotesHours,
          totalNotesAmount: totalNotesAmount,
          totalNotesCount: totalNotesCount,
          totalNotesAttachments: totalNotesAttachments,
        },
      ];
    }

    res.status(200).json({
      data: spillNotes,
    });
  } catch (err) {
    console.log("err", err);
  }
};

export const getCompleteSpill = async (req, res) => {
  let result;
  let wholeSpill;
  let is_inactive = 1;
  let isContractor = 1;
  let accessRestricted = 0;
  const { mode } = req.query;
  const { job_no } = req.query;
  const role = req.user.role_id;
  const contractor_role = req.user.role.role;
  const contractor_id = req.user.contractor_id;
  const contractor_address_id = req.user.contractor_address_id;
  const { TEST_USER_EMAIL_ADDRESS } = process.env;
  const testEmails = TEST_USER_EMAIL_ADDRESS?.split(",");
  if (!testEmails?.includes(req.user?.email) && job_no?.includes("TEST")) {
    res.status(404).send();
    return;
  }

  // first we have to check if there is contractor exit or not.
  if (contractor_id) {
    // if contractor exist then we have to check if contractor is active or not or has it performed any activity.
    const query = `select s.id, sc.is_inactive ,sc.activity_performed , sc.contractor_id ,sc.contractor_role from spills as s 
    left join  connections as c on c.spill_id = s.id
    left join  spill_contractors as sc on   sc.connection_id = c.id and sc.contractor_id = ${contractor_id}
    where s.job_no ="${job_no}" and (sc.accepted = true ) AND (sc.is_inactive = false  or sc.is_inactive is null or sc.activity_performed = true) 
    and c.deleted_at is null and sc.deleted_at is null and s.deleted_at is null`;

    result = await sequelize.query(query);

    for (const iterator of result[0]) {
      /* case 1: if login contractor role is CONTRACTOR_ADMIN and 
      the result spill contractor is head contractor then 
      we update the is_inactive. */
      if (
        contractor_role === ROLES.CONTRACTOR_ADMIN &&
        iterator.contractor_role === SPILL_CONTRACTOR_ROLES.HEAD_CONTRACTOR
      ) {
        is_inactive = iterator.is_inactive;
      }

      /* case 2: if login contractor role is CONTRACTOR_USER and 
      the result spill contractor is sub contractor then 
      we update the is_inactive.*/
      if (
        contractor_role === ROLES.CONTRACTOR_USER &&
        iterator.contractor_role === SPILL_CONTRACTOR_ROLES.SUB_CONTRACTOR
      ) {
        is_inactive = iterator.is_inactive;
      }

      /* case 3: if login contractor role is CONTRACTOR_USER and 
      the result spill contractor is head contractor and 
      address ID is null then this means this user belongs to head conractor. 
      So, we update the inactive */
      if (
        contractor_role === ROLES.CONTRACTOR_USER &&
        contractor_address_id === null &&
        iterator.contractor_role === SPILL_CONTRACTOR_ROLES.HEAD_CONTRACTOR
      ) {
        is_inactive = iterator.is_inactive;
      }

      /* case 4: if login contractor role is CONTRACTOR_ADMIN and
      the result spill contractor is sub congractor the we will
      update is_inactive*/

      if (
        contractor_role === ROLES.CONTRACTOR_ADMIN &&
        iterator.contractor_role === SPILL_CONTRACTOR_ROLES.SUB_CONTRACTOR
      ) {
        is_inactive = iterator.is_inactive;
      }

      /* case 5: if login contractor role is CONTRACTOR_USER and 
      the result spill contractor is head contractor then and
      the address ID is not null this means that the contractor user 
      not belongs to head contractor*/

      if (
        contractor_role === ROLES.CONTRACTOR_USER &&
        contractor_address_id !== null &&
        iterator.contractor_role === SPILL_CONTRACTOR_ROLES.HEAD_CONTRACTOR
      ) {
        accessRestricted = 1;
      }
    }
    isContractor = result[0].length;
  }

  // Roles based access to the logged in users to view/edit spill
  if (
    isContractor === 0 ||
    ((role === 3 || role === 5 || role === 6 || role === 7 || role === 8) &&
      mode === "edit")
  ) {
    /* case 1: if there is not contractor find then they don't have access. OR 
    we applied role based check on spill which are allowed to show on edit mode */
    res.status(404).send();
    return;
  } else if (
    is_inactive === 1 &&
    mode === "edit" &&
    role !== 1 &&
    role !== 2 &&
    role !== 12 &&
    role !== 11
  ) {
    /* case 2: if contractor is inactive and try to edit the spill then not allowed to perform this action 
    Further we also check the logged person should not be SUPER USER (role id is 1)  
    PES Admin (role id is 2) PES ACC Admin (role id is 12) PROB PM (role id is 11) */
    res.status(404).send();
    return;
  } else if (
    is_inactive === 1 &&
    mode === "edit" &&
    role !== 1 &&
    role !== 2 &&
    role !== 12 &&
    role !== 11
  ) {
    /* case 2: if contractor is inactive and try to edit the spill then not allowed to perform this action 
    Further we also check the logged person should not be SUPER USER (role id is 1)  
    PES Admin (role id is 2) PES ACC Admin (role id is 12) PROB PM (role id is 11) */

    res.status(404).send();
    return;
  } else if (
    accessRestricted === 1 &&
    is_inactive === 1 &&
    mode === "view" &&
    role !== 1 &&
    role !== 2 &&
    role !== 12
  ) {
    /* case 3: if contractor is inactive and try to view the spill and 
    we check if its accessRestricted then not allowed to perform this action */
    res.status(404).send();
    return;
  } else {
    wholeSpill = await getCompleteSpillByJobNo(job_no);
    if (!wholeSpill) {
      res.status(404).send();
      return;
    }
    res.status(200).json({
      data: wholeSpill,
    });
  }
};

const typeBasedBoolCheck = (value) => {
  if (value === null) {
    return null;
  } else {
    if (value === 1) {
      return true;
    } else {
      return false;
    }
  }
};

export const getCompleteSpillByJobNo = async (job_no) => {
  try {
    // increase group concat length for JSON object
    let query0 = `
      SET SESSION group_concat_max_len = 100000;
     `;
    await sequelize.query(query0);

    let query1 = `
    select s.*, JSON_OBJECT(
      "id", cof.id,
      "name", cof.name,
      "internal_id", cof.internal_id,
      "generator_status", cof.generator_status,
      "epa_id", cof.epa_id,
      "address", cof.address,
      "city", cof.city,
      "state", cof.state,
      "country", cof.country,
      "zip_code", cof.zip_code,
      "phone_number", cof.phone_number,
      "region", cof.region
      )
      as facility
    from spills s
    left join spill_notes sn on sn.spill_id = s.id
    left join note_attachments na on na.spill_note_id = sn.id
    left join salvage_containers sc on sc.note_id = sn.id
    left join spill_materials sm on sm.id = s.material_id 
    left join client_organizations co on co.id = s.org_id 
    left join client_organization_facilities cof on s.facility_id = cof.id 
    where job_no = '${job_no}'
    ORDER BY sn.created_at ASC, sc.sc_no ASC limit 1;
    `;
    let results1 = await sequelize.query(query1);

    const flattenedResult = results1.flat();

    const flattenedObj = Array.from(
      new Set(flattenedResult.map((a) => a.id))
    ).map((id) => {
      return flattenedResult.find((a) => a.id === id);
    })[0];

    let spillData = {
      ...flattenedObj,
      is_approved: typeBasedBoolCheck(flattenedObj?.is_approved),
      is_demo: typeBasedBoolCheck(flattenedObj?.is_demo),
      is_legacy: typeBasedBoolCheck(flattenedObj?.is_legacy),
      is_hazmat: typeBasedBoolCheck(flattenedObj?.is_hazmat),
      has_msds: typeBasedBoolCheck(flattenedObj?.has_msds),
      is_waste: typeBasedBoolCheck(flattenedObj?.is_waste),
      need_5800: typeBasedBoolCheck(flattenedObj?.need_5800),
      send_attachment: typeBasedBoolCheck(flattenedObj?.send_attachment),
      response_sent: typeBasedBoolCheck(flattenedObj?.response_sent),
      subrogation: typeBasedBoolCheck(flattenedObj?.subrogation),
      send_email: typeBasedBoolCheck(flattenedObj?.send_email),
      closed_on:
        flattenedObj?.closed_on === null
          ? "Still Open"
          : flattenedObj?.closed_on,
    };

    const spillId = results1[0][0]?.id;
    const orgId = results1[0][0]?.org_id;
    const userId = results1[0][0]?.user_id;
    const materialId = results1[0][0]?.material_id;

    if (!userId) {
      throw new Error("User id doesn't exist")
    }
    if (!spillId) {
      throw new Error("Spill id doesn't exist")
    }

    // users : ['full_name', 'email']
    let query2 = `
    select u.full_name, u.email, u.active
    from users u 
    where u.id = ${userId};
    `;
    let results2 = await sequelize.query(query2);

    let updatedUser = {
      ...results2[0][0],
      active: typeBasedBoolCheck(results2[0][0]?.active),
    };

    // recipients : [all]
    let query3 = `
    select recip.*, 
    JSON_OBJECT(
      "active", if(u.active MOD 2 = 0, cast(FALSE as json), cast(TRUE as json)),
      "id", u.id,
      "full_name", u.full_name,
      "phone", u.phone,
      "email", u.email,
      "secondary_email", u.secondary_email,
      "created_by", u.created_by,
      "confirmed", u.confirmed,
      "role_id", u.role_id,
      "email_notification", if(u.email_notification  MOD 2 = 0,  cast(FALSE as json), cast(TRUE as json)),
      "org_id", u.org_id,
      "eula_accepted", if(u.eula_accepted MOD 2 = 0,  cast(FALSE as json), cast(TRUE as json)),
      "updated_at", u.updated_at,
      "created_at", u.created_at,
      "deleted_at", u.deleted_at,
      "last_login", u.last_login,
      "is_demo", u.is_demo,
      "contractor_id", u.contractor_id,
      "contractor_address_id", u.contractor_address_id,
      "is_default", u.is_default
      )
      as user,
    JSON_OBJECT(
      "id", co.id,
      "name", co.name,
      "salesPerson", co.salesPerson,
      "taxId", co.taxId,
      "address", co.address,
      "city", co.city,
      "state",co.state,
      "zipCode", co.zipCode,
      "country", co.country,
      "phone", co.phone,
      "rate", co.rate,
      "active", if(co.active MOD 2 = 0, cast(FALSE as json), cast(TRUE as json)),
      "reporting", co.reporting,
      "report_5800", co.report_5800,
      "reporting_instruction", co.reporting_instruction,
      "instruction_5800", co.instruction_5800,
      "miscellaneous", co.miscellaneous,
      "service_id", co.service_id,
      "rate_type",co.rate_type,
      "is_demo", if(co.is_demo MOD 2 = 0, cast(FALSE as json), cast(TRUE as json)),
      "sales_person_id", co.sales_person_id,
      "is_god", co.is_god,
      "code", co.code,
      "payment_terms", co.payment_terms,
      "timestamp_visibility",co.timestamp_visibility,
      "monetary_visibility", co.monetary_visibility,
      "updated_at", co.updated_at,
      "created_at", co.created_at,
      "deleted_at", co.deleted_at
      ) as client_organization
      from recipients recip
      left join users u on u.id = recip.user_id
      left join client_organizations co on co.id = u.org_id
      where recip.spill_id = ${spillId}
      ORDER BY recip.id DESC;
    `;

    // reserves : [all]
    let query4 = `
    select resv.*, JSON_OBJECT(
      "active", if(u.active MOD 2 = 0, cast(FALSE as json), cast(TRUE as json)),
      "id", u.id,
      "full_name", u.full_name,
      "phone", u.phone,
      "email", u.email,
      "secondary_email", u.secondary_email,
      "created_by", u.created_by,
      "confirmed", u.confirmed,
      "role_id", u.role_id,
      "email_notification", if(u.email_notification MOD 2 = 0, cast(FALSE as json), cast(TRUE as json)),
      "org_id", u.org_id,
      "eula_accepted", if(u.eula_accepted MOD 2 = 0, cast(FALSE as json), cast(TRUE as json)),
      "updated_at", u.updated_at,
      "created_at", u.created_at,
      "deleted_at", u.deleted_at,
      "last_login", u.last_login,
      "is_demo", u.is_demo,
      "contractor_id", u.contractor_id,
      "contractor_address_id", u.contractor_address_id,
      "is_default", u.is_default
    ) as user from reserves resv
    left join users u on u.id = resv.user_id
    where resv.spill_id = ${spillId} AND resv.deleted_at is NULL
    ORDER BY resv.id ASC;
    `;

    // spill admins : ['is_complete', 'contractor_id']:
    let query5 = `
    select sa.contractor_id, sa.is_complete,
     JSON_ARRAYAGG(
      JSON_OBJECT(
        "admin_note", sat.admin_note,
        "created_at", sat.created_at,
        "deleted_at", sat.deleted_at,
        "id", sat.id,
        "key", sat.key,
        "name", sat.name,
        "rejected_count", sat.rejected_count,
        "size", sat.size,
        "spill_admin_id", sat.spill_admin_id,
        "status", sat.status,
        "type", sat.type,
        "updated_at", sat.updated_at,
        "url_link", sat.url_link,
        "user_id", sat.user_id)
      ) as spill_attachments
      from spill_admins sa
      left join users u on u.contractor_id = sa.contractor_id
      left join spill_attachments sat on sat.spill_admin_id = sa.id
      where sa.spill_id = ${spillId} AND sa.deleted_at is NULL
      group by sa.id;
      `;

    // client organization
    let query6 = `
    select co.*,
    JSON_OBJECT(
      "active", if(co.active MOD 2 = 0, cast(FALSE as json), cast(TRUE as json))
    ) as active,
    JSON_OBJECT(
      "is_demo", if(co.is_demo MOD 2 = 0, cast(FALSE as json), cast(TRUE as json))
    ) as is_demo
    from client_organizations co where co.id = ${orgId};
    `;

    // spill materials
    let query7 = `
    select sm.name from spill_materials sm where sm.id = ${materialId};
    `;

    // spill notes
    let query8 = `
    SELECT sn.*,
    JSON_OBJECT(
      "active", u.active,
      "full_name", u.full_name
    ) as user,
      JSON_ARRAYAGG(
       JSON_OBJECT(
        "id", na.id,
        "type", na.type,
        "url_link", na.url_link,
        "key", na.key,
        "spill_note_id", na.spill_note_id,
        "size", na.size,
        "name", na.name,
        "created_at", na.created_at,
        "updated_at", na.updated_at,
        "deleted_at", na.deleted_at
       )
      ) as note_attachments, 
      JSON_ARRAYAGG(
       JSON_OBJECT(
        "id", sc.id,
        "note_id", sc.note_id,
        "sc_no", sc.sc_no,
        "type", sc.type,
        "content", sc.content,
        "un_no", sc.uN_no,
        "drum_weight", sc.drum_weight,
        "is_hazmat", sc.is_hazmat,
        "created_at", sc.created_at,
        "updated_at", sc.updated_at,
        "deleted_at", sc.deleted_at
       )
      ) as salvage_containers
      from spill_notes sn
      left outer join note_attachments na on na.spill_note_id = sn.id
      left outer join salvage_containers sc on sc.note_id = sn.id
      left outer join users u on u.id = sn.user_id
      where sn.spill_id = ${spillId} AND sn.deleted_at is NULL
      group by sn.id, sc.note_id
      ORDER BY sn.created_at ASC
      LIMIT 0, 10;
    `;

    // spill notes count
    let query9 = `
	    SELECT sn.id, sn.amount, sn.hour ,     		
    JSON_ARRAYAGG(		
      JSON_OBJECT(		
       "id", na.id,		
       "type", na.type,		
       "url_link", na.url_link,		
       "key", na.key,		
       "spill_note_id", na.spill_note_id,		
       "size", na.size,		
       "name", na.name,		
       "created_at", na.created_at,		
       "updated_at", na.updated_at,		
       "deleted_at", na.deleted_at		
      )		
     ) as note_attachments
      from spill_notes sn
      left outer join note_attachments na on na.spill_note_id = sn.id
      left outer join salvage_containers sc on sc.note_id = sn.id
      left outer join users u on u.id = sn.user_id
      where sn.spill_id = ${spillId} AND sn.deleted_at is NULL
      group by sn.id, sc.note_id
      ORDER BY sn.created_at ASC;
    `;

    const wasteHandling = await findClientWasteHandlings(orgId, results1[0][0]?.opened_on ? moment(results1[0][0]?.opened_on).format("YYYY-MM-DD") : null);

    const clientContractorsDoNotUse = await models.ClientOrganizationContractors.findAll({
      attributes: ["id", "org_id", "contractor_id", "address_id"],
      where: {
        org_id: 136,
      }
    });

    const [
      results3,
      results4,
      results5,
      results6,
      results7,
      results8,
      results9,
    ] = await Promise.all([
      sequelize.query(query3),
      sequelize.query(query4),
      sequelize.query(query5),
      sequelize.query(query6),
      sequelize.query(query7),
      sequelize.query(query8),
      sequelize.query(query9),
    ]);

    // results3
    for (let item of results3[0]) {
      let co = item?.client_organization;
      delete item?.client_organization;
      item.user.client_organization = co;

      let is_demo = item?.user?.is_demo;
      let is_default = item?.user?.is_default;

      item.user.is_demo = typeBasedBoolCheck(is_demo);
      item.user.is_default = typeBasedBoolCheck(is_default);
    }

    // results5
    let updatedSpillAdmins = [...results5[0]];

    for (let admin of updatedSpillAdmins) {
      let adminIsComplete = admin?.is_complete;

      admin.is_complete = typeBasedBoolCheck(adminIsComplete);
    }

    let updatedSpillAdminAttachments = [];

    updatedSpillAdmins.map((item) => {
      for (let attachmentItem of item.spill_attachments) {
        updatedSpillAdminAttachments = item.spill_attachments.filter(
          (attachmentItem) => isEmptyObject(attachmentItem) === false
        );
      }
      item.spill_attachments = updatedSpillAdminAttachments;
    });

    // results6
    let updatedClientOrganization = {
      ...results6[0][0],
      active: results6[0][0]?.active?.active,
      is_demo: results6[0][0]?.is_demo?.is_demo,
    };

    // results7
    let spillMaterial = { ...results7[0][0] };

    const spillMaterialExists = Object.keys(spillMaterial).length;

    let updatedSpillMaterial = spillMaterialExists ? spillMaterial : null;

    // results8
    let spillNotes = [...results8[0]];

    let updatedSpillNoteAttachments = [];
    let updatedSpillNoteSalvageContainers = [];

    spillNotes.map((item, index) => {
      for (let noteItem of item.note_attachments) {
        updatedSpillNoteAttachments = item.note_attachments.filter(
          (note) => isEmptyObject(note) === false
        );
      }
      for (let cotainerItem of item.salvage_containers) {
        updatedSpillNoteSalvageContainers = item.salvage_containers.filter(
          (container) => isEmptyObject(container) === false
        );
      }

      let uniqueSpillNotesAttachments = updatedSpillNoteAttachments?.filter(
        (value, index) => {
          const stringifiedValue = JSON.stringify(value);
          return (
            index ===
            updatedSpillNoteAttachments.findIndex((obj) => {
              return JSON.stringify(obj) === stringifiedValue;
            })
          );
        }
      );

      let uniqueSpillNoteSalvageContainers = updatedSpillNoteSalvageContainers?.filter(
        (value, index) => {
          const stringifiedValue = JSON.stringify(value);
          return (
            index ===
            updatedSpillNoteSalvageContainers.findIndex((obj) => {
              return JSON.stringify(obj) === stringifiedValue;
            })
          );
        }
      );

      let filterSpillNoteSalvageContainers = uniqueSpillNoteSalvageContainers?.filter(
        (item, index) => item?.deleted_at === null
      );

      filterSpillNoteSalvageContainers.sort(
        (a, b) => parseFloat(a.id) - parseFloat(b.id)
      );

      uniqueSpillNotesAttachments = uniqueSpillNotesAttachments?.filter(
        (note) => note.deleted_at === null
      );

      item.note_attachments = uniqueSpillNotesAttachments;
      item.salvage_containers = filterSpillNoteSalvageContainers;

      let userIsNull = isNullish(item?.user);

      if (userIsNull === true) {
        item.user = null;
      } else {
        let isActiveUser = item?.user?.active;
        item.user.active = typeBasedBoolCheck(isActiveUser);
      }
    });

    // results9
    let totalSpillNotes = [...results9[0]];

    let totalSpillNotesAmount = totalSpillNotes
      ?.filter((note) => note?.amount !== null)
      ?.map((item) => parseFloat(item?.amount))
      .reduce((p, c) => p + c, 0);

    totalSpillNotesAmount = totalSpillNotesAmount.toFixed(2);

    totalSpillNotesAmount =
      totalSpillNotesAmount?.split(".")?.length > 0
        ? totalSpillNotesAmount
        : parseFloat(totalSpillNotesAmount.toFixed(2));

    let totalSpillNotesHour = totalSpillNotes
      ?.filter((note) => note?.hour !== null)
      ?.map((item) => +item?.hour)
      .reduce((p, c) => p + c, 0);

    totalSpillNotesHour = totalSpillNotesHour.toFixed(2);

    let spillNotesCount = totalSpillNotes?.length;
    let count = 0;

    totalSpillNotes.map((item) => {
      // count += item.note_attachments.length
      let uniqueSpillNotesAttachmentsCount;

      uniqueSpillNotesAttachmentsCount = item.note_attachments?.filter(
        (value, index) => {
          const isEmpty = Object.values(value).every(
            (x) => x === null || x === ""
          );

          if (isEmpty) {
            return false;
          } else {
            return true;
          }
        }
      );

      uniqueSpillNotesAttachmentsCount = uniqueSpillNotesAttachmentsCount?.filter(
        (note) => note.deleted_at === null
      );

      count += uniqueSpillNotesAttachmentsCount.length;
    });

    // update spill data
    spillData = {
      ...spillData,
      user: updatedUser,
      client_organization: updatedClientOrganization,
      spill_material: updatedSpillMaterial,
      recipients: [...results3[0]],
      reserves: [...results4[0]],
      spill_admins: updatedSpillAdmins,
      spill_notes: spillNotes,
      spill_notes_data: {
        count: spillNotesCount,
        amount: totalSpillNotesAmount,
        hour: totalSpillNotesHour,
        totalNotesAttachments: count,
      },
    };

    if (!spillData) {
      return null;
    }

    let connectionData = await models.Connections.findAll({
      where: {
        spill_id: spillData?.id,
      },
    });
    let adminData = await models.SpillAdmins.findAll({
      include: [
        {
          model: models.SpillAttachments,
          include: [
            {
              model: models.User,
              attributes: ["full_name", "email"],
              include: [
                {
                  model: models.Roles,
                  attributes: ["role"],
                },
              ],
            },
          ],
        },
      ],
      where: {
        spill_id: spillData?.id,
      },
    });

    for (const [index, admin] of adminData.entries()) {
      const fetchAdminAttachmentWithExpiry = `
      SELECT * FROM contractor_attachments_expiries
      WHERE contractor_id = ${admin?.contractor_id}
      AND contractor_address_id ${
        admin?.contractor_address_id === null
          ? "IS NULL"
          : `= ${admin?.contractor_address_id}`
      };
      `;

      const fetchedAdminAttachmentWithExpiry = await sequelize.query(
        fetchAdminAttachmentWithExpiry
      );

      const fetchCertificatesDoc = `
      SELECT * FROM generic_attached_documents
      WHERE contractor_id = ${admin?.contractor_id} and deleted_at is null
      `;
      const fetchedCertificatesDoc = await sequelize.query(
        fetchCertificatesDoc
      );

      adminData[index].dataValues.attachments_with_expiry =
        fetchedAdminAttachmentWithExpiry[0];

      adminData[index].dataValues.contractor_certificates =
        fetchedCertificatesDoc[0];
      adminData[index].dataValues.pes_paid = Moment(
        adminData[index].dataValues.pes_paid
      ).add(5, "hours");
      adminData[index].dataValues.contractor_paid = Moment(
        adminData[index].dataValues.contractor_paid
      ).add(5, "hours");
      adminData[index].dataValues.trans_to_ct = Moment(
        adminData[index].dataValues.trans_to_ct
      ).add(5, "hours");
      adminData[index].dataValues.pay_by = Moment(
        adminData[index].dataValues.pay_by
      ).add(5, "hours");
    }

    // Getting Spill Contractor Roles and replacing them in Admin Data
    let spillContractorRoles = [];

    let connectionId = connectionData[0]?.id;

    let updatedAdminData = [];

    for (let [index, admin] of adminData.entries()) {
      let contractor_id = admin.contractor_id;

      let spill_contractor_role = await models.SpillContractors.findAll({
        logging: false,
        attributes: ["contractor_role", "id", "is_inactive"],
        include: [
          {
            model: models.Contractors,
          },
        ],
        where: {
          $and: [
            {
              contractor_id: {
                $like: contractor_id,
              },
            },
            {
              connection_id: {
                $like: connectionId,
              },
            },
          ],
        },
      });

      spillContractorRoles.push({
        contractor_id: spill_contractor_role[0]?.dataValues.id,
        role: spill_contractor_role[0]?.dataValues?.contractor_role,
        adminId: admin.id,
        isAdminActive: spill_contractor_role[0]?.dataValues.is_inactive,
      });
    }

    spillContractorRoles.map((role) => {
      let adminFound = adminData.find((admin) => admin.id === role.adminId);

      if (adminFound) {
        adminFound = {
          ...adminFound.dataValues,
          spill_contractor_role: role.role,
          spill_contractor_id: role.contractor_id,
          spill_contractor_is_inactive: role.isAdminActive,
        };
      }

      updatedAdminData.push(adminFound);
    });

    // Add Spill Contractors
    let spillContractors = [];
    const reportingRequirement = await getReportingRequirementHistory(results1[0][0]?.country, results1[0][0]?.state, results1[0][0]?.opened_on ? moment(results1[0][0]?.opened_on).format("YYYY-MM-DD") : null);
    if (connectionData.length > 0) {
      let agency = await models.Agencies.findById(connectionData[0].agency_id);
      let nationalAgency = await models.Agencies.findById(
        connectionData[0].agency_national
      );
      if (nationalAgency?.dataValues?.id) {
        connectionData[0].dataValues = {
          ...connectionData[0].dataValues,
          agency_national: nationalAgency.dataValues,
        };
      }
      if (connectionData[0].address_id) {
        let address = await models.Addresses.findById(
          connectionData[0].address_id
        );
        address.dataValues = {
          ...address.dataValues,
          name: agency?.dataValues?.name,
          addressId: address?.dataValues?.id,
          id: agency?.dataValues?.id,
        };
        agency.dataValues = address?.dataValues;
      }

      connectionData[0].dataValues = {
        ...connectionData[0].dataValues,
        agency: agency?.dataValues,
        uniqueAgencyId:
          connectionData[0].agency_id && connectionData[0].address_id
            ? `${connectionData[0].agency_id}-${
                connectionData[0].address_id ? connectionData[0].address_id : ""
              }`
            : null,
      };

      let contractors = await getContractors(connectionData[0].id);
      spillContractors = mapContractors(contractors);
    }

    let closedOn;

    const searchStatusString = spillData?.status?.search("Open");

    if (spillData.closed_on != "Still Open" && searchStatusString != -1) {
      closedOn = "Re-Opened";
    } else {
      closedOn = spillData.closed_on || "Still Open";
    }

    // Fetch packet reviewer for spill
    const fetchPacketAssignmentData = `
    SELECT 
      packet_reviewer_user_id, 
      assigned_spill_id, 
      packet_reviewer_user_full_name 
    FROM 
      packet_reviewer_assignments 
    WHERE 
      assigned_spill_id=${spillData?.id}
    AND
      deleted_at IS NULL;
    `;

    let fetchedPacketAssignmentData = await sequelize.query(
      fetchPacketAssignmentData
    );

    fetchedPacketAssignmentData = fetchedPacketAssignmentData[0][0];

    let assigned_packet_reviewer = {};

    if (fetchedPacketAssignmentData) {
      const fetchPacketReviewerAssignments = `
        SELECT
          assigned_spill_id
        FROM 
          packet_reviewer_assignments
        WHERE 
          packet_reviewer_user_id=${fetchedPacketAssignmentData?.packet_reviewer_user_id}
        AND 
          deleted_at IS NULL;
      `;

      let fetchedPacketReviewerAssignments = await sequelize.query(
        fetchPacketReviewerAssignments
      );

      fetchedPacketReviewerAssignments = fetchedPacketReviewerAssignments[0];

      assigned_packet_reviewer = {
        updatedPacketReviewerData: fetchedPacketAssignmentData,
        count: fetchedPacketReviewerAssignments?.length,
      };
    }

    const currentSpillData = {
      ...spillData,
      closed_on: closedOn,
      assigned_packet_reviewer,
      reportingRequirement,
      wasteHandling,
      clientContractorsDoNotUse
    };

    // If admin is inactive and havenot perform any action
    let filteredADmins = [];

    filteredADmins = updatedAdminData.filter(
      (admin) =>
        admin.info === "" &&
        admin.contractor_invoice === "" &&
        admin.inv_no === "" &&
        admin.spill_attachments.length === 0 &&
        admin.is_removed === true
    );

    for (const [index, iterator] of updatedAdminData.entries()) {
      for (const iterator2 of filteredADmins) {
        if (iterator.id === iterator2.id) {
          updatedAdminData.splice(index, 1);
        }
      }
    }

    return {
      spill: currentSpillData,
      connection: connectionData[0] || null,
      admin: updatedAdminData || null,
      spillContractors,
    };
  } catch (err) {
    console.log("Error=========+>", err);
    // res.status(500).send(err);
  }
};

const getSpillNotesData = async (spillId) => {
  try {
    // spill notes count
    let query9 = `
      SELECT sn.id, sn.amount, sn.hour ,     		
      JSON_ARRAYAGG(		
      JSON_OBJECT(		
      "id", na.id,		
      "type", na.type,		
      "url_link", na.url_link,		
      "key", na.key,		
      "spill_note_id", na.spill_note_id,		
      "size", na.size,		
      "name", na.name,		
      "created_at", na.created_at,		
      "updated_at", na.updated_at,		
      "deleted_at", na.deleted_at		
      )		
      ) as note_attachments
      from spill_notes sn
      left outer join note_attachments na on na.spill_note_id = sn.id
      left outer join salvage_containers sc on sc.note_id = sn.id
      left outer join users u on u.id = sn.user_id
      where sn.spill_id = ${spillId} AND sn.deleted_at is NULL
      group by sn.id, sc.note_id
      ORDER BY sn.created_at ASC;
      `;

    const result9 = await sequelize.query(query9);

    // results9
    let totalSpillNotes = [...result9[0]];

    let totalSpillNotesAmount = totalSpillNotes
      ?.filter((note) => note?.amount !== null)
      ?.map((item) => parseFloat(item?.amount))
      .reduce((p, c) => p + c, 0);

    totalSpillNotesAmount = totalSpillNotesAmount.toFixed(2);

    totalSpillNotesAmount =
      totalSpillNotesAmount?.split(".")?.length > 0
        ? totalSpillNotesAmount
        : parseFloat(totalSpillNotesAmount.toFixed(2));

    let totalSpillNotesHour = totalSpillNotes
      ?.filter((note) => note?.hour !== null)
      ?.map((item) => +item?.hour)
      .reduce((p, c) => p + c, 0);

    totalSpillNotesHour = totalSpillNotesHour.toFixed(2);

    let spillNotesCount = totalSpillNotes?.length;
    let count = 0;

    totalSpillNotes.map((item) => {
      // count += item.note_attachments.length
      let uniqueSpillNotesAttachmentsCount;

      uniqueSpillNotesAttachmentsCount = item.note_attachments?.filter(
        (value, index) => {
          const isEmpty = Object.values(value).every(
            (x) => x === null || x === ""
          );

          if (isEmpty) {
            return false;
          } else {
            return true;
          }
        }
      );

      uniqueSpillNotesAttachmentsCount = uniqueSpillNotesAttachmentsCount?.filter(
        (note) => note.deleted_at === null
      );

      count += uniqueSpillNotesAttachmentsCount.length;
    });

    const spill_notes_data = {
      count: spillNotesCount,
      amount: totalSpillNotesAmount,
      hour: totalSpillNotesHour,
      totalNotesAttachments: count,
    };

    return spill_notes_data;
  } catch (error) {
    console.log(error);
  }
};

export const clearSpillData = async (req, res) => {
  try {
    const { spillId, connectionId, userId, legacyId, jobNo } = req.query;

    let date = new Date();

    let currentCSTDate = Moment.utc(date)
      ?.tz("America/Rankin_Inlet")
      ?.format("YYYY-MM-DD HH:mm:ss");

    // Clear spill data from Spill Table
    const query1 = `
    UPDATE spills
    SET status = 'Open: Work In Progress', 
    conditions = NULL, 
    address = NULL,
    city = NULL,
    state = NULL,
    zip_code = NULL,
    contact = NULL,
    type = NULL,
    responsible = NULL,
    need_5800 = NULL,
    is_waste = NULL,
    has_msds = NULL,
    is_hazmat = NULL,
    response_sent = NULL,
    subrogation = NULL,
    claim_no = NULL,
    is_demo = '0',
    closed_on = NULL,
    material = NULL,
    status_id = '1',
    assignment_no = NULL,
    freight_bill = NULL,
    money_saved_mgt = NULL,
    money_saved_waste = NULL,
    rate = NULL,
    material_id = NULL,
    is_approved = '1',
    is_legacy = '0',
    latitude = NULL,
    longitude = NULL,
    tractor = NULL,
    trailer = NULL,
    onsite_poc_name = NULL,
    onsite_poc_phone = NULL,
    driver_name = NULL,
    driver_phone = NULL,
    pro = NULL,
    map_needed = NULL,
    amount_released = NULL,
    quantity_type_released = NULL,
    damaged_container_type = NULL,
    damage_type = NULL,
    location_type = NULL,
    drain_impacted = NULL,
    waterway_impacted = NULL,
    legacy_id = NULL,
    un_no = NULL,
    last_status_changed = NULL,
    total_notes_sum = '22.50',
    is_emergency = '0',
    watched = '0'
    WHERE id = ${spillId}
    `;

    // Clear spill admins from Spill Admins Table
    const query2 = `
    UPDATE spill_admins 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    // Clear spill connections from Connections Table
    const query3 = `
    UPDATE connections 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    // Clear spill notes from Spill Notes Table
    const query4 = `
    UPDATE spill_notes 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    /* While clearing spill notes we need to create a default note
    with initial values for note
    */
    const query5 = `
   INSERT INTO spill_notes
   (
    service_id, 
    service_type,
    rate,
    hour, 
    amount,
    description, 
    created_at,
    updated_at,
    user_id,
    spill_id,
    legacy_id,
    type
    )
    VALUES
    (
      36,
      'Receipt of Assignment From Client',
      '85.00',
      "0.50",
      "42.50",
      "Initial information-gathering conversation with client was performed.",
      '${currentCSTDate}',
      '${currentCSTDate}',
      ${userId},
      ${spillId},
      ${legacyId},
      'hourly'
    )`;

    // Clear spill notes history from Spill Notes History Table
    const query6 = `
    UPDATE spill_notes_history 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    // Clear all reserves from Reserves Table
    const query7 = `
    UPDATE reserves 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    // Clear all contractor history from Contractor History Table
    const query8 = `
    UPDATE contractor_history 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    // Clear all spill status history from Spill History Table
    const query9 = `
    UPDATE spill_statuses_history 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    // Clear all spill packet assignment history from Packet Reviewer Assignments History Table
    const query10 = `
    UPDATE packet_reviewer_assignments_history 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id = ${spillId};
    `;

    // TODO: add try catch for raw queries
    await Promise.all([
      sequelize.query(query1),
      sequelize.query(query2),
      sequelize.query(query3),
      sequelize.query(query4),
      sequelize.query(query6),
      sequelize.query(query7),
      sequelize.query(query8),
      sequelize.query(query9),
      sequelize.query(query10),
    ]);

    await sequelize.query(query5);

    const query11 = `
    SELECT * FROM  spill_notes
    WHERE spill_id = ${spillId} AND service_id = 36 AND deleted_at is null;`;
    const newNote = await sequelize.query(query11);

    // Clear all packet assignments for the existing Spill Assignment
    const query12 = `
     DELETE FROM packet_reviewer_assignments 
     WHERE assigned_spill_id=${spillId};
     `;
    await sequelize.query(query12);

    // Clear all requested Doc for the existing Spill Assignment
    const query13 = `
    UPDATE contractor_requested_documentations 
    SET deleted_at = '${currentCSTDate}'
    WHERE spill_id=${spillId};
    `;
    await sequelize.query(query13);

    let wholeSpill = await getCompleteSpillByJobNo(jobNo);

    res.status(200).json(wholeSpill);
  } catch (err) {
    console.log("err", err);
  }
};

export const searchSpillsByConditions = async (body, user, paginate = true) => {
  const { org_id, contractor_id, contractor_address_id } = user;
  let {
    id,
    role,
    permission,
    job_no,
    statusData,
    opened_on,
    opened_to,
    close_on,
    close_to,
    city,
    state,
    country,
    claim_no,
    type,
    contact,
    responsible,
    address,
    material,
    conditions,
    organizations,
    childOrganizations,
    contractors,
    rejectContractors,
    managers,
    usersForEmail,
    packetReviewUsers,
    agencies,
    map_needed,
    need_5800,
    is_waste,
    has_msds,
    is_hazmat,
    un_no,
    response_sent,
    subrogation,
    amount_released,
    quantity_type_released,
    damaged_container_type,
    damaged_type,
    tractor,
    trailer,
    pro,
    location_type,
    drain_impacted,
    haz_waste_hauler,
    waterway_impacted,
    is_emergency,
    paginationProps,
    userType,
    date_to,
    date_from,
    isReport,
    pesInvoiceNo,
    contractorInvoiceNo,
    disposal_handled_by,
    container_disposition_type,
    pendingdisposal
  } = body;

  if (pendingdisposal === 1 && !disposal_handled_by && !container_disposition_type) {
    statusData = [CONSTANTS.PENDING_DISPOSAL_STATUS];
  }
  const { limit, offset, current } = pagination(
    paginationProps?.page,
    paginationProps
  );

  const spillPermission =
    permission.toString().toLowerCase() === "true" ? true : false;

  let organizations_id = [];
  let agencies_id = [];
  let contractors_id = [];
  let addresses_id = [];
  let managers_id = [];
  let usersForEmail_id = [];
  let packetReviewUsers_id = [];
  let rejectContractor_id = {
    addresses_id: [],
    contractors_id: [],
  };
  let rejectSpillIds = [];
  const order = [["created_at", "DESC"]];

  if (organizations && organizations.length > 0) {
    await Promise.all(
      organizations.map((org) => {
        organizations_id.push(org.value);
      })
    );
  }

  if (childOrganizations && childOrganizations.length > 0) {
    await Promise.all(
      childOrganizations.map((org) => {
        organizations_id.push(org.value);
      })
    );
  }

  if (agencies && agencies.length > 0) {
    await Promise.all(
      agencies.map((agency) => {
        agencies_id.push(agency.value);
      })
    );
  }
  if (contractors && contractors.length > 0) {
    await Promise.all(
      contractors.map((contractor) => {
        const temp_address_id = +contractor.value.split(" ")[1];
        temp_address_id
          ? addresses_id.push(temp_address_id)
          : contractors_id.push(+contractor.value.split(" ")[0]);
      })
    );
  }

  if (rejectContractors && rejectContractors?.length > 0) {
    rejectContractors.map((contractor) => {
      const temp_address_id = +contractor.value.split(" ")[1];
      temp_address_id
        ? rejectContractor_id.addresses_id.push(temp_address_id)
        : rejectContractor_id.contractors_id.push(
            +contractor.value.split(" ")[0]
          );
    });
    rejectSpillIds = await getRejectedSpillIds(rejectContractor_id);
  }
  if (managers && managers.length >= 0) {
    await Promise.all(
      managers.map((manager) => {
        managers_id.push(manager.value);
      })
    );
  }
  if (usersForEmail && usersForEmail?.length >= 0) {
    const temp = [];
    usersForEmail?.map((user) => {
      temp.push(user?.spill_ids);
    });
    usersForEmail_id = temp.flat();
  }

  if (packetReviewUsers && packetReviewUsers?.length >= 0) {
    const temp = [];
    packetReviewUsers?.map((user) => {
      temp.push(user?.value);
    });
    packetReviewUsers_id = temp.flat();
  }

  const checkContractorsAndAgencies =
    agencies_id.length || addresses_id.length || contractors_id.length;
  const spill_ids_contractor_filter = checkContractorsAndAgencies
    ? await buildIncludeQueryForConnections(
        agencies_id,
        addresses_id,
        contractors_id,
        role
      )
    : [];
  let isContractorFilter = false;
  if (agencies_id.length && (contractors_id.length || addresses_id.length) && spill_ids_contractor_filter.length === 0) {
    isContractorFilter = true;
  }

  try {
    let spillsData;
    let spillCount;
    let spillQuerry = paginate ? { limit, offset } : {};

    switch (role) {
      case ROLES.CONTRACTOR_USER: {
        /* 
        In where condistion OR clause is added because 
        when contractor is inactive and it have not performed 
        any activity then it will not show in the contractor listing
        Further groupby is added to avoid duplicate listings
        */
        let userData = await models.User.findOne({
          where: { id },
        });

        let query1 = `
        SELECT 
        spills.id,
        spills.user_id,
        spills.org_id,
        spills.job_no,
        spills.opened_on,
        spills.send_attachment,
        spills.status,
        spills.conditions,
        spills.address,
        spills.city,
        spills.state,
        spills.zip_code,
        spills.country,
        spills.contact,
        spills.type,
        spills.responsible,
        spills.need_5800,
        spills.is_waste,
        spills.has_msds,
        spills.is_hazmat,
        spills.response_sent,
        spills.subrogation,
        spills.claim_no,
        spills.is_demo,
        spills.closed_on,
        spills.material,
        spills.status_id,
        spills.assignment_no,
        spills.freight_bill,
        spills.money_saved_mgt,
        spills.money_saved_waste,
        spills.rate,
        spills.material_id,
        spills.is_approved,
        spills.is_legacy,
        spills.un_no,
        spills.latitude,
        spills.longitude,
        spills.tractor,
        spills.trailer,
        spills.onsite_poc_name,
        spills.onsite_poc_phone,
        spills.driver_name,
        spills.driver_phone,
        spills.pro,
        spills.map_needed,
        spills.amount_released,
        spills.quantity_type_released,
        spills.damaged_container_type,
        spills.damage_type,
        spills.location_type,
        spills.drain_impacted,
        spills.waterway_impacted,
        spills.is_emergency,
        spills.legacy_id,
        spills.last_status_changed,
        spills.total_notes_sum,
        JSON_OBJECT(
        "id" , client_organization.id,
        "name", client_organization.name
        ) as client_organization,
        JSON_OBJECT(
          "id", connections.id, 
          "spill_id", connections.spill_id,
          "address_id", connections.address_id,
          "agency_id", connections.agency_id,
          "agency_national", connections.agency_national,
          "created_at", connections.created_at,
          "deleted_at", connections.deleted_at,
          "updated_at", connections.updated_at,
          "incident_no", connections.incident_no,
          "state_incident_no", connections.state_incident_no
        ) as connections
        FROM
            spills AS spills
                ${
                  contractorInvoiceNo
                    ? `LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.inv_no LIKE '${contractorInvoiceNo}' AND spill_admin.deleted_at is NULL`
                    : pesInvoiceNo
                    ? `
                      LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.pes_inv_no = ${pesInvoiceNo} AND spill_admin.deleted_at is NULL`
                    : " "
                }
                LEFT OUTER JOIN
            client_organizations AS client_organization ON spills.org_id = client_organization.id
                AND client_organization.deleted_at IS NULL
                LEFT OUTER JOIN
            connections AS connections ON spills.id = connections.spill_id
                AND  connections.deleted_at IS NULL
                ${
                  isReport
                    ? `
                  LEFT OUTER JOIN 
                  spill_statuses_history ON spills.id = spill_statuses_history.spill_id
                  `
                    : " "
                }
                LEFT OUTER JOIN
            spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
                AND spill_contractors.deleted_at IS NULL
                AND spill_contractors.contractor_id = ${contractor_id}
                ${
                  userData?.dataValues?.contractor_address_id
                    ? `AND spill_contractors.address_id = ${userData?.dataValues?.contractor_address_id}`
                    : ""
                }
                LEFT OUTER JOIN
            contractors AS contractor ON spill_contractors.contractor_id = contractor.id
                AND contractor.deleted_at IS NULL
                AND contractor.id = ${contractor_id}
                LEFT OUTER JOIN
            packet_reviewer_assignments AS pra ON spills.id = pra.assigned_spill_id
                AND pra.deleted_at IS NULL
            ${ (disposal_handled_by || container_disposition_type) ? `
              LEFT OUTER JOIN spill_notes AS sn ON sn.spill_id = spills.id AND sn.deleted_at IS NULL
              LEFT OUTER JOIN salvage_containers AS sc ON sn.id = sc.note_id AND sc.deleted_at IS NULL
              ` : " "
            }
        WHERE            
            spills.is_approved = TRUE
                AND spills.is_demo = FALSE
                AND contractor.id = ${contractor_id}
                ${
                  haz_waste_hauler
                    ? `AND contractor.haz_waste_hauler = ${haz_waste_hauler}`
                    : " "
                }
                ${
                  userData?.dataValues?.contractor_address_id
                    ? `AND spill_contractors.address_id = ${userData?.dataValues?.contractor_address_id}`
                    : ""
                }
                AND (spill_contractors.accepted = TRUE)
                ${
                  is_hazmat
                    ? `AND spills.is_hazmat = ${
                        is_hazmat === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                  ${job_no ? `AND spills.job_no LIKE '%${job_no}%'` : " "}
                  ${
                    opened_on && opened_to
                      ? `AND
                  (spills.opened_on >= '${forceToCSTForRawQuery(
                    opened_on
                  )}' AND spills.opened_on <= '${forceToCSTForRawQuery(
                          opened_to
                        )}')`
                      : " "
                  }
                   ${
                     opened_on
                       ? `AND spills.opened_on >= '${forceToCSTForRawQuery(
                           opened_on
                         )}'`
                       : " "
                   }
                   ${
                     opened_to
                       ? `AND spills.opened_on <= '${forceToCSTForRawQuery(
                           opened_to
                         )}'`
                       : " "
                   }
                   ${
                     close_on && close_to
                       ? `AND
                  (spills.closed_on >= '${forceToCSTForRawQuery(
                    close_on
                  )}' AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}')`
                       : " "
                   }
                   ${
                     close_on
                       ? `AND spills.closed_on >= '${forceToCSTForRawQuery(
                           close_on
                         )}'`
                       : " "
                   }
                   ${
                     close_to
                       ? `AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}'`
                       : " "
                   }
                  ${city ? `AND spills.city LIKE '%${city}%'` : " "}
                  ${state ? `AND spills.state LIKE '${state}'` : " "}
                  ${country ? `AND spills.country LIKE '${country}'` : " "}
                  ${claim_no ? `AND spills.claim_no LIKE '%${claim_no}%'` : " "}
                  ${type ? `AND spills.type LIKE '${type}'` : " "}
                  ${contact ? `AND spills.contact LIKE '%${contact}%'` : " "}
                  ${
                    responsible
                      ? `AND spills.responsible LIKE '%${responsible}%'`
                      : " "
                  }
                  ${address ? `AND spills.address LIKE '%${address}%'` : " "}
                  ${
                    conditions
                      ? `AND spills.conditions LIKE '%${conditions}%'`
                      : " "
                  }
                  ${material ? `AND spills.material LIKE '%${material}%'` : " "}
                  ${
                    map_needed
                      ? `AND spills.map_needed LIKE '${map_needed}'`
                      : " "
                  }
                  ${
                    need_5800
                      ? `AND spills.need_5800 = ${
                          need_5800 === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    usersForEmail_id?.length
                      ? `
                    AND spills.id IN (${usersForEmail_id})
                    `
                      : " "
                  }
                  ${
                    packetReviewUsers_id?.length
                      ? `
                   AND pra.packet_reviewer_user_id IN (${packetReviewUsers_id})
                   `
                      : " "
                  }
                  ${
                    is_waste
                      ? `AND spills.is_waste = ${
                          is_waste === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    has_msds
                      ? `AND spills.has_msds = ${
                          has_msds === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${un_no ? `AND spills.un_no = '${un_no}'` : " "}
                  ${
                    response_sent
                      ? `AND spills.response_sent = ${
                          response_sent === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    subrogation
                      ? `AND spills.subrogation = ${
                          subrogation === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    statusData.length
                      ? `AND spills.status IN (${convertStatuses(
                          statusData,
                          user.role.role
                        ).map((status) => "'" + status + "'")})
                        ${
                          managers_id?.length
                            ? `AND spills.user_id IN (${managers_id})`
                            : " "
                        }
                        `
                      : " "
                  }
                  ${
                    managers_id?.length
                      ? `AND spills.user_id IN (${managers_id})`
                      : " "
                  }
                 ${
                   amount_released
                     ? `AND spills.amount_released = ${+amount_released}`
                     : " "
                 }
                 ${
                   quantity_type_released
                     ? `AND spills.quantity_type_released LIKE '${quantity_type_released}'`
                     : " "
                 }
                 ${
                   damaged_container_type
                     ? `AND spills.damaged_container_type LIKE '${damaged_container_type}'`
                     : " "
                 }
                 ${
                   damaged_type
                     ? `AND spills.damage_type LIKE '${damaged_type}'`
                     : " "
                 }
                ${
                  location_type
                    ? `AND spills.location_type LIKE '${location_type}'`
                    : " "
                }
                ${wasteGeneratedCondition(body)}
                ${
                  drain_impacted
                    ? `AND spills.drain_impacted = ${
                        drain_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  waterway_impacted
                    ? `AND spills.waterway_impacted = ${
                        waterway_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  is_emergency
                    ? `AND spills.is_emergency = ${
                        is_emergency === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${trailer ? `AND spills.trailer LIKE '${trailer}'` : " "}
                ${tractor ? `AND spills.tractor LIKE '${tractor}'` : " "}
                ${pro ? `AND spills.pro LIKE '${pro}'` : " "}
                ${
                  spill_ids_contractor_filter?.length || rejectSpillIds?.length
                    ? `AND spills.id IN (${[
                        ...spill_ids_contractor_filter,
                        ...rejectSpillIds,
                      ]})`
                    : isContractorFilter ? ` AND spills.id IN ('')` : " "
                }
                ${
                  organizations_id?.length
                    ? `AND spills.org_id IN (${organizations_id}) `
                    : " "
                }
                ${
                  contractorInvoiceNo
                    ? `AND spill_admin.inv_no = '${contractorInvoiceNo}'`
                    : " "
                }
                ${
                  pesInvoiceNo
                    ? `AND spill_admin.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                AND (spill_contractors.is_inactive = FALSE
                OR spill_contractors.activity_performed = TRUE OR spill_contractors.is_inactive IS NULL)
                ${
                  userType === USER_TYPE.GENERAL
                    ? `AND (spills.job_no NOT LIKE 'TEMP%'
               AND spills.job_no NOT LIKE '%TEST%')`
                    : " "
                }
        GROUP BY spills.id , connections.id , spill_contractors.id
        ORDER BY spills.created_at DESC
        LIMIT ${offset} , ${limit};
        `;
        let result1 = await sequelize.query(query1);

        let updatedSpillsData = [];

        for (const [index, spill] of result1[0].entries()) {
          let query2 = `
          SELECT * from spill_contractors where connection_id = ${spill?.connections?.id} and contractor_id = ${contractor_id};
          `;

          let result2 = await sequelize.query(query2);

          let spillContractors = [];

          spillContractors.push({ ...result2[0][0] });

          const searchStatusString = spill?.status?.search("Open");
          const searchStatusString2 = spill?.status?.split(":");

          updatedSpillsData.push({
            ...spill,
            closed_on:
              spill.closed_on &&
              (searchStatusString != -1 || searchStatusString2[1] != " Closed")
                ? "Re-Opened"
                : spill.closed_on
                ? spill?.closed_on
                : "Still Open",
            connections: {
              ...spill.connections,
              spill_contractors: [...spillContractors],
            },
          });
        }

        spillsData = updatedSpillsData;

        let isAdminToBeRemoved = false;
        for (const [index, spill] of spillsData.entries()) {
          spill?.connections?.spill_contractors?.map((item) => {
            if (
              item.activity_performed === false &&
              item.is_inactive === true
            ) {
              isAdminToBeRemoved = true;
            } else {
              isAdminToBeRemoved = false;
            }
          });
          if (isAdminToBeRemoved) {
            spillsData.splice(index, 1);
          }
        }

        spillCount = await getSpillCountForContractorUsers(
          id,
          ROLES.CONTRACTOR_USER,
          body,
          contractor_id,
          spill_ids_contractor_filter,
          rejectSpillIds,
          organizations_id,
          userType,
          contractorInvoiceNo,
          isContractorFilter
        );

        break;
      }

      case ROLES.CONTRACTOR_ADMIN: {
        /* 
        In where condistion OR clause is added because 
        when contractor is inactive and it have not performed 
        any activity then it will not show in the contractor listing
        Further groupby is added to avoid duplicate listings
        */
        let query1 = `
        SELECT 
        spills.id,
        spills.user_id,
        spills.org_id,
        spills.job_no,
        spills.opened_on,
        spills.send_attachment,
        spills.status,
        spills.conditions,
        spills.address,
        spills.city,
        spills.state,
        spills.zip_code,
        spills.country,
        spills.contact,
        spills.type,
        spills.responsible,
        spills.need_5800,
        spills.is_waste,
        spills.has_msds,
        spills.is_hazmat,
        spills.response_sent,
        spills.subrogation,
        spills.claim_no,
        spills.is_demo,
        spills.closed_on,
        spills.material,
        spills.status_id,
        spills.assignment_no,
        spills.freight_bill,
        spills.money_saved_mgt,
        spills.money_saved_waste,
        spills.rate,
        spills.material_id,
        spills.is_approved,
        spills.is_legacy,
        spills.un_no,
        spills.latitude,
        spills.longitude,
        spills.tractor,
        spills.trailer,
        spills.onsite_poc_name,
        spills.onsite_poc_phone,
        spills.driver_name,
        spills.driver_phone,
        spills.pro,
        spills.map_needed,
        spills.amount_released,
        spills.quantity_type_released,
        spills.damaged_container_type,
        spills.damage_type,
        spills.location_type,
        spills.drain_impacted,
        spills.waterway_impacted,
        spills.is_emergency,
        spills.legacy_id,
        spills.last_status_changed,
        spills.total_notes_sum,
        JSON_OBJECT(
        "id" , client_organization.id,
        "name", client_organization.name
        ) as client_organization,
        JSON_OBJECT(
          "id", connections.id, 
          "spill_id", connections.spill_id,
          "address_id", connections.address_id,
          "agency_id", connections.agency_id,
          "agency_national", connections.agency_national,
          "created_at", connections.created_at,
          "deleted_at", connections.deleted_at,
          "updated_at", connections.updated_at,
          "incident_no", connections.incident_no,
          "state_incident_no", connections.state_incident_no
        ) as connections
        FROM
            spills AS spills
            ${
              contractorInvoiceNo
                ? `LEFT OUTER JOIN
            spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.inv_no LIKE '${contractorInvoiceNo}' AND spill_admin.deleted_at is NULL`
                : pesInvoiceNo
                ? `
                  LEFT OUTER JOIN
            spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.pes_inv_no = ${pesInvoiceNo} AND spill_admin.deleted_at is NULL`
                : " "
            }
                LEFT OUTER JOIN
            client_organizations AS client_organization ON spills.org_id = client_organization.id
                AND client_organization.deleted_at IS NULL
                LEFT OUTER JOIN
            connections AS connections ON spills.id = connections.spill_id
                AND  connections.deleted_at IS NULL
                ${
                  isReport
                    ? `
                  LEFT OUTER JOIN 
                  spill_statuses_history ON spills.id = spill_statuses_history.spill_id
                  `
                    : " "
                }    
                LEFT OUTER JOIN
            spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
                AND spill_contractors.deleted_at IS NULL
                AND spill_contractors.contractor_id = ${contractor_id}
                LEFT OUTER JOIN
            contractors AS contractor ON spill_contractors.contractor_id = contractor.id
                AND contractor.deleted_at IS NULL
                AND contractor.id = ${contractor_id}
                LEFT OUTER JOIN
            packet_reviewer_assignments AS pra ON spills.id = pra.assigned_spill_id
                AND pra.deleted_at IS NULL
            ${ (disposal_handled_by || container_disposition_type) ? `
              LEFT OUTER JOIN spill_notes AS sn ON sn.spill_id = spills.id AND sn.deleted_at IS NULL
              LEFT OUTER JOIN salvage_containers AS sc ON sn.id = sc.note_id AND sc.deleted_at IS NULL
              ` : " "
            }
        WHERE
            spills.is_approved = TRUE
                AND spills.is_demo = FALSE
                AND contractor.id = ${contractor_id}
                AND (spill_contractors.accepted = TRUE)
                ${
                  haz_waste_hauler
                    ? `AND contractor.haz_waste_hauler = ${haz_waste_hauler}`
                    : " "
                }
                ${
                  is_hazmat
                    ? `AND spills.is_hazmat = ${
                        is_hazmat === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                  ${job_no ? `AND spills.job_no LIKE '%${job_no}%'` : " "}
                  ${
                    opened_on && opened_to
                      ? `AND
                  (spills.opened_on >= '${forceToCSTForRawQuery(
                    opened_on
                  )}' AND spills.opened_on <= '${forceToCSTForRawQuery(
                          opened_to
                        )}')`
                      : " "
                  }
                   ${
                     opened_on
                       ? `AND spills.opened_on >= '${forceToCSTForRawQuery(
                           opened_on
                         )}'`
                       : " "
                   }
                   ${
                     opened_to
                       ? `AND spills.opened_on <= '${forceToCSTForRawQuery(
                           opened_to
                         )}'`
                       : " "
                   }
                   ${
                     close_on && close_to
                       ? `AND
                  (spills.closed_on >= '${forceToCSTForRawQuery(
                    close_on
                  )}' AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}')`
                       : " "
                   }
                   ${
                     close_on
                       ? `AND spills.closed_on >= '${forceToCSTForRawQuery(
                           close_on
                         )}'`
                       : " "
                   }
                   ${
                     close_to
                       ? `AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}'`
                       : " "
                   }
                  ${city ? `AND spills.city LIKE '%${city}%'` : " "}
                  ${state ? `AND spills.state LIKE '${state}'` : " "}
                  ${country ? `AND spills.country LIKE '${country}'` : " "}
                  ${claim_no ? `AND spills.claim_no LIKE '%${claim_no}%'` : " "}
                  ${type ? `AND spills.type LIKE '${type}'` : " "}
                  ${contact ? `AND spills.contact LIKE '%${contact}%'` : " "}
                  ${
                    responsible
                      ? `AND spills.responsible LIKE '%${responsible}%'`
                      : " "
                  }
                  ${address ? `AND spills.address LIKE '%${address}%'` : " "}
                  ${
                    conditions
                      ? `AND spills.conditions LIKE '%${conditions}%'`
                      : " "
                  }
                  ${material ? `AND spills.material LIKE '%${material}%'` : " "}
                  ${
                    map_needed
                      ? `AND spills.map_needed LIKE '${map_needed}'`
                      : " "
                  }
                  ${
                    need_5800
                      ? `AND spills.need_5800 = ${
                          need_5800 === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    is_waste
                      ? `AND spills.is_waste = ${
                          is_waste === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    has_msds
                      ? `AND spills.has_msds = ${
                          has_msds === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    usersForEmail_id?.length
                      ? `
                    AND spills.id IN (${usersForEmail_id})
                    `
                      : " "
                  }
                  ${
                    packetReviewUsers_id?.length
                      ? `
                   AND pra.packet_reviewer_user_id IN (${packetReviewUsers_id})
                   `
                      : " "
                  }
                  ${un_no ? `AND spills.un_no = '${un_no}'` : " "}
                  ${
                    response_sent
                      ? `AND spills.response_sent = ${
                          response_sent === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    subrogation
                      ? `AND spills.subrogation = ${
                          subrogation === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    statusData?.length
                      ? `AND spills.status IN (${convertStatuses(
                          statusData,
                          user?.role?.role
                        ).map((status) => "'" + status + "'")})
                        ${
                          managers_id?.length
                            ? `AND spills.user_id IN (${managers_id})`
                            : " "
                        }
                        `
                      : " "
                  }
                  ${
                    managers_id?.length
                      ? `AND spills.user_id IN (${managers_id})`
                      : " "
                  }
                 ${
                   amount_released
                     ? `AND spills.amount_released = ${+amount_released}`
                     : " "
                 }
                 ${
                   quantity_type_released
                     ? `AND spills.quantity_type_released LIKE '${quantity_type_released}'`
                     : " "
                 }
                 ${
                   damaged_container_type
                     ? `AND spills.damaged_container_type LIKE '${damaged_container_type}'`
                     : " "
                 }
                 ${
                   damaged_type
                     ? `AND spills.damage_type LIKE '${damaged_type}'`
                     : " "
                 }
                ${
                  location_type
                    ? `AND spills.location_type LIKE '${location_type}'`
                    : " "
                }
                ${wasteGeneratedCondition(body)}
                ${
                  drain_impacted
                    ? `AND spills.drain_impacted = ${
                        drain_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  waterway_impacted
                    ? `AND spills.waterway_impacted = ${
                        waterway_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  is_emergency
                    ? `AND spills.is_emergency = ${
                        is_emergency === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${trailer ? `AND spills.trailer LIKE '${trailer}'` : " "}
                ${tractor ? `AND spills.tractor LIKE '${tractor}'` : " "}
                ${pro ? `AND spills.pro LIKE '${pro}'` : " "}
                ${
                  spill_ids_contractor_filter?.length || rejectSpillIds?.length
                    ? `AND spills.id IN (${[
                        ...spill_ids_contractor_filter,
                        ...rejectSpillIds,
                      ]})`
                    : isContractorFilter ? ` AND spills.id IN ('')` : " "
                }
                ${
                  organizations_id?.length
                    ? `AND spills.org_id IN (${organizations_id}) `
                    : " "
                }
                ${
                  contractorInvoiceNo
                    ? `AND spill_admin.inv_no = '${contractorInvoiceNo}'`
                    : " "
                }
                ${
                  pesInvoiceNo
                    ? `AND spill_admin.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                AND (spill_contractors.is_inactive = FALSE
                  OR spill_contractors.activity_performed = TRUE OR 
                  spill_contractors.is_inactive IS NULL)
                  ${
                    userType === USER_TYPE.GENERAL
                      ? `AND (spills.job_no NOT LIKE 'TEMP%'
               AND spills.job_no NOT LIKE '%TEST%')`
                      : " "
                  }
        GROUP BY spills.id , connections.id , spill_contractors.id
        ORDER BY spills.created_at DESC
        LIMIT ${offset} , ${limit};
        `;

        let result1 = await sequelize.query(query1);

        let updatedSpillsData = [];

        for (const [index, spill] of result1[0].entries()) {
          let query2 = `
          SELECT * from spill_contractors where connection_id = ${spill?.connections?.id} and contractor_id = ${contractor_id};
          `;

          let result2 = await sequelize.query(query2);

          let spillContractors = [];

          spillContractors.push({ ...result2[0][0] });

          const searchStatusString = spill?.status?.search("Open");
          const searchStatusString2 = spill?.status?.split(":");

          updatedSpillsData.push({
            ...spill,
            closed_on:
              spill?.closed_on &&
              (searchStatusString != -1 || searchStatusString2[1] != " Closed")
                ? "Re-Opened"
                : spill.closed_on
                ? spill?.closed_on
                : "Still Open",
            connections: {
              ...spill.connections,
              spill_contractors: [...spillContractors],
            },
          });
        }

        spillsData = updatedSpillsData;

        let isAdminToBeRemoved = false;
        for (const [index, spill] of spillsData.entries()) {
          spill?.connections?.spill_contractors?.map((item) => {
            if (
              item.activity_performed === false &&
              item.is_inactive === true
            ) {
              isAdminToBeRemoved = true;
            } else {
              isAdminToBeRemoved = false;
            }
          });
          if (isAdminToBeRemoved) {
            spillsData.splice(index, 1);
          }
        }

        spillCount = await getSpillCountForContractorUsers(
          id,
          ROLES.CONTRACTOR_ADMIN,
          body,
          contractor_id,
          spill_ids_contractor_filter,
          rejectSpillIds,
          organizations_id,
          userType,
          contractorInvoiceNo,
          isContractorFilter
        );

        break;
      }

      case ROLES.CORPORATE_USER: {
        const fetchSpillsForCorporateUsers = `
          SELECT 
                spills.id,
                spills.user_id,
                spills.org_id,
                spills.job_no,
                spills.opened_on,
                spills.send_attachment,
                spills.status,
                spills.conditions,
                spills.address,
                spills.city,
                spills.state,
                spills.zip_code,
                spills.country,
                spills.closed_on,
                JSON_OBJECT('id',
                        client_organization.id,
                        'name',
                        client_organization.name) AS client_organization
            FROM
                spills AS spills
                ${
                  contractorInvoiceNo
                    ? `LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.inv_no LIKE '${contractorInvoiceNo}'`
                    : pesInvoiceNo
                    ? `
                      LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                    LEFT OUTER JOIN
                client_organizations AS client_organization ON spills.org_id = client_organization.id
                    AND client_organization.deleted_at IS NULL
                    LEFT OUTER JOIN
                spill_admins AS spill_admins ON spills.id = spill_admins.spill_id
                    AND (spill_admins.is_removed = FALSE OR spill_admins.is_removed IS NULL)
                    AND spill_admins.deleted_at IS NULL
              ${
                isReport
                  ? `
                LEFT OUTER JOIN 
                spill_statuses_history ON spills.id = spill_statuses_history.spill_id
                `
                  : " "
              }
                    LEFT OUTER JOIN
                connections AS connections ON spills.id = connections.spill_id
                    AND connections.deleted_at IS NULL
                    LEFT OUTER JOIN
                spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
                    AND spill_contractors.deleted_at IS NULL
                    LEFT OUTER JOIN
                contractors AS contractor ON spill_contractors.contractor_id = contractor.id
                    AND contractor.deleted_at IS NULL
                    LEFT OUTER JOIN
                packet_reviewer_assignments AS pra ON spills.id = pra.assigned_spill_id
                    AND pra.deleted_at IS NULL
                ${ (disposal_handled_by || container_disposition_type) ? `
                  LEFT OUTER JOIN spill_notes AS sn ON sn.spill_id = spills.id AND sn.deleted_at IS NULL
                  LEFT OUTER JOIN salvage_containers AS sc ON sn.id = sc.note_id AND sc.deleted_at IS NULL
                  ` : " "
                }
            WHERE
                spills.is_approved = TRUE
                ${
                  pesInvoiceNo
                    ? `AND spill_admins.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                ${
                  contractorInvoiceNo
                    ? `AND spill_admins.inv_no = '${contractorInvoiceNo}'`
                    : " "
                }
                ${
                  isReport
                    ? `
                  AND spill_statuses_history.status LIKE 'Closed: Invoice Submitted to Client'
                  ${
                    date_to
                      ? `
                      AND spill_statuses_history.started_at >= '${forceToCSTForRawQuery(
                        date_to
                      )}'
                      ${
                        date_from
                          ? `AND spill_statuses_history.started_at <= '${forceToCSTForRawQuery(
                              date_from
                            )}'`
                          : " "
                      } 
                      
                      `
                      : " " || date_from
                      ? `
                  AND spills.opened_on <= '${forceToCSTForRawQuery(date_from)}'
                  `
                      : " "
                  }
                  `
                    : " "
                }
                ${
                  haz_waste_hauler
                    ? `AND contractor.haz_waste_hauler = ${haz_waste_hauler}`
                    : " "
                }
                ${
                  is_hazmat
                    ? `AND spills.is_hazmat = ${
                        is_hazmat === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                  ${job_no ? `AND spills.job_no LIKE '%${job_no}%'` : " "}
                  ${
                    opened_on && opened_to
                      ? `AND
                  (spills.opened_on >= '${forceToCSTForRawQuery(
                    opened_on
                  )}' AND spills.opened_on <= '${forceToCSTForRawQuery(
                          opened_to
                        )}')`
                      : " "
                  }
                   ${
                     opened_on
                       ? `AND spills.opened_on >= '${forceToCSTForRawQuery(
                           opened_on
                         )}'`
                       : " "
                   }
                   ${
                     opened_to
                       ? `AND spills.opened_on <= '${forceToCSTForRawQuery(
                           opened_to
                         )}'`
                       : " "
                   }
                   ${
                     close_on && close_to
                       ? `AND
                  (spills.closed_on >= '${forceToCSTForRawQuery(
                    close_on
                  )}' AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}')`
                       : " "
                   }
                   ${
                     close_on
                       ? `AND spills.closed_on >= '${forceToCSTForRawQuery(
                           close_on
                         )}'`
                       : " "
                   }
                   ${
                     close_to
                       ? `AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}'`
                       : " "
                   }
                  ${city ? `AND spills.city LIKE '%${city}%'` : " "}
                  ${state ? `AND spills.state LIKE '${state}'` : " "}
                  ${country ? `AND spills.country LIKE '${country}'` : " "}
                  ${claim_no ? `AND spills.claim_no LIKE '%${claim_no}%'` : " "}
                  ${type ? `AND spills.type LIKE '${type}'` : " "}
                  ${contact ? `AND spills.contact LIKE '%${contact}%'` : " "}
                  ${
                    responsible
                      ? `AND spills.responsible LIKE '%${responsible}%'`
                      : " "
                  }
                  ${address ? `AND spills.address LIKE '%${address}%'` : " "}
                  ${
                    conditions
                      ? `AND spills.conditions LIKE '%${conditions}%'`
                      : " "
                  }
                  ${material ? `AND spills.material LIKE '%${material}%'` : " "}
                  ${
                    usersForEmail_id?.length
                      ? `
                    AND spills.id IN (${usersForEmail_id})
                    `
                      : " "
                  }
                  ${
                    packetReviewUsers_id?.length
                      ? `
                   AND pra.packet_reviewer_user_id IN (${packetReviewUsers_id})
                   `
                      : " "
                  }
                  ${
                    map_needed
                      ? `AND spills.map_needed LIKE '${map_needed}'`
                      : " "
                  }
                  ${
                    need_5800
                      ? `AND spills.need_5800 = ${
                          need_5800 === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    is_waste
                      ? `AND spills.is_waste = ${
                          is_waste === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    has_msds
                      ? `AND spills.has_msds = ${
                          has_msds === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${un_no ? `AND spills.un_no = '${un_no}'` : " "}
                  ${
                    response_sent
                      ? `AND spills.response_sent = ${
                          response_sent === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    subrogation
                      ? `AND spills.subrogation = ${
                          subrogation === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    statusData?.length
                      ? `AND spills.status IN (${convertStatuses(
                          statusData,
                          user?.role?.role
                        ).map((status) => "'" + status + "'")})
                        ${
                          managers_id?.length
                            ? `AND spills.user_id IN (${managers_id})`
                            : " "
                        }
                        `
                      : " "
                  }
                  ${
                    managers_id?.length
                      ? `AND spills.user_id IN (${managers_id})`
                      : " "
                  }
                 ${
                   amount_released
                     ? `AND spills.amount_released = ${+amount_released}`
                     : " "
                 }
                 ${
                   quantity_type_released
                     ? `AND spills.quantity_type_released LIKE '${quantity_type_released}'`
                     : " "
                 }
                 ${
                   damaged_container_type
                     ? `AND spills.damaged_container_type LIKE '${damaged_container_type}'`
                     : " "
                 }
                 ${
                   damaged_type
                     ? `AND spills.damage_type LIKE '${damaged_type}'`
                     : " "
                 }
                ${
                  location_type
                    ? `AND spills.location_type LIKE '${location_type}'`
                    : " "
                }
                ${wasteGeneratedCondition(body)}
                ${
                  drain_impacted
                    ? `AND spills.drain_impacted = ${
                        drain_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  waterway_impacted
                    ? `AND spills.waterway_impacted = ${
                        waterway_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${org_id ? `AND spills.org_id = ${org_id}` : " "}
                ${
                  is_emergency
                    ? `AND spills.is_emergency = ${
                        is_emergency === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${trailer ? `AND spills.trailer LIKE '${trailer}'` : " "}
                ${tractor ? `AND spills.tractor LIKE '${tractor}'` : " "}
                ${pro ? `AND spills.pro LIKE '${pro}'` : " "}
                ${
                  spill_ids_contractor_filter?.length || rejectSpillIds?.length
                    ? `AND spills.id IN (${[
                        ...spill_ids_contractor_filter,
                        ...rejectSpillIds,
                      ]})`
                    : isContractorFilter ? ` AND spills.id IN ('')` : " "
                }
                ${
                  organizations_id?.length
                    ? `AND spills.org_id IN (${organizations_id}) `
                    : " "
                }
                ${
                  userType === USER_TYPE.GENERAL
                    ? `AND (spills.job_no NOT LIKE 'TEMP%'
                      AND spills.job_no NOT LIKE '%TEST%')`
                    : " "
                }
              GROUP BY spills.id
              ORDER BY spills.created_at DESC
              LIMIT ${offset} , ${limit};`;

        const fetchedSpillsForCorporateUsers = await sequelize.query(
          fetchSpillsForCorporateUsers
        );

        spillsData = fetchedSpillsForCorporateUsers[0];

        spillCount = await getSpillCountForGeneralUsers(
          body,
          user,
          spill_ids_contractor_filter,
          rejectSpillIds,
          organizations_id,
          userType,
          isReport,
          isContractorFilter
        );

        break;
      }
      default: {
        if (spillPermission) {
          let associatedOrgs = await models.AssociatedOrganizations.findAll({
            where: {
              org_id: org_id,
            },
          });

          let associated_orgs = [org_id];

          associatedOrgs.map((associatedOrgs) => {
            if (organizations_id.includes(associatedOrgs.associated_org_id))
              associated_orgs.push(associatedOrgs.associated_org_id);
          });

          const defaultFetchSpillsQuery = `
          SELECT   
          spills.id,
          spills.user_id,
          spills.org_id,
          spills.job_no,
          spills.opened_on,
          spills.send_attachment,
          spills.status,
          spills.conditions,
          spills.address,
          spills.city,
          spills.state,
          spills.zip_code,
          spills.country,
          spills.closed_on,
          JSON_OBJECT('id',
                  client_organization.id,
                  'name',
                  client_organization.name,
                  'address',
                  client_organization.address,
                  'city',
                  client_organization.city,
                  'state',
                  client_organization.state) AS client_organization
                ${
                  isReport
                    ? `,
                JSON_ARRAYAGG(
                  JSON_OBJECT(
                    'id', spill_statuses_history.id,
                    'spill_id', spill_statuses_history.spill_id,
                    'status', spill_statuses_history.status
                  )
                ) as spill_status_histories`
                    : " "
                }
            FROM
                spills AS spills
                ${
                  contractorInvoiceNo
                    ? `LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.inv_no = '${contractorInvoiceNo}'`
                    : pesInvoiceNo
                    ? `
                      LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                    LEFT OUTER JOIN
                client_organizations AS client_organization ON spills.org_id = client_organization.id
                    AND client_organization.deleted_at IS NULL
                    LEFT OUTER JOIN
                spill_admins AS spill_admins ON spills.id = spill_admins.spill_id
                    AND (spill_admins.is_removed = FALSE OR spill_admins.is_removed IS NULL)
                    AND spill_admins.deleted_at IS NULL
                    LEFT OUTER JOIN
                connections AS connections ON spills.id = connections.spill_id
                    AND connections.deleted_at IS NULL
                    LEFT OUTER JOIN
                spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
                    AND spill_contractors.deleted_at IS NULL
                    LEFT OUTER JOIN
                contractors AS contractor ON spill_contractors.contractor_id = contractor.id
                    AND contractor.deleted_at IS NULL
                    LEFT OUTER JOIN
                packet_reviewer_assignments AS pra ON spills.id = pra.assigned_spill_id
                    AND pra.deleted_at IS NULL
                ${ (disposal_handled_by || container_disposition_type) ? `
                  LEFT OUTER JOIN spill_notes AS sn ON sn.spill_id = spills.id AND sn.deleted_at IS NULL
                  LEFT OUTER JOIN salvage_containers AS sc ON sn.id = sc.note_id AND sc.deleted_at IS NULL
                  ` : " "
                }
            WHERE
                spills.is_approved = TRUE
                ${
                  pesInvoiceNo
                    ? `AND spill_admins.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                ${
                  contractorInvoiceNo
                    ? `AND spill_admins.inv_no = '${contractorInvoiceNo}'`
                    : " "
                }
                ${
                  isReport
                    ? `
                  AND spill_statuses_history.status LIKE 'Closed: Invoice Submitted to Client'
                  ${
                    date_to
                      ? `
                  AND spill_statuses_history.started_at >= '${forceToCSTForRawQuery(
                    date_to
                  )}'
                  ${
                    date_from
                      ? ` spill_statuses_history.started_at <= '${forceToCSTForRawQuery(
                          date_from
                        )}'`
                      : " "
                  } 
                  `
                      : " " || date_from
                      ? `
                  AND spills.opened_on <= '${forceToCSTForRawQuery(date_from)}'
                  `
                      : " "
                  }
                  `
                    : " "
                }
                ${
                  haz_waste_hauler
                    ? `AND contractor.haz_waste_hauler = ${haz_waste_hauler}`
                    : " "
                }
                ${
                  is_hazmat
                    ? `AND spills.is_hazmat = ${
                        is_hazmat === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                  ${job_no ? `AND spills.job_no LIKE '%${job_no}%'` : " "}
                  ${
                    opened_on && opened_to
                      ? `AND
                  (spills.opened_on >= '${forceToCSTForRawQuery(
                    opened_on
                  )}' AND spills.opened_on <= '${forceToCSTForRawQuery(
                          opened_to
                        )}')`
                      : " "
                  }
                   ${
                     opened_on
                       ? `AND spills.opened_on >= '${forceToCSTForRawQuery(
                           opened_on
                         )}'`
                       : " "
                   }
                   ${
                     opened_to
                       ? `AND spills.opened_on <= '${forceToCSTForRawQuery(
                           opened_to
                         )}'`
                       : " "
                   }
                   ${
                     close_on && close_to
                       ? `AND
                  (spills.closed_on >= '${forceToCSTForRawQuery(
                    close_on
                  )}' AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}')`
                       : " "
                   }
                   ${
                     close_on
                       ? `AND spills.closed_on >= '${forceToCSTForRawQuery(
                           close_on
                         )}'`
                       : " "
                   }
                   ${
                     close_to
                       ? `AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}'`
                       : " "
                   }
                   ${
                     usersForEmail_id?.length
                       ? `
                    AND spills.id IN (${usersForEmail_id})
                    `
                       : " "
                   }
                   ${
                     packetReviewUsers_id?.length
                       ? `
                    AND pra.packet_reviewer_user_id IN (${packetReviewUsers_id})
                    `
                       : " "
                   }
                  ${city ? `AND spills.city LIKE '%${city}%'` : " "}
                  ${state ? `AND spills.state LIKE '${state}'` : " "}
                  ${country ? `AND spills.country LIKE '${country}'` : " "}
                  ${claim_no ? `AND spills.claim_no LIKE '%${claim_no}%'` : " "}
                  ${type ? `AND spills.type LIKE '${type}'` : " "}
                  ${contact ? `AND spills.contact LIKE '%${contact}%'` : " "}
                  ${
                    responsible
                      ? `AND spills.responsible LIKE '%${responsible}%'`
                      : " "
                  }
                  ${address ? `AND spills.address LIKE '%${address}%'` : " "}
                  ${
                    conditions
                      ? `AND spills.conditions LIKE '%${conditions}%'`
                      : " "
                  }
                  ${material ? `AND spills.material LIKE '%${material}%'` : " "}
                  ${
                    map_needed
                      ? `AND spills.map_needed LIKE '${map_needed}'`
                      : " "
                  }
                  ${
                    need_5800
                      ? `AND spills.need_5800 = ${
                          need_5800 === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    is_waste
                      ? `AND spills.is_waste = ${
                          is_waste === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    has_msds
                      ? `AND spills.has_msds = ${
                          has_msds === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${un_no ? `AND spills.un_no = '${un_no}'` : " "}
                  ${
                    response_sent
                      ? `AND spills.response_sent = ${
                          response_sent === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    subrogation
                      ? `AND spills.subrogation = ${
                          subrogation === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    statusData?.length
                      ? `AND spills.status IN (${convertStatuses(
                          statusData,
                          user?.role?.role
                        ).map((status) => "'" + status + "'")})
                        ${
                          managers_id.length
                            ? `AND spills.user_id IN (${managers_id})`
                            : " "
                        }
                        `
                      : " "
                  }
                  ${
                    managers_id.length
                      ? `AND spills.user_id IN (${managers_id})`
                      : " "
                  }
                 ${
                   amount_released
                     ? `AND spills.amount_released = ${+amount_released}`
                     : " "
                 }
                 ${
                   quantity_type_released
                     ? `AND spills.quantity_type_released LIKE '${quantity_type_released}'`
                     : " "
                 }
                 ${
                   damaged_container_type
                     ? `AND spills.damaged_container_type LIKE '${damaged_container_type}'`
                     : " "
                 }
                 ${
                   damaged_type
                     ? `AND spills.damage_type LIKE '${damaged_type}'`
                     : " "
                 }
                ${
                  location_type
                    ? `AND spills.location_type LIKE '${location_type}'`
                    : " "
                }
                ${wasteGeneratedCondition(body)}
                ${
                  drain_impacted
                    ? `AND spills.drain_impacted = ${
                        drain_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  waterway_impacted
                    ? `AND spills.waterway_impacted = ${
                        waterway_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  is_emergency
                    ? `AND spills.is_emergency = ${
                        is_emergency === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${trailer ? `AND spills.trailer LIKE '${trailer}'` : " "}
                ${tractor ? `AND spills.tractor LIKE '${tractor}'` : " "}
                ${pro ? `AND spills.pro LIKE '${pro}'` : " "}
                ${
                  spill_ids_contractor_filter?.length || rejectSpillIds?.length
                    ? `AND spills.id IN (${[
                        ...spill_ids_contractor_filter,
                        ...rejectSpillIds,
                      ]})`
                    : isContractorFilter ? ` AND spills.id IN ('')` : " "
                }
                ${
                  organizations_id?.length
                    ? `AND spills.org_id IN (${organizations_id}) `
                    : " "
                }
                ${
                  associated_orgs?.length
                    ? `AND spills.org_id IN (${associated_orgs}) `
                    : " "
                }
                ${
                  isReport
                    ? `
                  AND spill_statuses_history.status LIKE 'Closed: Invoice Submitted to Client'
                  ${
                    date_to
                      ? `
                      AND spill_statuses_history.started_at >= '${forceToCSTForRawQuery(
                        date_to
                      )}'
                      ${
                        date_from
                          ? `AND spill_statuses_history.started_at <= '${forceToCSTForRawQuery(
                              date_from
                            )}'`
                          : " "
                      } 
                      
                      `
                      : " " || date_from
                      ? `
                  AND spills.opened_on <= '${forceToCSTForRawQuery(date_from)}'
                  `
                      : " "
                  }
                  `
                    : " "
                }
                ${
                  userType === USER_TYPE.GENERAL
                    ? `AND (spills.job_no NOT LIKE 'TEMP%'
                      AND spills.job_no NOT LIKE '%TEST%')`
                    : " "
                }
                GROUP BY spills.id
                ORDER BY spills.created_at DESC
                LIMIT ${offset} , ${limit};`;

          const defaultFetchedSpillsQuery = await sequelize.query(
            defaultFetchSpillsQuery
          );

          spillsData = defaultFetchedSpillsQuery[0];

          spillCount = await getSpillCountForGeneralUsers(
            body,
            user,
            spill_ids_contractor_filter,
            rejectSpillIds,
            associated_orgs,
            userType,
            isReport,
            isContractorFilter
          );
        } else {
          const defaultFetchSpillsQuery = `
          SELECT 
                spills.id,
                spills.user_id,
                spills.org_id,
                spills.job_no,
                spills.opened_on,
                spills.send_attachment,
                spills.status,
                spills.conditions,
                spills.address,
                spills.city,
                spills.state,
                spills.zip_code,
                spills.country,
                spills.closed_on,
                JSON_OBJECT('id',
                  client_organization.id,
                  'name',
                  client_organization.name,
                  'address',
                  client_organization.address,
                  'city',
                  client_organization.city,
                  'state',
                  client_organization.state) AS client_organization
                  ${
                    isReport
                      ? `,
                  JSON_ARRAYAGG(
                  JSON_OBJECT(
                    'id', spill_statuses_history.id,
                    'spill_id', spill_statuses_history.spill_id,
                    'status', spill_statuses_history.status
                  )
                ) as spill_status_histories`
                      : " "
                  }
            FROM
                spills AS spills
                ${
                  contractorInvoiceNo
                    ? `LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.inv_no LIKE '${contractorInvoiceNo}'`
                    : pesInvoiceNo
                    ? `
                      LEFT OUTER JOIN
                spill_admins AS spill_admin ON spill_admin.spill_id = spills.id AND spill_admin.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                    LEFT OUTER JOIN
                client_organizations AS client_organization ON spills.org_id = client_organization.id
                    AND client_organization.deleted_at IS NULL
                    LEFT OUTER JOIN
                spill_admins AS spill_admins ON spills.id = spill_admins.spill_id
                    AND (spill_admins.is_removed = FALSE OR spill_admins.is_removed IS NULL)
                    AND spill_admins.deleted_at IS NULL
                    ${
                      isReport
                        ? `
                      LEFT OUTER JOIN
                  spill_statuses_history ON spills.id = spill_statuses_history.spill_id
                      `
                        : ""
                    }
                    ${
                      haz_waste_hauler
                        ? `        
                    LEFT OUTER JOIN                
                        connections AS connections ON spills.id = connections.spill_id
                        AND connections.deleted_at IS NULL
                    LEFT OUTER JOIN
                        spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
                        AND spill_contractors.deleted_at IS NULL
                    LEFT OUTER JOIN
                        contractors AS contractor ON spill_contractors.contractor_id = contractor.id
                        AND contractor.deleted_at IS NULL`
                        : " "
                    }
                    LEFT OUTER JOIN
                packet_reviewer_assignments AS pra ON spills.id = pra.assigned_spill_id
                    AND pra.deleted_at IS NULL
                ${ (disposal_handled_by || container_disposition_type) ? `
                  LEFT OUTER JOIN spill_notes AS sn ON sn.spill_id = spills.id AND sn.deleted_at IS NULL
                  LEFT OUTER JOIN salvage_containers AS sc ON sn.id = sc.note_id AND sc.deleted_at IS NULL
                  ` : " "
                }
            WHERE
                spills.is_approved = TRUE
                ${
                  pesInvoiceNo
                    ? `AND spill_admins.pes_inv_no = ${pesInvoiceNo}`
                    : " "
                }
                ${
                  contractorInvoiceNo
                    ? `AND spill_admins.inv_no = '${contractorInvoiceNo}'`
                    : " "
                }
                ${
                  haz_waste_hauler
                    ? `AND contractor.haz_waste_hauler = ${haz_waste_hauler}`
                    : " "
                }
                ${
                  is_hazmat
                    ? `AND spills.is_hazmat = ${
                        is_hazmat === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                  ${job_no ? `AND spills.job_no LIKE '%${job_no}%'` : " "}
                  ${
                    opened_on && opened_to
                      ? `AND
                  (spills.opened_on >= '${forceToCSTForRawQuery(
                    opened_on
                  )}' AND spills.opened_on <= '${forceToCSTForRawQuery(
                          opened_to
                        )}')`
                      : " "
                  }
                   ${
                     opened_on
                       ? `AND spills.opened_on >= '${forceToCSTForRawQuery(
                           opened_on
                         )}'`
                       : " "
                   }
                   ${
                     opened_to
                       ? `AND spills.opened_on <= '${forceToCSTForRawQuery(
                           opened_to
                         )}'`
                       : " "
                   }
                   ${
                     close_on && close_to
                       ? `AND
                  (spills.closed_on >= '${forceToCSTForRawQuery(
                    close_on
                  )}' AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}')`
                       : " "
                   }
                   ${
                     close_on
                       ? `AND spills.closed_on >= '${forceToCSTForRawQuery(
                           close_on
                         )}'`
                       : " "
                   }
                   ${
                     close_to
                       ? `AND spills.closed_on <= '${forceToCSTForRawQuery(
                           close_to
                         )}'`
                       : " "
                   }
                   ${
                     usersForEmail_id?.length
                       ? `
                    AND spills.id IN (${usersForEmail_id})
                    `
                       : " "
                   }
                   ${
                     packetReviewUsers_id?.length
                       ? `
                   AND pra.packet_reviewer_user_id IN (${packetReviewUsers_id})
                   `
                       : " "
                   }
                  ${city ? `AND spills.city LIKE '%${city}%'` : " "}
                  ${state ? `AND spills.state LIKE '${state}'` : " "}
                  ${country ? `AND spills.country LIKE '${country}'` : " "}
                  ${claim_no ? `AND spills.claim_no LIKE '%${claim_no}%'` : " "}
                  ${type ? `AND spills.type LIKE '${type}'` : " "}
                  ${contact ? `AND spills.contact LIKE '%${contact}%'` : " "}
                  ${
                    responsible
                      ? `AND spills.responsible LIKE '%${responsible}%'`
                      : " "
                  }
                  ${address ? `AND spills.address LIKE '%${address}%'` : " "}
                  ${
                    conditions
                      ? `AND spills.conditions LIKE '%${conditions}%'`
                      : " "
                  }
                  ${material ? `AND spills.material LIKE '%${material}%'` : " "}
                  ${
                    map_needed
                      ? `AND spills.map_needed LIKE '${map_needed}'`
                      : " "
                  }
                  ${
                    need_5800
                      ? `AND spills.need_5800 = ${
                          need_5800 === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    is_waste
                      ? `AND spills.is_waste = ${
                          is_waste === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    has_msds
                      ? `AND spills.has_msds = ${
                          has_msds === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${un_no ? `AND spills.un_no = '${un_no}'` : " "}
                  ${
                    response_sent
                      ? `AND spills.response_sent = ${
                          response_sent === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    subrogation
                      ? `AND spills.subrogation = ${
                          subrogation === 1 ? `TRUE` : `FALSE`
                        }`
                      : " "
                  }
                  ${
                    statusData?.length
                      ? `AND spills.status IN (${convertStatuses(
                          statusData,
                          user?.role?.role
                        ).map((status) => "'" + status + "'")})
                        ${
                          managers_id?.length
                            ? `AND spills.user_id IN (${managers_id})`
                            : " "
                        }
                        `
                      : " "
                  }
                  ${
                    managers_id?.length
                      ? `AND spills.user_id IN (${managers_id})`
                      : " "
                  }
                 ${
                   amount_released
                     ? `AND spills.amount_released = ${+amount_released}`
                     : " "
                 }
                 ${
                   quantity_type_released
                     ? `AND spills.quantity_type_released LIKE '${quantity_type_released}'`
                     : " "
                 }
                 ${
                   damaged_container_type
                     ? `AND spills.damaged_container_type LIKE '${damaged_container_type}'`
                     : " "
                 }
                 ${
                   damaged_type
                     ? `AND spills.damage_type LIKE '${damaged_type}'`
                     : " "
                 }
                ${
                  location_type
                    ? `AND spills.location_type LIKE '${location_type}'`
                    : " "
                }
                ${wasteGeneratedCondition(body)}
                ${
                  drain_impacted
                    ? `AND spills.drain_impacted = ${
                        drain_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  waterway_impacted
                    ? `AND spills.waterway_impacted = ${
                        waterway_impacted === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${
                  is_emergency
                    ? `AND spills.is_emergency = ${
                        is_emergency === 1 ? `TRUE` : `FALSE`
                      }`
                    : " "
                }
                ${trailer ? `AND spills.trailer LIKE '${trailer}'` : " "}
                ${tractor ? `AND spills.tractor LIKE '${tractor}'` : " "}
                ${pro ? `AND spills.pro LIKE '${pro}'` : " "}
                ${
                  spill_ids_contractor_filter?.length || rejectSpillIds?.length
                    ? `AND spills.id IN (${[
                        ...spill_ids_contractor_filter,
                        ...rejectSpillIds,
                      ]})`
                    : isContractorFilter ? ` AND spills.id IN ('')` : " "
                }
                ${
                  isReport
                    ? `
                  AND spill_statuses_history.status LIKE 'Closed: Invoice Submitted to Client'
                  ${
                    date_to
                      ? `
                      AND spill_statuses_history.started_at >= '${forceToCSTForRawQuery(
                        date_to
                      )}'
                      ${
                        date_from
                          ? `AND spill_statuses_history.started_at <= '${forceToCSTForRawQuery(
                              date_from
                            )}'`
                          : " "
                      } 
                      
                      `
                      : " " || date_from
                      ? `
                  AND spills.opened_on <= '${forceToCSTForRawQuery(date_from)}'
                  `
                      : " "
                  }
                  `
                    : " "
                }
                ${
                  organizations_id?.length
                    ? `AND spills.org_id IN (${organizations_id}) `
                    : " "
                }
                ${
                  userType === USER_TYPE.GENERAL
                    ? `AND (spills.job_no NOT LIKE 'TEMP%'
                      AND spills.job_no NOT LIKE '%TEST%')`
                    : " "
                }
                GROUP BY spills.id
                ORDER BY spills.created_at DESC
                LIMIT ${offset} , ${limit};`;

          const defaultFetchedSpillsQuery = await sequelize.query(
            defaultFetchSpillsQuery
          );

          spillsData = defaultFetchedSpillsQuery[0];

          spillCount = await getSpillCountForGeneralUsers(
            body,
            user,
            spill_ids_contractor_filter,
            rejectSpillIds,
            organizations_id,
            userType,
            isReport,
            isContractorFilter
          );
        }
      }
    }

    // Check if role is contractor admin/user then get the count via queries
    spillsData = spillsData.map((spill) => {
      let closedOn;

      const searchStatusString = spill?.status?.search("Open");
      const searchStatusString2 = spill?.status?.split(":");

      if (
        spill.closed_on !== null &&
        spill.closed_on !== "Still Open" &&
        (searchStatusString !== -1 || searchStatusString2[0] !== "Closed")
      ) {
        closedOn = "Re-Opened";
      } else {
        closedOn = spill.closed_on ? spill?.closed_on : "Still Open";
      }

      spill = {
        ...spill,
        opened_on: spill.opened_on,
        closed_on: closedOn,
      };

      return spill;
    });

    return { spillsData, count: spillCount };
  } catch (err) {
    console.log(err);
  }
};

export const searchSpills = async (req, res) => {
  let toReturn = await searchSpillsByConditions(req.body, req.user, true);

  res.status(200).json({
    data: toReturn,
  });
};

export const getDocumentationInReviewSpills = async (req, res) => {
  try {
    const { paginationProps } = req.body;

    const { limit, offset, current } = pagination(
      paginationProps?.page,
      paginationProps
    );

    const fetchDocumentationInReviewSpills = `
      SELECT 
        spills.id,
        spills.user_id,
        spills.org_id,
        spills.job_no,
        spills.opened_on,
        spills.send_attachment,
        spills.status,
        spills.conditions,
        spills.address,
        spills.city,
        spills.state,
        spills.zip_code,
        spills.claim_no,
        spills.country,
        spills.closed_on,
        JSON_OBJECT('id',
          client_organization.id,
          'name',
          client_organization.name,
          'address',
          client_organization.address,
          'city',
          client_organization.city,
          'state',
          client_organization.state) AS client_organization,
        ssh.started_at as started_at,
        DATEDIFF(CURDATE(), ssh.started_at) as days
    FROM
        spills AS spills
        LEFT OUTER JOIN client_organizations AS client_organization ON spills.org_id = client_organization.id AND client_organization.deleted_at IS NULL
        LEFT OUTER JOIN spill_statuses_history ssh ON spills.id = ssh.spill_id AND ssh.status IN ('Open: Documentation In Review') AND ssh.ended_at is NULL and ssh.deleted_at is NULL
    WHERE
        spills.is_approved = TRUE
        AND spills.status IN ('Open: Documentation In Review')
        AND (
          spills.job_no NOT LIKE 'TEMP%'
        AND 
          spills.job_no NOT LIKE '%TEST%'
          )
        GROUP BY spills.id
        ORDER BY ssh.started_at ASC
        LIMIT ${offset} , ${limit};`;

    const fetchDocumentationInReviewSpillIds = `
      SELECT 
        id FROM spills 
      WHERE
        spills.is_approved = TRUE AND spills.status IN ('Open: Documentation In Review')
        AND (
          spills.job_no NOT LIKE 'TEMP%'
        AND 
          spills.job_no NOT LIKE '%TEST%'
          )
      GROUP BY spills.id
      ORDER BY spills.created_at DESC;`;

    const fetchedDocumentationInReviewSpills = await sequelize.query(
      fetchDocumentationInReviewSpills
    );

    const fetchedDocumentationInReviewSpillIds = await sequelize.query(
      fetchDocumentationInReviewSpillIds
    );

    let spillsData = fetchedDocumentationInReviewSpills[0];
    let spillIdsData = fetchedDocumentationInReviewSpillIds[0];

    let spillCount = await getDocumentationInReviewSpillsCount();

    // Update closed on and opened on dates
    spillsData = spillsData?.map((spill) => {
      let closedOn;

      const searchStatusString = spill?.status?.search("Open");
      const searchStatusString2 = spill?.status?.split(":");

      if (
        spill.closed_on !== null &&
        spill.closed_on !== "Still Open" &&
        (searchStatusString !== -1 || searchStatusString2[1] !== " Closed")
      ) {
        closedOn = "Re-Opened";
      } else {
        closedOn = spill.closed_on ? spill?.closed_on : "Still Open";
      }

      spill = {
        ...spill,
        opened_on: spill.opened_on,
        closed_on: closedOn,
      };

      return spill;
    });

    // Fetch packet reviewer name for each spill assigned
    let packetReviewerSpillData = [];

    for (let spill of spillsData) {
      const fetchPacketReviewerName = `
      SELECT packet_reviewer_user_full_name 
      FROM packet_reviewer_assignments
      WHERE 
      assigned_spill_id = ${spill?.id} AND deleted_at IS NULL
      `;
      let fetchedPacketReviewerName = await sequelize.query(
        fetchPacketReviewerName
      );
      fetchedPacketReviewerName = fetchedPacketReviewerName[0][0];

      spill = {
        ...spill,
        assigned_reviewer:
          fetchedPacketReviewerName?.packet_reviewer_user_full_name,
      };

      packetReviewerSpillData?.push(spill);
    }

    // Fetch spill admin attachment invoice amounts
    let adminInvoiceAmountsSpillData = [];
    const spillAdmins = [];

    for (let spill of packetReviewerSpillData) {
      let fetchSpillAdminWithAttachments = `
      select sa.contractor_id, sa.is_complete, sa.id, sa.spill_id,
       JSON_ARRAYAGG(
        JSON_OBJECT(
          "id", sat.id,
          "inv_amount", sat.inv_amount,
          "type", sat.type
        )) as spill_attachments
        from spill_admins sa
        left join users u on u.contractor_id = sa.contractor_id
        left join spill_attachments sat on sat.spill_admin_id = sa.id
        where sa.spill_id = ${spill?.id} AND sa.deleted_at is NULL
        group by sa.id;
        `;

      let fetchedSpillAdminWithAttachments = await sequelize.query(
        fetchSpillAdminWithAttachments
      );

      fetchedSpillAdminWithAttachments?.map((attachment) => {
        const attachmentObject = attachment;
        spillAdmins.push(...attachmentObject);
      });
    }

    let adminIds = [];
    spillAdmins.map((admin) => adminIds.push(admin?.id));
    adminIds = adminIds?.filter((id) => id !== undefined);

    const nonDuplicateAdminsList = spillAdmins?.filter(
      (admin, index) => !adminIds?.includes(admin?.id, index + 1)
    );

    let nonDuplicateAttachments = nonDuplicateAdminsList?.map((admin) =>
      admin?.spill_attachments?.reduce((previous, current) => {
        const element = previous.find((item) => item.id === current.id);
        if (!element) {
          return previous.concat({ ...current, spill_id: admin?.spill_id });
        } else {
          return previous;
        }
      }, [])
    );

    nonDuplicateAttachments = nonDuplicateAttachments?.flat();

    // Sum up contractor inv amounts based on matching spill ids for objects
    let hash = {};
    let invoiceAmountsList = [];

    nonDuplicateAttachments?.forEach((attachment) => {
      if (!hash[attachment?.spill_id]) {
        hash[attachment.spill_id] = {
          id: attachment?.id,
          inv_amount: 0,
          type: attachment?.type,
          spill_id: attachment?.spill_id,
        };
        invoiceAmountsList?.push(hash[attachment.spill_id]);
      }
      if (attachment?.type === "contractorInv") {
        hash[attachment.spill_id].inv_amount += +attachment.inv_amount;
      }
    });

    // Update spill invoice amounts based on id match
    const invoiceAmountsMap = new Map();
    invoiceAmountsList.forEach((invoiceData) => {
      invoiceAmountsMap.set(invoiceData.spill_id, invoiceData);
    });

    packetReviewerSpillData.forEach((spill) => {
      const foundObj = invoiceAmountsMap.get(spill.id);

      if (foundObj) {
        spill = {
          ...spill,
          inv_amount: foundObj.inv_amount,
        };
      } else {
        spill = {
          ...spill,
          inv_amount: null,
        };
      }
      adminInvoiceAmountsSpillData.push(spill);
    });

    res.status(200).json({
      spillsData: adminInvoiceAmountsSpillData,
      count: spillCount,
      spillIds: spillIdsData,
    });
  } catch (error) {
    res.status(400).json({
      status: 400,
      error,
    });
  }
};

export const assignPacketReviewer = async (req, res) => {
  try {
    const { packet_reviewer_data, spills_data } = req.body;
    const { id, full_name, count } = packet_reviewer_data;
    const { email: userEmail } = req?.user;

    const newDate = new Date();
    const date = moment.tz(newDate, "YYYY-MM-DDTHH:mm:ssZ");
    const cstDate = date.tz("America/Chicago");
    const formattedCSTDate = cstDate.format("YYYY-MM-DD HH:mm:ss");

    let dataToInsert = spills_data?.map(
      (spill) =>
        (spill = {
          assigned_spill_id: spill,
          packet_reviewer_user_id: id,
          packet_reviewer_user_full_name: full_name,
        })
    );

    let hasAssignmentDone = false;

    const fetchAssignedUserEmail = `
    SELECT email FROM users WHERE id = ${id};
    `;

    let fetchedAssignedUserEmail = await sequelize.query(
      fetchAssignedUserEmail
    );

    fetchedAssignedUserEmail = fetchedAssignedUserEmail[0][0]?.email;

    const fetchPacketReviewerData = `
    SELECT * FROM packet_reviewer_assignments
    WHERE 
    packet_reviewer_user_id = ${id}; 
    `;

    let fetchedPacketReviewerData = await sequelize.query(
      fetchPacketReviewerData
    );

    fetchedPacketReviewerData = fetchedPacketReviewerData[0];

    // Filter out data if assignment is already done to the same reviewer
    dataToInsert = filterPacketReviewers(
      dataToInsert,
      fetchedPacketReviewerData
    );

    if (dataToInsert?.length > 0) {
      // Filter out data if assignment is already done but to a different reviewer to update spill assignment
      const fetchAllPacketReviewerAssignments = `
      SELECT * FROM packet_reviewer_assignments;
      `;
      let fetchedAllPacketReviewerAssignments = await sequelize.query(
        fetchAllPacketReviewerAssignments
      );

      fetchedAllPacketReviewerAssignments =
        fetchedAllPacketReviewerAssignments[0];

      // Filter spills to update
      let dataToUpdate = filterSpillsToUpdate(
        dataToInsert,
        fetchedAllPacketReviewerAssignments
      );

      // Filter spills to insert
      dataToInsert = filterSpillsToInsert(dataToInsert, dataToUpdate);

      // Update logic for packet reviewer assignment in db
      for (const data of dataToUpdate) {
        const fetchSpillCurrentAssignment = `
        SELECT * FROM packet_reviewer_assignments
        WHERE assigned_spill_id = ${data?.assigned_spill_id};
        `;

        const fetchedSpillCurrentAssignment = await sequelize.query(
          fetchSpillCurrentAssignment
        );

        const fetchedCurrentPacketReviewerUserId =
          fetchedSpillCurrentAssignment[0][0]?.packet_reviewer_user_id;

        const assigned_at = fetchedSpillCurrentAssignment[0][0]?.created_at;

        const assigned_at_date_new_date = new Date(assigned_at);
        const assigned_at_date = moment.tz(
          assigned_at_date_new_date,
          "YYYY-MM-DDTHH:mm:ssZ"
        );
        const assigned_at_date_cst_ate = assigned_at_date.tz("America/Chicago");
        const formatted_assigned_at_date_cst_date = assigned_at_date_cst_ate.format(
          "YYYY-MM-DD HH:mm:ss"
        );

        const updatePacketReviewerAssignmentHistory = `
          INSERT INTO packet_reviewer_assignments_history
          (
            spill_id,
            assigned_packet_reviewer_id,
            assigned_at,
            created_at,
            updated_at
            )
            VALUES
            (
              ${data?.assigned_spill_id},
              ${fetchedCurrentPacketReviewerUserId},
              '${formatted_assigned_at_date_cst_date}',
              '${formattedCSTDate}',
              '${formattedCSTDate}'
              );`;

        await sequelize.query(updatePacketReviewerAssignmentHistory);

        const updatePacketReviewer = `
        UPDATE packet_reviewer_assignments
        SET 
        packet_reviewer_user_id = ${data?.packet_reviewer_user_id},
        packet_reviewer_user_full_name = '${data?.packet_reviewer_user_full_name}',
        updated_at = '${formattedCSTDate}',
        deleted_at = NULL
        WHERE assigned_spill_id = ${data?.assigned_spill_id};
        `;

        await sequelize.query(updatePacketReviewer);
        hasAssignmentDone = true;
      }

      // Insertion logic for packet reviewer assignment in db
      for (const data of dataToInsert) {
        const asssignReviewer = `
        INSERT INTO packet_reviewer_assignments
        (
          packet_reviewer_user_id,
          assigned_spill_id,
          packet_reviewer_user_full_name,
          created_at,
          updated_at
          )
          VALUES
          (
        ${data?.packet_reviewer_user_id},
        ${data?.assigned_spill_id},
        '${data?.packet_reviewer_user_full_name}',
        '${formattedCSTDate}',
        '${formattedCSTDate}'
        )
        `;

        await sequelize.query(asssignReviewer);
        hasAssignmentDone = true;
      }
    }

    // Fetch updated packet assignment data
    const fetchUpdatedPacketAssignmentData = `
      SELECT
      packet_reviewer_user_id,
      assigned_spill_id,
      packet_reviewer_user_full_name
      FROM
      packet_reviewer_assignments;
      `;

    let fetchedUpdatedPacketAssignmentData = await sequelize.query(
      fetchUpdatedPacketAssignmentData
    );

    fetchedUpdatedPacketAssignmentData = fetchedUpdatedPacketAssignmentData[0];

    // Dipsatch email to packet reviewer, assigned reviewer and user who assigns the packet reviewer
    if (hasAssignmentDone) {
      // Find all users where packet reviewer is true
      const fetchPacketReviewerCapacity = `
       SELECT id, full_name, email, is_packet_reviewer 
       FROM users
       WHERE is_packet_reviewer = TRUE;
       `;

      let fetchedPacketReviewerCapacity = await sequelize.query(
        fetchPacketReviewerCapacity
      );

      fetchedPacketReviewerCapacity = fetchedPacketReviewerCapacity[0]?.map(
        (reviewer) =>
          (reviewer = {
            ...reviewer,
            is_packet_reviewer:
              reviewer?.is_packet_reviewer === 1 ? "TRUE" : "FLASE",
          })
      );

      const updatedPacketReviewerCapacity = [];

      // Fetch and update count as capacity
      for (let packetReviewer of fetchedPacketReviewerCapacity) {
        const fetchPacketReviewerAssignmentCount = `
         SELECT assigned_spill_id
         FROM packet_reviewer_assignments
         WHERE packet_reviewer_user_id = ${packetReviewer?.id}
         `;

        let fetchedPacketReviewerAssignmentCount = await sequelize.query(
          fetchPacketReviewerAssignmentCount
        );

        fetchedPacketReviewerAssignmentCount =
          fetchedPacketReviewerAssignmentCount[0];

        packetReviewer = {
          ...packetReviewer,
          packet_reviewer_count: fetchedPacketReviewerAssignmentCount?.length,
        };
        updatedPacketReviewerCapacity.push(packetReviewer);
      }

      if (updatedPacketReviewerCapacity?.length > 0) {
        const csvData = [];

        updatedPacketReviewerCapacity?.map((data) =>
          csvData?.push({ ...data })
        );

        const fields = [
          "full_name",
          "email",
          "is_packet_reviewer",
          "packet_reviewer_count",
        ];

        const json2CSVParser = new Parser({ fields });
        const csv = json2CSVParser.parse(csvData);

        const attachmentId = uniqueIdGenerator();
        const attachmentPath = `./uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`;

        fs.writeFile(attachmentPath, csv, (err) => {
          if (err) {
            console.log("Error writing file", err);
          } else {
            console.log("Successfully wrote file");
          }
        });

        const attachmentsList = [
          {
            filename: attachmentPath.split("/").pop(),
            path: attachmentPath,
          },
        ];

        // Filter out duplciate users to email
        let usersToEmailList = [
          CONSTANTS.PACKET_REVIEW_EMAIL,
          userEmail,
          fetchedAssignedUserEmail,
        ];

        usersToEmailList = usersToEmailList?.filter(uniqueStringsInArray);

        // Build data for email
        for (const spillId of spills_data) {
          let spillData = await models.Spills.findOne({
            where: { id: spillId },
            include: [
              { model: models.User, required: false },
              { model: models.ClientOrganizations, required: false },
            ],
          });

          const fetchAssignedUser = `
        SELECT packet_reviewer_user_full_name
        FROM packet_reviewer_assignments
        WHERE assigned_spill_id = ${spillId};
        `;

          let fetchedAssignedUser = await sequelize.query(fetchAssignedUser);

          fetchedAssignedUser =
            fetchedAssignedUser[0][0]?.packet_reviewer_user_full_name;

          const dataForEmail = {
            sendEmailTo: usersToEmailList,
            sendEmailFrom: userEmail,
            ...generateHtml(
              {
                spill: getDataValues(spillData),
                assignedPacketReviewer: fetchedAssignedUser,
                assignerUser: userEmail,
              },
              ACTIONS.PACKET_REVIEWER_ASSIGNMENT
            ),
            attachments: attachmentsList,
          };

          await genericSender(dataForEmail);
        }

        // Remove CSV
        fs.unlink(
          `uploads/admin/csv-packet-reviewer-capacity-${attachmentId}.csv`,
          (err) => {
            if (err) {
              console.log("WARNING! Unable to delete csv file.");
            } else {
              console.log("File removed successfully");
            }
          }
        );
      }
    }

    res
      .status(200)
      .json({ updated_packet_assignment: fetchedUpdatedPacketAssignmentData });
  } catch (error) {
    console.log("error", error);
    res.status(400).json({
      status: 400,
      error,
    });
  }
};

export const createSpillReserves = async (req, res, next) => {
  try {
    const { user_id, spill_id, amount } = req.body;

    const reserve = {
      user_id,
      spill_id,
      amount,
    };

    await models.Reserves.create(reserve);

    const updatedReserves = await models.Reserves.findAll({
      include: [
        {
          model: models.User,
          required: false,
        },
      ],
      where: { spill_id },
    });

    res.status(200).json({
      data: updatedReserves,
    });
  } catch (err) {
    console.log(err);
    let message;
    switch (err.message) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};

export const editSpillReserves = async (req, res, next) => {
  try {
    const { id, user_id, spill_id, amount } = req.body;

    const reserve = {
      user_id,
      amount,
    };

    await models.Reserves.update(reserve, {
      where: { id },
    });

    const updatedReserves = await models.Reserves.findAll({
      include: [
        {
          model: models.User,
          required: false,
        },
      ],
      where: { spill_id },
    });

    res.status(200).json({
      data: updatedReserves,
    });
  } catch (err) {
    console.log(err);
    let message;
    switch (err.message) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};

//Function to upload attachments from admin section of Spills
export const addSpillAttachments = async (
  admins,
  files,
  fileData,
  userId,
  spillId
) => {
  try {
    const attachments = [];
    const requestedAttachments = [];
    const updatedRequestedDocumentsList = [];

    for (const fileIndex in files) {
      const uniqueId = uniqueIdGenerator();
      const data = await uploadFileToS3Bucket(
        files[fileIndex].path,
        `${spillId}/admin/${uniqueId}/${
          files[fileIndex].originalname.split("#")[1]
        }`
      );

      /* Check if admin is inactive and has not done any activity 
      then removed that admin from list to upload files on active 
      admins only */
      for (const [index, admin] of admins.entries()) {
        const adminIsRemoved = admin?.is_removed === true;
        const adminHasNoAttachments = admin?.spill_attachments.length === 0;
        const adminHasNotDoneAnyActivity =
          admin?.info === "" &&
          admin?.contractor_invoice === "" &&
          admin?.inv_no === "";
        if (
          adminIsRemoved &&
          adminHasNoAttachments &&
          adminHasNotDoneAnyActivity
        ) {
          admins.splice(index, 1);
        }
      }

      if (fileData[fileIndex]?.isFileRequested) {
        requestedAttachments.push({
          url_link: data.Location,
          key: data.key || data.Key,
          name: files[fileIndex].originalname.split("#")[1],
          spill_admin_id: admins[fileData[fileIndex].adminIndex].id,
          user_id: userId,
          type: fileData[fileIndex].type,
          size: fileData[fileIndex].size,
          inv_amount: fileData[fileIndex].inv_amount,
          expiry_date: fileData[fileIndex].expiry_date,
        });

        updatedRequestedDocumentsList.push({
          type: fileData[fileIndex].type,
          request_id: fileData[fileIndex]?.requestId,
        });
      } else {
        attachments.push({
          url_link: data.Location,
          key: data.key || data.Key,
          name: files[fileIndex].originalname.split("#")[1],
          spill_admin_id: admins[fileData[fileIndex].adminIndex].id,
          user_id: userId,
          type: fileData[fileIndex].type,
          size: fileData[fileIndex].size,
          inv_amount: fileData[fileIndex].inv_amount,
          expiry_date: fileData[fileIndex].expiry_date,
        });
      }
      console.log("path=", files[fileIndex].path);
      fs.unlinkSync(files[fileIndex].path);
    }

    if (attachments?.length) {
      const createdAttachments = await models.SpillAttachments.bulkCreate(
        attachments
      );
      const spillAttachmentLogsToUpdate = [];

      if (createdAttachments?.length) {
        for (let i = 0; i < createdAttachments?.length; i++) {
          spillAttachmentLogsToUpdate.push({
            spill_attachment_id: createdAttachments[i]?.id,
            status: null,
            spill_admin_id: createdAttachments[i]?.spill_admin_id,
            type: createdAttachments[i]?.type,
          });
        }
      }
      if (spillAttachmentLogsToUpdate?.length) {
        await models.SpillAttachmentLogs.bulkCreate(
          spillAttachmentLogsToUpdate
        );
      }
    }

    if (requestedAttachments?.length) {
      const createdRequestedAttachmentsIds = [];
      const spillAttachmentLogsToUpdate = [];

      const createdAttachments = await models.SpillAttachments.bulkCreate(
        requestedAttachments
      );

      for (let i = 0; i < createdAttachments?.length; i++) {
        createdRequestedAttachmentsIds?.push({
          spill_attachment_id: createdAttachments[i]?.id,
          spill_attachment_type: createdAttachments[i]?.type,
          uploaded_at: createdAttachments[i]?.created_at,
          uploaded_by: createdAttachments[i]?.spill_admin_id,
          updated_at: createdAttachments[i]?.created_at,
        });

        spillAttachmentLogsToUpdate.push({
          spill_attachment_id: createdAttachments[i]?.id,
          status: null,
          spill_admin_id: createdAttachments[i]?.spill_admin_id,
          type: createdAttachments[i]?.type,
        });
      }

      if (spillAttachmentLogsToUpdate?.length) {
        await models.SpillAttachmentLogs.bulkCreate(
          spillAttachmentLogsToUpdate
        );
      }

      const matchedAttachmentIdsAndTypes = createdRequestedAttachmentsIds.reduce(
        (acc, curr) => {
          const matchedDocument = updatedRequestedDocumentsList.find(
            (doc) => doc.type === curr.spill_attachment_type
          );
          if (matchedDocument) {
            acc.push({
              spill_attachment_id: curr?.spill_attachment_id,
              spill_attachment_type: curr?.spill_attachment_type,
              request_id: matchedDocument?.request_id,
              uploaded_at: curr?.uploaded_at,
              uploaded_by: curr?.uploaded_by,
              updated_at: curr?.updated_at,
            });
          }
          return acc;
        },
        []
      );

      const updateRequestedDocsData = matchedAttachmentIdsAndTypes?.map(
        (item) => {
          return {
            id: item?.request_id,
            uploaded_at: item?.uploaded_at,
            uploaded_by: item?.uploaded_by,
            updated_at: item?.updated_at,
            spill_attachment_type: item?.spill_attachment_type,
          };
        }
      );

      const updateRequestedSpillAttachmentsMappingData = matchedAttachmentIdsAndTypes?.map(
        (item) => {
          return {
            spill_attachment_id: item?.spill_attachment_id,
            request_id: item?.request_id,
          };
        }
      );

      const uniqueDocsData = updateRequestedDocsData.filter(
        (doc, index, docs) => {
          // Find the index of the first occurrence of the document with the same ID
          const firstIndex = docs.findIndex((d) => d?.id === doc?.id);
          // Return true if the current index is the same as the first index
          return index === firstIndex;
        }
      );

      // Update main request for submitted docs
      const requestedDocIds = [];
      const updatedRequestDocEntries = [];
      for (let i = 0; i < uniqueDocsData?.length; i++) {
        // Find the latest requested doc
        const findLatestRequest = await models.ContractorRequestedDocumentations.findAll(
          {
            limit: 1,
            order: [["created_at", "DESC"]],
          }
        );

        // Update latest requested doc only
        await models.ContractorRequestedDocumentations.update(
          {
            status: "submitted",
            uploaded_at: uniqueDocsData[i]?.uploaded_at,
            uploaded_by: uniqueDocsData[i]?.uploaded_by,
            updated_at: uniqueDocsData[i]?.updated_at,
          },
          {
            where: { id: findLatestRequest[0]?.id },
          }
        );

        // Find spill admin id and requested type for the updated docs
        const fetchedUpdatedRequestedDocData = await models.ContractorRequestedDocumentations.findOne(
          {
            attributes: ["requested_type", "spill_admin_id"],
            where: { id: uniqueDocsData[i]?.id },
          }
        );

        updatedRequestDocEntries.push({
          requested_type: fetchedUpdatedRequestedDocData?.requested_type,
          spill_admin_id: fetchedUpdatedRequestedDocData?.spill_admin_id,
        });

        requestedDocIds.push(uniqueDocsData[i]?.id);
      }

      // Update all previous requested document by type and admin id to submitted
      for (let i = 0; i < updatedRequestDocEntries.length; i++) {
        await models.ContractorRequestedDocumentations.update(
          {
            status: "submitted",
          },
          {
            where: {
              status: "requested",
              uploaded_at: null,
              requested_type: updatedRequestDocEntries[i]?.requested_type,
              spill_admin_id: updatedRequestDocEntries[i]?.spill_admin_id,
            },
          }
        );
      }

      // Dispatch on requested docs being submitted
      const generatedEmailData = await emailDataMapper(requestedDocIds);

      const dataForEmail = {
        sendEmailTo: generatedEmailData?.user_email_list,
        sendEmailFrom: EMAIL_SENDER,
        ...generateHtml(
          {
            spill_job_no: generatedEmailData?.spill_job_no,
            requested_doc_types: generatedEmailData?.requested_doc_types,
          },
          ACTIONS.REQUEST_DOCUMENTATION_SUBMISSION
        ),
      };

      await genericSender(dataForEmail);

      // Update mapping table for Request Doc
      for (
        let i = 0;
        i < updateRequestedSpillAttachmentsMappingData?.length;
        i++
      ) {
        const objectToCreate = {
          request_id: updateRequestedSpillAttachmentsMappingData[i]?.request_id,
          uploaded_admin_attachments_id:
            updateRequestedSpillAttachmentsMappingData[i]?.spill_attachment_id,
        };

        await models.ContractorRequestedDocumentsAdminAttachmentsMaps.create(
          objectToCreate
        );
      }
    }
  } catch (err) {
    console.log(err);
  }
};

const emailDataMapper = async (requestedDocIds) => {
  try {
    const user_ids_to_email_on_submission = [];
    let spill_job_number = "";
    const requestedTypes = [];

    for (let i = 0; i < requestedDocIds?.length; i++) {
      const updatedRequestDocumentation = await models.ContractorRequestedDocumentations.findOne(
        {
          include: [
            {
              model: models.Spills,
              required: false,
              attributes: ["job_no", "user_id"],
            },
          ],
          attributes: ["requested_by", "spill_id", "requested_type"],
          where: {
            id: requestedDocIds[i],
            deleted_at: null,
          },
        }
      );

      user_ids_to_email_on_submission.push(
        updatedRequestDocumentation?.spill?.user_id
      );
      user_ids_to_email_on_submission.push(
        updatedRequestDocumentation?.requested_by
      );
      spill_job_number = updatedRequestDocumentation?.spill?.job_no;
      requestedTypes.push(updatedRequestDocumentation?.requested_type);
    }

    const uniqueTypesToReturn = [...new Set(requestedTypes)];
    const uniqueIdsToReturn = [...new Set(user_ids_to_email_on_submission)];
    const userEmailList = [];

    for (let i = 0; i < uniqueIdsToReturn?.length; i++) {
      let user = await models.User.findOne({
        attributes: ["email"],
        where: { id: uniqueIdsToReturn[i] },
      });
      userEmailList.push(user?.email);
    }

    return {
      user_email_list: userEmailList,
      spill_job_no: spill_job_number,
      requested_doc_types: uniqueTypesToReturn,
    };
  } catch (error) {
    console.log(error);
  }
};

export const closeSpillById = async (id, timestamp = new Date()) => {
  const status = "Closed: Closed";

  const spillStatusSplitter = status.split(":");

  const status_type = spillStatusSplitter[0].trim();
  const status_name = spillStatusSplitter[1].trim();

  const statusFound = await models.SpillStatuses.findOne({
    where: {
      status: status_type,
      name: status_name,
    },
  });

  const spillStatus = statusFound;

  await models.Spills.update(
    { closed_on: timestamp, status, status_id: spillStatus.id },
    {
      where: { id: id },
    }
  );
};

export const closeSpill = async (req, res) => {
  const { id } = req.params;
  const closed_on = await closeSpillById(id);
  res.status(200).json({
    closed_on,
  });
};

export const getClientAssociatedServices = async (req, res) => {
  const { orgId } = req.query;

  try {
    let clientAssociatedServices = await models.ClientOrganizationServices.findAll(
      {
        include: [
          {
            model: models.Services,
            required: false,
            include: [{ model: models.Categories, required: false }],
          },
        ],
        where: {
          org_id: orgId,
        },
      }
    );

    let services = [];

    if (clientAssociatedServices?.length > 0) {
      clientAssociatedServices.forEach((associatedService) => {
        let serviceObj = {
          ...associatedService.service?.dataValues,
          type: associatedService.type,
          rate: associatedService.rate,
        };

        services.push(serviceObj);
      });
    }

    res.status(200).send({
      services,
    });
  } catch (err) {
    console.log(err);
  }
};

const createRemovalNotes = async (
  contractors,
  userId,
  spillId,
  userFullName
) => {
  let findPromises = [];
  let createPromises = [];
  let addressPromises = [];
  let contractorAddressMapping = {};
  const date = new Date();

  for (const index in contractors) {
    findPromises.push(
      models.Contractors.findOne({
        where: {
          id: contractors[index].contractor_id,
        },
      })
    );
    if (contractors[index].addressId) {
      addressPromises.push(
        models.Addresses.findOne({
          where: {
            id: contractors[index].addressId,
          },
        })
      );
      contractorAddressMapping[index] = addressPromises.length - 1;
    }
  }

  const responses = await Promise.all(findPromises);
  const addresses = await Promise.all(addressPromises);

  for (const index in responses) {
    let description = "";
    let addressIndex = contractorAddressMapping[index];
    if (addressIndex === 0 || addressIndex) {
      description = createDescription(
        responses[index],
        date,
        userFullName,
        addresses[addressIndex]
      );
    } else {
      description = createDescription(responses[index], date, userFullName);
    }
    createPromises.push(
      models.SpillNotes.create({
        spill_id: spillId,
        user_id: userId,
        description,
      })
    );
  }

  await Promise.all(createPromises);
};

export const getSpillMaterials = async (req, res) => {
  const { value } = req.body;

  try {
    const materials = await models.SpillMaterial.findAll({
      where: {
        name: {
          $like: `%${value}%`,
        },
      },
    });

    res.status(200).json({
      data: materials,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getSpillStatuses = async (req, res) => {
  try {
    const statuses = await models.SpillStatuses.findAll();

    res.status(200).json({
      data: statuses,
    });
  } catch (err) {
    console.log(err);
  }
};

export const countSpillInMonth = async (req, res) => {
  var date = new Date();

  var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

  const where = {
    opened_on: {
      $between: [firstDay, lastDay],
    },
  };
  try {
    const result = await models.Spills.count({
      where,
    });
    res.json({
      data: {
        count: result,
      },
    });
  } catch (err) {
    res.status(500).send();
    console.log(err);
  }
};

export const getSpillsWithClosure = async (req, res) => {
  const {
    page,
    id,
    permission,
    role,
    limit: rowsPerPage,
    userType,
  } = req.query;

  const { limit, offset, current } = pagination(page, { limit: +rowsPerPage });

  let total = 0;

  // let order = [["created_at", "DESC"]];

  let include = [
    {
      model: models.ClientOrganizations,
      required: false,
      attributes: ["name", "payment_terms"],
    },
    {
      model: models.SpillNotes,
      attributes: ["service_id", "created_at"],
    },
  ];

  let closureSpills = await models.SpillNotes.findAll({
    attributes: ["spill_id"],
    where: { service_id: 58 },
  });

  // Flatten the array
  closureSpills = closureSpills.map((note) => note.dataValues.spill_id);

  const spillPermission =
    permission.toString().toLowerCase() === "true" ? true : false;

  let where = {
    is_approved: true,
    id: closureSpills,
    status: { $not: "Closed: Closed" },
  };

  if (userType === USER_TYPE.GENERAL) {
    where = {
      ...where,
      job_no: {
        $and: [
          {
            $notLike: "TEMP%",
          },
          {
            $notLike: "%TEST%",
          },
        ],
      },
    };
  }

  try {
    let spillsData;
    switch (role) {
      case ROLES.CONTRACTOR_USER: {
        where = {
          ...where,
          is_approved: true,
        };
        let user = await models.User.findOne({
          where: { id },
        });

        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = {
            ...where,
            "$connections.spill_contractors.address_id$":
              user.contractor_address_id,
          };
          where = {
            ...where,
            "$connections.spill_contractors.contractor.id$": user.contractor_id,
          };
        }

        let date = new Date();
        date.setDate(date.getDate() - 10);

        let currentCSTDateMinusTen = Moment.utc(date)
          ?.tz("America/Rankin_Inlet")
          ?.format("YYYY-MM-DD HH:mm:ss");

        const queryContractor = `SELECT 
        spills.id,
        spills.user_id,
        spills.org_id,
        spills.job_no,
        spills.opened_on,
        spills.send_attachment,
        spills.status,
        spills.conditions,
        spills.address,
        spills.city,
        spills.state,
        spills.zip_code,
        spills.country,
        spills.contact,
        spills.type,
        spills.responsible,
        spills.need_5800,
        spills.is_waste,
        spills.has_msds,
        spills.is_hazmat,
        spills.response_sent,
        spills.subrogation,
        spills.claim_no,
        spills.is_demo,
        spills.closed_on,
        spills.material,
        spills.status_id,
        spills.assignment_no,
        spills.freight_bill,
        spills.money_saved_mgt,
        spills.money_saved_waste,
        spills.rate,
        spills.material_id,
        spills.is_approved,
        spills.send_email,
        spills.is_legacy,
        spills.un_no,
        spills.latitude,
        spills.longitude,
        spills.tractor,
        spills.trailer,
        spills.onsite_poc_name,
        spills.onsite_poc_phone,
        spills.driver_name,
        spills.driver_phone,
        spills.pro,
        spills.map_needed,
        spills.amount_released,
        spills.quantity_type_released,
        spills.damaged_container_type,
        spills.damage_type,
        spills.location_type,
        spills.drain_impacted,
        spills.waterway_impacted,
        spills.legacy_id,
        spills.last_status_changed,
        spills.total_notes_sum,
        spills.is_emergency,
        spills.watched,
        JSON_OBJECT(
          "id" , client_organization.id,
          "name", client_organization.name,
          "payment_terms", client_organization.payment_terms
          ) as client_organization,
          JSON_ARRAYAGG(

          JSON_OBJECT(
        "id" , spill_notes.id,
		"service_id" , spill_notes.service_id,
		"created_at" , spill_notes.created_at

            )) as spill_notes
      
    FROM
        spills AS spills
            LEFT OUTER JOIN
        client_organizations AS client_organization ON spills.org_id = client_organization.id
            AND (client_organization.deleted_at IS NULL)
            LEFT OUTER JOIN
        spill_notes AS spill_notes ON spills.id = spill_notes.spill_id
            AND (spill_notes.deleted_at IS NULL
    
           )
            LEFT OUTER JOIN
        connections AS connections ON spills.id = connections.spill_id
            AND ( connections.deleted_at IS NULL)
            LEFT OUTER JOIN
        spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
            AND ((spill_contractors.deleted_at IS NULL)
            AND spill_contractors.contractor_id =  ${user.contractor_id})
            LEFT OUTER JOIN
        contractors AS contractor ON spill_contractors.contractor_id = contractor.id
            AND (( contractor.deleted_at IS NULL)
            AND contractor.id = ${user.contractor_id})
    WHERE
           (spill_notes.service_id = 58
           AND (spill_notes.created_at > '${currentCSTDateMinusTen}' ) )
           AND
        spills.is_approved = TRUE
            AND spills.id IN 
            (${closureSpills.join(",")}  )
            AND spills.status != 'Closed: Closed'
            AND spills.is_demo = FALSE
            AND spill_contractors.address_id = ${user.contractor_address_id}
            AND contractor.id = ${user.contractor_id}
            ${
              userType === USER_TYPE.GENERAL
                ? `AND (spills.job_no NOT LIKE 'TEMP%'
            AND spills.job_no NOT LIKE '%TEST%')`
                : " "
            }
            Group by spills.id
            ORDER BY spills.created_at ASC
            LIMIT ${offset} , ${limit};
    `;

        let spills = await sequelize.query(queryContractor);

        spills = spills[0];

        let spillsCount = await models.Spills.count({
          include: [
            {
              model: models.ClientOrganizations,
              required: false,
              attributes: ["name", "payment_terms"],
            },
            {
              model: models.SpillNotes,
              attributes: ["service_id", "created_at"],
              where: {
                service_id: 58,
                created_at: {
                  [Op.gt]: currentCSTDateMinusTen,
                },
              },
            },
            {
              model: models.Connections,
              required: false,
              as: "connections",
              include: [
                {
                  model: models.SpillContractors,
                  required: false,
                  as: "spill_contractors",
                  where: { contractor_id: user.contractor_id },
                  include: [
                    {
                      model: models.Contractors,
                      as: "contractor",
                      required: false,
                      where: { id: user.contractor_id },
                    },
                  ],
                },
              ],
            },
          ],
          where: {
            ...where,
            is_approved: true,
          },

          paranoid: false,
          distinct: true,
        });

        total = spillsCount;
        spillsData = spills;

        break;
      }
      case ROLES.CONTRACTOR_ADMIN: {
        where = {
          ...where,
          is_approved: true,
        };
        let user = await models.User.findOne({
          where: { id },
        });

        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = {
            ...where,
            "$connections.spill_contractors.contractor.id$": user.contractor_id,
          };
        }

        let date = new Date();
        date.setDate(date.getDate() - 10);

        let currentCSTDateMinusTen = Moment.utc(date)
          ?.tz("America/Rankin_Inlet")
          ?.format("YYYY-MM-DD HH:mm:ss");

        const queryContractor = `SELECT 
        spills.id,
        spills.user_id,
        spills.org_id,
        spills.job_no,
        spills.opened_on,
        spills.send_attachment,
        spills.status,
        spills.conditions,
        spills.address,
        spills.city,
        spills.state,
        spills.zip_code,
        spills.country,
        spills.contact,
        spills.type,
        spills.responsible,
        spills.need_5800,
        spills.is_waste,
        spills.has_msds,
        spills.is_hazmat,
        spills.response_sent,
        spills.subrogation,
        spills.claim_no,
        spills.is_demo,
        spills.closed_on,
        spills.material,
        spills.status_id,
        spills.assignment_no,
        spills.freight_bill,
        spills.money_saved_mgt,
        spills.money_saved_waste,
        spills.rate,
        spills.material_id,
        spills.is_approved,
        spills.send_email,
        spills.is_legacy,
        spills.un_no,
        spills.latitude,
        spills.longitude,
        spills.tractor,
        spills.trailer,
        spills.onsite_poc_name,
        spills.onsite_poc_phone,
        spills.driver_name,
        spills.driver_phone,
        spills.pro,
        spills.map_needed,
        spills.amount_released,
        spills.quantity_type_released,
        spills.damaged_container_type,
        spills.damage_type,
        spills.location_type,
        spills.drain_impacted,
        spills.waterway_impacted,
        spills.legacy_id,
        spills.last_status_changed,
        spills.total_notes_sum,
        spills.is_emergency,
        spills.watched,
        JSON_OBJECT(
          "id" , client_organization.id,
          "name", client_organization.name,
          "payment_terms", client_organization.payment_terms
          ) as client_organization,
          JSON_ARRAYAGG(

          JSON_OBJECT(
        "id" , spill_notes.id,
		"service_id" , spill_notes.service_id,
		"created_at" , spill_notes.created_at

            )) as spill_notes
      
    FROM
        spills AS spills
            LEFT OUTER JOIN
        client_organizations AS client_organization ON spills.org_id = client_organization.id
            AND (client_organization.deleted_at IS NULL)
            LEFT OUTER JOIN
        spill_notes AS spill_notes ON spills.id = spill_notes.spill_id
            AND (spill_notes.deleted_at IS NULL
    
           )
            LEFT OUTER JOIN
        connections AS connections ON spills.id = connections.spill_id
            AND ( connections.deleted_at IS NULL)
            LEFT OUTER JOIN
        spill_contractors AS spill_contractors ON connections.id = spill_contractors.connection_id
            AND ((spill_contractors.deleted_at IS NULL)
            AND spill_contractors.contractor_id =  ${user.contractor_id})
            LEFT OUTER JOIN
        contractors AS contractor ON spill_contractors.contractor_id = contractor.id
            AND (( contractor.deleted_at IS NULL)
            AND contractor.id = ${user.contractor_id})
    WHERE
           (spill_notes.service_id = 58
           AND (spill_notes.created_at > '${currentCSTDateMinusTen}' ) )
           AND
        spills.is_approved = TRUE
            AND spills.id IN 
            (${closureSpills.join(",")}  )
            AND spills.status != 'Closed: Closed'
            AND spills.is_demo = FALSE
            AND contractor.id = ${user.contractor_id}
            ${
              userType === USER_TYPE.GENERAL
                ? `AND (spills.job_no NOT LIKE 'TEMP%'
            AND spills.job_no NOT LIKE '%TEST%')`
                : " "
            }
            Group by spills.id
            ORDER BY spills.created_at ASC

            LIMIT ${offset} , ${limit};
    `;

        let spills = await sequelize.query(queryContractor);

        spills = spills[0];

        let spillsCount = await models.Spills.count({
          include: [
            {
              model: models.ClientOrganizations,
              required: false,
              attributes: ["name", "payment_terms"],
            },
            {
              model: models.SpillNotes,
              attributes: ["service_id", "created_at"],
              where: {
                service_id: 58,
                created_at: {
                  [Op.gt]: currentCSTDateMinusTen,
                },
              },
            },
            {
              model: models.Connections,
              required: false,
              as: "connections",
              include: [
                {
                  model: models.SpillContractors,
                  required: false,
                  as: "spill_contractors",
                  where: { contractor_id: user.contractor_id },
                  include: [
                    {
                      model: models.Contractors,
                      as: "contractor",
                      required: false,
                      where: { id: user.contractor_id },
                    },
                  ],
                },
              ],
            },
          ],
          where: {
            ...where,
            is_approved: true,
          },

          paranoid: false,
          distinct: true,
        });

        total = spillsCount;
        spillsData = spills;

        break;
      }
      case ROLES.CORPORATE_USER: {
        let user = await models.User.findOne({
          where: { id },
        });

        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = { ...where, org_id: user?.org_id };
        }

        let spills = await models.Spills.findAndCountAll({
          include,
          where,
          // order,
          limit,
          offset,
          paranoid: false,
          distinct: true,
        });

        total = spills.count;
        spillsData = spills.rows;

        break;
      }
      default:
        if (spillPermission) {
          let user = await models.User.findOne({
            where: { id },
          });

          let associatedOrgs = await models.AssociatedOrganizations.findAll({
            where: {
              org_id: user?.org_id,
            },
          });

          let associated_orgs = [user.org_id];

          associatedOrgs.map((associatedOrgs) => {
            associated_orgs.push(associatedOrgs.associated_org_id);
          });

          if (role === ROLES.DEMO) {
            where = { ...where, is_demo: true };
          } else {
            where = { ...where, is_demo: false };
            where = { ...where, org_id: { $in: associated_orgs } };
          }

          let spills = await models.Spills.findAndCountAll({
            include,
            where,
            // order,
            limit,
            offset,
            paranoid: false,
            distinct: true,
          });

          total = spills.count;
          spillsData = spills.rows;
        } else {
          if (role === ROLES.DEMO) {
            where = { ...where, is_demo: true };
          } else {
            where = { ...where, is_demo: false };
          }
          let spills = await models.Spills.findAndCountAll({
            include,
            where,
            limit,
            offset,
            paranoid: false,
            distinct: true,
            // order,
          });
          total = spills.count;
          spillsData = spills.rows;
        }
    }

    spillsData = filterSpills(role, spillsData);

    spillsData = spillsData.map((spill) => {
      let closedOn;
      let daysCounter;
      let isOverdue = false;
      const date = Moment();

      const searchStatusString = spill?.status?.search("Open");

      if (spill.closed_on && searchStatusString != -1) {
        closedOn = "Re-Opened";
      } else {
        closedOn = spill.closed_on
          ? Moment(spill.closed_on).format("MMMM DD YYYY hh:mm a")
          : "Still Open";
      }
      if (isContractorUser(role)) {
        for (const note of spill.spill_notes) {
          if (note.service_id === 58) {
            const serviceDate = Moment(note.created_at);
            const diff = date.diff(serviceDate, "days");
            if (!daysCounter || daysCounter < diff + 1) {
              daysCounter = diff + 1;
            }
          }
        }

        if (daysCounter > (spill.client_organization.payment_terms || 10)) {
          isOverdue = true;
        }

        spill = {
          ...spill,
          opened_on: spill.opened_on,
          closed_on: closedOn,
          daysCounter,
          isOverdue,
        };
      } else {
        for (const note of spill.spill_notes) {
          if (note.service_id === 58) {
            const serviceDate = Moment(note.created_at);
            const diff = date.diff(serviceDate, "days");
            if (!daysCounter || daysCounter < diff + 1) {
              daysCounter = diff + 1;
            }
          }
        }

        if (daysCounter > (spill.client_organization.payment_terms || 10)) {
          isOverdue = true;
        }

        spill.dataValues = {
          ...spill.dataValues,
          opened_on: spill.opened_on,
          closed_on: closedOn,
          daysCounter,
          isOverdue,
        };
      }

      return spill;
    });

    if (isContractorUser(role)) {
      spillsData = spillsData.filter((spill) => spill.daysCounter <= 10);
    }

    res.status(200).json({
      data: spillsData,
      pagination: {
        current: current > total ? total : current,
        total,
      },
    });
  } catch (err) {
    console.log("err :", err);
  }
};

export const getSpillsSummary = async (req, res) => {
  const { userType } = req.query;
  const role = req.user.role.role;
  const id = req.user.id;
  const permission = req.user.role.permission.view_related_spills;

  const spillPermission =
    permission.toString().toLowerCase() === "true" ? true : false;

  let where = { is_approved: true, status: { [Op.ne]: 'Closed: Closed' } };

  if (userType === USER_TYPE.GENERAL) {
    where = {
      ...where,
      job_no: {
        $and: [
          {
            $notLike: "TEMP%",
          },
          {
            $notLike: "%TEST%",
          },
        ],
      },
    };
  }

  try {
    let spills;

    switch (role) {
      case ROLES.CONTRACTOR_USER: {
        let user = await models.User.findOne({
          where: { id },
        });

        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = {
            ...where,
            "$connections.spill_contractors.address_id$":
              user.contractor_address_id,
          };
          where = {
            ...where,
            "$connections.spill_contractors.contractor.id$": user.contractor_id,
            $or: [
              {
                "$connections.spill_contractors.is_inactive$": false,
              },
              {
                "$connections.spill_contractors.is_inactive$": null,
              },
              { "$connections.spill_contractors.activity_performed$": true },
            ],
          };
        }

        spills = await models.Spills.findAll({
          include: [
            {
              model: models.Connections,
              required: false,
              as: "connections",
              include: [
                {
                  model: models.SpillContractors,
                  required: false,
                  as: "spill_contractors",
                  where: {
                    contractor_id: user.contractor_id,
                    address_id: user.contractor_address_id,
                  },
                  include: [
                    {
                      model: models.Contractors,
                      as: "contractor",
                      required: false,
                      where: { id: user.contractor_id },
                    },
                  ],
                },
              ],
            },
          ],
          where,
          paranoid: false,
          distinct: true,
        });

        break;
      }
      case ROLES.CONTRACTOR_ADMIN: {
        let user = await models.User.findOne({
          where: { id },
        });

        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = {
            ...where,
            "$connections.spill_contractors.contractor.id$": user.contractor_id,
            $or: [
              {
                "$connections.spill_contractors.is_inactive$": false,
              },
              {
                "$connections.spill_contractors.is_inactive$": null,
              },
              { "$connections.spill_contractors.activity_performed$": true },
            ],
          };
        }

        spills = await models.Spills.findAll({
          include: [
            {
              model: models.Connections,
              required: false,
              as: "connections",
              include: [
                {
                  model: models.SpillContractors,
                  required: false,
                  as: "spill_contractors",
                  where: { contractor_id: user.contractor_id },
                  include: [
                    {
                      model: models.Contractors,
                      as: "contractor",
                      required: false,
                      where: { id: user.contractor_id },
                    },
                  ],
                },
              ],
            },
          ],
          where,
          paranoid: false,
          distinct: true,
        });
        break;
      }
      case ROLES.CORPORATE_USER: {
        let user = await models.User.findOne({
          where: { id },
        });

        if (role === ROLES.DEMO) {
          where = { ...where, is_demo: true };
        } else {
          where = { ...where, is_demo: false };
          where = { ...where, org_id: user.org_id };
        }

        spills = await models.Spills.findAll({
          where,
          paranoid: false,
          distinct: true,
        });

        break;
      }
      default:
        if (spillPermission) {
          let user = await models.User.findOne({
            where: { id },
          });

          let associatedOrgs = await models.AssociatedOrganizations.findAll({
            where: {
              org_id: user?.org_id,
            },
          });

          let associated_orgs = [user.org_id];

          associatedOrgs.map((associatedOrgs) => {
            associated_orgs.push(associatedOrgs.associated_org_id);
          });

          if (role === ROLES.DEMO) {
            where = { ...where, is_demo: true };
          } else {
            where = { ...where, is_demo: false };
            where = { ...where, org_id: { $in: associated_orgs } };
          }

          spills = await models.Spills.findAll({
            where,
            paranoid: false,
          });
        } else {
          if (role === ROLES.DEMO) {
            where = { ...where, is_demo: true };
          } else {
            where = { ...where, is_demo: false };
          }

          spills = await models.Spills.findAll({
            where,
            paranoid: false,
          });
        }
    }

    spills = filterSpills(role, spills);

    const statusTotals = getStatusCounts(spills);

    res.status(200).json({
      data: statusTotals,
    });
  } catch (err) {
    console.log(err);
  }
};

const removeDuplicatesBy = (arr, key) => {
  try {
    return [...new Map(arr.map((item) => [item[key], item])).values()];
  } catch (error) {
    console.error(error, "Error removing duplicate");
  }
};

// (update-attachment-expiry)
// Do not use will be executed on staging / production for updating contrator attachment expiry (do not use)
// export const updateContractorAttachmentTypes = async (req, res) => {
//   try {
//     const finalData = [];

//     const query1 = `
// SELECT * FROM users WHERE role_id IN (9,10)`;

//     const result1 = await sequelize.query(query1);

//     for (const r1 of result1[0]) {
//       for (let i = 1; i <= 5; i++) {
//         finalData.push({
//           user_id: r1.id,

//           contractor_id: r1.contractor_id,

//           contractor_address_id: r1.contractor_address_id,

//           attachment_id: i,
//         });
//       }
//     }

//     await models.ContractorAttachmentsExpiry.bulkCreate(finalData);

//     return res.status(200);
//   } catch (error) {
//   }
// };

export const getSpillAdminAttachmentTypes = async (req, res) => {
  try {
    let fetchAttachmentTypes = `SELECT * FROM contractor_attachment_types`;

    const fetchedAttachmentTypes = await sequelize.query(fetchAttachmentTypes);
    res.status(200).json({
      data: [...fetchedAttachmentTypes[0]],
    });
  } catch (err) {
    console.log("Error::", err);
  }
};

export const initializeUpload = async (req, res, next) => {
  try {
    const { name, parts } = req.body;

    const { fileKey, fileId } = await initiateMultiPartUpload(name);

    let signedUrls = await getSignedUrl(fileKey, fileId, parts);
    // signedUrls = signedUrls.map(({ signedUrl }) => signedUrl);

    return res.status(200).json({
      signedUrls,
      fileKey,
      fileId,
    });
  } catch (e) {
    res.sendStatus(500);
  }
};
export const completeUpload = async (req, res, next) => {
  try {
    const { fileKey, fileId, parts } = req.body;

    const url = await finalizeMultiPartUpload(fileKey, fileId, parts);

    return res.send({ url });
  } catch (e) {
    console.log(e);
    res.sendStatus(500);
  }
};
export const CreateAttachmentV2 = async (req, res, next) => {
  try {
    const { note_id } = req.params;
    const { name, url, fieldKey, size } = req.body;
    const attachmentData = {
      name,
      url_link: url,
      key: fieldKey,
      spill_note_id: note_id,
      size,
      status: "uploaded",
    };
    await models.NoteAttachments.bulkCreate([attachmentData]);
    return res.sendStatus(201);
  } catch (e) {
    console.log(e);
    res.sendStatus(500);
  }
};
export const getScript = async (req, res, next) => {
  try {
    const all_users = ` Select id from users`;

    const result1 = await sequelize.query(all_users);

    for (const item of result1[0]) {
      const packet_review_query = `
      UPDATE users AS u
      SET
          u.packet_reviewer_count = (SELECT
                  COUNT(s.id)
              FROM
                  spills AS s
              WHERE
                  s.user_id = ${item.id})
      WHERE
          u.id = ${item.id};
          `;
      const result2 = await sequelize.query(packet_review_query);
    }
    return res.sendStatus(200);
  } catch (e) {
    console.log(e);
    res.sendStatus(500);
  }
};