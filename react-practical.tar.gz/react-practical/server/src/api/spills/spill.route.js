import * as spillController from "./spill.controller";

export default (route) => {
  route.get("/spill/spills", spillController.getSpills);
  route.post("/spill/createNew", spillController.createNewSpill);
  route.post("/spill/editSpill", spillController.editSpill);
  route.get("/spill/completeSpill", spillController.getCompleteSpill);
  route.post("/spill/search", spillController.searchSpills);
  route.post(
    "/spill/getDocumentationInReviewSpills",
    spillController.getDocumentationInReviewSpills
  );
  route.post(
    "/spill/assign-packet-reviewer",
    spillController.assignPacketReviewer
  );
  route.post("/spill/editSpillNotes", spillController.editNote);
  route.get("/spill/noteHistory", spillController.getNoteHistory);
  route.get("/spill/paginatedNotes", spillController.getPaginatedNotes);
  route.get(
    "/spill/totalPrintableNotes",
    spillController.getTotalNotesForPrintSpill
  );
  route.post("/spill/clearSpillData", spillController.clearSpillData);
  route.get("/spill/contractorHistory", spillController.getContractorHistory);
  route.get("/spill/mySpills", spillController.getMySpills);
  route.post("/spill/createSingleNote", spillController.createSingleNote);
  route.post("/spill/createSpillReserves", spillController.createSpillReserves);
  route.post("/spill/editSpillReserves", spillController.editSpillReserves);
  route.patch("/spill/closeSpill/:id", spillController.closeSpill);
  route.patch(
    "/spill/spillAttachments/:id",
    spillController.addSpillAttachments
  );
  route.get(
    "/spill/associatedServices",
    spillController.getClientAssociatedServices
  );
  route.get(
    "/spill/getAdminAttachmentHistory",
    spillController.getAdminAttachmentHistory
  );
  route.post("/spill/materials", spillController.getSpillMaterials);
  route.get("/spill/statuses", spillController.getSpillStatuses);
  route.get("/spill/count", spillController.countSpillInMonth);
  route.get("/spill/submitted", spillController.getSpillsWithClosure);
  route.get("/spill/summary", spillController.getSpillsSummary);
  route.post("/spill/updateStatus", spillController.updateStatus);
  route.post("/spill/statusHistory", spillController.getSpillStatusHistory);
  route.post(
    "/spill/updateSpillForAddingArrivedOnService",
    spillController.updateSpillForAddingArrivedOnService
  );

  // Attachment upload
  route.post(
    "/spill/notes/attachments/init_upload",
    spillController.initializeUpload
  );
  route.post(
    "/spill/notes/attachments/completed_upload",
    spillController.completeUpload
  );
  route.post(
    "/spill/notes/:note_id/attachment",
    spillController.CreateAttachmentV2
  );
  // (update-attachment-expiry)
  // route.post(
  //   '/spill/updateContractorAttachmentTypes',
  //   spillController.updateContractorAttachmentTypes
  // );
  route.get(
    "/spill/getSpillAdminAttachmentTypes",
    spillController.getSpillAdminAttachmentTypes
  );
  route.get("/spill/getScript", spillController.getScript);
  route.get(
    "/spill/packetAssignmentHistory",
    spillController.getSpillPacketAssignmentHistory
  );
  route.post(
    "/spill/request-documentation",
    spillController.requestDocumentation
  );
  route.get(
    "/spill/get_spill_admin_requested_documentation",
    spillController.getSpillAdminRequestDocumentation
  );
};
