import * as connectionController from "./client-organizations.controller";

export default (route) => {
  route.get("/connection", connectionController.getConnection);
  route.post("/connection/createNew", connectionController.createNewConnection);
  route.post("/connection/editConnection", connectionController.editConnection);
};
