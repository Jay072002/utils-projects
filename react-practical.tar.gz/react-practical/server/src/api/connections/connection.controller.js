import models from "../../models";

export const createNewConnection = async (req, res, next) => {
  try {
    const {
      spillId,
      agencyNational,
      nationalIncidentNo,
      agencyId,
      stateIncidentNo,
    } = req.body;

    const connectionObj = {
      spill_id: spillId,
      agency_national: agencyNational,
      national_incident_no: nationalIncidentNo,
      agency_id: agencyId,
      state_incident_no: stateIncidentNo,
    };

    let { contractors } = req.body;

    const connection = await models.Connection.create(connectionObj);

    const finalContractors = contractors.map((contractor) => {
      contractor = { ...contractor, connection_id: connection.dataValues.id };
      return contractor;
    });

    const spillContractors = await models.Spill_contractors.bulkCreate(
      finalContractors
    );

    const contractordetail = await models.Contractor.findAll({
      where: {
        id: contractors,
      },
      paranoid: false,
    });

    const fullConnection = {
      ...connection,
      spillContractors: spillContractors,
    };

    res.status(200).json({
      data: fullConnection,
    });
  } catch (err) {
    console.log(err);
    let message;
    switch (err.message) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};
export const getAllOrganizations = async (req, res) => {
  const { id } = req.query;

  try {
    const organizations = await models.Connection.findById(id);

    const contractors = await models.res.status(200).json({
      data: organizations,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getAllOrganizationNames = async (req, res) => {
  try {
    let organizations = await models.ClientOrganizations.findAll({
      paranoid: false,
    });

    organizations = organizations.map((org) => {
      return { id: org.id, name: org.name };
    });

    res.status(200).json({
      organizations,
    });
  } catch (err) {
    console.log(err);
  }
};

export const editOrganization = (req, res, next) => {
  const {
    id,
    name,
    salesPerson,
    taxId,
    address,
    city,
    state,
    zipCode,
    country,
    phone,
    rate,
    active,
  } = req.body;

  models.ClientOrganizations.update(
    {
      name,
      salesPerson,
      taxId,
      address,
      city,
      state,
      zipCode,
      country,
      phone,
      rate,
      active,
    },
    {
      where: {
        id,
      },
    }
  )
    .then((response) => {
      res.json({ success: true, data: req.body });
    })
    .catch((err) => next(err));
};
