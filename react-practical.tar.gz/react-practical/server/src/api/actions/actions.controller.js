import models from "../../models";
import { newAction, executeAction } from "../../util/actions";
import { ACTIONS, ROLES } from "../../util/constants";
import { genericSender } from "../../services/email/emailProvider";
import { generateHtml } from "../../util/helper";
import { isPESUser } from "../../util";

const { URL_FOR_EMAIL } = process.env;

export const getActions = async (req, res) => {
  const { user } = req;
  let where = { status: { $not: "Accepted" } };
  if (user.role.role === ROLES.PROB_PM) {
    where = { ...where, user_id: user.id };
  } else if ([ROLES.PES_ADMIN, ROLES.PES_USER].includes(user.role.role)) {
    where = { ...where, manager_id: user.id };
  } else {
    if (user.role.role !== ROLES.SUPER_USER) {
      res.json({
        data: [],
      });
      return;
    }
  }

  const result = await models.PmActions.findAll({
    where,
    include: [
      {
        model: models.User,
        as: "manager",
      },
      {
        model: models.User,
        as: "user",
      },
    ],
    order: [["updated_at", "DESC"]],
  });

  res.json({
    data: result,
  });
};

export const createAction = async (req, res) => {
  const { user } = req;
  if (!user.role.role === ROLES.PROB_PM) {
    res.status(403).send();
    return;
  }
  const { type, managerId, data, status = "Pending" } = req.body;

  try {
    const resData = await newAction({
      type,
      data,
      status,
      manager_id: managerId,
      user_id: user.id,
    });

    res.json({
      data: resData,
    });
  } catch (err) {
    console.log(err);
    res.status(500).send();
  }
};

export const editAction = async (req, res) => {
  const { user } = req;
  const { id: actionId } = req.params;
  const { status, notes, data } = req.body;

  if (!isPESUser(user.role.role)) {
    res.status(403).send();
    return;
  }
  try {
    const action = await models.PmActions.findOne({
      where: { id: actionId },
      include: [
        {
          model: models.User,
          as: "user",
        },
      ],
    });
    if (status === "Accepted") {
      if (action.dataValues.status !== "Accepted") {
        await executeAction(action);
      }
    }

    if (status === "Rejected") {
      if (action.dataValues.status !== "Rejected") {
        const dataForEmail = {
          sendEmailTo: action.user.email,
          sendEmailFrom: user.email,
          ...generateHtml(
            {
              notes,
              origin: URL_FOR_EMAIL,
              jobNo: action?.dataValues?.data?.jobNo,
            },
            action.dataValues.data.type === ACTIONS.CREATE_SPILL
              ? ACTIONS.CREATE_SPILL_REJECTED
              : ACTIONS.EDIT_SPILL_REJECTED
          ),
        };
        genericSender(dataForEmail);
      }
    }

    await models.PmActions.update(
      { status, notes, data },
      {
        where: { id: actionId },
      }
    );

    res.json({
      data: { ...action.dataValues, status, notes, data },
    });
  } catch (err) {
    res.status(500).send();
    console.log(err);
  }
};
