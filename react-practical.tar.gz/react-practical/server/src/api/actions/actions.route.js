import * as actionsController from "./actions.controller";

export default (route) => {
  route.get("/actions/actions", actionsController.getActions);
  route.post("/actions/action", actionsController.createAction);
  route.patch("/actions/action/:id", actionsController.editAction)
};
