/** @format */

import { Op } from "sequelize";
import * as clientOrganizationService from "./client-organization.service";
import models, { sequelize } from "../../models";
import pagination from "../../util/pagination";
import { ACTIONS, ROLES } from "../../util/constants";

export const createNewOrganization = async (req, res, next) => {
  let transaction;
  try {
    const files = req.files;
    const { user } = req;
    const {
      name,
      salesPerson,
      taxId,
      code,
      address,
      city,
      state,
      zipCode,
      country,
      phone,
      rate,
      active,
      serviceId,
      rateType,
      associatedClients,
      associatedServices,
      paymentTerms,
      timestampVisibility,
      monetaryVisibility,
      defaultParentUsers,
      hazardous_waste,
      non_hazardous_waste,
      revision_date,
      reporting,
      reporting_instruction,
      report_5800,
      instruction_5800,
      miscellaneous,
      facilities,
      contractors,
    } = req.body;

    const organizationObj = {
      name,
      sales_person_id: salesPerson,
      taxId,
      code,
      address,
      city,
      state,
      zipCode,
      country,
      phone,
      rate,
      active,
      payment_terms: paymentTerms || null,
      service_id: serviceId,
      rate_type: rateType,
      timestamp_visibility: timestampVisibility,
      monetary_visibility: monetaryVisibility,
      is_default_parent_users: defaultParentUsers,
      hazardous_waste: hazardous_waste || null,
      non_hazardous_waste: non_hazardous_waste || null,
      revision_date: revision_date || null,
      reporting: reporting || null,
      reporting_instruction: reporting_instruction || null,
      report_5800: report_5800 || null,
      instruction_5800: instruction_5800 || null,
      miscellaneous: miscellaneous || null,
    };

    if (await findClientsByName(organizationObj.name, -1)) {
      res.status(400).json({
        status: 400,
        message: "Client with this name already exists.",
      });
      return;
    }

    transaction = await sequelize.transaction();
    const organization = await models.ClientOrganizations.create(
      organizationObj,
      { transaction }
    );
    const associatedClientsData = associatedClients?.map((org) => {
      return {
        org_id: organization.dataValues.id,
        associated_org_id: org.value,
      };
    });
    const associatedServicesData = associatedServices?.map((service) => {
      return {
        org_id: organization.dataValues.id,
        service_id: service.value,
        type: service.type,
        rate: service.rate === "" ? 0 : service.rate,
      };
    });
    if (user?.role?.role === ROLES.SUPER_USER) {
      let facilitiesData = facilities?.map((facility) => {
        if (facility?.name) {
          return {
            org_id: organization.dataValues.id,
            name: facility?.name,
            internal_id: facility?.internal_id,
            generator_status: facility?.generator_status,
            epa_id: facility?.epa_id,
            address: facility?.address,
            city: facility?.city,
            state: facility?.state,
            country: facility?.country,
            zip_code: facility?.zip_code,
            phone_number: facility?.phone_number,
            region: facility?.region,
            is_active: facility.is_active,
          };
        }
      });
      facilitiesData = [...facilitiesData].filter(item => item);
      let contractorData = contractors?.map((contractor) => {
        if (contractor) {
          return {
            org_id: organization.dataValues.id,
            contractor_id: contractor?.contractor_id,
            address_id: contractor?.address_id || null,
          };
        }
      });
      contractorData = [...contractorData].filter(item => item);
      if (organization.dataValues.id && revision_date) {
        const wasteHanding = {
          hazardous_waste: hazardous_waste,
          non_hazardous_waste: hazardous_waste,
        };
        if (!Object.values(wasteHanding).every((v) => v === null)) {
          await models.ClientOrganizationWasteHandlings.create(
            {
              org_id: organization.dataValues.id,
              ...wasteHanding,
              revision_date,
            },
            { transaction }
          );
        }
      }
      if (facilitiesData?.length) {
        await models.ClientOrganizationFacilities.bulkCreate(facilitiesData, {
          individualHooks: true,
          transaction,
        });
      }
      if (contractorData?.length) {
        await models.ClientOrganizationContractors.bulkCreate(contractorData, {
          individualHooks: true,
          transaction,
        });
      }
    }

    try {
      const recipients = await models.AssociatedOrganizations.bulkCreate(
        associatedClientsData
      );
      const clientServices = await models.ClientOrganizationServices.bulkCreate(
        associatedServicesData ?? []
      );
    } catch (e) {
      console.log(e);
    }

    await transaction.commit();

    const organizationNew = await models.ClientOrganizations.findOne({
      include: [
        {
          model: models.AssociatedOrganizations,
          required: false,
        },
        {
          model: models.ClientOrganizationServices,
          required: false,
        },
      ],
      where: { id: organization.dataValues.id },
    });
    res.status(200).json({
      data: { ...organizationNew.toJSON() },
    });
  } catch (err) {
    console.log(err);
    if (transaction) {
      await transaction.rollback();
    }
    let message;
    switch (err.message) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;
      default:
        message = null;
    }
    res.status(400).json({
      status: 400,
      err,
    });
  }
};

export const getAllOrganizations = async (req, res) => {
  const { page } = req.query;
  const { role } = req.user;

  const { limit, offset, current } = pagination(page);

  let where = {};

  if (role.role === ROLES.DEMO) {
    where = { ...where, is_demo: true };
  } else {
    where = { ...where, [Op.or]: [{ is_demo: null }, { is_demo: false }] };
  }

  try {
    const organizationCount = await models.ClientOrganizations.count({ where });
    let organizations = await models.ClientOrganizations.findAll({
      include: [
        {
          model: models.AssociatedOrganizations,
          required: false,
        },
        {
          model: models.ClientOrganizationServices,
          required: false,
        },
      ],
      where,
      limit,
      offset,
      paranoid: false,
      order: [["created_at", "DESC"]],
    });

    const total = Math.ceil(organizationCount / limit) || 0;

    res.status(200).json({
      data: organizations,
      pagination: {
        page,
        totalPages: total,
        count: organizationCount,
        currentPage: current > total ? total : current,
      },
    });
  } catch (err) {
    console.log(err);
  }
};

export const getAllOrganizationNames = async (req, res) => {
  const { role } = req.user;

  let where = {};

  if (role.role === ROLES.DEMO) {
    where = { ...where, is_demo: true };
  }

  try {
    let organizations = {};

    organizations = await models.ClientOrganizations.findAll({
      where,
      // paranoid: false,
      include: [
        {
          model: models.AssociatedOrganizations,
          required: false,
          include: [
            {
              model: models.ClientOrganizations,
              required: false,
            },
          ],
        },
      ],
    });

    organizations = organizations.map((org) => {
      return {
        id: org.id,
        name: org.name,
        code: org.code,
        active: org.active,
        AssociatedOrganizations: org.associated_organizations,
      };
    });

    res.status(200).json({
      organizations,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getClientParents = async (req, res) => {
  const { id } = req.query;
  try {
    let parents = await models.AssociatedOrganizations.findAll({
      paranoid: false,
      attributes: ["org_id"],
      where: {
        associated_org_id: id,
        deleted_at: null,
      },
    });
    res.status(200).json({
      parents,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getClientChildren = async (req, res) => {
  const { id } = req.query;
  try {
    let associatedOrganizations = await models.AssociatedOrganizations.findAll({
      paranoid: false,
      where: {
        org_id: id,
        deleted_at: null,
      },
    });

    let orgIds = [id];

    associatedOrganizations.forEach((associatedOrganization) => {
      orgIds.push(associatedOrganization.associated_org_id);
    });

    let organizations = {};

    organizations = await models.ClientOrganizations.findAll({
      where: {
        id: { $in: orgIds },
      },
      paranoid: false,
    });

    organizations = organizations.map((org) => {
      return { id: org.id, name: org.name };
    });

    res.status(200).json({
      organizations,
    });
  } catch (err) {
    console.log(err);
  }
};

export const editOrganization = async (req, res, next) => {
  let transaction;
  try {
    const files = req.files;
    const { user } = req;
    const {
      id,
      name,
      address,
      salesPerson,
      taxId,
      code,
      city,
      state,
      zipCode,
      country,
      phone,
      rate,
      active,
      serviceId,
      rateType,
      paymentTerms,
      canSeeTimestamp,
      associatedClients,
      associatedServices,
      timestampVisibility,
      monetaryVisibility,
      defaultParentUsers,
      hazardous_waste,
      non_hazardous_waste,
      revision_date,
      reporting,
      reporting_instruction,
      report_5800,
      instruction_5800,
      miscellaneous,
      facilities,
      contractors,
      uncheckedContractors,
    } = req.body;

    if (await findClientsByName(name, id)) {
      res.status(400).json({
        status: 400,
        message: "Client with this name already exists.",
      });
      return;
    }

    transaction = await sequelize.transaction();
    if (!associatedClients) {
      await models.AssociatedOrganizations.destroy({
        where: { org_id: id },
        transaction,
        truncate: true,
      });
    } else {
      const associatedClientsData = associatedClients.map((org) => {
        if (org.id) {
          return {
            id: org.id,
            org_id: id,
            associated_org_id: org.value,
          };
        } else {
          return {
            org_id: id,
            associated_org_id: org.value,
          };
        }
      });
      if (user?.role?.role === ROLES.SUPER_USER) {
        let facilitiesData = facilities?.map((facility) => {
          if (facility?.name) {
            return {
              org_id: id,
              name: facility?.name,
              internal_id: facility?.internal_id,
              generator_status: facility?.generator_status,
              epa_id: facility?.epa_id,
              address: facility?.address,
              city: facility?.city,
              state: facility?.state,
              country: facility?.country,
              zip_code: facility?.zip_code,
              phone_number: facility?.phone_number,
              region: facility?.region,
              is_active: facility.is_active,
            };
          }
        });
        facilitiesData = [...facilitiesData].filter(item => item);
        const contractorData = [];
        for (let index = 0; index < contractors.length; index++) {
          const element = contractors[index];
          if (element?.contractor_id) {
            contractorData.push({
              org_id: id,
              contractor_id: element?.contractor_id,
              address_id: element?.address_id || null,
            });
          }
        }
        if (facilitiesData?.length) {
          const existingRecords = await models.ClientOrganizationFacilities.findAll(
            {
              where: {
                org_id: id,
                [Op.or]: facilitiesData.map((data) => ({
                  name: data.name,
                })),
              },
            }
          );
          const facilitiesToCreate = facilitiesData.filter((data) => {
            return !existingRecords.some(
              (existingFacility) => existingFacility.name === data.name
            );
          });
          await models.ClientOrganizationFacilities.bulkCreate(
            facilitiesToCreate,
            { individualHooks: true, transaction }
          );
        }
        if (uncheckedContractors?.length) {
          for (let index = 0; index < uncheckedContractors.length; index++) {
            const element = uncheckedContractors[index];
            if (element) {
              await models.ClientOrganizationContractors.destroy({
                where: {
                  org_id: id,
                  contractor_id: element?.contractor_id,
                  address_id: element?.address_id || null,
                },
                truncate: true,
                transaction,
              });
            }
          }
        }
        if (contractorData?.length) {
          await models.ClientOrganizationContractors.destroy({
            where: { org_id: id },
            truncate: true,
            individualHooks: true,
            transaction,
          });
          await models.ClientOrganizationContractors.bulkCreate(
            contractorData,
            { individualHooks: true, transaction }
          );
        }
      }
      let idsForOrganizationDeletion = [];
      await associatedClients.map((org) => {
        if (org.id) idsForOrganizationDeletion.push(org.id);
      });
      try {
        await models.AssociatedOrganizations.destroy({
          where: { id: { $notIn: idsForOrganizationDeletion }, org_id: id },
          truncate: true,
        });
        await models.AssociatedOrganizations.bulkCreate(associatedClientsData, {
          updateOnDuplicate: ["org_id", "associated_org_id"],
          returning: true,
        });
      } catch (error) {
        console.log(error);
      }
    }
    if (!associatedServices) {
      await models.ClientOrganizationServices.destroy({
        where: { org_id: id },
        transaction,
        truncate: true,
      });
    } else {
      const associatedServicesData = associatedServices.map((service) => {
        if (service.id) {
          return {
            id: service.id,
            org_id: id,
            service_id: service.value,
            type: service.type,
            rate: service.rate,
          };
        } else {
          return {
            org_id: id,
            service_id: service.value,
            type: service.type,
            rate: service.rate,
          };
        }
      });
      let idsForServiceDeletion = [];
      await associatedServices.map((service) => {
        if (service.id) idsForServiceDeletion.push(service.id);
      });
      try {
        await models.ClientOrganizationServices.destroy({
          where: { id: { $notIn: idsForServiceDeletion }, org_id: id },
          truncate: true,
        });
        await models.ClientOrganizationServices.bulkCreate(
          associatedServicesData,
          {
            updateOnDuplicate: ["org_id", "service_id", "type", "rate"],
            returning: true,
          }
        );
      } catch (error) {
        console.log(error);
      }
    }

    await models.ClientOrganizations.update(
      {
        name,
        sales_person_id: salesPerson,
        taxId,
        code,
        address,
        city,
        state,
        zipCode,
        country,
        phone,
        rate,
        active,
        payment_terms: paymentTerms || null,
        service_id: serviceId,
        rate_type: rateType,
        timestamp_visibility: timestampVisibility,
        monetary_visibility: monetaryVisibility,
        is_default_parent_users: defaultParentUsers,
        hazardous_waste: hazardous_waste || null,
        non_hazardous_waste: non_hazardous_waste || null,
        revision_date: revision_date || null,
        reporting: reporting || null,
        reporting_instruction: reporting_instruction || null,
        report_5800: report_5800 || null,
        instruction_5800: instruction_5800 || null,
        miscellaneous: miscellaneous || null,
      },
      {
        where: {
          id,
        },
        transaction,
      }
    );
    await transaction.commit();

    const updatedOrg = await models.ClientOrganizations.findOne({
      include: [
        {
          model: models.AssociatedOrganizations,
          required: false,
        },
        {
          model: models.ClientOrganizationServices,
          required: false,
          include: [
            {
              model: models.Services,
              required: false,
            },
          ],
        },
      ],
      where: { id },
    });

    //Update Users when orgranization is set to inactive
    await clientOrganizationService.updateClientUsers(id, active);

    res.json({ success: true, data: { ...updatedOrg.toJSON() } });
  } catch (error) {
    console.log(error);
    if (transaction) {
      await transaction.rollback();
    }
    throw error;
  }
};

export const getClientOrganization = async (req, res) => {
  if (!req.params || !req.params.id) {
    res.status(400).send({});
  }
  const { user } = req;
  const orgId = req.params.id;
  try {
    const include = [
      {
        model: models.AssociatedOrganizations,
        required: false,
      },
      {
        model: models.ClientOrganizationServices,
        required: false,
        include: [
          {
            model: models.Services,
            required: false,
          },
        ],
      },
    ];
    if (user?.role?.role === ROLES.SUPER_USER) {
      include.push(
        {
          model: models.ClientOrganizationFacilities,
          required: false,
        },
        {
          model: models.ClientOrganizationContractors,
          required: false,
        }
      );
    }
    const [clientOrganization] = await Promise.all([
      models.ClientOrganizations.findOne({
        where: {
          id: orgId,
        },
        include,
      }),
    ]);
    const data = { ...clientOrganization?.toJSON() };
    return res.status(200).json(data);
  } catch (e) {
    console.log(e);
    res.status(500).send();
  }
};

const findClientsByName = async (name, id) => {
  const duplicate = await models.ClientOrganizations.findOne({
    where: { name: name, id: { [Op.ne]: id } },
  });

  return duplicate;
};

const findFacilitiesByName = async (org_id, id, name) => {
  const query = `select count(*) as count from client_organization_facilities WHERE name = '${name}' AND org_id = ${org_id} AND id != '${id}'`;
  const duplicate = await sequelize.query(query);
  return duplicate[0][0].count;
};

export const updateFacility = async (req, res) => {
  try {
    const {
      id,
      org_id,
      name,
      internal_id,
      generator_status,
      epa_id,
      address,
      city,
      state,
      country,
      zip_code,
      phone_number,
      region,
      is_active,
    } = req.body;

    if (!org_id) {
      return res.status(400).json({
        status: 400,
        message: "Client organization is not exists.",
      });
    }
    if (!id) {
      return res.status(400).json({
        status: 400,
        message: "Facility is not exist.",
      });
    }
    if (await findFacilitiesByName(org_id, id, name)) {
      return res.status(400).json({
        status: 400,
        message: "Facility with this name already exists.",
      });
    }

    await models.ClientOrganizationFacilities.update(
      {
        name,
        internal_id,
        generator_status,
        epa_id,
        address,
        city,
        state,
        country,
        zip_code,
        phone_number,
        region,
        is_active,
      },
      {
        where: {
          id,
          org_id,
        },
      }
    );
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ status: 400, error });
  }
};

export const getClientFacilities = async (req, res, next) => {
  try {
    const orgId = req.params.id;
    const getFacilities = await models.ClientOrganizationFacilities.findAll({
      where: {
        org_id: orgId,
        is_active: true,
      },
    });
    return res.json({ success: true, data: getFacilities });
  } catch (error) {
    res.status(400).send({});
  }
};

export const getClientContractor = async (req, res, next) => {
  try {
    const orgId = req.params.id;
    const data = await models.ClientOrganizationContractors.findAll({
      attributes: ["id", "contractor_id", "address_id"],
      where: {
        org_id: orgId,
      },
    });
    return res.json({ success: true, data });
  } catch (error) {
    res.status(400).send({});
  }
};

export const deleteFacility = async (req, res, next) => {
  try {
    if (!req.body?.id && !req.body?.org_id) {
      return res.status(400).json({
        status: 400,
        message: "Facility id is not exist.",
      });
    }
    const spillCount = await models.Spills.count({
      where: {
        facility_id: req.body?.id,
        org_id: req.body?.org_id,
      },
    });
    if (spillCount) {
      return res.status(400).json({
        status: 400,
        message:
          "The facility cannot be deleted as it is already being used for a spill.",
      });
    }
    const data = await models.ClientOrganizationFacilities.destroy({
      where: {
        id: req.body?.id,
        org_id: req.body?.org_id,
      },
      truncate: true,
    });
    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    res.status(400).send({});
  }
};
