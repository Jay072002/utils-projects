/** @format */

import models, { sequelize } from "../../models/";
import { Op } from "sequelize";
import fs from "fs";
import { uploadFileToS3Bucket } from '../../util';

export const updateClientUsers = async (clientId, active) => {
  try {
    const isActive = active?.toString()?.toLowerCase() === 'true' ? 1 : 0;

    const query = `UPDATE client_organizations co
                  join users u on co.id = u.org_id
                  join roles r on u.role_id = r.id
                  SET u.active = ${isActive},u.updated_at = CURRENT_TIMESTAMP()
                  WHERE co.id = ${clientId}
                  and r.role Like 'corporate%';`;

    const [, result] = await sequelize.query(query);

    return result;
  } catch (error) {
    throw error;
  }
};

export const updateAndStoreWasteHandlings = async (reqBody, transaction) => {
  try {
    const {
      id,
      hazardous_waste,
      non_hazardous_waste,
      revision_date,
    } = reqBody;
    const returnObj = {
      hazardous_waste: hazardous_waste,
      non_hazardous_waste: non_hazardous_waste,
    }
    if (!Object.values(returnObj).every((v) => v === null)) {
      const where = {
        where: { 
          org_id: id,
          revision_date: {
            [Op.eq]: revision_date ? revision_date : null
          }
        },
        transaction
      }
      const result = await models.ClientOrganizationWasteHandlings.count(where);
      if (result > 0) {
        await models.ClientOrganizationWasteHandlings.destroy(where);
      }
      await models.ClientOrganizationWasteHandlings.create(
        { 
          org_id: id,
          ...returnObj,
          revision_date
        },
        { transaction }
      );
    }
  } catch (error) {
    console.log(error);
  }
};

export const uploadFacility = async (files, user, org_id, transaction) => {
  try {
    const { id } = user;
    const attachments = [];
    const attachmentsToBeRemovedPathList = [];
    if (files?.length && org_id) {
      for (let file of files) {
        const fileName = file.originalname?.split("#")[1];
        const data = await uploadFileToS3Bucket(
          file.path,
          `client/${org_id}/facility/${id}/${fileName}`
        );
        const facility = {
          org_id: org_id,
          user_id: id,
          file_name: fileName,
          key: data.key,
          url_link: data.Location,
          status: 'not_processed'
        }
        const where = {
          org_id,
          file_name: fileName
        }
        const existRecord = await models.RequestFacilities.findAndCountAll({ where });
        if(existRecord.count) {
          await models.RequestFacilities.update(facility, { where });
        } else {
          attachments.push(facility)
        }
        attachmentsToBeRemovedPathList.push(file?.path);
      }
      for (let attachmentPath of attachmentsToBeRemovedPathList) {
        fs.unlinkSync(attachmentPath);
      }
      attachments.length && await models.RequestFacilities.bulkCreate(attachments, { individualHooks: true, transaction});
    }
  } catch (error) {
    console.log("upload Facility", error);
  }
};