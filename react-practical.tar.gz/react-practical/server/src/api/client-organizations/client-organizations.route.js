import * as clientOrganizationController from "./client-organizations.controller";

export default (route) => {
  route.get(
    "/client/allOrganizationNames",
    clientOrganizationController.getAllOrganizationNames
  );
  route.get(
    "/client/organizations",
    clientOrganizationController.getAllOrganizations
  );
  route.post(
    "/client/createNew",
    clientOrganizationController.createNewOrganization
  );
  route.post(
    "/client/editClientOrganizations",
    clientOrganizationController.editOrganization
  );
  route.get("/client/parents", clientOrganizationController.getClientParents);
  route.get("/client/children", clientOrganizationController.getClientChildren);
  route.get("/client/:id", clientOrganizationController.getClientOrganization);
  route.patch(
    "/client/update-facility",
    clientOrganizationController.updateFacility
  );
  route.get(
    "/client/facilities/:id",
    clientOrganizationController.getClientFacilities
  );
  route.get(
    "/client/contractor/:id",
    clientOrganizationController.getClientContractor
  );
  route.delete(
    "/client/facility",
    clientOrganizationController.deleteFacility
  );
};
