import * as userController from './user.controller';

export default (route) => {
  //FIXME: Remove this mockoperation later
  route.get('/user/mockoperation', (req, res, next) =>
    res.send({ hit: 'mocks' })
  );
  route.get('/user/mockoperation/:id', (req, res, next) => next());
  route.post('/user/login', userController.login);
  route.post('/user/become_user/:id', userController.becomeUser);
  route.post('/user/become_default', userController.becomeDefaultUser);
  route.post('/user/signup', userController.signup);
  route.post('/user/logout', userController.logout);
  route.get('/user/me', userController.loginInfo);
  route.post('/user/editProfile', userController.editProfile);
  route.post('/user/editEmail', userController.editEmail);
  route.post('/user/changePassword', userController.changePassword);
  route.get('/user/all', userController.getAllUsers);
  route.post('/user/add', userController.addUser);
  route.post('/user/edit', userController.editUser);
  route.post('/user/orgId', userController.getUsersByOrgId);
  route.get('/user/admins', userController.getAdmins);
  route.get('/user/salePersons', userController.getSalePersons);
  route.get('/user/organizationAdmins', userController.getAdminsOfOrganization);
  route.get('/user/roles', userController.getUserRoles);
  route.post('/user/search', userController.searchUser);
  route.post('/user/notification', userController.setNotificationPreference);
  route.post('/user/associatedServices', userController.associatedServices);
  route.get('/user/checkInSpills', userController.checkInSpills);
  route.get('/user/getUsersForEmail', userController.getUsersForEmail);
  route.post('/user/updateEula', userController.updateEula);
  route.get('/user/fetchAttachmentTypes', userController.fetchAttachmentTypes);
  route.post(
    '/user/updateUserAttachmentExpiry',
    userController.updateUserAttachmentExpiry
  );
  route.get('/user/getPacketReviewers', userController.getPacketReviewers);
};
