import _ from "lodash";
import { Op } from "sequelize";
import moment from "moment";
import Moment from "moment";
import crypto from "crypto";

import * as authorization from "../../util/authorization";
import models, { sequelize } from "../../models";
import {
  generateRandomString,
  getChanges,
  getDataValues,
  generateHtml,
} from "../../util/helper";
import { ROLES, ACTIONS, Permissions } from "../../util/constants";
import { isCorporateUser } from "../../util/preProcessors";
import pagination from "../../util/pagination";
import { emailSender, genericSender } from "../../services/email/emailProvider";
import { forceToCSTForRawQuery } from "../../util/convertDateRange";

const { TEST_USER_EMAIL_ADDRESS } = process.env;

export const checkEmail = (req, res) => {
  const { email } = req.query;
  models.User.find({
    where: {
      email,
    },
    paranoid: false,
  })
    .then((user) =>
      res.json({
        exists: !!user,
      })
    )
    .catch((err) => res.status(400).json(err));
};

export const login = async (req, res, next) => {
  const { email, password } = req.body;
  try {
    let user = await models.User.findByEmailPassword(email, password);
    let isTestUser = false;

    if (!user || !user?.dataValues?.active) {
      res.status(403).json({
        success: false,
        message: !user
          ? "Incorrect email or password"
          : "Your account has been disabled. Please contact Administrator for further assistance",
      });
    } else if (user && user.confirmed) {
      if (user && user.created_by !== 4) {
        const clientOrg = await models.ClientOrganizations.findOne({
          include: [
            {
              model: models.ClientOrganizationServices,
              include: [
                {
                  model: models.Services,
                  required: false,
                },
              ],
            },
          ],
          where: {
            id: user?.org_id,
          },
        });

        const contractor = await models.Contractors.findOne({
          where: {
            id: user.contractor_id,
          },
        });

        const address = await models.Addresses.findOne({
          where: {
            id: user.contractor_address_id,
          },
        });

        const userRole = await models.Roles.findOne({
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
          where: {
            id: user.role_id,
          },
        });

        const userService = await models.UserServicesNotifications.findAll({
          required: false,
          where: {
            user_id: user.id,
          },
          include: [
            {
              model: models.Services,
              required: false,
            },
          ],
        });

        user.update({
          last_login: Date.now(),
        });

        user = user.toJSON();

        user.role = userRole;

        const testEmails = TEST_USER_EMAIL_ADDRESS?.split(",");

        if (testEmails?.includes(user?.email)) {
          isTestUser = true;
        }

        user.test_user = isTestUser;

        res
          .cookie("session_id", authorization.generateToken(user), {
            httpOnly: true,
          })
          .send({
            ...user,
            contractor,
            address,
            client_organization: clientOrg,
            user_services_notifications: userService,
          });
      } else {
        res.status(400).json({
          success: false,
          message: "Can not loggin because user is created by demo account",
        });
      }
    } else {
      res.status(400).json({
        success: false,
        message:
          "Your account is not active. Please contact the administration",
      });
    }
  } catch (error) {
    console.log("Error:", error);
  }
};

export const logout = async (req, res) => {
  try {
    const { id } = req?.user;

    const user = await models.User.findById(id, {
      paranoid: false,
    });

    user.update({
      last_logout: Date.now(),
    });

    res
      .status(200)
      .clearCookie("session_id")
      .json({
        message: "success",
      });
  } catch (err) {
    res.status(400).json({
      status: 400,
      err,
    });
  }
};

export const signup = async (req, res, next) => {
  try {
    const {
      full_name, // eslint-disable-line
      email,
      password,
    } = req.body;

    const userObj = {
      email,
      password,
      full_name,
      confirmed: true,
      user_type: "user",
    };
    const user = await models.User.create(userObj);
    res.json(user);
  } catch (err) {
    console.log(err);
    let message;
    switch (err.message) {
      case "Validation error":
        message = "This email is already in use";
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};

export const verifyUser = async (req, res, next) => {
  try {
    const userObject = authorization.decodeToken(req.query.token);
    const user = await models.User.findById(userObject.id, {
      paranoid: false,
    });
    if (user && String(user.confirmed).toLowerCase() !== "true") {
      await user.update({
        confirmed: true,
      });

      if (user.spyder_id) {
      }
    }

    res.redirect(`/${user ? "?confirmed" : ""}`);
  } catch (err) {
    next(err);
  }
};

export const loginInfo = async (req, res, next) => {
  const { id, role_id, eula_accepted_year } = req.user;

  const currentYear = new Date().getFullYear();
  let isTestUser = false;

  if (
    currentYear !== eula_accepted_year &&
    [5, 6, 7, 8, 9, 10].includes(role_id)
  ) {
    await models.User.update(
      {
        eula_accepted: false,
      },
      { where: { id }, returning: true }
    );

    res.clearCookie("session_id").json({
      message: "success",
    });
  }

  const testEmails = TEST_USER_EMAIL_ADDRESS?.split(",");

  if (testEmails?.includes(req?.user?.email)) {
    isTestUser = true;
  }

  req.user.dataValues.test_user = isTestUser;

  res.json(req.user);
};

const findInEmails = async (emailToFind, id) => {
  const duplicateUser = await models.User.findOne({
    where: { email: emailToFind, id: { $ne: id } },
  });

  return duplicateUser;
};

export const editEmail = async (req, res, next) => {
  const { id } = req.user;
  const { email, secondary_email } = req.body;

  if (!email) {
    return res.status(400).json({
      success: false,
      message: "Email must pe provided",
    });
  }

  if (await findInEmails(email, id))
    return res.status(400).json({
      success: false,
      message: "Email already exists",
    });

  models.User.update(
    {
      id,
      email,
      secondary_email: secondary_email || null,
    },
    {
      where: {
        id,
      },
    }
  )
    .then((response) => {
      const data = {
        id,
        email,
        secondary_email,
      };

      res.json({
        success: true,
        data,
      });
    })
    .catch((err) => next(err));
};

// export const editUserLicense = async (req, res, next) => {
//   const { id } = req.user;
//   const { haz_waste_hauler, license_number, license_number_expiry } = req.body;
//   try {
//     if (!license_number) {
//       return res.status(400).json({
//         success: false,
//         message: 'License number must pe provided',
//       });
//     }

//     await models.User.update(
//       {
//         haz_waste_hauler,
//         license_number,
//         license_number_expiry,
//       },
//       { where: { id }, returning: true }
//     );

//     const data = await models.User.findOne({
//       where: {
//         id,
//       },
//       paranoid: false,
//     });

//     res.json({
//       success: true,
//       data,
//     });
//   } catch (error) {
//     console.log('Error:', error);
//   }
// };

export const updateEula = async (req, res, next) => {
  const { id } = req.user;
  const { eula_accepted } = req.body.data;

  try {
    if (eula_accepted === undefined || eula_accepted === null) {
      return res.status(200).json({
        success: false,
        message: "EULA status must be provided",
      });
    }

    const currentYear = new Date().getFullYear();

    await models.User.update(
      {
        eula_accepted,
        eula_accepted_year: currentYear,
      },
      { where: { id }, returning: true }
    );
  } catch (err) {
    next(err);
  }
};

export const editProfile = (req, res, next) => {
  // const { id } = req.params;
  const { id, full_name, phone, is_packet_reviewer } = req.body;

  models.User.update(
    {
      id,
      full_name,
      phone,
      is_packet_reviewer,
    },
    {
      where: {
        id,
      },
    }
  )
    .then((response) => {
      const data = {
        id,
        full_name,
        phone,
        is_packet_reviewer,
      };

      res.json({
        success: true,
        data,
      });
    })
    .catch((err) => next(err));
};

export const setStatus = (req, res) => {
  const { id } = req.params;
  const { subscribed } = req.body;
  models.User.find({
    where: {
      id,
    },
    paranoid: false,
  }).then((user) => {
    models.User.update(
      {
        subscribed,
      },
      {
        where: {
          id: {
            [Op.eq]: id,
          },
        },
      }
    ).then((response) =>
      res
        .status(200)
        .json({
          success: true,
        })
        .catch((err) =>
          res.json({
            success: false,
            message: err,
          })
        )
    );
  });
};

export const getUsers = (req, res) => {
  const where = {};
  // set user not admin
  where.user_type = {
    [Op.ne]: "admin",
  };
  models.User.findAll({
    where,
    order: [["created_at", "DESC"]],
    paranoid: false,
  })
    .then((users) => {
      const response = _.map(users, (user) => {
        if (String(user.info).includes('\\"')) {
          try {
            user.info = JSON.parse(user.info);
          } catch (err) {
            console.error(err);
          }
        }

        return user;
      });

      return res.json(response);
    })
    .catch((err) => res.status(400).json(err));
};
export const getUsersForEmail = async (req, res) => {
  try {
    const { role, org_id } = req.user;
    const query = `select u.id, JSON_OBJECT(
      "id", u.id,
      "full_name", u.full_name,
      "is_packet_reviewer", u.is_packet_reviewer,
      "active", u.active
      ) as user, JSON_ARRAYAGG(r.spill_id) as spill_ids from recipients 
      r left JOIN users u on r.user_id = u.id 
      where r.user_id is not null and r.deleted_at is null ${isCorporateUser(role.dataValues.role) ? `AND org_id = ${org_id}` : ''} group by r.user_id`
    const users = await sequelize.query(query);
    return res.json({ data: users.length == 2 ? users[0] : [] });
  } catch (err) {
    res.status(400).json(err);
  }
};

export const forgotPassword = (req, res, next) => {
  const { email } = req.body;
  const { User } = models;

  User.find({
    where: {
      email,
    },
  })
    .then((user) => {
      if (user) {
        const duration = moment
          .duration(moment().diff(user.updated_at))
          .asMinutes();
        const newPassword = generateRandomString();

        if (duration >= 15) {
          User.updatePassword(user.id, newPassword);

          return res.status(200).json({
            success: true,
          });
        }

        return res.json({
          success: false,
          message: "Email already sent",
        });
      }

      return res.json({
        success: false,
        message: "Email not found",
      });
    })
    .catch((err) => next(err));
};

export const changePassword = (req, res) => {
  const { id } = req.user;
  const { oldPassword, newPassword } = req.body;
  const { User } = models;

  if (String(req.user.id) === String(id)) {
    User.verifyPassword(req.user.id, oldPassword)
      .then((user) => {
        if (user) {
          User.updatePassword(req.user.id, newPassword)
            .then(() => {
              res.json({
                success: true,
                message: "Password updated successfully!",
              });
            })
            .catch((err) =>
              res.json({
                success: false,
                message: err,
              })
            );
        } else {
          res.json({
            success: false,
            message: "Old password is not correct!",
          });
        }
      })
      .catch((err) =>
        res.json({
          success: false,
          message: err,
        })
      );
  } else if (req.user.type === "admin") {
    Promise.all([
      User.findById(id, {
        paranoid: false,
      }),
      User.updatePassword(id, newPassword),
    ])
      .then(([user]) => {
        if (user) {
          user.restore();
        }
        res.json({
          success: true,
          message: "Password updated successfully!",
        });
      })
      .catch((err) =>
        res.json({
          success: false,
          message: err,
        })
      );
  }
};

export const resetPassword = async (req, res, next) => {
  try {
    const { email } = req.body;

    if (email) {
      const user = await models.User.find({
        where: {
          email: {
            [Op.eq]: email,
          },
        },
        paranoid: false,
      });

      if (user) {
        const newPassword = generateRandomString();
        await models.User.updatePassword(user.id, newPassword);
        user.update({
          confirmed: true,
        });
        user.restore();
        res.json({
          success: true,
          message: "Password has been successfully reset",
        });
      } else {
        throw new Error("User doesn't exist");
      }
    } else {
      throw new Error("Email is not provided");
    }
  } catch (err) {
    next(err);
  }
};

export const checkInSpills = async (req, res, next) => {
  const { userId } = req.query;
  try {
    const spillsAssinged = await models.Spills.findAll({
      where: { user_id: userId, status_id: { [Op.not]: 11 } },
    });

    res.status(200).json({
      data: { spills: spillsAssinged.map((spill) => spill.dataValues) },
    });
  } catch (err) {
    console.log("Error in CheckInSpills ::", err);
  }
};
export const getAllUsers = async (req, res, next) => {
  const { page } = req.query;
  let where = {};
  const { contractor_id, role, dataValues, client_organization } = req.user;

  const { limit, offset, current } = pagination(page);
  if (dataValues.role_id === 4)
    where.is_demo = {
      [Op.eq]: true,
    };
  else
    where = {
      [Op.or]: [
        {
          is_demo: null,
        },
        {
          is_demo: false,
        },
      ],
    };

  try {
    const usersCount = await models.User.count({
      where,
    });
    if (role.dataValues.role === ROLES.CONTRACTOR_ADMIN) {
      let users = await models.User.findAndCountAll({
        where: {
          contractor_id: contractor_id,
        },
        include: [
          {
            model: models.ClientOrganizations,
            attributes: ["name"],
          },
          {
            model: models.Roles,
            required: false,
            include: [
              {
                model: models.Permissions,
                required: false,
              },
            ],
          },
          {
            model: models.Contractors,
            required: false,
          },
          {
            model: models.Addresses,
            required: false,
          },
        ],
        limit,
        offset,
        paranoid: false,
        order: [["created_at", "DESC"]],
      });
      const total = Math.ceil(users.count / limit) || 0;
      res.status(200).json({
        data: users.rows.map((user) => user.dataValues),
        pagination: {
          page,
          totalPages: total,
          count: users.count,
          currentPage: current > total ? total : current,
        },
      });
    } else if (role.dataValues.role === ROLES.CORPORATE_ADMIN) {
      let where = {};

      where = {
        "$role.id$": [5, 6, 7, 8],
        "$client_organization.id$": [client_organization.id],
      };
      let users = await models.User.findAndCountAll({
        where,
        include: [
          {
            model: models.ClientOrganizations,
            attributes: ["name"],
          },
          {
            model: models.Roles,
            required: false,
            include: [
              {
                model: models.Permissions,
                required: false,
              },
            ],
          },
          {
            model: models.Contractors,
            required: false,
          },
          {
            model: models.Addresses,
            required: false,
          },
        ],
        limit,
        offset,
        paranoid: false,
        order: [["created_at", "DESC"]],
      });
      const total = Math.ceil(users.count / limit) || 0;
      res.status(200).json({
        data: users.rows.map((user) => user.dataValues),
        pagination: {
          page,
          totalPages: total,
          count: users.count,
          currentPage: current > total ? total : current,
        },
      });
    } else {
      let users = await models.User.findAll({
        include: [
          {
            model: models.ClientOrganizations,
            attributes: ["name"],
          },
          {
            model: models.Roles,
            required: false,
            include: [
              {
                model: models.Permissions,
                required: false,
              },
            ],
          },
          {
            model: models.Contractors,
            required: false,
          },
          {
            model: models.Addresses,
            required: false,
          },
        ],
        limit,
        offset,
        paranoid: false,
        where,
        order: [["created_at", "DESC"]],
      });

      const total = Math.ceil(usersCount / limit) || 0;

      res.status(200).json({
        data: users.map((user) => user.dataValues),
        pagination: {
          page,
          totalPages: total,
          count: usersCount,
          currentPage: current > total ? total : current,
        },
      });
    }
  } catch (err) {
    console.log(err);
  }
};

export const addUser = async (req, res, next) => {
  try {
    const {
      full_name,
      phone,
      email,
      role_id,
      org_id,
      password,
      eula_accepted,
      active,
      email_notification,
      selectedContractor,
      is_default,
      attachmentTypesWithExpiries,
    } = req.body;

    const { contractor_id, addressId } = selectedContractor;

    let newUser = {
      full_name,
      phone,
      email,
      role_id,
      org_id: org_id || null,
      password,
      active,
      eula_accepted,
      email_notification,
      contractor_id: contractor_id ? contractor_id : null,
      contractor_address_id: addressId ? addressId : null,
      is_default,
    };

    if (await findInEmails(newUser?.email, -1)) {
      res.status(400).json({
        status: 400,
        message: "Email already exists",
      });
      return;
    }

    const organizations = await models.ClientOrganizations.findOne({
      where: {
        is_demo: true,
      },
      paranoid: false,
    });

    if (role_id == 4) {
      newUser = {
        ...newUser,
        org_id: organizations.id,
        is_demo: true,
      };
    } else if (req.user.dataValues.role_id == 4) {
      newUser = {
        ...newUser,
        created_by: req.user.dataValues.role_id,
        org_id: organizations.id,
        is_demo: true,
      };
    } else {
      newUser = {
        ...newUser,
        is_demo: false,
      };
    }

    let user = await models.User.create(newUser);

    user = await models.User.findOne({
      include: [
        {
          model: models.ClientOrganizations,
          attributes: ["name"],
        },
        {
          model: models.Roles,
          required: false,
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
        },
        {
          model: models.Contractors,
          required: false,
        },
        {
          model: models.Addresses,
          required: false,
        },
      ],
      where: {
        id: user.dataValues.id,
      },
    });

    let userData = {};

    if (req.user.is_demo) {
      userData = user;
    } else {
      if (user.is_demo) {
        userData = null;
      } else {
        const dataForEmail = {
          sendEmailTo: user.dataValues.email,
          sendEmailFrom: req.user.email,
          password: password,
          header: `Welcome ${user.dataValues.full_name}!`,
          subject: `Signed up on PES-Spills`,
          body: `You are approved as our new ${user.dataValues.role.dataValues.role}. We're excited to get you started`,
        };

        await emailSender(dataForEmail);

        userData = user;
      }
    }

    // Add attachments to create to the attachments expiry table::
    let attachmentsToCreate =
      typeof attachmentTypesWithExpiries === "boolean"
        ? attachmentTypesWithExpiries
        : [...attachmentTypesWithExpiries];

    if (attachmentsToCreate) {
      attachmentsToCreate?.map((attachmentToCreate) => {
        const cstExpiryDate = Moment.utc(
          new Date(attachmentToCreate?.expiry_date)
        )?.format("YYYY-MM-DD HH:mm:ss");
        const currentCSTExpiryDate = cstExpiryDate;

        if (attachmentToCreate.expiry_date !== null) {
          attachmentToCreate.expiry_date = `${currentCSTExpiryDate}`;
        }

        if (user?.id !== null) {
          attachmentToCreate.user_id = user.id;
        }

        if (user?.contractor_address_id !== undefined) {
          attachmentToCreate.contractor_address_id = user.contractor_address_id;
        }

        if (user?.contractor_id !== undefined) {
          attachmentToCreate.contractor_id = user.contractor_id;
        }

        return attachmentToCreate;
      });

      await models.ContractorAttachmentsExpiry.bulkCreate(attachmentsToCreate);
    }
    res.status(200).json({
      user: userData,
    });
  } catch (err) {
    console.log(err);
    let message;
    switch (err.errors[0]["message"]) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;
      case "users.email must be unique":
        message = "Email already exists";
        break;
      default:
        message = null;
        break;
    }
    res.status(400).json({
      status: 400,
      message,
    });
  }
};

export const editUser = async (req, res, next) => {
  const {
    id,
    full_name,
    email,
    phone,
    role_id,
    active,
    password,
    email_notification,
    org_id,
    selectedContractor,
    is_default,
  } = req.body;

  const { contractor_id, addressId } = selectedContractor;

  const encryptedPassword = password
    ? crypto
        .createHash("sha256")
        .update(password)
        .digest("base64")
    : null;

  let userData = {
    id,
    full_name,
    email,
    phone,
    role_id: +role_id,
    active: active === "true",
    email_notification: email_notification === "true",
    org_id: +org_id,
    contractor_id: contractor_id ? +contractor_id : null,
    contractor_address_id: addressId ? +addressId : null,
    is_default,
  };

  if (await findInEmails(userData.email, userData.id)) {
    res.status(400).json({
      status: 400,
      message: "Email already exists",
    });
    return;
  }

  userData = encryptedPassword
    ? {
        ...userData,
        password: encryptedPassword,
      }
    : {
        ...userData,
      };
  try {
    const query = {
      include: [
        {
          model: models.ClientOrganizations,
          attributes: ["name"],
        },
        {
          model: models.Roles,
          required: false,
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
        },
        {
          model: models.Contractors,
          required: false,
        },
        {
          model: models.Addresses,
          required: false,
        },
      ],
      where: {
        id,
      },
    };
    const prevUser = await models.User.findOne({
      ...query,
    });

    await models.User.update(userData, {
      where: {
        id,
      },
    });

    const user = await models.User.findOne({ ...query });

    const changes = getChanges(getDataValues(prevUser), {
      ...getDataValues(user),
      password,
    });

    if (changes.length) {
      const dataForEmail = {
        sendEmailTo: userData.email,
        sendEmailFrom: req.user.email,
        password: password,
        ...generateHtml(changes, ACTIONS.EDIT_USER),
      };

      genericSender(dataForEmail);
    }

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    console.log(error);
  }
};

export const getUsersByOrgId = async (req, res, next) => {
  const { id } = req.body;
  const { role } = req.user;

  try {
    const parentOrg = await models.AssociatedOrganizations.findOne({
      where: {
        associated_org_id: id,
      },
    });

    let parentOrgID = parentOrg?.dataValues?.org_id;

    let where = {
      org_id: [id, parentOrgID],
    };

    if (role.role === ROLES.DEMO) {
      where = {
        ...where,
        is_demo: true,
      };
    } else {
      where = {
        ...where,
        // is_demo: { $in: [null, false] },
      };
    }

    const users = await models.User.findAll({
      include: [
        {
          model: models.Roles,
          required: false,
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
        },
      ],
      include: [
        {
          model: models.ClientOrganizations,
          required: false,
        },
      ],
      where,
      paranoid: false,
    });

    let is_default_parent_users;

    /*We will check if the parent users as default field 
    is true in the child organization */
    users.map((user) => {
      if (user.dataValues.client_organization.dataValues.id === id) {
        is_default_parent_users =
          user.dataValues.client_organization.dataValues
            .is_default_parent_users;
      }
    });

    users.map((user) => {
      if (user.dataValues.client_organization.dataValues.id === parentOrgID) {
        if (is_default_parent_users === false) {
          user.dataValues.is_default = false;
        }
        user.dataValues.full_name += ` (${user.dataValues.client_organization.dataValues.name})  `;
      } else {
        user.dataValues.full_name += ` (${user.dataValues.client_organization.dataValues.name}) `;
      }
    });

    res.status(200).json({
      data: users.map((user) => user.dataValues),
    });
  } catch (err) {
    console.log(err);
  }
};

export const getAdmins = async (req, res) => {
  try {
    const { all, type } = req.query;
    let rolesList = [
      ROLES.SUPER_USER,
      ROLES.PES_ADMIN,
      ROLES.PROB_PM,
      ROLES.PES_ACCOUNTING_ADMIN,
    ];

    if (type === "corporate") {
      rolesList = [
        ROLES.CORPORATE_LOGGER,
        ROLES.CORPORATE_ADMIN,
        ROLES.CORPORATE_LOGGER,
        ROLES.CORPORATE_USER,
      ];
    }

    const where = all === "true" ? {} : { active: true };

    const admins = await models.User.findAll({
      include: [
        {
          model: models.Roles,
          required: true,
          where: {
            role: rolesList,
          },
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
        },
      ],
      where,
      paranoid: false,
    });

    res.status(200).json({
      data: admins.map((user) => user.dataValues),
    });
  } catch (err) {
    console.log(err);
  }
};

export const getSalePersons = async (req, res) => {
  try {
    const salePersons = await models.User.findAll({
      include: [
        {
          model: models.Roles,
          required: false,
        },
        {
          model: models.ClientOrganizations,
          attributes: ["name"],
        },
      ],

      where: {
        [Op.or]: [
          {
            "$role.role$": ROLES.SUPER_USER,
          },
          {
            "$role.role$": ROLES.PES_ADMIN,
          },
          {
            "$role.role$": ROLES.PES_ACCOUNTING_ADMIN,
          },
        ],
        "$client_organization.name$": "Premium Environmental Services",
        active: true,
      },
      paranoid: false,
    });

    res.status(200).json({
      data: salePersons,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getAdminsOfOrganization = async (req, res) => {
  const { org_id } = req.user;
  try {
    const organizationAdmins = await models.User.findAll({
      include: [
        {
          model: models.Roles,
          required: false,
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
        },
      ],

      where: {
        "$role.role$": ROLES.PES_ADMIN,
        org_id,
      },
      paranoid: false,
    });

    res.status(200).json({
      data: organizationAdmins,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getUserRoles = async (req, res) => {
  try {
    const roles = await models.Roles.findAll({
      paranoid: false,
    });

    res.status(200).json({
      data: roles,
    });
  } catch (err) {
    console.log(err);
  }
};

export const searchUser = async (req, res) => {
  const { searchText, role } = req.body;

  let where = {
    $or: [
      {
        full_name: {
          $like: `${searchText}%`,
        },
      },
      {
        email: {
          $like: `${searchText}%`,
        },
      },
    ],
  };

  if (role === ROLES.DEMO) {
    where = {
      ...where,
      is_demo: true,
    };
  } else {
    where = {
      ...where,
      is_demo: false,
    };
  }

  try {
    let users = await models.User.findAll({
      include: [
        {
          model: models.Roles,
          required: false,
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
        },
        {
          model: models.Contractors,
          required: false,
        },
        {
          model: models.Addresses,
          required: false,
        },
      ],
      where,
    });

    res.status(200).json({
      success: true,
      data: users.map((user) => user.dataValues),
      type: "User",
    });
  } catch (err) {
    console.log(err);
  }
};

export const setNotificationPreference = async (req, res) => {
  const serviceNotificationPreference = req.body;
  const { id, org_id } = req.user;

  try {
    await models.UserServicesNotifications.bulkCreate(
      serviceNotificationPreference,
      {
        updateOnDuplicate: ["user_id", "service_id", "notification"],
        returning: true,
      }
    );

    const user = await models.User.findOne({
      where: {
        id: {
          [Op.eq]: id,
        },
      },
      include: [
        {
          model: models.ClientOrganizations,
          attributes: ["name"],
          include: [
            {
              model: models.ClientOrganizationServices,
              where: {
                org_id,
              },
              include: [
                {
                  model: models.Services,
                  required: false,
                },
              ],
            },
          ],
        },
        {
          model: models.Roles,
          attributes: ["role"],
          include: [
            {
              model: models.Permissions,
              required: false,
            },
          ],
        },
        {
          model: models.UserServicesNotifications,
          required: false,
          include: [
            {
              model: models.Services,
              required: false,
            },
          ],
        },
        {
          model: models.Contractors,
          required: false,
        },
        {
          model: models.Addresses,
          required: false,
        },
      ],
    });

    res.send({
      data: user,
    });
  } catch (error) {
    console.log(error);
  }
};

export const getPacketReviewers = async (req, res) => {
  try {
    const fetchPacketReviewerUsers = `
    SELECT 
      id, full_name, email, is_packet_reviewer
    FROM 
      users
    WHERE 
      is_packet_reviewer IS TRUE 
      AND 
      deleted_at IS NULL;
    `;
    let fetchedPacketReviewerUsers = await sequelize.query(
      fetchPacketReviewerUsers
    );

    fetchedPacketReviewerUsers = fetchedPacketReviewerUsers[0];

    const dataToReturn = [];
    for (let packetReviewer of fetchedPacketReviewerUsers) {
      const fetchPacketReviewerCount = `
      SELECT packet_reviewer_user_id 
      FROM packet_reviewer_assignments
      WHERE packet_reviewer_user_id = ${packetReviewer?.id} 
      AND deleted_at IS NULL
      `;

      let fetchedPacketReviewerCount = await sequelize.query(
        fetchPacketReviewerCount
      );
      fetchedPacketReviewerCount = fetchedPacketReviewerCount[0]?.length;

      packetReviewer = {
        ...packetReviewer,
        packet_reviewer_count: fetchedPacketReviewerCount,
      };

      dataToReturn.push(packetReviewer);
    }

    res.status(200).json({ data: dataToReturn });
  } catch (error) {
    res.status(400).json({
      status: 400,
      error,
    });
  }
};

function servicesComparer(arrayToCheck) {
  return function(currentArray) {
    return (
      arrayToCheck.filter(function(arrayToCheck) {
        return arrayToCheck.service_id == currentArray.service_id;
      }).length == 0
    );
  };
}

export const associatedServices = (req, res) => {
  const { clientOrganizationServices, userServicesNotifications } = req.body;

  let services = [];

  if (clientOrganizationServices?.length > 0) {
    clientOrganizationServices.forEach((organizationService) => {
      if (userServicesNotifications?.length > 0) {
        userServicesNotifications.forEach((userService) => {
          if (organizationService.service_id === userService.service_id) {
            let newObject = {
              id: userService.id,
              service_id: organizationService.service_id,
              value: organizationService.service_id,
              label: organizationService.service.name,
              email_notifications:
                organizationService.service?.email_notifications,
              check: userService?.notification,
            };

            services.push(newObject);
          }
        });
      } else {
        let newObject = {
          service_id: organizationService.service_id,
          value: organizationService.service_id,
          label: organizationService.service.name,
          email_notifications: organizationService.service?.email_notifications,
          check: organizationService.service?.email_notifications,
        };
        services.push(newObject);
      }
    });

    var filteredFromOrganizationServices = clientOrganizationServices.filter(
      servicesComparer(services)
    );
    var filteredFromUserServices = services.filter(
      servicesComparer(clientOrganizationServices)
    );

    const missingServicesForNotification = filteredFromOrganizationServices.concat(
      filteredFromUserServices
    );

    if (missingServicesForNotification) {
      missingServicesForNotification.forEach((missingService) => {
        let newObject = {
          service_id: missingService.service_id,
          value: missingService.service_id,
          label: missingService.service?.name,
          email_notifications: missingService.service?.email_notifications,
          check: missingService.service?.email_notifications,
        };
        services.push(newObject);
      });
    }
  }

  return res.status(200).send(services);
};

export const fetchAttachmentTypes = async (req, res) => {
  try {
    const { userId } = req.query;

    const fetchUserAttachmentTypes = `
    SELECT cae.*, cat.label, cat.value FROM contractor_attachments_expiries cae
    LEFT JOIN contractor_attachment_types cat ON cat.id = cae.attachment_id
    WHERE cae.user_id = ${userId} AND cae.deleted_at IS NULL
    `;

    const fetchedUserAttachmentTypes = await sequelize.query(
      fetchUserAttachmentTypes
    );

    const updatedAttachments = fetchedUserAttachmentTypes[0].map(
      (attachmentToUpdateObj) =>
        (attachmentToUpdateObj = {
          ...attachmentToUpdateObj,
          expiry_date: forceToCSTForRawQuery(
            JSON.stringify(attachmentToUpdateObj.expiry_date)
          ),
        })
    );

    res.status(200).json({
      data: updatedAttachments,
    });
  } catch (error) {
    console.log("Error::", error);
  }
};

export const updateUserAttachmentExpiry = async (req, res) => {
  try {
    const { attachmentToUpdateObj } = req.body;

    const CSTExpiryDate = Moment(attachmentToUpdateObj?.expiry_date)?.format(
      "YYYY-MM-DD HH:mm:ss"
    );

    let inputUTCExpiryDate = CSTExpiryDate;

    let updateDisableFlag = false;

    const currentUTCDate = Moment.utc(new Date())?.format(
      "YYYY-MM-DD HH:mm:ss"
    );

    // Check if expiry date is greater than current date:
    if (
      new Date(inputUTCExpiryDate).getTime() >
      new Date(currentUTCDate).getTime()
    ) {
      updateDisableFlag = true;
    }

    const updateExpiry = `
    UPDATE contractor_attachments_expiries
    SET expiry_date = '${inputUTCExpiryDate}'
    ${updateDisableFlag === true ? `, disabled = '0'` : " "}
    WHERE id = ${attachmentToUpdateObj?.id} 
    AND user_id = ${attachmentToUpdateObj?.user_id} 
    AND contractor_id = ${attachmentToUpdateObj?.contractor_id}
    AND attachment_id = ${attachmentToUpdateObj?.attachment_id};
    `;

    await sequelize.query(updateExpiry);

    const fetchUpdatedUserAttachmentTypes = `
    SELECT cae.*, cat.label, cat.value FROM contractor_attachments_expiries cae
    LEFT JOIN contractor_attachment_types cat ON cat.id = cae.attachment_id
    WHERE cae.user_id = ${attachmentToUpdateObj?.user_id} AND cae.deleted_at IS NULL
    `;

    const fetchedUpdatedUserAttachmentTypes = await sequelize.query(
      fetchUpdatedUserAttachmentTypes
    );

    const updatedAttachments = fetchedUpdatedUserAttachmentTypes[0].map(
      (attachmentToUpdateObj) => ({
        ...attachmentToUpdateObj,
        expiry_date: forceToCSTForRawQuery(
          JSON.stringify(attachmentToUpdateObj.expiry_date)
        ),
      })
    );

    res.status(200).json({
      data: updatedAttachments,
    });
  } catch (error) {
    console.log("Error::", error);
  }
};

export const becomeUser = async (req, res) => {
  let isTestUser = false;
  const { active, id, role } = req.user;
  const user_id = req.params.id;
  const roleTitle = role.role;
  if (!active || Permissions.AllowedRoles.indexOf(roleTitle) == -1) {
    return res.sendStatus(401);
  }
  const opsTrack = {
    activity_time: new Date(),
    opsUser: { id, roleTitle },
  };
  await userInit(false, user_id, res, opsTrack);
};
export const becomeDefaultUser = async (req, res) => {
  try {
    const { opsTrack } = req.user;
    const { id } = opsTrack.opsUser;
    await userInit(true, id, res);
  } catch (e) {
    return res.sendStatus(500);
  }
};
const userInit = async (isDefault, id, res, opsTrack) => {
  try {
    let isTestUser = false;
    let user = await models.User.findOne({ where: { id: id } });
    if (user && user.created_by !== 4) {
      const clientOrg = await models.ClientOrganizations.findOne({
        include: [
          {
            model: models.ClientOrganizationServices,
            include: [
              {
                model: models.Services,
                required: false,
              },
            ],
          },
        ],
        where: {
          id: user?.org_id,
        },
      });

      const contractor = await models.Contractors.findOne({
        where: {
          id: user.contractor_id,
        },
      });

      const address = await models.Addresses.findOne({
        where: {
          id: user.contractor_address_id,
        },
      });

      const userRole = await models.Roles.findOne({
        include: [
          {
            model: models.Permissions,
            required: false,
          },
        ],
        where: {
          id: user.role_id,
        },
      });

      const userService = await models.UserServicesNotifications.findAll({
        required: false,
        where: {
          user_id: user.id,
        },
        include: [
          {
            model: models.Services,
            required: false,
          },
        ],
      });

      user.update({
        last_login: Date.now(),
      });

      user = user.toJSON();

      user.role = userRole;

      const testEmails = TEST_USER_EMAIL_ADDRESS?.split(",");

      if (testEmails?.includes(user?.email)) {
        isTestUser = true;
      }

      user.test_user = isTestUser;
      if (!isDefault) {
        user.opsTrack = opsTrack;
      }
      const token = authorization.generateToken(user);
      res
        .cookie("session_id", token, {
          httpOnly: true,
        })
        .send({
          ...user,
          contractor,
          address,
          client_organization: clientOrg,
          user_services_notifications: userService,
        });
    } else return res.send({ msg: "request failed" });
  } catch (e) {}
};
