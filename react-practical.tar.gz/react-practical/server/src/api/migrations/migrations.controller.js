import moment from "moment";
import mysql from "mysql2/promise";
import models from "../../models";
import { ROLES } from "../../util/constants";

import fs from "fs";

import { uploadFileToS3Bucket } from "../../util/s3";
import crypto from "crypto";
import sequelize from "sequelize";

const {
  MIGRATION_HOST,
  MIGRATION_USERNAME,
  MIGRATION_PASSWORD,
  MIGRATION_DATABASE_NAME,
  DATABASE_NAME,
  DATABASE_PORT,
} = process.env;

export const calculateSum = async (req, res) => {
  res.status(200).json({
    data: "Starting calculating and setting sum",
  });
  try {
    let allSpills = await models.Spills.findAll({
      attributes: ["id", "job_no", "created_at", "updated_at"],
    });
    allSpills = allSpills.map((x) => x.dataValues);
    const totalSpills = allSpills.length;
    const iterations = totalSpills / 200;
    const startTime = new Date();
    for (let i = 0; i <= iterations; i++) {
      console.log("Spills Calculated :", i * 200);
      let spills = allSpills.splice(0, 200);
      const spillIds = spills.map((x) => x.id);

      let sums = await models.SpillNotes.findAll({
        attributes: [
          [sequelize.fn("sum", sequelize.col("amount")), "total_notes_sum"],
          ["spill_id", "id"],
        ],
        where: { spill_id: spillIds },
        group: ["spill_id"],
      });
      sums = sums.map((x) => {
        return {
          ...spills.find((y) => y.id === x.dataValues.id),
          total_notes_sum: +x.dataValues.total_notes_sum,
        };
      });
      await models.Spills.bulkCreate(sums, {
        updateOnDuplicate: ["total_notes_sum"],
      });
    }
    const endTime = new Date();
    var timeDiff = endTime - startTime; //in ms
    // strip the ms
    timeDiff /= 1000;

    // get seconds
    var seconds = Math.round(timeDiff);
    console.log(seconds + " seconds");
  } catch (err) {
    console.log("Error in Calculating Sum:", err);
  }
};

const extractRows = (data) => {
  return data.rows.map((row) => row.dataValues);
};

export const runAllMigrations = async (req, res) => {
  res.status(200).json({
    data: "Starting All Migrations",
  });
  await adjustServices();

  // await contractorMigration();
  // await contractorAddressesTierUpdation();
  // await agencyMigration();
  // await organizationMigration();
  // await userMigration();
  // await assignSalesPersonsToOrgs();
  // await migrateStatus();
  // await migrateMaterial();
  // await spillMigration();
  // await uploadFilesToS3(); //Uncomment this when updating with new legacy table.
  // await spillNotesMigration();
  // await spillReservesMigration();
  // // await syncSpillsID();
  // await updateS3UploadHistory();
  // //await migrateNoteAttachments();
  // await handleExceptions();
  console.log("Done");
};
const truncateTable = async (tableName) => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: DATABASE_NAME,
  });

  const querry = "TRUNCATE `pes-spills`." + tableName;
  await connection.execute(querry);
};

export const adjustServices = async () => {
  await models.Services.update(
    { is_default: true },
    { where: { is_default: false } }
  );
  const services = await models.Services.findAll();
  const orgServices = await models.ClientOrganizationServices.findAll();

  const servicesIds = services.map((x) => x.id);
  console.log("servicesIds :", servicesIds.length);

  let orgServicesObj = {};
  orgServices.map((orgService) => {
    if (orgServicesObj[orgService.dataValues.org_id]) {
      orgServicesObj[orgService.dataValues.org_id].push(
        services.find((x) => x.id === orgService.dataValues.service_id)
      );
    } else {
      orgServicesObj[orgService.dataValues.org_id] = [
        services.find((x) => x.id === orgService.dataValues.service_id),
      ];
    }
  });
  console.log("Orgs Count ::", Object.keys(orgServicesObj).length);

  await Promise.all(
    Object.keys(orgServicesObj).map(async (key) => {
      console.log("Org ID :", key);
      const servicesList = orgServicesObj[key];
      const serviceIdList = servicesList?.map((x) => x.id);
      console.log("Current Services :", serviceIdList.length);
      const newServices = [];
      servicesIds.map(async (y) => {
        if (!serviceIdList.includes(y)) {
          const newOrgService = {
            org_id: key,
            service_id: y,
            type: null,
            rate: 0.0,
          };
          newServices.push(newOrgService);
        }
      });
      console.log("New Services Added ::", newServices.length);
      console.log("");
      newServices.length &&
        (await models.ClientOrganizationServices.bulkCreate(newServices));
    })
  );
};

export const contractorMigration = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    port: DATABASE_PORT,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  await truncateTable("contractors");
  await truncateTable("addresses");

  let [rows] = await connection.execute(
    "SELECT * FROM `spill`.contractor ORDER BY name ASC" //reading data from source database
  );

  let name = "";
  let entityId = "";

  console.log("Contractor Migration");
  console.log("Length ::", rows.length);

  let count = 0;
  for (let contractor of rows) {
    //separating name and tier level of contractor
    const contractorDetail = contractor.name.split("- ");
    if (name !== contractorDetail[0].trim()) {
      //creating object for our contractor table
      if (contractor.ctry === "USA") {
        contractor.ctry = "United States of America";
      } else if (contractor.ctry === "CAN") {
        contractor.ctry = "Canada";
      }
      let contractorObject = {
        name: contractorDetail[0].trim(),
        tier_level: contractorDetail[1] ? contractorDetail[1].trim() : null,
        address: contractor.address,
        city: contractor.city,
        state: contractor.st,
        zipCode: contractor.zip,
        country: contractor.ctry,
        phone: contractor.phone,
        phone2: contractor.phone2,
        fax: contractor.fax,
        contact: contractor.contact,
        email: contractor.email,
      };
      //cleaning the obejct
      Object.keys(contractorObject).forEach(
        (k) => !(contractorObject[k] !== null) && delete contractorObject[k]
      );
      name = contractorDetail[0].trim();
      const contractorCreated = await models.Contractors.create(
        contractorObject
      );
      entityId = contractorCreated.dataValues.id;
    } else {
      //creating object for our address table
      if (contractor.ctry === "USA") {
        contractor.ctry = "United States of America";
      } else if (contractor.ctry === "CAN") {
        contractor.ctry = "Canada";
      }
      let addressObject = {
        entity_id: entityId,
        entity_type: "contractor",
        tier_level: contractorDetail[1] ? contractorDetail[1].trim() : null,
        address: contractor.address,
        city: contractor.city,
        state: contractor.st,
        zipCode: contractor.zip,
        country: contractor.ctry,
        phone: contractor.phone,
        phone2: contractor.phone2,
        fax: contractor.fax,
        contact: contractor.contact,
      };
      //Cleaning the object
      Object.keys(addressObject).forEach(
        (k) => !(addressObject[k] !== null) && delete addressObject[k]
      );

      await models.Addresses.create(addressObject);
    }
    count += 1;
    count % 100 === 0 && console.log(count);
  }
};

export const contractorAddressesTierUpdation = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: DATABASE_NAME,
  });

  console.log("Contractor Address Tier Update");
  try {
    const [contractorRows] = await connection.execute(
      "SELECT * FROM `contractors`"
    );

    const [addressesRows] = await connection.execute(
      "SELECT * FROM `addresses`"
    );

    console.log("Updating Contractors");
    console.log("Length :: ", contractorRows.length);
    let count = 0;

    for (let contractor of contractorRows) {
      let tier = contractor.tier_level ? contractor.tier_level : null;

      if (contractor.tier_level === "I") {
        tier = "Tier I";
      } else if (contractor.tier_level === "II") {
        tier = "Tier II";
      } else if (contractor.tier_level === "III") {
        tier = "Tier III";
      } else if (contractor.tier_level === "X") {
        tier = "Do Not Use";
      }

      let customAgencyObject = {
        ...contractor,
        tier_level: tier,
      };

      await models.Contractors.update(customAgencyObject, {
        where: {
          id: contractor.id,
        },
      });
      count += 1;
      count % 100 === 0 && console.log(count);
    }

    console.log("Updating Addresses");
    console.log("Length :: ", addressesRows.length);
    count = 0;

    for (let address of addressesRows) {
      let tier = address.tier_level ? address.tier_level : null;

      if (address.tier_level === "I") {
        tier = "Tier I";
      } else if (address.tier_level === "II") {
        tier = "Tier II";
      } else if (address.tier_level === "III") {
        tier = "Tier III";
      } else if (address.tier_level === "X") {
        tier = "Do Not Use";
      }

      let customAgencyObject = {
        ...address,
        tier_level: tier,
      };

      await models.Addresses.update(customAgencyObject, {
        where: {
          id: address.id,
        },
      });
      count += 1;
      count % 100 === 0 && console.log(count);
    }
  } catch (error) {
    console.log(error);
  }
};

export const agencyMigration = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  console.log("Agency Migration");

  try {
    await truncateTable("agencies");
    const [rows] = await connection.execute("SELECT * FROM `agency`");
    let bulkAgencies = [];
    let count = 0;

    console.log("Length: ", rows.length);

    for (let c of rows) {
      let data = c;

      let customAgencyObject = {
        name: data.name,
        city: data.city,
        address: data.address,
        state: data.st,
        zipCode: data.zip,
        country: data.ctry
          ? data.ctry === "USA"
            ? "United States of America"
            : "Canada"
          : null,
        fax: data.fax,
        contact: data.contact,
        jurisdiction: data.jurisdiction,
        phone: data.phone,
      };
      bulkAgencies.push(customAgencyObject);
      if (bulkAgencies.length >= 1000) {
        await models.Agencies.bulkCreate(bulkAgencies);
        bulkAgencies = [];
        count += 1;
        console(count);
      }
    }
    await models.Agencies.bulkCreate(bulkAgencies);
  } catch (error) {
    console.log(error);
  }
};

export const organizationMigration = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  const defaultServices = await models.Services.findAll({
    where: {
      is_default: true,
    },
  });

  console.log("Organization Migration");
  let count = 0;

  try {
    // await truncateTable("client_organization_services");
    // await truncateTable("client_organizations");

    const [rows] = await connection.execute("SELECT * FROM spill.org");
    let organizationsInDB = await models.ClientOrganizations.findAll({
      attributes: ["id", "name", "code"],
    });
    organizationsInDB = organizationsInDB.map((x) => x.dataValues);
    console.log("Length ::", rows.length);
    for (let organization of rows) {
      if (
        organization.name &&
        !organizationsInDB.find((x) => x.name === organization.name)
      ) {
        let customOrganizationObject = {
          name: organization.name,
          code: organization.code,
          taxId: organization.tax_id,
          address: organization.address,
          city: organization.city,
          state: organization.st,
          rate: organization.rate,
          zipCode: organization.zip,
          country: organization.ctry
            ? organization.ctry === "USA"
              ? "United States of America"
              : "Canada"
            : null,
          phone: organization.phone,
          is_god: organization.is_god,
          active: organization.active,
        };
        //cleaning the object
        Object.keys(customOrganizationObject).forEach(
          (k) =>
            !(customOrganizationObject[k] !== null) &&
            delete customOrganizationObject[k]
        );

        const organizationCreated = await models.ClientOrganizations.create(
          customOrganizationObject
        );

        let orgId = organizationCreated.dataValues.id;

        //Associated Services Creation
        const associatedServicesBulk = [];
        for (let service of defaultServices) {
          let associatedServicesObject = {
            org_id: orgId,
            service_id: service.dataValues.id,
          };
          associatedServicesBulk.push(associatedServicesObject);
        }
        await models.ClientOrganizationServices.bulkCreate(
          associatedServicesBulk
        );
      }
      count += 1;
      console.log(count);
    }
  } catch (error) {
    console.log(error);
  }
};

// Please disable isEmail check from sequelize user model and remove unique check from database to run this migration
// After running user migration change the checks, and then run the saleperson assign migration,
export const userMigration = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  try {
    await truncateTable("users");
    const [rows] = await connection.execute("SELECT * FROM spill.person");

    const orgsData = await connection.execute("SELECT * FROM spill.org ");
    const rolesData = await connection.execute("SELECT * FROM spill.role");

    const newOrgs = extractRows(
      await models.ClientOrganizations.findAndCountAll()
    );

    const newRoles = extractRows(await models.Roles.findAndCountAll());

    let data = orgsData[0];

    let bulkUsers = [];
    let count = 0;
    console.log("User migration");
    console.log("Length ::", rows.length);
    for (let person of rows) {
      let orgInOldDB = orgsData[0].filter((x) => x.id === person.org)[0];

      let roleInOldDB = rolesData[0].filter((x) => x.id === person.role)[0]
        .name;

      if (roleInOldDB === "Kahuna") {
        roleInOldDB = ROLES.SUPER_USER;
      }
      if (roleInOldDB === "Admin") {
        roleInOldDB = ROLES.SUPER_USER;
      }
      if (roleInOldDB === "Manager") {
        roleInOldDB =
          orgInOldDB.id !== 1 ? ROLES.CORPORATE_ADMIN : ROLES.PES_ADMIN;
      }
      if (roleInOldDB === "User") {
        roleInOldDB =
          orgInOldDB.id !== 1 ? ROLES.CORPORATE_USER : ROLES.PES_USER;
      }
      if (roleInOldDB === "Logger") {
        roleInOldDB = ROLES.CORPORATE_LOGGER;
      }

      let organizationInDB = newOrgs.find(
        (org) => org.name === orgInOldDB.name
      );

      let rolesInDB = newRoles.find((role) => role.role === roleInOldDB);

      if (organizationInDB) {
        let userOrgId = organizationInDB.id;
        let userRoleId = rolesInDB.id;

        let name =
          (person.nameFirst ? person.nameFirst : "") +
          " " +
          (person.nameLast ? person.nameLast : "");

        let customUserObject = {
          full_name: name.trim(),
          email: person.email ? person.email : `${person.nameFirst}@email.com`,
          password: person.passwd
            ? crypto
                .createHash("sha256")
                .update(person.passwd)
                .digest("base64")
            : "nopassword",
          confirmed: true,
          phone: person.phone,
          role_id: userRoleId,
          org_id: userOrgId,
          email_notification: person.ok2email,
          active: person.active,
        };
        bulkUsers.push(customUserObject);
        if (bulkUsers.length >= 500) {
          count += 0.5;

          await models.User.bulkCreate(bulkUsers);
          bulkUsers = [];
          console.log(count);
        }
      }
    }
    //creating the users remaining in the array
    await models.User.bulkCreate(bulkUsers);
  } catch (error) {
    console.log(error);
  }
};

export const assignSalesPersonsToOrgs = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  try {
    const [rows] = await connection.execute("SELECT * FROM spill.org");
    const persons = await connection.execute("SELECT * FROM spill.person ");
    const usersRaw = await models.User.findAndCountAll();
    const usersInNewDB = extractRows(usersRaw);

    const orgsInNewDB = extractRows(
      await models.ClientOrganizations.findAndCountAll()
    );

    console.log("Assign Sales Persons To Orgs");
    console.log("Length ::", rows.length);
    let count = 0;

    for (let orgs of rows) {
      try {
        let salePersonInOldDB = orgs.salesperson;
        let personEmail = persons[0].filter(
          (x) => x.id === salePersonInOldDB
        )[0];

        let emailToFind = personEmail?.email;

        if (emailToFind) {
          let userInNewDB = usersInNewDB.find(
            (user) => user.email === emailToFind
          );

          let organizationInNewDB = orgsInNewDB.find(
            (org) => org.name === orgs.name
          );

          await models.ClientOrganizations.update(
            {
              salesPerson: userInNewDB.id,
            },
            {
              where: {
                id: organizationInNewDB.id,
              },
            }
          )
            .then((response) => {})
            .catch((err) => next(err));
        }
        count += 1;
        count % 100 === 0 && console.log(count);
      } catch (err) {
        console.log("Err in assign ::", err);
      }
    }
  } catch (error) {
    console.log(error);
  }
};

export const migrateStatus = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  const checkStatusException = (status) => {
    if (status.name === "Invoiced but not paid") {
      return { ...state, name: "Invoice Submitted to Client" };
    } else if (status.name === "Paid but Contractor not yet paid") {
      return { ...state, name: "Payment Pending" };
    }
    return status;
  };
  try {
    await truncateTable("spill_statuses");
    const [rows] = await connection.execute("SELECT * FROM spill.status");

    console.log("Migrate Spill Status");
    console.log("Length ::", rows.length);
    const statuses = [];
    for (let status of rows) {
      const modifiedStatus = checkStatusException(status);
      let statusObject = {
        id: modifiedStatus.id,
        name: modifiedStatus.name,
        status: modifiedStatus.status,
      };
      statuses.push({ ...statusObject });
    }
    statuses.push({ name: "Final Review", status: "Open" });
    statuses.push({ name: "Ready to Invoice", status: "Open" });
    statuses.push({
      name: "Documentation Sent Back to Contractor for Revision",
      status: "Open",
    });
    await models.SpillStatuses.bulkCreate(statuses);
  } catch (error) {
    console.log(error);
    throw error;
  }
};

export const migrateMaterial = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });
  try {
    await truncateTable("spill_materials");

    const [rows] = await connection.execute("SELECT * FROM spill.material");

    console.log("Migrating Materials");
    console.log("Length ::", rows.length);
    let bulkMaterial = [];
    let count = 0;

    for (let material of rows) {
      let materialObject = {
        id: material.id,
        name: material.name,
        hits: material.hits,
      };
      bulkMaterial.push(materialObject);
      if (bulkMaterial.length >= 1000) {
        await models.SpillMaterial.bulkCreate(bulkMaterial);
        bulkMaterial = [];
        count += 1;
        console.log(count);
      }
    }
    bulkMaterial.length > 0 &&
      (await models.SpillMaterial.bulkCreate(bulkMaterial));
  } catch (error) {
    console.log(error);
    throw error;
  }
};

export const spillMigration = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  console.log("Migrating Spills");

  try {
    await truncateTable("spills");
    await truncateTable("connections");
    await truncateTable("spill_contractors");
    await truncateTable("spill_admins");
    await truncateTable("recipients");

    const idHash = ({ id }) => `${id}`;
    const incidentHash = ({ incident }) => `${incident}`;
    const nameHash = ({ name }) => `${name}`;
    const emailPhoneHash = ({ email, phone }) => `${email}|${phone}`;
    const addressHash = ({ entity_id, city, address, state, entity_type }) =>
      `${entity_id}|${city}|${address}|${state}|${entity_type}`;

    const [rows] = await connection.execute("SELECT * FROM spill.incident");
    const orgsData = await connection.execute("SELECT * FROM spill.org");

    const orgsDataHash = Object.fromEntries(
      orgsData[0].map((x) => [idHash(x), x])
    );

    const userData = await connection.execute("SELECT * FROM spill.person");

    const userDataHash = Object.fromEntries(
      userData[0].map((x) => [idHash(x), x])
    );

    const agencyData = await connection.execute("SELECT * FROM spill.agency");

    const agencyDataHash = Object.fromEntries(
      agencyData[0].map((x) => [idHash(x), x])
    );

    const spillContractorsData = await connection.execute(
      "SELECT * FROM spill.incident_contractor"
    );
    const contractorsData = await connection.execute(
      "SELECT * FROM spill.contractor"
    );

    const contractorsDataHash = Object.fromEntries(
      contractorsData[0].map((x) => [idHash(x), x])
    );

    const spillInfoData = await connection.execute(
      "SELECT * FROM spill.incident_info"
    );

    const spillInfoDataHash = Object.fromEntries(
      spillInfoData[0].map((x) => [incidentHash(x), x])
    );

    const spillRecipientsData = await connection.execute(
      "SELECT * FROM spill.incident_person"
    );

    const orgsInNewDB = extractRows(
      await models.ClientOrganizations.findAndCountAll()
    );

    const orgsNewDataHash = Object.fromEntries(
      orgsInNewDB.map((x) => [nameHash(x), x])
    );

    const usersInNewDB = extractRows(await models.User.findAndCountAll());

    const usersNewDataHash = Object.fromEntries(
      usersInNewDB.map((x) => [emailPhoneHash(x), x])
    );

    const materialsInNewDB = extractRows(
      await models.SpillMaterial.findAndCountAll()
    );

    const materialsNewDataHash = Object.fromEntries(
      materialsInNewDB.map((x) => [idHash(x), x])
    );

    const agenciesInNewDB = extractRows(
      await models.Agencies.findAndCountAll()
    );

    const agencyNewDataHash = Object.fromEntries(
      agenciesInNewDB.map((x) => [nameHash(x), x])
    );

    const contractorsInNewDB = extractRows(
      await models.Contractors.findAndCountAll()
    );

    const contractorsNewDataHash = Object.fromEntries(
      contractorsInNewDB.map((x) => [nameHash(x), x])
    );

    const addressesInNewDB = extractRows(
      await models.Addresses.findAndCountAll()
    );

    const addressesNewDataHash = Object.fromEntries(
      addressesInNewDB.map((x) => [addressHash(x), x])
    );

    console.log("Starting");
    console.log("Length :: ", rows.length);
    let count = 0;

    const statusObj = {
      1: "Open: Work In Progress",
      2: "Open: Site Work Complete",
      3: "Open: Extended Remediation",
      12: "Open: Pending Excavation",
      5: "Open: Documentation In Review",
      6: "Open: Partial",
      13: "Open: Pending Disposal",
      9: "Closed: Invoice Submitted to Client",
      10: "Closed: Payment Pending",
      11: "Closed: Closed",
    };

    for (let spill of rows) {
      count += 1;
      count % 100 === 0 && console.log(count);

      let orgInOldDB = orgsDataHash[spill.org];

      let userInOldDB = userDataHash[spill.pm];
      userData[0].find((x) => x.id === spill.pm);

      let organizationInDB = orgsNewDataHash[orgInOldDB.name];

      let usersInDB =
        usersNewDataHash[`${userInOldDB.email}|${userInOldDB.phone}`];

      let materialInDB = materialsNewDataHash[spill.material];

      if (organizationInDB && usersInDB) {
        let statusText = "";
        let userId = usersInDB.id;
        let spillOrgId = organizationInDB.id;
        let materialId = materialInDB?.id;
        let materialName = materialInDB?.name;

        statusText = statusObj[spill.status];

        let spills = [];

        if (spill.num) {
          const spillJobNumberSplitter = spill.num.split("--");
          let spillOrgCode = organizationInDB.code;

          let spillJobNumber = `${spillJobNumberSplitter[0].trim()}-${spillOrgCode}-${spillJobNumberSplitter[1].trim()}`;

          let customSpillObject = {
            job_no: spillJobNumber,
            user_id: userId,
            org_id: spillOrgId,
            address: spill.address,
            city: spill.city,
            state: spill.st,
            rate: spill.rate,
            zipCode: spill.zip,
            country: spill.ctry
              ? spill.ctry === "USA"
                ? "United States of America"
                : "Canada"
              : null,
            contact: spill.who_on_scene,
            send_attachment: spill.send_attachments,
            conditions: spill.site_conditions,
            type: spill.type,
            responsible: spill.responsible_party,
            need_5800: spill.need_5800,
            is_waste: spill.is_waste,
            is_hazmat: spill.is_hazmat,
            has_msds: spill.has_msds,
            response_sent: spill.response_sent,
            subrogation: spill.subrogation,
            claim_no: spill.claim_no,
            is_demo: false,
            opened_on: spill.opened ? moment(spill.opened).utc(true) : null,
            closed_on: spill.closed ? moment(spill.closed).utc(true) : null,
            status: statusText,
            status_id: spill.status,
            assignment_no: spill.assignment_no,
            freight_bill: spill.freight_bill,
            money_saved_mgt: spill.money_saved_mgt,
            money_saved_waste: spill.money_saved_waste,
            rate: spill.rate,
            material_id: materialId,
            material: materialName,
            legacy_id: spill.id,
          };
          Object.keys(customSpillObject).forEach(
            (k) =>
              !(customSpillObject[k] !== null) && delete customSpillObject[k]
          );

          const spillCreated = await models.Spills.create(customSpillObject);

          const spillId = spillCreated.dataValues.id;

          // Spill Connection

          const agencyInOldDB = agencyDataHash[spill.agency_state];

          const agencyInDB = agencyNewDataHash[agencyInOldDB?.name];

          const spillAgencyId = agencyInDB?.id;

          const spillConnectionObject = {
            spill_id: spillId,
            agency_national: spill.agency_national,
            incident_no: spill.agency_national_no,
            agency_id: spillAgencyId ? spillAgencyId : null,
            state_incident_no: spill.agency_state_no,
          };

          Object.keys(spillConnectionObject).forEach(
            (k) =>
              !(spillConnectionObject[k] !== null) &&
              delete spillConnectionObject[k]
          );

          const createdConnection = await models.Connections.create(
            spillConnectionObject
          );

          const connectionId = createdConnection.dataValues.id;

          // Spill Contractors

          const spillContractorsOldDB = spillContractorsData[0].filter(
            (x) => x.incident === spill.id
          );

          let bulkContractors = [];

          for (let contractor of spillContractorsOldDB) {
            const contractorOldDB = contractorsDataHash[contractor.contractor];
            const contractorDetail = contractorOldDB.name.split("- ");
            const contractorsInDB =
              contractorsNewDataHash[contractorDetail[0].trim()];

            const contractorsAddressInDB = addressesInNewDB.find(
              (x) =>
                x.entity_id === contractorsInDB.id &&
                x.city === contractorOldDB.city &&
                x.address === contractorOldDB.address &&
                x.state === contractorOldDB.st &&
                x.entity_type === "contractor"
            );

            const contractorCurrentId = contractorsInDB.id;
            const contractorAddressId = contractorsAddressInDB?.id;

            const spillContractorObject = {
              connection_id: connectionId,
              contractor_id: contractorCurrentId,
              address_id: contractorAddressId,
            };

            bulkContractors.push(spillContractorObject);
          }
          bulkContractors.length > 0 &&
            (await models.SpillContractors.bulkCreate(bulkContractors));
          bulkContractors = [];

          // Spill Admin

          const spillInfoInOldDB = spillInfoDataHash[spill.id];

          if (spillId) {
            const spillInfo = spillInfoInOldDB?.info;

            const customAdminObject = {
              is_main: true,
              info: spillInfo,
              spill_id: spillId,
              inv_no: spill.inv_no,
              savings: spill.ref_no,
              response_time: spill.resp_time,
              final_contractor_invoice: spill.final_inv,
              contractor_invoice: spill.contractor_inv,
              pix: spill.pix ? moment(spill.pix).utc(true) : null,
              trans_to_ct: spill.got_5800
                ? moment(spill.got_5800).utc(true)
                : null,
              waste_doc: spill.waste_doc
                ? moment(spill.waste_doc).utc(true)
                : null,
              pay_by: spill.pes_invoice
                ? moment(spill.pes_invoice).utc(true)
                : null,
              spill_summary: spill.spill_summary
                ? moment(spill.spill_summary).utc(true)
                : null,
              contractor_inv: spill.closure_packet
                ? moment(spill.closure_packet).utc(true)
                : null,
              contractor_paid: spill.closure_letter
                ? moment(spill.closure_letter).utc(true)
                : null,
              pes_paid: spill.project_billing
                ? moment(spill.project_billing).utc(true)
                : null,
            };
            Object.keys(customAdminObject).forEach(
              (k) =>
                !(customAdminObject[k] !== null) && delete customAdminObject[k]
            );

            await models.SpillAdmins.create(customAdminObject);
          }

          // Spill Recipients

          const spillRecipientsInOldDB = spillRecipientsData[0].filter(
            (x) => x.incident === spill.id
          );
          let bulkRecipients = [];

          for (let recipient of spillRecipientsInOldDB) {
            const userInOldDB = userDataHash[recipient.person];

            const usersInDB =
              usersNewDataHash[`${userInOldDB.email}|${userInOldDB.phone}`];

            const spillRecipientsObject = {
              spill_id: spillId,
              user_id: usersInDB?.id,
            };

            bulkRecipients.push(spillRecipientsObject);
          }
          bulkRecipients.length > 0 &&
            (await models.Recipients.bulkCreate(bulkRecipients));
          bulkRecipients = [];
        }
      }
    }
  } catch (error) {
    console.log(error);
  }
};

// Please add some services from real DB due to name match check
// Convert description datavalue from string to TEXT in database and model
const addFailure = async (
  connection,
  attachmentId,
  errorMessage,
  oldPath,
  newPath
) => {
  const querry = `INSERT INTO upload_failure_history (attachment_id, error_message, old_path, new_path) VALUES (${attachmentId}, "${errorMessage}","${oldPath}","${newPath}")`;
  await connection.execute(querry);
};
export const uploadFilesToS3 = async () => {
  try {
    //creating connection with spills db
    console.log("Uploading files to s3");
    const connection = await mysql.createConnection({
      host: MIGRATION_HOST,
      user: MIGRATION_USERNAME,
      password: MIGRATION_PASSWORD,
      database: MIGRATION_DATABASE_NAME,
    });

    await connection.execute("TRUNCATE `spill`.upload_failure_history");

    //selecting legacy attachments

    let [rows] = await connection.execute(
      "SELECT path, incident, note, name, id FROM `spill`.attachment where id > 456000" //reading data from source database
    );

    let [uploadedRows] = await connection.execute(
      "SELECT attachment_id FROM `spill`.s3_upload_history"
    );

    // getting path of the legacy attachments
    const osama = "../../../../../";
    const home = osama + "../";
    const root = home + "../";
    const mnt = root + "mnt/";
    const spillAttach = mnt + "spill-attach/";
    const oldData = spillAttach + "olddata/";
    const spillFiles = oldData + "spill-files/";

    let count = 0;
    let failureCount = 0;
    let uploadingCount = 0;
    let skippedCount = 0;
    for (let attachment of rows) {
      // setting the file path by concatenating the relative path stored in db and previous absolute path
      const combinedPath = spillFiles + attachment.path;
      // new path for s3 bucket
      const newPath =
        attachment.incident +
        "/note/" +
        attachment.note +
        "/" +
        attachment.name;

      //checking if attachment is uploaded previously or not
      if (!uploadedRows.find((x) => x.attachment_id === attachment.id)) {
        // checking if legacy file exists
        if (fs.existsSync(combinedPath)) {
          uploadingCount += 1;
          // uploading to S3
          const uploadResponse = await uploadFileToS3Bucket(
            combinedPath,
            newPath
          );

          //If upload successfull

          if (uploadResponse.key || uploadResponse.Key) {
            //inserting into the s3 upload history table
            uploadingCount % 100 === 0 &&
              console.log("Files Uploaded to S3 : ", uploadingCount);
            const query = `INSERT INTO s3_upload_history (note_id, spill_id, attachment_id, old_path, new_path) VALUES (${attachment.note}, ${attachment.incident},${attachment.id},"${attachment.path}","${newPath}")`;
            await connection.execute(query);
          } else {
            console.log(" ERROR in uploading, ID ::", attachment.id);
            await addFailure(
              connection,
              attachment.id,
              uploadResponse.message || "No message",
              attachment.path || "No path",
              newPath || "No path"
            );
            failureCount += 1;
            console.log("Failure Count ::", failureCount);
            console.log("S3 Response ::", uploadResponse);
          }
        } else {
          await addFailure(
            connection,
            attachment.id,
            "File not found at path",
            attachment.path || "No path",
            newPath || "No path"
          );
          failureCount += 1;
          console.log("Attachment not Found , ID ::", attachment.id);
          console.log("Path ::", combinedPath);
          console.log("Failure Count ::", failureCount);
        }
      } else {
        skippedCount += 1;
        skippedCount % 5000 === 0 &&
          console.log("Skipped Count ::", skippedCount);
      }
      count += 1;
    }
    console.log("DONE");
    console.log("Failure Count ::", failureCount);
    console.log("Skipped Count ::", skippedCount);
    console.log("Uploading Count ::", uploadingCount);
  } catch (e) {
    console.log(e);
  }
};

export const spillNotesMigration = async () => {
  await truncateTable("spill_notes");
  await spillNotesMigrationHandler(true);
  await spillNotesMigrationHandler(false);
};

export const spillNotesMigrationHandler = async (firstOne) => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  console.log("Spill Notes Migration");

  try {
    const [rows] = await connection.execute(
      `SELECT * FROM spill.note where  ${
        firstOne ? "id < 440001" : "id > 440000"
      }`
    );

    const spillsData = await connection.execute("SELECT * FROM spill.incident");
    const servicesData = await connection.execute(
      "SELECT * FROM spill.service"
    );
    const userData = await connection.execute("SELECT * FROM spill.person");
    const orgsData = await connection.execute("SELECT * FROM spill.org");

    let organizationsInDB = await models.ClientOrganizations.findAll({
      attributes: ["id", "name", "code"],
    });

    organizationsInDB = organizationsInDB.map((organization) => {
      return organization.dataValues;
    });

    let spillsNewDB = await models.Spills.findAll({
      attributes: ["id", "job_no"],
    });

    spillsNewDB = spillsNewDB.map((spill) => {
      return spill.dataValues;
    });

    let usersInNewDB = await models.User.findAll({
      attributes: ["id", "email", "phone"],
    });
    usersInNewDB = usersInNewDB.map((user) => {
      return user.dataValues;
    });

    let servicesInDB = await models.Services.findAll({
      attributes: ["id", "name"],
    });

    servicesInDB = servicesInDB.map((service) => {
      return service.dataValues;
    });

    let notes = [];
    let count = 0;
    console.log("rows ::", rows.length);

    for (let note of rows) {
      if (notes.length >= 1000) {
        await models.SpillNotes.bulkCreate(notes);
        count += 1;
        console.log(count);
        notes = [];
        notes.length = 0;
      }

      let spillJobNumber = null;
      let spillsInDB = null;

      const spillInOldDB = spillsData[0].find((x) => x.id === note.incident);
      const servicesInOldDB = servicesData[0].find(
        (x) => x.id === note.service
      );

      const orgInOldDB = orgsData[0].find((x) => x.id === spillInOldDB?.org);
      const userInOldDB = userData[0].find((x) => x.id === note.person);
      if (spillInOldDB) {
        const orgInArray = organizationsInDB.find(
          (x) => x.name === orgInOldDB?.name
        );

        const spillJobNumberSplitter = spillInOldDB?.num?.split("--");
        const spillOrgCode = orgInArray.code;
        spillJobNumber = `${spillJobNumberSplitter[0].trim()}-${spillOrgCode}-${spillJobNumberSplitter[1].trim()}`;
      }

      if (spillJobNumber) {
        spillsInDB = spillsNewDB.find((x) => x.job_no === spillJobNumber);
      }
      const serviceInDB = servicesInDB.find((service) =>
        service.name.toLowerCase().includes(servicesInOldDB.name.toLowerCase())
      );

      const usersInDB = usersInNewDB.find(
        (x) => x.email === userInOldDB?.email && x.phone === userInOldDB?.phone
      );

      if (spillsInDB) {
        const spillId = spillsInDB?.id;
        const serviceId = serviceInDB.id;
        const serviceName = serviceInDB.name;
        const userId = usersInDB?.id;

        const customNoteObject = {
          spill_id: spillId,
          user_id: userId,
          service_id: serviceId,
          service_type: serviceName,
          rate: note.rate,
          hour: note.hours,
          amount: note.amount,
          description: note.description,
          legacy_id: note.id,
          created_at: note.as_of ? moment(note.as_of).utc(true) : null,
        };
        Object.keys(customNoteObject).forEach(
          (k) => !customNoteObject[k] && delete customNoteObject[k]
        );

        notes.push(customNoteObject);
      }
    }

    if (notes.length > 0) {
      await models.SpillNotes.bulkCreate(notes);

      notes.length = 0;
    }
  } catch (error) {
    console.log("error ::", error);
  }
};

// Please make amount default NULL and datatype to DOUBLE
export const spillReservesMigration = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });
  console.log("Spill Reserves Migration");
  let count = 0;

  try {
    await truncateTable("reserves");
    const [rows] = await connection.execute("SELECT * FROM spill.reserve");
    const spillsData = await connection.execute("SELECT * FROM spill.incident");
    const userData = await connection.execute("SELECT * FROM spill.person");
    const orgsData = await connection.execute("SELECT * FROM spill.org");

    let organizationsInDB = await models.ClientOrganizations.findAll({
      attributes: ["id", "name", "code"],
    });

    organizationsInDB = organizationsInDB.map((organization) => {
      return organization.dataValues;
    });

    let spillsNewDB = await models.Spills.findAll({
      attributes: ["id", "job_no"],
    });

    spillsNewDB = spillsNewDB.map((spill) => {
      return spill.dataValues;
    });

    let usersInNewDB = await models.User.findAll({
      attributes: ["id", "email", "phone"],
    });
    usersInNewDB = usersInNewDB.map((user) => {
      return user.dataValues;
    });

    let reserves = [];
    console.log("Length ::", rows.length);

    for (let reserve of rows) {
      try {
        count += 1;
        if (reserves.length >= 1000) {
          await models.Reserves.bulkCreate(reserves);
          reserves = [];
          console.log(count);
          reserves.length = 0;
        }
        let spillJobNumber = null;
        let spillsInDB = null;

        let spillInOldDB = spillsData[0].filter(
          (x) => x.id === reserve.incident
        )[0];
        let userInOldDB = userData[0].filter(
          (x) => x.id === reserve.approved_by
        )[0];
        let orgInOldDB = orgsData[0].filter(
          (x) => x.id === spillInOldDB?.org
        )[0];

        if (spillInOldDB) {
          let orgInArray = organizationsInDB.filter(
            (x) => x.name === orgInOldDB?.name
          );

          const spillJobNumberSplitter = spillInOldDB?.num?.split("--");
          let spillOrgCode = orgInArray[0].code;
          spillJobNumber = `${spillJobNumberSplitter[0].trim()}-${spillOrgCode}-${spillJobNumberSplitter[1].trim()}`;
        }

        if (spillJobNumber) {
          spillsInDB = spillsNewDB.find((x) => x.job_no === spillJobNumber);
        }

        let usersInDB = usersInNewDB.find(
          (x) =>
            x.email === userInOldDB?.email && x.phone === userInOldDB?.phone
        );

        if (spillsInDB) {
          let spillId = spillsInDB?.id;
          let userId = usersInDB?.id;

          let customReserveObject = {
            spill_id: spillId,
            user_id: userId,
            amount: reserve.amount,
            legacy_id: reserve.id,
            created_at: reserve.as_of ? moment(reserve.as_of).utc(true) : null,
          };
          Object.keys(customReserveObject).forEach(
            (k) =>
              !(customReserveObject[k] !== null) &&
              delete customReserveObject[k]
          );

          reserves.push(customReserveObject);
        }
      } catch (err) {
        console.log("Err ::", err);
      }
    }
    if (reserves.length > 0) {
      await models.Reserves.bulkCreate(reserves);
      count += 1;

      reserves.length = 0;
    }
  } catch (error) {
    console.log(error);
  }
};

// for this DB must have contractors and addresses.
// change the database name from legacy to new databse in .env

export const syncSpillsID = async () => {
  console.log("syncing spill ids");
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  const [oldSpillsData] = await connection.execute(
    "SELECT id, num, org FROM spill.incident"
  );

  let spillsData = await models.Spills.findAndCountAll();
  spillsData = spillsData.rows.map((org) => org.dataValues);
  const [oldOrgsData] = await connection.execute(
    "SELECT id, name, code FROM spill.org"
  );

  let orgsData = await models.ClientOrganizations.findAndCountAll();
  orgsData = orgsData.rows.map((org) => org.dataValues);
  let count = 0;

  for (let oldSpill of oldSpillsData) {
    const orgInOldDB = oldOrgsData.filter((org) => org.id === oldSpill.org)[0];

    const orgInNewDB = orgsData.filter(
      (org) => org.name === orgInOldDB.name
    )[0];

    const spillJobNumber = `${oldSpill.num.split("--")[0].trim()}-${
      orgInNewDB.code
    }-${oldSpill.num.split("--")[1].trim()}`;

    const spillInNewDB = spillsData.filter(
      (spill) => spill.job_no === spillJobNumber
    )[0];

    count += 1;
    count % 100 === 0 && console.log(count);
    const query = `INSERT INTO spill_mapper (old_spill_id, new_spill_id) VALUES (${oldSpill.id}, ${spillInNewDB.id})`;
    await connection.execute(query);
  }
  console.log("done");
};

export const updateS3UploadHistory = async () => {
  console.log("Updating S3 Uplaod History");
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  console.log("Retrieving spill ids");
  console.log("Retrieving note ids (will take a bit)");

  await truncateTable("updated_upload_history_records");
  await truncateTable("update_upload_history_failures");

  const temp = await models.Spills.findAll({
    attributes: ["id", "legacy_id"],
  });
  const spills = temp.map((x) => x.dataValues);
  const temp2 = await models.SpillNotes.findAll({
    attributes: ["id", "legacy_id"],
  });
  const noteIds = temp2.map((x) => x.dataValues);

  console.log("Getting History");
  const [history] = await connection.execute(
    "SELECT * FROM spill.s3_upload_history "
  );
  let count = 0;
  let failureCount = 0;
  let bulkHistory = [];
  const myHash = ({ legacy_id }) => `${legacy_id}`;
  const spillsHash = Object.fromEntries(spills.map((x) => [myHash(x), x]));
  const notesHash = Object.fromEntries(noteIds.map((x) => [myHash(x), x]));

  for (let index in history) {
    const historyTemp = history[index];
    try {
      historyTemp.spill_id = spillsHash[historyTemp.spill_id]?.id;

      historyTemp.note_id = notesHash[historyTemp.note_id]?.id;

      bulkHistory.push(historyTemp);
      if (bulkHistory.length > 1000) {
        count += 1;

        await models.UpdatedUploadHistoryRecords.bulkCreate(bulkHistory);
        console.log(count);
        bulkHistory = [];
      }
    } catch (error) {
      console.log("Error ::", error);
      console.log("index ::", index);
      console.log("history ::", history[index]);
      console.log(
        "note id ::",
        noteIds.find((noteId) => noteId.legacy_id === history[index].note_id)
      );
      failureCount++;
      await models.UpdateUploadHistoryFailures.create(history[index]);
      console.log("Failure Count ::", failureCount);
    }
  }
  bulkHistory.length > 0 &&
    (await models.UpdatedUploadHistoryRecords.bulkCreate(bulkHistory));

  console.log("done");
};

export const runMigrateNoteAttachments = async (req, res) => {
  res.status(200).json({
    data: "Starting Note Attachments Migration",
  });

  await migrateNoteAttachments();
  console.log("Done");
};

export const migrateNoteAttachments = async () => {
  const connection = await mysql.createConnection({
    host: MIGRATION_HOST,
    user: MIGRATION_USERNAME,
    password: MIGRATION_PASSWORD,
    database: MIGRATION_DATABASE_NAME,
  });

  await truncateTable("note_attachments");

  console.log("Migrating Note Attachments");

  console.log("getting legacy attachments");

  const [legacyAttachments1] = await connection.execute(
    "SELECT id, bytes, mime, name FROM spill.attachment where id < 350000"
  );

  const [legacyAttachments2] = await connection.execute(
    "SELECT id, bytes, mime, name FROM spill.attachment where id > 349999"
  );
  const myHash = ({ id }) => `${id}`;
  const legacyAttachmentHash1 = Object.fromEntries(
    legacyAttachments1.map((x) => [myHash(x), x])
  );
  const legacyAttachmentHash2 = Object.fromEntries(
    legacyAttachments2.map((x) => [myHash(x), x])
  );

  const temp = await models.UpdatedUploadHistoryRecords.findAndCountAll();
  const history = temp.rows.map((row) => row.dataValues);
  let bulkAttachments = [];
  let count = 0;
  let biggerCount = 0;
  console.log("Starting");

  console.log("Length ::", history.length);
  for (let attachment of history) {
    count += 1;
    const legacyAttachment =
      legacyAttachmentHash1[attachment.attachment_id] ||
      legacyAttachmentHash2[attachment.attachment_id];

    const noteAttachmentToCreate = {
      contractor_id: null,
      type: legacyAttachment?.mime || null,
      url_link: null,
      key: attachment.new_path,
      spill_note_id: attachment.note_id,
      size: legacyAttachment?.bytes || null,
      name: legacyAttachment?.name || null,
    };
    bulkAttachments.push({
      ...noteAttachmentToCreate,
    });
    if (count > 1000) {
      await models.NoteAttachments.bulkCreate(bulkAttachments);
      bulkAttachments = [];
      biggerCount += 1;
      console.log(" Done ::", biggerCount);
      count = 0;
    }
  }
  await models.NoteAttachments.bulkCreate(bulkAttachments);
  connection.destroy();
};

const handleExceptions = async () => {
  await models.Spills.update(
    { status: "Closed: Payment Pending" },
    { where: { status_id: 10 } }
  );
  await models.Spills.update(
    { status: "Closed: Invoice Submitted to Client" },
    { where: { status_id: 9 } }
  );
};

export const adjustAdminsData = async (req, res) => {
  res.status(200).json({
    data: "Adjusting Admins",
  });
  // const idHash = ({ id }) => `${id}`;
  // const incidentHash = ({ incident }) => `${incident}`;
  // const nameHash = ({ name }) => `${name}`;
  // const emailPhoneHash = ({ email, phone }) => `${email}|${phone}`;
  // const addressHash = ({ entity_id, city, address, state, entity_type }) =>
  //   `${entity_id}|${city}|${address}|${state}|${entity_type}`;

  // const spillInfoDataHash = Object.fromEntries(
  //   spillInfoData[0].map((x) => [incidentHash(x), x])
  // );

  // const contractorsInNewDB = extractRows(
  //   await models.Contractors.findAndCountAll()
  // );

  // const contractorsNewDataHash = Object.fromEntries(
  //   contractorsInNewDB.map((x) => [nameHash(x), x])
  // );

  // const addressesInNewDB = extractRows(
  //   await models.Addresses.findAndCountAll()
  // );

  // const addressesNewDataHash = Object.fromEntries(
  //   addressesInNewDB.map((x) => [addressHash(x), x])
  // );

  const spills = await models.Spills.findAll({
    include: [
      {
        model: models.Connections,
        as: "connections",
        paranoid: false,
        include: {
          model: models.SpillContractors,
        },
      },
    ],
  });
  const spillAdmins = await models.SpillAdmins.findAll({
    where: { contractor_id: null },
  });
  console.log("Total ::", spillAdmins.count);
  let updated = 0;
  let skipped = 0;
  for (let admin of spillAdmins) {
    const relevantSpill = spills.find((spill) => {
      // console.log("admin :", admin);
      // console.log("spill :", spill);
      return spill.dataValues.id === admin.dataValues.spill_id;
    })?.dataValues;
    const relevantContractor =
      relevantSpill?.connections[0]?.dataValues?.spill_contractors[0]
        ?.dataValues;
    // console.log("relevantSpill :", relevantSpill.connections[0]?.dataValues);

    if (relevantContractor) {
      updated += 1;
      await models.SpillAdmins.update(
        {
          contractor_id: relevantContractor.contractor_id,
          contractor_address_id: relevantContractor.address_id,
        },
        {
          where: { id: admin.dataValues.id },
        }
      );
    } else {
      skipped += 1;
    }
  }
  console.log("Done");
  console.log("Updated Records :: ", updated);
  console.log("Skipped Records ::", skipped);
};

// Need this in next section

// export const spillNoteAttachmentsMigration = async () => {
//   const connection = await mysql.createConnection({
//     host: MIGRATION_HOST,
//     user: MIGRATION_USERNAME,
//     password: MIGRATION_PASSWORD,
//     database: MIGRATION_DATABASE_NAME,
//   });

//   res.status(200).json({
//     data: "adding attachments",
//   });

//   try {
//     const [rows] = await connection.execute("SELECT * FROM spill.attachment");
//     const notesData = await connection.execute("SELECT * FROM spill.note");
//     const spillsData = await connection.execute("SELECT * FROM spill.incident");

//     for (let attachment of rows) {
//       let spillInOldDB = spillsData[0].filter(
//         (x) => x.id === attachment.incident
//       )[0];
//       let notesInOldDB = notesData[0].filter(
//         (x) => x.id === attachment.note
//       )[0];

//       let spillsInDB = await models.Spills.find({
//         where: { job_no: spillInOldDB.num },
//       });
//       let notesInDB = await models.Notes.find({
//         where: {
//           description: notesInOldDB.description,
//           hour: notesInOldDB.hours,
//           rate: notesInOldDB.rate,
//           amount: notesInOldDB.amount,
//         },
//       });

//       console.log("note found =============+>>>>> ", notesInDB);

//       if (attachment.incident && attachment.note) {
//         // let spillId = spillsInDB?.dataValues?.id;
//         let noteId = notesInDB.dataValues.id;

//         let customNoteAttachmentObject = {
//           // contractor_id: attachment,
//           type: attachment.mimi,
//           url_link: attachment.url_link,
//           spill_note_id: noteId,
//           created_at: attachment.as_of,
//         };
//         //cleaning the object
//         Object.keys(customNoteAttachmentObject).forEach(
//           (k) => !(customNoteAttachmentObject[k] !== null) && delete customNoteAttachmentObject[k]
//         );

//         await models.SpillNotes.create(customNoteAttachmentObject);
//       }
//     }
//   } catch (error) {
//     console.log(error);
//   }
// };
