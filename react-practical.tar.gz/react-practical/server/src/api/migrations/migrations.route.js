import * as migrationController from "./migrations.controller";

export default (route) => {
  //        COMMENT AS SHOULD NOT BE USED FOR RUNNING MIGRATIONS ONLY
  // route.get("/migration/contractor", migrationController.contractorMigration);
  // route.get("/migration/agency", migrationController.agencyMigration);
  // route.get(
  //   "/migration/clientOrganization",
  //   migrationController.organizationMigration
  // );
  // route.get("/migration/user", migrationController.userMigration);
  // route.get(
  //   "/migration/salePersonID",
  //   migrationController.assignSalesPersonsToOrgs
  // );
  // route.get("/migration/spill", migrationController.spillMigration);
  // route.get("/migration/spillNotes", migrationController.spillNotesMigration);
  // route.get(
  //   "/migration/spillReserves",
  //   migrationController.spillReservesMigration
  // );
  // route.get("/migration/status", migrationController.migrateStatus);
  // route.get("/migration/material", migrationController.migrateMaterial);
  // route.get(
  //   "/migration/tiers",
  //   migrationController.contractorAddressesTierUpdation
  // );
  // route.get("/migration/syncSpillId", migrationController.syncSpillsID);
  // route.get(
  //   "/migration/updateS3UploadHistory",
  //   migrationController.updateS3UploadHistory
  // );
  // route.get(
  //   "/migration/migrateNoteAttachments",
  //   migrationController.runMigrateNoteAttachments
  // );
  // route.get("/migration/runAll", migrationController.runAllMigrations);
  // route.get("/migration/adjustAdmins", migrationController.adjustAdminsData);
  route.get("/migration/calculateSum", migrationController.calculateSum);
};
