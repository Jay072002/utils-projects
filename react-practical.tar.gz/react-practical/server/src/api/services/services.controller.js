import models from '../../models';
import pagination from '../../util/pagination';

export const createNewService = async (req, res, next) => {
  try {
    const {
      name,
      order,
      emailNotification,
      is_default,
      report_number,
      ip_address_identifier,
      owner,
      salvage_containers,
      samples,
      cost,
      establish_lane_closure,
      excavation_begun,
      excavation_completed,
      task_associated_relevance,
      time,
      date,
      upload_attachment,
      projected_eta,
      actual_eta,
      state_incident_no,
      national_incident_no,
      category_id,
    } = req.body;

    const contractor = await models.Services.create({
      name,
      order,
      email_notifications: emailNotification,
      report_number: report_number,
      is_default,
      ip_address_identifier,
      owner,
      salvage_containers,
      samples,
      cost,
      establish_lane_closure,
      excavation_begun,
      excavation_completed,
      task_associated_relevance,
      time,
      date,
      upload_attachment,
      projected_eta,
      actual_eta,
      state_incident_no,
      national_incident_no,
      category_id,
    });
    res.status(200).json({
      data: contractor,
    });
  } catch (err) {
    let message;
    switch (err.message) {
      case 'Validation error':
        message = 'Please fill out all the fields';
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};
export const getAllServices = async (req, res) => {
  const { page } = req.query;

  const { limit, offset, current } = pagination(page);

  try {
    const services = await models.Services.findAll({
      paranoid: false,
      order: [['order', 'ASC']],
    });

    const total = Math.ceil(services.count / limit) || 0;

    res.status(200).json({
      data: services,
      pagination: {
        current: current > total ? total : current,
        total,
      },
    });
  } catch (err) {
    console.log(err);
  }
};

export const editServices = (req, res, next) => {
  const {
    id,
    name,
    emailNotification,
    order,
    is_default,
    report_number,
    ip_address_identifier,
    owner,
    salvage_containers,
    samples,
    cost,
    establish_lane_closure,
    excavation_begun,
    excavation_completed,
    task_associated_relevance,
    time,
    date,
    upload_attachment,
    projected_eta,
    actual_eta,
    active,
    state_incident_no,
    national_incident_no,
    category_id,
  } = req.body;

  const serviceToEdit = {
    name,
    email_notifications: emailNotification,
    order,
    is_default,
    report_number,
    ip_address_identifier,
    owner,
    salvage_containers,
    samples,
    cost,
    establish_lane_closure,
    excavation_begun,
    excavation_completed,
    task_associated_relevance,
    time,
    date,
    upload_attachment,
    projected_eta,
    actual_eta,
    active,
    state_incident_no,
    national_incident_no,
    category_id,
  };

  models.Services.update(serviceToEdit, {
    where: {
      id,
    },
  })
    .then((response) => {
      res.json({ success: true, data: { ...serviceToEdit, id } });
    })
    .catch((err) => next(err));
};

export const reorderServices = async (req, res, next) => {
  const { reorderedServices } = req.body;

  try {
    await Promise.all(
      reorderedServices.map((service) => {
        const sortService = models.Services.update(
          { order: service.order },
          { where: { id: service.id } }
        );
        return sortService;
      })
    );

    res.json({ success: true, data: reorderedServices });
  } catch (error) {
    console.log(error);
  }
};

export const changeServiceStatus = async (req, res, next) => {
  const { id, active } = req.body;
  const services = await models.Services.update(
    { active: active },
    { where: { id } }
  );
  res.json({ success: true });
};

export const getCategories = async (req, res, next) => {
  try {
    const categories = await models.Categories.findAll();
    res.json({ success: true, data: categories });
  } catch (error) {
    console.log(error);
    res.json({ success: false, error });
  }
};
