import * as servicesController from "./services.controller";

export default (route) => {
  route.get("/services/all", servicesController.getAllServices);
  route.post("/services/createNew", servicesController.createNewService);
  route.post("/services/update", servicesController.editServices);
  route.post("/services/reorder", servicesController.reorderServices);
  route.post("/services/changeStatus", servicesController.changeServiceStatus);
  route.get("/services/getCategories", servicesController.getCategories);
};
