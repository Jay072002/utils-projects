import * as downloadController from "./download.controller";

export default (route) => {
  route.post("/download/data", downloadController.download);
  route.post("/download/file", downloadController.downloadFile);
  route.get("/download/all", downloadController.downloadAll);
  route.get("/download/admin", downloadController.downloadAdminFiles);
  route.post("/download/getUrl", downloadController.getSignedUrl);
};
