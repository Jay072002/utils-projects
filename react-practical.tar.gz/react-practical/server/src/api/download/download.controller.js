import _, { update } from 'lodash';
import fs from 'fs';
import AWS from 'aws-sdk';
import path from 'path';
import downloadFileFromUrl from 'download';

import models from '../../models';
import {
  createZipFile,
  buildSearchQuery,
  extractNameFromPathString,
  extractNamesFromPathArray,
  findAssociatedServices,
  generateAutoServiceNote,
  ACTIONS,
  CONSTANTS,
  generateHtml,
  getAddedObj,
  searchDownloadObjects,
  isPESUser,
} from '../../util';
import { genericSender } from '../../services/email/emailProvider';
import { createNote } from '../spills/spill.controller';
import { searchSpillsForCSV } from './download.service';

const accessKey = process.env.AWS_S3_ACCESS_KEY_ID;
const secretKey = process.env.AWS_S3_SECRET_ACCESS_KEY;
const bucketName = process.env.AWS_S3_BUCKET;

const s3 = new AWS.S3({
  accessKeyId: accessKey,
  secretAccessKey: secretKey,
});

export const signURL = (key, expires) => {
  // TODO: method to be placed inside s3 util
  return s3.getSignedUrl('getObject', {
    Bucket: process.env.AWS_S3_BUCKET,
    Key: key,
    Expires: expires || 500,
  });
};

export const download = async (req, res) => {
  const { type, searchText, searchFilters, timeZoneOffSet, subType } = req.body;
  const { role, contractor_id } = req.user;

  try {
    let responsedata;
    let responseType;

    switch (type) {
      case 'User': {
        try {
          const query = await buildSearchQuery(
            searchText,
            type,
            role,
            searchFilters?.searchFields,
            searchFilters?.activeFilter,
            contractor_id
          );

          let users = await models.User.findAll({
            ...query,
          });

          responsedata = users.map((x) => x.dataValues);
          responseType = type;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      case 'Agency': {
        let where = {};
        if (searchText)
          where = {
            ...where,
            $or: [
              {
                name: {
                  $like: `%${searchText}%`,
                },
              },
            ],
          };

        try {
          let agencies = await models.Agencies.findAll({
            include: [
              {
                model: models.Addresses,
                required: false,
              },
            ],
            where,
            paranoid: false,
          });

          responsedata = agencies;
          responseType = type;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      case 'Contractor': {
        let where = {};
        if (searchText)
          where = {
            ...where,
            $or: [
              {
                name: {
                  $like: `%${searchText}%`,
                },
              },
            ],
          };
        try {
          let completeContractors = [];
          const contractors = await models.Contractors.findAll({
            where,
            paranoid: false,
          });

          for (const contractor of contractors) {
            const addresses = await models.Addresses.findAll({
              where: {
                entity_type: 'contractor',
                entity_id: contractor.dataValues.id,
              },
            });
            completeContractors.push({ ...contractor.toJSON(), addresses });
          }

          responsedata = completeContractors;
          responseType = type;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      case 'Client': {
        let where = {};
        if (searchText)
          where = {
            ...where,
            $or: [
              {
                name: {
                  $like: `%${searchText}%`,
                },
              },
              {
                code: {
                  $like: `%${searchText}%`,
                },
              },
            ],
          };
        try {
          let clientOrganizations = await models.ClientOrganizations.findAll({
            include: [
              {
                model: models.AssociatedOrganizations,
                required: false,
              },
            ],
            where,
            paranoid: false,
          });

          responsedata = clientOrganizations;
          responseType = type;
        } catch (err) {
          console.log(err);
        }
        break;
      }
      case 'SearchResults': {
        let include = [
          {
            model: models.Reserves,
            attributes: ['id', 'amount'],
            required: false,
            paranoid: false,
          },

          {
            model: models.ClientOrganizations,
            attributes: ['name'],
            required: false,
            paranoid: false,
          },
          {
            model: models.User,
            required: false,
            attributes: ['full_name'],
            paranoid: false,
          },
          {
            model: models.SpillAdmins,
            required: false,
            paranoid: false,
            attributes: [
              'pix',
              'waste_doc',
              'spill_summary',
              'contractor_inv',
              'contractor_id',
              'contractor_address_id',
              'contractor_invoice',
              'pes_inv_amount',
              'inv_no',
              'final_contractor_invoice',
              'pay_by',
              'pes_paid',
              'contractor_paid',
              'trans_to_ct',
              'response_time',
            ],
            include: [
              {
                model: models.Contractors,
                required: false,
                paranoid: false,
                attributes: [
                  'id',
                  'name',
                  'address',
                  'city',
                  'state',
                  'country',
                ],
              },
              {
                model: models.Addresses,
                required: false,
                paranoid: false,
                attributes: ['address', 'city', 'state', 'country'],
              },
            ],
          },
        ];
        const searchedSpills = await searchSpillsForCSV(
          searchText,
          req.user,
          false,
          include,
          [
            'id',
            'user_id',
            'org_id',
            'job_no',
            'opened_on',
            'status',
            'address',
            'quantity_type_released',
            'amount_released',
            'city',
            'state',
            'country',
            'contact',
            'type',
            'claim_no',
            'closed_on',
            'material',
            'status_id',
            'un_no',
            'latitude',
            'longitude',
            'onsite_poc_name',
            'total_notes_sum',
          ]
        );

        console.log('searchedSpills :', searchedSpills.spillsData.length);

        responsedata = searchDownloadObjects(
          subType,
          timeZoneOffSet,
          searchedSpills.spillsData
        );
      }
      default:
        null;
    }

    res.status(200).json({
      success: true,
      data: responsedata,
      type: responseType,
    });
  } catch (error) {
    console.log(error);
  }
};

export const downloadFile2 = async (req, res, next) => {
  const { filePath } = req.body;
  const options = {
    root: '.',
    dotfiles: 'deny',
    headers: {
      'x-timestamp': Date.now(),
      'x-sent': true,
    },
  };
  res.sendFile(filePath, options, function(err) {
    if (err) {
      res.status(500);
    } else {
      console.log('Sent:', filePath);
    }
  });
};

export const downloadFile = async (req, res, next) => {
  const { key, spillId, ipAddress } = req.body.data;

  const options = {
    root: '.',
    dotfiles: 'deny',
    headers: {
      'x-timestamp': Date.now(),
      'x-sent': true,
    },
  };
  createDownloadFileAttachmentNote(
    [extractNameFromPathString(key)],
    req.user.dataValues,
    spillId,
    ipAddress
  );

  s3.getSignedUrl(
    'getObject',
    {
      Bucket: process.env.AWS_S3_BUCKET,
      Key: key,
      Expires: 20,
    },
    (error, url) => {
      if (error) {
        console.log(error);
      }
      res.send({ url });
    }
  );
};

export const getSignedUrl = async (req, res, next) => {
  const { urlList } = req.body;

  const listToReturn = urlList.map((urlToSign) => ({
    key: urlToSign,
    url: signURL(urlToSign),
  }));

  res.status(200).json({
    success: true,
    data: listToReturn,
  });
};

/************** All Files Download ********************/
export const downloadAll = async (req, res, next) => {
  const { id, type: fileType, spillId, ipAddress } = req.query;
  let adminFilesKeysArray = [];
  let noteFilesKeysArray = [];
  let localFilesArray = [];
  let adminFiles = [];
  let noteFiles = [];
  const adminDestination = path.resolve(__dirname, '../../../uploads/admin');
  const notesDestination = path.resolve(__dirname, '../../../uploads/notes');
  const noteAllDestination = path.resolve(
    __dirname,
    '../../../uploads/notesAll'
  );
  const allAttachmentsDestination = path.resolve(
    __dirname,
    '../../../uploads/all'
  );

  if (!['admin', 'note', 'all', 'note_all'].includes(fileType)) {
    res.status(400);
    return;
  }

  const onEnd = () => {
    const options = {
      root: './temp-zip-files',
      dotfiles: 'deny',
      headers: {
        'x-timestamp': Date.now(),
        'x-sent': true,
      },
    };
    res.sendFile(`${timeStamp}.zip`, options, function(err) {
      if (err) {
        next(err);
      } else {
        fs.unlink(`temp-zip-files/${timeStamp}.zip`, (err) => {
          if (err) console.log('WARNING! Unable to delete temporary file.');
        });
        console.log('Sent:', `${timeStamp}.zip`);
      }
    });
  };

  const timeStamp = new Date().toISOString();

  if (fileType === 'admin' || fileType === 'all') {
    let promises = [];

    const spillAdmins = await models.SpillAdmins.findAll({
      where: {
        spill_id: id,
      },
    });
    for (const admin of spillAdmins) {
      promises.push(
        models.SpillAttachments.findAll({ where: { spill_admin_id: admin.id } })
      );
    }
    const responses = await Promise.all(promises);
    for (const response of responses) {
      for (const row of response) {
        if (row.dataValues.key) {
          adminFilesKeysArray.push(row.dataValues.key);
          let keyNameSet = row.dataValues.key.split('/');
          let file = adminDestination + '/' + keyNameSet[keyNameSet.length - 1];
          let localFile =
            allAttachmentsDestination + '/' + keyNameSet[keyNameSet.length - 1];
          localFilesArray.push(localFile);
          adminFiles.push(file);
        }
      }
    }
  }
  if (fileType === 'note' || fileType === 'all') {
    let promises = [];
    const spillNotes = await models.SpillNotes.findAll({
      where: {
        spill_id: id,
      },
    });
    for (const note of spillNotes) {
      promises.push(
        models.NoteAttachments.findAll({ where: { spill_note_id: note.id } })
      );
    }
    const responses = await Promise.all(promises);
    for (const response of responses) {
      for (const row of response) {
        if (row.dataValues.key) {
          noteFilesKeysArray.push(row.dataValues.key);
          let keyNameSet = row.dataValues.key.split('/');
          let file = notesDestination + '/' + keyNameSet[keyNameSet.length - 1];
          let localFile =
            allAttachmentsDestination + '/' + keyNameSet[keyNameSet.length - 1];
          localFilesArray.push(localFile);
          noteFiles.push(file);
        }
      }
    }
  }

  if (fileType === 'note_all') {
    let promises = [];
    promises.push(
      models.NoteAttachments.findAll({ where: { spill_note_id: id } })
    );
    const responses = await Promise.all(promises);
    for (const response of responses) {
      for (const row of response) {
        if (row.dataValues.key) {
          noteFilesKeysArray.push(row.dataValues.key);
          let keyNameSet = row.dataValues.key.split('/');
          let file =
            noteAllDestination + '/' + keyNameSet[keyNameSet.length - 1];
          noteFiles.push(file);
        }
      }
    }
  }
  if (fileType === 'admin') {
    await downloadFilesFromS3(adminFilesKeysArray, adminDestination);
    console.log(
      adminFiles,
      '--------_Local Admin Files are been created here now -----------'
    );

    await createZipFile(adminFiles, onEnd, `temp-zip-files/${timeStamp}.zip`);
  } else if (fileType === 'note') {
    await downloadFilesFromS3(noteFilesKeysArray, notesDestination);
    console.log(
      noteFiles,
      '--------_Local Notes Files are been created here now -----------'
    );

    await createZipFile(noteFiles, onEnd, `temp-zip-files/${timeStamp}.zip`);
  } else if (fileType === 'all') {
    await downloadFilesFromS3(
      noteFilesKeysArray.concat(adminFilesKeysArray),
      allAttachmentsDestination
    );
    console.log(
      localFilesArray,
      '--------------Local Files created -----------'
    );

    await createZipFile(
      localFilesArray,
      onEnd,
      `temp-zip-files/${timeStamp}.zip`
    );
  } else if (fileType === 'note_all') {
    const resp = await downloadFilesFromS3(
      noteFilesKeysArray,
      noteAllDestination
    );
    console.log(
      noteFiles,
      '--------_Local Notes Files are been created here now -----------'
    );

    await createZipFile(noteFiles, onEnd, `temp-zip-files/${timeStamp}.zip`);
  }

  const allFiles = [...localFilesArray, ...adminFiles, ...noteFiles];

  createDownloadFileAttachmentNote(
    [...new Set(extractNamesFromPathArray(allFiles))],
    req.user.dataValues,
    spillId,
    ipAddress
  );
};

/************** Admin Files Download ********************/
export const downloadAdminFiles = async (req, res, next) => {
  const { id: spillAdminId } = req.query;
  let adminFilesKeysArray = [];
  let localFilesArray = [];
  const destination = path.resolve(__dirname, '../../../uploads/admin');

  const timeStamp = new Date().toISOString();

  const onEnd = () => {
    const options = {
      root: './temp-zip-files',
      dotfiles: 'deny',
      headers: {
        'x-timestamp': Date.now(),
        'x-sent': true,
      },
    };

    res.sendFile(`${timeStamp}.zip`, options, function(err) {
      if (err) {
        next(err);
      } else {
        fs.unlink(`temp-zip-files/${timeStamp}.zip`, (err) => {
          if (err) console.log('WARNING! Unable to delete temporary file.');
        });
        console.log('Sent:', `${timeStamp}.zip`);
      }
    });
  };
  const attachments = await models.SpillAttachments.findAll({
    where: { spill_admin_id: spillAdminId },
  });

  for (const attachment of attachments) {
    adminFilesKeysArray.push(attachment.dataValues.key);
    let keyNameSet = attachment.dataValues.key.split('/');
    let file = destination + '/' + keyNameSet[keyNameSet.length - 1];
    localFilesArray.push(file);
  }

  await downloadFilesFromS3(adminFilesKeysArray, destination);
  console.log(
    localFilesArray,
    '--------_Local Files are been created here now -----------'
  );

  await createZipFile(
    localFilesArray,
    onEnd,
    `temp-zip-files/${timeStamp}.zip`
  );
};

const downloadFilesFromS3 = async (adminFilesKeysArray, destination) => {
  for (let s3Key of adminFilesKeysArray) {
    try {
      const url = signURL(s3Key, 20);
      console.log('url :', url);

      await downloadFileFromUrl(url, destination);
      console.log('File --- ', s3Key, '-----------Downloaded-----------');
    } catch (err) {
      console.log(err);
    }
  }
};

const createDownloadFileAttachmentNote = async (
  filesDownloaded,
  user,
  spillId,
  ipAddress = 'Not Known'
) => {
  if (isPESUser(user.role.role)) return;
  let spillObj = await models.Spills.findOne({
    where: { id: spillId },
    include: [{ model: models.ClientOrganizations }],
  });
  spillObj = spillObj.dataValues;
  spillObj.client_organization = spillObj.client_organization.dataValues;

  let recipients = await models.Recipients.findAll({
    where: { spill_id: spillId },
    include: [{ model: models.User }],
  });
  recipients = recipients.map(
    (recipient) => recipient.dataValues.user.dataValues
  );

  const associatedService = await findAssociatedServices(
    spillObj.client_organization.id,
    CONSTANTS.DOWNLOAD_ATTACHMENT_SERVICE_NAME
  );
  if (!associatedService?.length) return;

  const note = generateAutoServiceNote(
    associatedService[0].dataValues,
    associatedService[0].service.dataValues.id,
    user.id,
    CONSTANTS.DOWNLOAD_ATTACHMENT_SERVICE_NAME,
    {
      filesDownloaded,
      name: user.full_name,
      ipAddress,
    }
  );

  const changes = getAddedObj(note);

  createNote([note], spillId, [], []);

  if (
    !recipients?.length ||
    !associatedService[0].service.dataValues.email_notifications
  )
    return;

  const dataForEmail = {
    sendEmailTo: recipients.map((recipient) => recipient.email),
    sendEmailFrom: user.email,
    ...generateHtml(
      { changes, spillObj: spillObj, userName: user.full_name, note },
      ACTIONS.ADD_NOTE
    ),
  };
  genericSender(dataForEmail);
};
