import Moment from "moment";
import models from "../../models";
import {
  ROLES,
  convertStatuses,
  buildIncludeQueryForConnections,
  convertDateToDateRange,
} from "../../util";
import pagination from "../../util/pagination";

export const searchSpillsForCSV = async (
  body,
  user,
  paginate = true,
  include,
  attributes
) => {
  const { org_id, contractor_id, contractor_address_id } = user;
  const {
    id,
    role,
    permission,
    job_no,
    statusData,
    opened_on,
    opened_to,
    close_on,
    close_to,
    city,
    state,
    country,
    claim_no,
    type,
    contact,
    responsible,
    address,
    material,
    conditions,
    organizations,
    contractors,
    managers,
    usersForEmail,
    agencies,
    need_5800,
    is_waste,
    has_msds,
    is_hazmat,
    un_no,
    response_sent,
    subrogation,
    amount_released,
    packetReviewUsers,
    quantity_type_released,
    damaged_container_type,
    damaged_type,
    tractor,
    trailer,
    pro,
    location_type,
    drain_impacted,
    waterway_impacted,
    page,
  } = body;

  const { limit, offset, current } = pagination(page);

  const spillPermission =
    permission.toString().toLowerCase() === "true" ? true : false;

  let agencies_id = [];
  let managers_id = [];
  let addresses_id = [];
  let contractors_id = [];
  let usersForEmail_id = [];
  let organizations_id = [];
  let packetReviewUsers_id = [];

  const order = [["created_at", "DESC"]];

  if (organizations && organizations.length > 0) {
    await Promise.all(
      organizations.map((org) => {
        organizations_id.push(org.value);
      })
    );
  }

  if (agencies && agencies.length > 0) {
    await Promise.all(
      agencies.map((agency) => {
        agencies_id.push(agency.value);
      })
    );
  }
  if (contractors && contractors.length > 0) {
    await Promise.all(
      contractors.map((contractor) => {
        const temp_address_id = +contractor.value.split(" ")[1];
        temp_address_id
          ? addresses_id.push(temp_address_id)
          : contractors_id.push(+contractor.value.split(" ")[0]);
      })
    );
  }
  if (managers && managers.length >= 0) {
    await Promise.all(
      managers.map((manager) => {
        managers_id.push(manager.value);
      })
    );
  }
  if (usersForEmail && usersForEmail.length >= 0) {
    const temp = [];
    usersForEmail.map((user) => {
      temp.push(user.spill_ids);
    });
    usersForEmail_id = temp.flat();
  }

  if (packetReviewUsers && packetReviewUsers?.length) {
    packetReviewUsers_id = packetReviewUsers?.map((user) => {
      return user?.value;
    });
  }

  let where = {};
  const checkContractorsAndAgencies =
    agencies_id.length || addresses_id.length || contractors_id.length;
  const spill_ids_contractor_filter = checkContractorsAndAgencies
    ? await buildIncludeQueryForConnections(
        agencies_id,
        addresses_id,
        contractors_id,
        role
      )
    : [];

  if (packetReviewUsers_id.length) {
    include = [
      ...include,
      {
        model: models.PacketReviewerAssignments,
        required: false,
        paranoid: false,
      },
    ];

    where = {
      ...where,
      "$packet_reviewer_assignment.packet_reviewer_user_id$": {
        $in: packetReviewUsers_id,
      },
    };
  }

  where = spill_ids_contractor_filter?.length
    ? {
        ...where,
        id: spill_ids_contractor_filter,
      }
    : checkContractorsAndAgencies
    ? {
        ...where,
        job_no: "0",
      }
    : { ...where };

  where = job_no
    ? {
        ...where,
        job_no: {
          $like: `%${job_no}%`,
        },
      }
    : { ...where };
  where =
    opened_on || opened_to
      ? {
          ...where,
          ...convertDateToDateRange(opened_on, opened_to, "opened_on"),
        }
      : { ...where };

  where =
    close_on || close_to
      ? {
          ...where,
          ...convertDateToDateRange(close_on, close_to, "closed_on"),
        }
      : { ...where };
  where = city
    ? {
        ...where,
        city: {
          $like: `%${city}%`,
        },
      }
    : { ...where };

  where = state ? { ...where, state } : { ...where };
  where = country ? { ...where, country } : { ...where };
  where = claim_no
    ? {
        ...where,
        claim_no: {
          $like: `%${claim_no}%`,
        },
      }
    : { ...where };
  where = type ? { ...where, type } : { ...where };
  where = contact
    ? {
        ...where,
        contact: {
          $like: `%${contact}%`,
        },
      }
    : { ...where };
  where = responsible
    ? {
        ...where,
        responsible: {
          $like: `%${responsible}%`,
        },
      }
    : { ...where };

  where = address
    ? {
        ...where,
        address: {
          $like: `%${address}%`,
        },
      }
    : { ...where };
  where = conditions
    ? {
        ...where,
        conditions: {
          $like: `%${conditions}%`,
        },
      }
    : { ...where };
  where = material
    ? {
        ...where,
        material: {
          $like: `%${material}%`,
        },
      }
    : { ...where };
  where = need_5800 ? { ...where, need_5800 } : { ...where };
  where = is_waste ? { ...where, is_waste } : { ...where };
  where = has_msds ? { ...where, has_msds } : { ...where };
  where = is_hazmat ? { ...where, is_hazmat } : { ...where };
  where = un_no ? { ...where, un_no } : { ...where };
  where = response_sent ? { ...where, response_sent } : { ...where };
  where = subrogation ? { ...where, subrogation } : { ...where };
  where = statusData.length
    ? {
        ...where,
        status: { $in: convertStatuses(statusData, user.role.role) },
      }
    : { ...where };
  where = managers_id.length
    ? {
        ...where,

        user_id: { $in: managers_id },
      }
    : { ...where };

  where = usersForEmail_id.length
    ? {
        ...where,
        id: { $in: usersForEmail_id },
      }
    : { ...where };

  where = amount_released
    ? { ...where, amount_released: +amount_released }
    : { ...where };
  where = quantity_type_released
    ? { ...where, quantity_type_released }
    : { ...where };

  where = damaged_container_type
    ? { ...where, damaged_container_type }
    : { ...where };
  where = damaged_type ? { ...where, damage_type: damaged_type } : { ...where };
  where = location_type ? { ...where, location_type } : { ...where };
  where = drain_impacted ? { ...where, drain_impacted } : { ...where };
  where = waterway_impacted ? { ...where, waterway_impacted } : { ...where };
  where = trailer ? { ...where, trailer } : { ...where };
  where = tractor ? { ...where, tractor } : { ...where };
  where = pro ? { ...where, pro } : { ...where };
  if (role === ROLES.DEMO) {
    where = { ...where, is_demo: true };
  }

  try {
    let spillsData;
    let spillCount;
    let spillQuerry = {
      attributes,
      paranoid: false,
      order,
    };

    switch (role) {
      case ROLES.CONTRACTOR_USER: {
        where = organizations_id.length
          ? { ...where, org_id: { $in: organizations_id } }
          : { ...where };
        spillQuerry = {
          include,
          where,
          ...spillQuerry,
        };
        spillsData = await models.Spills.findAll(spillQuerry);

        break;
      }

      case ROLES.CONTRACTOR_ADMIN: {
        where = organizations_id.length
          ? { ...where, org_id: { $in: organizations_id } }
          : { ...where };
        spillQuerry = {
          include,
          where,
          ...spillQuerry,
        };
        spillsData = await models.Spills.findAll(spillQuerry);

        break;
      }

      case ROLES.CORPORATE_USER: {
        where = org_id ? { ...where, org_id: org_id } : { ...where };
        spillQuerry = {
          include,
          where,
          ...spillQuerry,
        };
        spillsData = await models.Spills.findAll(spillQuerry);

        break;
      }
      default: {
        if (spillPermission) {
          let associatedOrgs = await models.AssociatedOrganizations.findAll({
            where: {
              org_id: org_id,
            },
          });

          let associated_orgs = [org_id];

          associatedOrgs.map((associatedOrgs) => {
            if (organizations_id.includes(associatedOrgs.associated_org_id))
              associated_orgs.push(associatedOrgs.associated_org_id);
          });

          where = associated_orgs.length
            ? { ...where, org_id: { $in: associated_orgs } }
            : { ...where };
          spillQuerry = {
            include,
            where,
            ...spillQuerry,
          };
          spillsData = await models.Spills.findAll(spillQuerry);
        } else {
          where = organizations_id.length
            ? { ...where, org_id: { $in: organizations_id } }
            : { ...where };
          spillQuerry = {
            include,
            where,
            ...spillQuerry,
          };
          spillsData = await models.Spills.findAll(spillQuerry);
        }
      }
    }
    spillCount = await models.Spills.count({ include, where });
    spillsData = spillsData.map((spill) => {
      let closedOn;

      const searchStatusString = spill?.status?.search("Open");
      const searchStatusString2 = spill?.status?.split(":");

      if (
        spill.closed_on &&
        (searchStatusString != -1 || searchStatusString2[1] != " Closed")
      ) {
        closedOn = "Re-Opened";
      } else {
        closedOn = spill.closed_on
          ? Moment(spill.closed_on).format("MMMM DD YYYY hh:mm a")
          : "Still Open";
      }

      spill.dataValues = {
        ...spill.dataValues,
        opened_on: spill.opened_on,
        closed_on: closedOn,
      };
      return spill;
    });

    return { spillsData, count: spillCount };
  } catch (err) {
    console.log(err);
  }
};
