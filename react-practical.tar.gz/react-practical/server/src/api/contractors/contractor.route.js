import * as contractorController from './contractor.controller';

export default (route) => {
  route.get('/contractor/contractors', contractorController.getAllContractors);
  route.post('/contractor/createNew', contractorController.createNewContractor);
  route.post('/contractor/editContractor', contractorController.editContractor);
  route.get(
    '/contractors/withAddress',
    contractorController.getContractorsWithAddress
  );
  route.get(
    '/contractor/contractorERailClassICertifications',
    contractorController.getContractorERailClassICertifications
  );
  route.post(
    '/contractor/contractorCertficates',
    contractorController.contractorCertficates
  );
  route.post(
    '/contractor/deleteContractorCertficates',
    contractorController.deleteContractorCertficates
  );
  route.post('/contractor/do-not-use', contractorController.doNotUseContractor);
};
