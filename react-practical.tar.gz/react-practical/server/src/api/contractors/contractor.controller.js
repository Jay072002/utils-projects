import { Op } from "sequelize";
import models, { sequelize } from "../../models";
import pagination from "../../util/pagination";
import { isNonEmptyAddress } from "../../util/preProcessors";
import { uploadFileToS3Bucket } from "../../util/s3";
import { uniqueIdGenerator } from "../../util/helper";
import fs from "fs";
import moment from "moment";
import { fetchDataFromAttachmentTable } from "../../util/additionalAttachments";
import { TIER_LEVEL } from "../../util/constants";
export const createNewContractor = async (req, res, next) => {
  try {
    const {
      name,
      address,
      city,
      state,
      zipCode,
      country,
      email,
      phone,
      fax,
      tier_level,
      contact,
      addresses,
      haz_waste_hauler,
      license_number,
      license_number_expiry,
      certification_classes,
    } = req.body;

    const contractorObj = {
      name,
      address,
      city,
      state,
      zipCode,
      country,
      email,
      phone,
      tier_level,
      fax,
      contact,
      haz_waste_hauler,
      license_number,
      license_number_expiry,
      certification_classes,
    };

    if (await findContractorsByName(name, -1)) {
      res.status(400).json({
        status: 400,
        message: "Contractor with this name already exists.",
      });
      return;
    }
    const contractor = await models.Contractors.create(contractorObj);
    let newAddresses = [];
    let addressResponse = [];

    for (const index in addresses) {
      if (isNonEmptyAddress(addresses[index])) {
        newAddresses = [
          ...newAddresses,
          {
            ...addresses[index],
            entity_id: contractor.dataValues.id,
            entity_type: "contractor",
          },
        ];
      }
    }

    if (newAddresses.length > 0) {
      addressResponse = await models.Addresses.bulkCreate(newAddresses);
    }
    res.status(200).json({
      data: { ...contractor.toJSON(), addresses: addressResponse },
    });
  } catch (err) {
    console.log(err);
    let message;
    switch (err.message) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};

export const getContractorERailClassICertifications = async (req, res) => {
  try {
    const fetchedERailClassICertifications = await models.ContractorCertificationClasses.findAll(
      {
        where: {
          type: "E-Rail",
          class: "Class I",
        },
      }
    );

    let classIERailCertifications = [];

    if (fetchedERailClassICertifications?.length > 0) {
      fetchedERailClassICertifications?.map((eRailCertification) =>
        classIERailCertifications.push({ ...eRailCertification.dataValues })
      );
    }

    res.status(200).json({
      data: classIERailCertifications,
    });
  } catch (error) {
    console.log(error);
  }
};

export const getAllContractors = async (req, res) => {
  const { page } = req.query;

  const { limit, offset, current } = pagination(page);

  try {
    let completeContractors = [];
    const contractorsCount = await models.Contractors.count();
    const contractors = await models.Contractors.findAll({
      limit,
      offset,
      paranoid: false,
      order: [["created_at", "DESC"]],
      where: { deleted_at: null },
    });

    for (const contractor of contractors) {
      let additionalAttachmentTypes = await fetchDataFromAttachmentTable(
        contractor?.dataValues?.id
      );

      const addresses = await models.Addresses.findAll({
        where: {
          entity_type: "contractor",
          entity_id: contractor.dataValues.id,
        },
      });

      completeContractors.push({
        ...contractor.toJSON(),
        GenericAttachedDocuments: additionalAttachmentTypes,
        addresses,
      });
    }

    const total = Math.ceil(contractorsCount / limit) || 0;

    res.status(200).json({
      data: completeContractors,
      pagination: {
        page,
        totalPages: total,
        count: contractorsCount,
        currentPage: current > total ? total : current,
      },
    });
  } catch (err) {
    console.log(err);
  }
};

export const editContractor = async (req, res, next) => {
  const {
    id,
    name,
    address,
    city,
    state,
    zipCode,
    country,
    email,
    phone,
    fax,
    contact,
    tier_level,
    addresses,
    haz_waste_hauler,
    license_number,
    license_number_expiry,
    certification_classes,
  } = req.body;

  if (await findContractorsByName(name, id)) {
    res.status(400).json({
      status: 400,
      message: "Contractor with this name already exists.",
    });
    return;
  }

  let additionalAttachmentTypes = await fetchDataFromAttachmentTable(id);

  addresses &&
    addresses.forEach(async (address) => {
      if (address.id) {
        if (!isNonEmptyAddress(address)) {
          await models.Addresses.destroy({ where: { id: address.id } });
        } else {
          await models.Addresses.update(
            {
              address: address.address,
              city: address.city,
              state: address.state,
              zipCode: address.zipCode,
              country: address.country,
              phone: address.phone,
              fax: address.fax,
              contact: address.contact,
              tier_level: address.tier_level,
            },
            {
              where: { id: address.id },
            }
          );
        }
      } else if (isNonEmptyAddress(address)) {
        await models.Addresses.create(address);
      }
    });

  models.Contractors.update(
    {
      name,
      address,
      city,
      state,
      zipCode,
      country,
      email,
      phone,
      fax,
      contact,
      tier_level,
      haz_waste_hauler,
      license_number,
      license_number_expiry,
      certification_classes,
    },
    {
      where: {
        id,
      },
    }
  )
    .then((response) => {
      res.json({
        success: true,
        data: {
          ...req.body,
          addresses: req.body.addresses.length
            ? req.body.addresses.filter((subAddress) =>
              isNonEmptyAddress(subAddress)
            )
            : [],
          GenericAttachedDocuments: additionalAttachmentTypes,
        },
      });
    })
    .catch((err) => next(err));
};

export const getContractorsWithAddress = async (req, res) => {
  try {
    let combinedContractors = [];
    let shouldFetchAttachmentExpiries = (req?.query?.withAttachmentExpiry !== 'false')
    let getAddressQuery = {
      where: {
        entity_type: "contractor",
        tier_level: {
          [Op.ne]: "Do Not Use"
        },
        deleted_at: null,
      },
      ...(shouldFetchAttachmentExpiries && {
        include: [
          {
            model: models.ContractorAttachmentsExpiry,
            where:{ attachment_id:  2},
            required: false,
          },
        ],
        order: [
          [  models.ContractorAttachmentsExpiry, 'updated_at', 'DESC' ],
        ]
      })
    }
    let getContractorQuery = {
      where: {
        deleted_at: null,
        tier_level: {
          [Op.ne]: "Do Not Use"
        },
      },
      ...(shouldFetchAttachmentExpiries && {
      include: [
        {
          model: models.ContractorAttachmentsExpiry,
          where:{ attachment_id:  2},
          required: false,
        },
      ],
      order: [
        [  models.ContractorAttachmentsExpiry, 'updated_at', 'DESC' ],
      ],
    })
    }

    Promise.all([
      models.Addresses.findAll(getAddressQuery),
      models.Contractors.findAll(getContractorQuery),
    ])
      .then(([addresses, contractors]) => {
        if (addresses.length) {
          const contractorsFromAddresses = addresses.map((address) => {
            contractors.map((contractor) => {
              if (address.entity_id === contractor.id) {
                address.dataValues = {
                  ...address.dataValues,
                  name: contractor.dataValues.name,
                  addressId: address.dataValues.id,
                  id: contractor.dataValues.id,
                };
              }
            });
            return address;
          });
          combinedContractors = [...contractors, ...contractorsFromAddresses];

          res.status(200).json({
            data: combinedContractors,
          });
        } else {
          res.status(200).json({
            data: contractors,
          });
        }
      })
      .catch((err) => console.log("error here", err));
  } catch (error) {
    console.log(error);
  }
};

export const contractorCertficates = async function(req, res) {
  try {
    const payload = req.body;
    const userId = req.user.id;
    let finalResponse = [];
    let onlyExpiryUpdate = [];
    for (let key in payload) {
      const [splittedKey, index] = key.split("_");
      finalResponse[index] = {
        ...(finalResponse[index] && finalResponse[index]),
        [splittedKey]: payload[key],
      };
    }
    const allFiles = req.files;
    let contractorID = finalResponse[0].contractorID;

    onlyExpiryUpdate = finalResponse.filter(
      (files) => !files.hasOwnProperty("fileName")
    );

    if (allFiles.length > 0) {
      await addContractorCertficates(finalResponse, allFiles, userId);
    }
    if (onlyExpiryUpdate.length > 0) {
      for (const data of finalResponse) {
        const dataToUpdate = {
          contractor_id: contractorID,
          attachment_id: data?.attachmentTypeId,
          expiry_date: data?.expiryDate ? data?.expiryDate : null,
          user_id: userId,
          disabled: false,
        };
        const options = {
          where: {
            contractor_id: contractorID,
            attachment_id: data?.attachmentTypeId,
          },
        };

        let record = await models.ContractorAttachmentsExpiry.findOne({
          where: options.where,
        });
        if (record) {
          await record.update(dataToUpdate);
        } else {
          await models.ContractorAttachmentsExpiry.create(dataToUpdate);
        }
      }
    }

    let additionalAttachmentTypes = await fetchDataFromAttachmentTable(
      contractorID
    );

    res.status(200).json({
      data: additionalAttachmentTypes,
      contractorID: contractorID,
    });
  } catch (error) {
    console.log("err", error);
    res.status(500).json({
      message:
        "There was an error on the server and the request could not be completed.",
    });
  }
};

export const addContractorCertficates = async (fileData, files, userId) => {
  try {
    let attachments = [];
    let contractorID;
    let prevAttId;
    let attachmentTypeId;
    let expiryDate;
    for (const fileIndex in files) {
      contractorID = fileData[fileIndex].contractorID;
      prevAttId = fileData[fileIndex].prevAttId;
      expiryDate = fileData[fileIndex].expiryDate === 'undefined' ? null :  moment(new Date(fileData[fileIndex].expiryDate))?.format(
        "YYYY-MM-DD HH:mm:ss" 
      ) ;

      attachmentTypeId = fileData[fileIndex].attachmentTypeId;
      const uniqueId = uniqueIdGenerator();
      const data = await uploadFileToS3Bucket(
        files[fileIndex].path,
        `${fileData[fileIndex].contractorID}/admin/${uniqueId}/${
          files[fileIndex].originalname.split("#")[1]
        }`
      );

      attachments.push({
        url_link: data.Location,
        key: data.key || data.Key,
        name: files[fileIndex].originalname.split("#")[1],
        contractor_id: contractorID,
        attachment_type: fileData[fileIndex].attachmentType,
        is_contractors: true,
        is_pes_admin: false,
        attachment_id: attachmentTypeId,
      });
      console.log("path=", files[fileIndex].path);
      if (prevAttId !== "undefined") {
        await models.GenericAttachedDocuments.destroy({
          where: { id: prevAttId },
        });
      }
      const dataToUpdate = {
        contractor_id: contractorID,
        attachment_id: attachmentTypeId,
        expiry_date: expiryDate,
        user_id: userId,
        disabled: false,
      };

      const options = {
        where: {
          contractor_id: contractorID,
          attachment_id: attachmentTypeId,
        },
      };

      models.ContractorAttachmentsExpiry.findOne({
        where: options.where,
      }).then((record) => {
        if (record) {
          record.update(dataToUpdate);
        } else {
          models.ContractorAttachmentsExpiry.create(dataToUpdate);
        }
      });

      fs.unlinkSync(files[fileIndex].path);
    }
    await models.GenericAttachedDocuments.bulkCreate(attachments);
    return contractorID;
  } catch (err) {
    res.status(500).json({
      message:
        "There was an error on the server and the request could not be completed.",
    });
    console.log(err);
  }
};

export const deleteContractorCertficates = async function(req, res) {
  try {
    await models.GenericAttachedDocuments.destroy({
      where: { id: req.body.id },
    });

    const query = `UPDATE contractor_attachments_expiries 
    SET 
        expiry_date = NULL
    WHERE
        contractor_id = ${req.body.contractorId} 
        AND 
        attachment_id = ${req.body.attachmentIdInExpiray}`;
        await  sequelize.query(query)
        res.status(200).json({message: 'success'});
  } catch (error) {
    console.log(error);
  }
};
const findContractorsByName = async (name, id) => {
  const duplicate = await models.Contractors.findOne({
    where: { name: name, id: { $ne: id } },
  });

  return duplicate;
};

export const doNotUseContractor = async function(req, res) {
  try {
    const contractorId = req.body?.contractor_id
    const doNotUse = req.body?.do_not_use

    if(!contractorId) throw new Error("Please provide the contractor ID.");

    if(!(doNotUse === true || doNotUse === false)) throw new Error("Please provide the correct boolean value in the 'do_not_use' parameter.");

    await models.Contractors.update(
      {
        do_not_use: doNotUse,
        tier_level: doNotUse ? TIER_LEVEL.DO_NOT_USE : null
      },
      {
        where: { id: contractorId },
      }
    );

    await models.Addresses.update(
      {
        tier_level: doNotUse ? TIER_LEVEL.DO_NOT_USE : null
      },
      {
        where: { 
          entity_id: contractorId,
          entity_type: "contractor"
      },
      }
    ); 

    return res.status(200).json({
      status: 200,
      success: true,
      message: "The contractor's status has been updated."
    });
  } catch (error) {
    return res.status(400).json({ status: 400, success: false, message: error.message });
  }
};
