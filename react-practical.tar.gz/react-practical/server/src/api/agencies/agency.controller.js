import { Op } from "sequelize";
import models, { sequelize } from "../../models";
import { updateReportingRequirementHistory, createReportingRequirementsHistory } from '../../util/helper';
import pagination from "../../util/pagination";
import { ROLES } from '../../util';

export const createNewAgency = async (req, res, next) => {
  let transaction;
  try {
    const { user } = req;
    const {
      name,
      address,
      city,
      state,
      zipCode,
      country,
      phone,
      fax,
      contact,
      jurisdiction,
      petroleum_release_amount,
      petroleum_release,
      hazardous_material_amount,
      hazardous_material,
      water_impact_amount,
      water_impact,
      soil_impact_amount,
      soil_impact,
      revision_date,
    } = req.body;

    const agencyObj = {
      name,
      address,
      city,
      state,
      zipCode,
      country,
      phone,
      fax,
      contact,
      jurisdiction,
    };

    if (await findAgencyByName(agencyObj.name, -1)) {
      res.status(400).json({
        status: 400,
        message: "Agency with this name already exists.",
      });
      return;
    }

    transaction = await sequelize.transaction();
    let reportingHistory = {};
    let agency = await models.Agencies.create(agencyObj, { transaction });

    if (agency && agency?.id && user?.role?.role === ROLES.SUPER_USER && revision_date) {
      const historyObj = {
        petroleum_release_amount,
        petroleum_release,
        hazardous_material_amount,
        hazardous_material,
        water_impact_amount,
        water_impact,
        soil_impact_amount,
        soil_impact,
        revision_date
      }
      reportingHistory = await createReportingRequirementsHistory(transaction, agency.id, historyObj);
    }
    
    agency = {
      ...agency?.dataValues,
    }
    if (user?.role?.role === ROLES.SUPER_USER) {
      agency = {
        ...agency,
        reportingRequirements: reportingHistory
      }
    }

    await transaction.commit();

    res.status(200).json({
      data: agency,
    });
  } catch (err) {
    if(transaction) {
      await transaction.rollback();
    }
    console.log(err);
    let message;
    switch (err.message) {
      case "Validation error":
        message = "Please fill out all the fields";
        break;

      default:
        message = null;
    }

    res.status(400).json({
      status: 400,
      err,
    });
  }
};

export const getAllAgencies = async (req, res) => {
  const { user } = req;
  const { page } = req.query;
  const { limit, offset, current } = pagination(page);

  try {
    let agencies = [];
    const agenciesCount = await models.Agencies.count();

    if (!isNaN(page)) {
      // agencies = await models.Agencies.findAll({
      //   limit,
      //   offset,
      //   paranoid: false,
      //   order: [["created_at", "DESC"]],
      // });
      const query = `SELECT * FROM  agencies LIMIT ${limit} OFFSET ${offset}`;

      agencies = await sequelize.query(query);
    } else {
      const query = `SELECT * FROM  agencies`;
      agencies = await sequelize.query(query);
    }
    agencies = [...agencies[0]];
    if (user?.role?.role === ROLES.SUPER_USER) {
      for (let index = 0; index < agencies.length; index++) {
        const element = agencies[index];
        const reportingRequirementsHistory = await models.ReportingRequirementsHistory.findOne({
          where: { 
            agency_id: element.id,
            deleted_at: {
              [Op.eq]: null
            }
          },
          order: [["created_at","DESC"]]
        });
        agencies[index].reportingRequirements = reportingRequirementsHistory || {};
      }
    }

    const total = Math.ceil(agenciesCount / limit) || 0;

    res.status(200).json({
      data: agencies || [],
      pagination: {
        page,
        totalPages: total,
        count: agenciesCount,
        currentPage: current > total ? total : current,
      },
    });
  } catch (err) {
    console.log(err);
  }
};

export const editAgency = async (req, res, next) => {
  const { user } = req;
  const {
    id,
    name,
    address,
    city,
    state,
    zipCode,
    country,
    phone,
    fax,
    contact,
    jurisdiction,
  } = req.body;

  if (await findAgencyByName(name, id)) {
    res.status(400).json({
      status: 400,
      message: "Agency with this name already exists.",
    });
    return;
  }
  const transaction = await sequelize.transaction();
  try {
    await models.Agencies.update(
      {
        name,
        address,
        city,
        state,
        zipCode,
        country,
        phone,
        fax,
        contact,
        jurisdiction,
      },
      {
        where: { id },
        transaction
      }
    );

    let reeturnData = {
      ...req.body
    }
    if (user?.role?.role === ROLES.SUPER_USER && req?.body?.revision_date) {
      await updateReportingRequirementHistory(req, transaction);
      reeturnData = {
        ...reeturnData,
        reportingRequirements: {
          petroleum_release_amount: req.body.petroleum_release_amount,
          petroleum_release: req.body.petroleum_release,
          hazardous_material_amount: req.body.hazardous_material_amount,
          hazardous_material: req.body.hazardous_material,
          water_impact_amount: req.body.water_impact_amount,
          water_impact: req.body.water_impact,
          soil_impact_amount: req.body.soil_impact_amount,
          soil_impact: req.body.soil_impact,
          revision_date: req.body.revision_date,
        }
      }
    }
    await transaction.commit();

    res.status(200).json({
      success: true,
      data: reeturnData,
    });
  } catch (error) {
    if(transaction) {
      await transaction.rollback();
    }
    next(error);
  }
};

const findAgencyByName = async (name, id) => {
  const duplicate = await models.Agencies.findOne({
    where: { name: name, id: { $ne: id } },
  });

  return duplicate;
};
