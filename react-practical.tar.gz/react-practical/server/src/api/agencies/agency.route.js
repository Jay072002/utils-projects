import * as agencyController from "./agency.controller";

export default (route) => {
  route.get("/agency/agencies", agencyController.getAllAgencies);
  route.post("/agency/createNew", agencyController.createNewAgency);
  route.post("/agency/editAgency", agencyController.editAgency);
};
