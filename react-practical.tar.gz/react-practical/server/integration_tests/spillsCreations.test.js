const supertest = require("supertest");
const moment = require("moment");

const { server } = require("../src/app");

const models = require("../src/models");
const { padZero } = require("../src/util/padZero");
const { setSystemTime } = require("./utils/setSystemTime");

const createSpill = async ({
  agent,
  userId,
  orgId,
  isTestSpill,
  email,
  today,
}) => {
  const response = await agent
    .post("/api/spill/createNew")
    .send({
      user_id: userId,
      org_id: orgId,
      opened_on: today.toJSON(),
      send_attachment: false,
      users: [
        {
          active: true,
          email,
          is_default: true,
          label: "test",
          value: userId,
        },
      ],
      status: "Open: Work In Progress",
      current_time: JSON.stringify(today),
      is_test_spill: isTestSpill,
      send_email: false,
      is_emergency: false,
    })
    .expect(200);

  return response.body;
};

const testJobNumberCreation = async ({
  start,
  end,
  agent,
  userId,
  orgId,
  email,
  isTestSpill = false,
  isProbPM = false,
}) => {
  const createdSpills = [];
  let monthlySpillCount = 0;
  const orgCode = 234;

  for (
    var today = moment(start);
    today.diff(end, "days") <= 0;
    today.add(1, "day")
  ) {
    setSystemTime(today.toJSON());
    const responseBody = await createSpill({
      agent,
      userId,
      orgId,
      isTestSpill,
      email,
      today,
    });

    monthlySpillCount = monthlySpillCount + 1;

    console.log(responseBody.data.spill.id);
    console.log(responseBody);
    createdSpills.push(responseBody.data.spill.id);

    const TEST_PREFIX = isTestSpill ? "TEST" : "";
    const TEMP_PREFIX = isProbPM ? "TEMP-" : "";

    const paddedCount = padZero(monthlySpillCount, 4);
    const testJobNumber = today.format(`YY-${orgCode}-MM`);

    const testJobNumberWPrefix = `${TEMP_PREFIX}${testJobNumber}${TEST_PREFIX}${paddedCount}`;

    const endOfMonth = moment(today).endOf("month");
    if (today.format("YYYY-MM-DD") === endOfMonth.format("YYYY-MM-DD")) {
      monthlySpillCount = 0;
    }

    expect(responseBody.data.spill.job_no).toBe(testJobNumberWPrefix);
  }
  return createdSpills;
};
const createdSpills = [];

afterAll(async () => {
  if (!createdSpills.length) return;

  console.log("deleting ...", createdSpills);
  await models.sequelize.query(
    `delete from spills where id in (${createdSpills
      .map((id) => `'${id}'`)
      .join(",")})`
  );
});

describe("Spills Creation API Test", () => {
  let agent, userId, orgId, email, pmUserId, pmOrgId, pmEmail, probPmAgent;

  beforeAll(async () => {
    agent = supertest.agent(server);
    const response = await agent
      .post("/api/user/login")
      .send({ email: "hamzarizwan8822@gmail.com", password: "1234" });

    ({
      id: userId,
      email,
      client_organization: { id: orgId },
    } = response.body);

    probPmAgent = supertest.agent(server);
    const responseForPM = await probPmAgent.post("/api/user/login").send({
      email: "ashlianacrabtreetann@savageservices.com",
      password: "1234",
    });

    ({
      id: pmUserId,
      email: pmEmail,
      client_organization: { id: pmOrgId },
    } = responseForPM.body);
    // console.log(response.body);
    console.log({ pmOrgId });
  }, 15000);

  it.skip("should call the SPILLS POST API to create a spill for next month", async () => {
    setSystemTime("2024-01-01");
    const today = new Date();
    console.log({ today });
    const response = await agent.post("/api/spill/createNew").send({
      user_id: userId,
      org_id: orgId,
      opened_on: today.toJSON(),
      send_attachment: false,
      users: [
        {
          active: true,
          email,
          is_default: true,
          label: "test",
          value: userId,
        },
      ],
      status: "Open: Work In Progress",
      current_time: JSON.stringify(today),
      is_test_spill: true,
      send_email: false,
      is_emergency: false,
    });
    // .expect(200);
    console.log(response.body.data.spill.id);
    createdSpills.push(response.body.data.spill.id);
    console.log(response.body);
  }, 15000);

  it.skip("should create a spill at 23:59 of a month end and create a new one at the next month start", async () => {
    setSystemTime("2024-01-27T10:59:00.000Z");
    const today = new Date();
    console.log({ today });
    const response = await agent.post("/api/spill/createNew").send({
      user_id: userId,
      org_id: orgId,
      opened_on: today.toJSON(),
      send_attachment: false,
      users: [
        {
          active: true,
          email,
          is_default: true,
          label: "test",
          value: userId,
        },
      ],
      status: "Open: Work In Progress",
      current_time: JSON.stringify(today),
      is_test_spill: true,
      send_email: false,
      is_emergency: false,
    });
    // .expect(200);
    console.log(response.body.data.spill.id);
    createdSpills.push(response.body.data.spill.id);
    console.log(response.body);

    const response2 = await agent.post("/api/spill/createNew").send({
      user_id: userId,
      org_id: orgId,
      opened_on: today.toJSON(),
      send_attachment: false,
      users: [
        {
          active: true,
          email,
          is_default: true,
          label: "test",
          value: userId,
        },
      ],
      status: "Open: Work In Progress",
      current_time: JSON.stringify(today),
      is_test_spill: true,
      send_email: false,
      is_emergency: false,
    });
    // .expect(200);
    console.log(response2.body.data.spill.id);
    createdSpills.push(response2.body.data.spill.id);
    console.log(response2.body);
  }, 15000);

  it.skip("should create a new one at the next month start", async () => {
    setSystemTime("2024-02-01T00:00:00.000Z");
    const today = new Date();
    console.log({ today });
    const response = await agent.post("/api/spill/createNew").send({
      user_id: userId,
      org_id: orgId,
      opened_on: today.toJSON(),
      send_attachment: false,
      users: [
        {
          active: true,
          email,
          is_default: true,
          label: "test",
          value: userId,
        },
      ],
      status: "Open: Work In Progress",
      current_time: JSON.stringify(today),
      is_test_spill: true,
      send_email: false,
      is_emergency: false,
    });
    // .expect(200);
    console.log(response.body.data.spill.id);
    createdSpills.push(response.body.data.spill.id);
    console.log(response.body);
  }, 15000);

  it.skip("should create (n) spills every month for the next (n) years", async () => {
    var start = moment("2024-01-01T00:00:00.000Z");
    var end = moment("2025-01-02T00:00:00.000Z");

    const createdSpillsIds = await testJobNumberCreation({
      start,
      end,
      agent,
    });
    createdSpills.push([...createdSpillsIds]);
  }, 150000000);

  it.skip("should create (n) TEST spills every month for the next (n) years", async () => {
    var start = moment("2024-01-01T00:00:00.000Z");
    var end = moment("2025-01-02T00:00:00.000Z");

    const testSpills = await testJobNumberCreation({
      start,
      end,
      email,
      agent,
      userId,
      orgId,
      isTestSpill: true,
    });
    createdSpills.push([...testSpills]);
  }, 1500000000);

  it.skip("should create (n) TEMP spills every month for the next (n) years", async () => {
    var start = moment("2024-01-01T00:00:00.000Z");
    var end = moment("2025-01-02T00:00:00.000Z");

    const tempSpills = await testJobNumberCreation({
      start,
      end,
      email: pmEmail,
      agent: probPmAgent,
      isProbPM: true,
      userId: pmUserId,
      orgId: pmOrgId,
    });
    createdSpills.push([...tempSpills]);
  }, 1500000000);

  it("should create a test spill, a temp spill and normal spill, and do the same again for the same day", async () => {
    setSystemTime("2024-01-01T00:00:00.000Z");
    var start = moment("2024-01-01T00:00:00.000Z");
    var end = moment("2024-01-02T00:00:00.000Z");

    const testSpills = await testJobNumberCreation({
      start,
      end,
      email,
      agent,
      userId,
      orgId,
      isTestSpill: true,
    });

    console.log("created test spills");
    const tempSpills = await testJobNumberCreation({
      start,
      end,
      email: pmEmail,
      agent: probPmAgent,
      isProbPM: true,
      userId: pmUserId,
      orgId: pmOrgId,
    });
    console.log("created temp spills");
    const spills = await testJobNumberCreation({
      start,
      end,
      email,
      agent,
      userId,
      orgId,
    });

    createdSpills.push(...tempSpills, ...testSpills, ...spills);
  }, 150000000);
});
