const express = require("express");
const postmark = require("postmark");
const cors = require("cors");

const app = express();

app.use(cors({ origin: "*" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: "25mb" }));

// Set your Postmark API key
const postmarkApiKey = "80bb568c-8bf0-47bd-95cf-2d5518b2556b";
const client = new postmark.ServerClient(postmarkApiKey);

app.post("/send-mail", async (req, res) => {
  try {
    const { from, to, subject, message } = req.body;

    const user_name = to.split("@")[0];

    client
      .sendEmailWithTemplate({
        From: from,
        To: to,
        TemplateAlias: "code-your-own-1",
        TemplateModel: {
          user_name,
          subject,
          content: message,
        },
        replyTo: "25e250188f4b1002ef87330fc7f0703f@inbound.postmarkapp.com",
      })
      .then((response) => {
        console.log("Email sent successfully:", response.To);
        res.status(200).json({ message: "Successfully sent the mail" });
      })
      .catch((error) => {
        console.error("Error sending email:", error);
        res.status(500).json({ message: "Error sending mail", error });
      });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Error sending mail", error });
  }
});

// Handle incoming webhook events from Postmark (inbounce event)
app.post("/incoming-mail", (req, res) => {
  try {
    console.log("Webhook triggered with data:", req.body);
    res.status(200).json({ message: "Webhook event triggered" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Webhook error", error });
  }
});

const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
