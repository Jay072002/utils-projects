import { useState } from "react";
import axios from "axios";

function App() {
  const [formData, setFormData] = useState({
    from: "",
    to: "",
    subject: "",
    message: "",
  });

  console.log(formData, "formdata");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post("http://localhost:5000/send-mail", formData);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div className="container">
        <form onSubmit={handleSubmit}>
          From :{" "}
          <input
            style={{ margin: "10px", padding: "7px 0" }}
            type="text"
            value={formData.from}
            onChange={(e) => setFormData({ ...formData, from: e.target.value })}
          ></input>
          To :{" "}
          <input
            style={{ margin: "10px", padding: "7px 0" }}
            type="text"
            value={formData.to}
            onChange={(e) => setFormData({ ...formData, to: e.target.value })}
          ></input>
          Subject :{" "}
          <input
            type="text"
            style={{ margin: "10px", padding: "7px 0" }}
            value={formData.subject}
            onChange={(e) =>
              setFormData({ ...formData, subject: e.target.value })
            }
          ></input>
          Message :{" "}
          <input
            type="text"
            style={{ margin: "10px", padding: "7px 0" }}
            value={formData.message}
            onChange={(e) =>
              setFormData({ ...formData, message: e.target.value })
            }
          ></input>
          <button type="submit" style={{ padding: "7px", cursor: "pointer" }}>
            SEND MAIL
          </button>
        </form>
      </div>
    </>
  );
}

export default App;
