const express = require("express");
const mailgun = require("mailgun-js");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: "*" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set your Mailgun API key and domain
const mailgunApiKey = "6b41a4eb0b878d1f31ca1397670095b6-3e508ae1-e818ca46"; // Replace with your Mailgun API key
const mailgunDomain = "sandbox5ae968adf4084bacbbba2b25dfc1650a.mailgun.org"; // Replace with your Mailgun domain

const mailgunClient = mailgun({ apiKey: mailgunApiKey, domain: mailgunDomain });

// Create an interactive email template in your Mailgun account and obtain its template name.
const templateName = "mailgun email template"; // Replace with your template name

// Create a mail endpoint
app.post("/send-mail", async (req, res) => {
  try {
    const { to, from, subject, message } = req.body;

    console.log(req.body, "request body");

    // Create an email message with the interactive template
    const emailData = {
      from,
      to,
      subject,
      template: templateName,
      "h:X-Mailgun-Variables": {
        user_name: "Jay", // Example variable
      },
    };

    // Send the interactive email using the Mailgun client
    mailgunClient.messages().send(emailData, (error, body) => {
      if (error) {
        console.error("Error sending email:", error);
        res.status(500).json({ message: "Couldn't send email", error });
      } else {
        res.status(201).json({ message: "Email sent successfully", body });
      }
    });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ message: "Couldn't send email", error });
  }
});

// Handle the email reply
app.post("/reply-email", (req, res) => {
  try {
    console.log("Reply email entry");
    const reply = req.body.reply;

    res.status(200).send("Email reply received and processed.");
  } catch (error) {
    console.error("Error handling email reply:", error);
    res.status(500).send("Internal Server Error");
  }
});

// Create a webhook to receive email replies
app.post("/incoming-email", async (req, res) => {
  try {
    console.log(req.body, "webhook triggered");

    // await saveEmailToDatabase({ recipientEmail, subject, message }, inboxId);

    res.status(200).send("Email reply received and processed.");
  } catch (error) {
    console.error("Error handling incoming email reply:", error);
    res.status(500).send("Internal Server Error");
  }
});

// Save the email reply to the user's inbox in the database
async function saveEmailToDatabase(emailReply, inboxId) {}

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
